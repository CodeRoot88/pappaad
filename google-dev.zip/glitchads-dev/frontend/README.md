# Glitch Ads Frontend

## [Vite](https://vitejs.dev/)
We use Vite as the build too.

* Create a new project using Vite
`
bun create vite frontend
`

This command creates a project in frontend folder interactively. I chose React +
Typescript + SWC.

* I used Bun
Yes, it's a new node run time, it's faster. But it probably doesn't matter, since we
will probably only install the dependencies once in a while .
So npm/pnpm/yarn can be used here too. Whichever you have installed on your system. We
don't do nodejs. so should be the same.

* Chose [Typescript + SWC](https://vitejs.dev/plugins/#vitejs-plugin-react-swc)
Use the new SWC instead of babel.

* Add taildwindcss with vite
https://tailwindcss.com/docs/guides/vite

* @takstack/React-query and @tanstack/react-router
https://tanstack.com

* Why tanstack router
https://tanstack.com/router/latest/docs/framework/react/comparison

* Component libraries
  * https://tailwindui.com/
  * https://catalyst.tailwindui.com
  * https://ui.shadcn.com/

* Frontend structure
  * Entry point `src/main.tsx`
  * Routes powered by tanstack file based router in `src/routes`
  * UI components (Pure components without business logic) in `src/components`
    * Shadcn UI in `ui` folder
	* Tailwind catalyst UI in `catalyst` folder
	* Our own glitch UI components in `gltich-ui` folder
	* Charts based on react charts in `Charts`
  * `src/lib` contains the following
    * http requests using fetch in `src/apis.ts`
	* React query options in `src/query-options`
	* auth related logic in `src/auth.ts`
	* types for most data in `src/types`
	* Base url is consts.ts


## Local dev env set up

* Install dependencies
```
cd frontend
bun i
```
* Run dev server
```
bun dev
```

## Deployment

First, make sure you auth your gcloud cli.

```
gcloud auth login
```

### Staging

First modify the `.env` file
Make sure you have the following:

```
VITE_NODE_ENV=staging
VITE_GOOGLE_ADS_CLIENT_ID=
VITE_SENTRY_DSN=
```

Make sure the values are filled out, if you don't know, ask in #eng slack channel.
Then run:

```
bun run build
```
If builds successfully, you should have a dist folder. Then upload this folder to google
cloud.
```
gcloud storage cp -r dist/* gs://glitch-staging
```

### Production

First modify the `.env` file
Make sure you have the following:

```
VITE_POSTHOG_HOST=
VITE_POSTHOG_API_KEY=
VITE_NODE_ENV=production
VITE_GOOGLE_ADS_CLIENT_ID=
VITE_SENTRY_DSN=
```

Make sure the values are filled out, if you don't know, ask in #eng slack channel.
Then run:

```
bun run build
```
If builds successfully, you should have a dist folder. Then upload this folder to google
cloud.
```
gcloud storage cp -r dist/* gs://glitch-fe-prod
```
