import React from 'react';
import { useNavigate } from '@tanstack/react-router';
import { CogIcon } from '@heroicons/react/24/solid';
import { MembershipRole, MembershipStatus, OrganizationDataWithMembership } from '@/lib/types';
import { useSetAtom } from 'jotai';
import { organizationDataAtom } from '@/store';

interface OrganizationCardProps {
  organization: OrganizationDataWithMembership;
}

const OrganizationCard: React.FC<OrganizationCardProps> = ({ organization }) => {
  const navigate = useNavigate();
  const setOrganizationData = useSetAtom(organizationDataAtom);

  const handleClick = () => {
    setOrganizationData(organization);
    navigate({ to: `/campaigns` });
  };

  const handleSetting = () => {
    navigate({ to: `/organizations/${organization.slug}/setting` });
  };

  const getRoleBadgeStyles = (role: MembershipRole): string => {
    const baseStyles = 'px-2 py-1 rounded-full text-xs font-semibold';
    switch (role) {
      case MembershipRole.OWNER:
        return `${baseStyles} bg-blue-100 text-blue-600`;
      case MembershipRole.ADMIN:
        return `${baseStyles} bg-green-100 text-green-600`;
      case MembershipRole.MEMBER:
        return `${baseStyles} bg-gray-100 text-gray-600`;
      default:
        return baseStyles;
    }
  };

  const getStatusBadgeStyles = (status: MembershipStatus): string => {
    const baseStyles = 'px-2 py-1 rounded-full text-xs font-semibold';

    switch (status) {
      case MembershipStatus.ACTIVE:
        return `${baseStyles} bg-green-100 text-green-600`;
      case MembershipStatus.PENDING:
        return `${baseStyles} bg-yellow-100 text-yellow-600`;
      case MembershipStatus.DISABLED:
        return `${baseStyles} bg-red-100 text-red-600`;
      default:
        return baseStyles;
    }
  };

  return (
    <div
      className={`border rounded-md shadow-md h-40 p-4 flex flex-col items-center relative cursor-pointer ${organization.membership.status === MembershipStatus.DISABLED ? 'opacity-50 cursor-not-allowed' : ''}`}
      onClick={organization.membership.status !== MembershipStatus.DISABLED ? handleClick : undefined}
    >
      <div className='absolute top-2 right-2'>
        <CogIcon
          className='h-5 w-5 text-gray-500'
          aria-hidden='true'
          onClick={(e) => {
            e.stopPropagation();
            organization.membership.status !== MembershipStatus.DISABLED ? handleSetting() : undefined;
          }}
        />
      </div>

      <span className={`${getRoleBadgeStyles(organization.membership.role)} absolute top-2 left-2`}>
        {organization.membership.role.toUpperCase()}
      </span>

      <div className='bg-purple-100 rounded-full w-12 h-12 mt-4 flex items-center justify-center text-purple-600 text-xl font-bold'>
        {organization.name[0].toUpperCase()}
      </div>

      <h3 className='text-lg font-semibold mt-2'>{organization.name}</h3>

      <span className={`${getStatusBadgeStyles(organization.membership.status)} absolute bottom-2`}>
        {organization.membership.status.toUpperCase()}
      </span>
    </div>
  );
};

export default OrganizationCard;
