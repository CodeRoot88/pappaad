import React from 'react';
import { useNavigate } from '@tanstack/react-router';

const AddNewCard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div
      className='border rounded-md shadow-md p-4 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50'
      onClick={() => navigate({ to: '/organizations/new' })}
    >
      <div className='flex items-center justify-center text-gray-400 text-3xl w-12 h-12 border-2 border-dashed border-gray-300 rounded-full'>
        +
      </div>
    </div>
  );
};

export default AddNewCard;
