import { useState } from 'react';
import Modal from 'react-modal';
import { useAtomValue } from 'jotai';
import { fetchOrganizationDataAtom, organizationDataAtom } from '@/store';
import MemberTable from './MemberTable';

import { useSendInvitationToUserMutation } from '@/lib/query-options';
interface UserFormState {
  name: string;
  email: string;
  role: string;
}

// Modal styles (customize as needed)
const customModalStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    borderRadius: '8px',
    width: '100%',
    maxWidth: '400px',
    padding: '20px',
  },
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
};

// Main Members Component
const Members: React.FC = () => {
  const organization = useAtomValue(organizationDataAtom);
  const fetchOrganization = useAtomValue(fetchOrganizationDataAtom);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formState, setFormState] = useState<UserFormState>({
    name: 'peter',
    email: 'peter+1@glitchads.ai',
    role: 'admin',
  });

  const sendInvitationToUserMutation = useSendInvitationToUserMutation();
  const handleInputChange = (field: keyof UserFormState, value: string) => {
    setFormState((prevState) => ({ ...prevState, [field]: value }));
  };

  const handleAddUser = async () => {
    if (formState.name && formState.email && formState.role) {
      console.log('New User Added:', formState);
      try {
        await sendInvitationToUserMutation.mutateAsync({ ...formState, organizationId: organization?.id ?? -1 });
        if (fetchOrganization) fetchOrganization();
      } catch (err) {
        console.error(err);
      }

      setFormState({ name: '', email: '', role: '' });
      setIsModalOpen(false);
    } else {
      alert('All fields are required.');
    }
  };

  return (
    <div className='bg-white p-6 rounded-md shadow'>
      <div className='flex justify-between items-center mb-4'>
        <h2 className='text-lg font-medium text-gray-900'>Team</h2>
        <button
          className='px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700'
          onClick={() => setIsModalOpen(true)}
        >
          + Add User
        </button>
      </div>
      {organization && organization?.users && organization.users.length > 0 ? (
        <MemberTable members = {organization.users}/>
      ) : (
        <p>No members found.</p>
      )}

      <Modal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        style={customModalStyles}
        ariaHideApp={false}
      >
        <div className='flex justify-between items-center mb-4'>
          <h2 className='text-lg font-medium'>Add User</h2>
          <button
            onClick={() => setIsModalOpen(false)}
            className='text-gray-500 hover:text-gray-700 focus:outline-none'
          >
            &times;
          </button>
        </div>

        {/* Modal Form */}
        <div className='space-y-4'>
          <div>
            <label htmlFor='name' className='block text-sm font-medium text-gray-700'>
              Name
            </label>
            <input
              id='name'
              type='text'
              value={formState.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              className='mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm'
              placeholder='Last Name'
            />
          </div>

          <div>
            <label htmlFor='email' className='block text-sm font-medium text-gray-700'>
              Email
            </label>
            <input
              id='email'
              type='email'
              value={formState.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className='mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm'
              placeholder='Email'
            />
          </div>

          <div>
            <label htmlFor='role' className='block text-sm font-medium text-gray-700'>
              Role
            </label>
            <select
              id='role'
              value={formState.role}
              onChange={(e) => handleInputChange('role', e.target.value)}
              className='mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm'
            >
              <option value='admin'>Select Role</option>
              <option value='admin'>ADMIN</option>
              <option value='member'>MEMBER</option>
            </select>
          </div>
        </div>

        <div className='flex justify-end mt-6 space-x-2'>
          <button
            onClick={() => setIsModalOpen(false)}
            className='px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 focus:outline-none'
          >
            Cancel
          </button>
          <button
            onClick={handleAddUser}
            className='px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none'
          >
            Add User
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default Members;
