import { MembershipRole, MembershipStatus, UserAccountWithMembership } from '@/lib/types';

interface MemberTableProps {
  members: UserAccountWithMembership[];
}
const MemberTable = ({ members }: MemberTableProps) => {

  return (
    <div className='overflow-auto'>
      <table className='min-w-full border-collapse border border-gray-300'>
        <thead className='bg-gray-50'>
          <tr>
            <th scope='col' className='px-4 py-2 text-left text-sm font-medium text-gray-700'>
              Name
            </th>
            <th scope='col' className='px-4 py-2 text-left text-sm font-medium text-gray-700'>
              Email
            </th>
            <th scope='col' className='px-4 py-2 text-left text-sm font-medium text-gray-700'>
              Role
            </th>
            <th scope='col' className='px-4 py-2 text-left text-sm font-medium text-gray-700'>
              Status
            </th>
          </tr>
        </thead>
        <tbody>
          {members.map(({name, email, membership}, index) => (
            <tr key={`member-table-${index}`}>
              <td className='px-4 py-2 text-sm text-gray-700'>{name}</td>
              <td className='px-4 py-2 text-sm text-gray-700'>{email}</td>
              <td className='px-4 py-2 text-sm text-gray-700'>
                <span
                  className={`px-2 py-1 rounded-md text-xs font-medium ${
                    membership.role === MembershipRole.OWNER ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {membership.role}
                </span>
              </td>
              <td className='px-4 py-2 text-sm text-gray-700'>
                <span
                  className={`px-2 py-1 rounded-md text-xs font-medium ${
                    membership.status === MembershipStatus.ACTIVE ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {membership.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MemberTable;
