import { usePostHog } from 'posthog-js/react';
import { useForm } from '@tanstack/react-form';
import { zodValidator } from '@tanstack/zod-form-adapter';

import { FieldGroup, Fieldset } from '@/components/catalyst/fieldset';
import { OrganizationDataWithUsersMembership } from '@/lib/types';
import { useToast } from '@/components/ui/use-toast';
import { OrganizationNameField } from '@/form-fields/setup/organization-name';
import { useOrganizationMutationOptions } from '@/lib/query-options';

type generalProps = {
  organization: OrganizationDataWithUsersMembership;
};

export default function GeneralSettings({ organization }: generalProps) {
  const posthog = usePostHog();
  const { toast } = useToast();
  const updateOrganizationMutation = useOrganizationMutationOptions();

  const form = useForm({
    defaultValues: {
      name: organization.name,
    },

    onSubmit: async (form) => {
      if (!form.value.name.trim()) {
        toast({
          description: 'Organization Name is required.',
          variant: 'destructive',
        });
        return;
      }
      try {
        await updateOrganizationMutation.mutateAsync({
          ...organization,
          name: form.value.name,
        });

        posthog?.capture('organization_updated', {
          organizationSlug: organization.slug,
          organizationName: organization.name,
        });
        toast({ description: 'Organization is successfully updated.' });
      } catch (err) {
        toast({
          description: 'Failed to update organization. Please try again.',
          variant: 'destructive',
        });
      }
    },
    validatorAdapter: zodValidator(),
  });

  const handleFieldChange = <T,>(fieldName: string, value: T) => {
    posthog?.capture('field_changed', { fieldName, value });
  };

  return (
    <div className='max-w p-4 bg-white shadow rounded-lg'>
      <h2 className='text-lg font-semibold mb-4'>General Settings</h2>

      <div className='mb-4'>
        <form
          className='space-y-6'
          onSubmit={(e) => {
            e.preventDefault();
            form.handleSubmit();
          }}
        >
          <Fieldset>
            <FieldGroup>
              <div className='-space-y-px rounded-md shadow-sm'>
                <form.Field name='name'>
                  {(field) => (
                    <OrganizationNameField field={field} onFieldChange={(value) => handleFieldChange('name', value)} />
                  )}
                </form.Field>
              </div>

              <div className='flex justify-end space-x-4 mt-6'>
                <button
                  type='submit'
                  className='px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'
                >
                  Update
                </button>
              </div>
            </FieldGroup>
          </Fieldset>
        </form>
      </div>
    </div>
  );
}
