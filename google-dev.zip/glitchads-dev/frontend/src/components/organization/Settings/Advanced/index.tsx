import { useState } from 'react';
import Modal from 'react-modal';
import { usePostHog } from 'posthog-js/react';
import { useToast } from '@/components/ui/use-toast';
import { OrganizationDataWithUsersMembership } from '@/lib/types';
import { useOrganizationDeleteMutationOptions } from '@/lib/query-options';
import { useNavigate } from '@tanstack/react-router';

const customModalStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    borderRadius: '8px',
    width: '100%',
    maxWidth: '400px',
    padding: '20px',
  },
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
};

export default function Advanced({ organization }: { organization: OrganizationDataWithUsersMembership }) {
  const posthog = usePostHog();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();

  const organizationDeleteMutation = useOrganizationDeleteMutationOptions(organization.id);

  const handleDelete = async () => {
    try {
      await organizationDeleteMutation.mutateAsync();
      setIsModalOpen(false);
      posthog?.capture('organization_deleted', {
        organizationSlug: organization.slug,
        organizationName: organization.name,
      });
      toast({ description: 'Organization is successfully deleted.' });
      navigate({ to: '/organizations' });
    } catch (error) {
      toast({ description: 'Failed to delete organization', variant: 'destructive' });
    }
  };

  return (
    <div className='bg-white p-6 rounded-md shadow'>
      <h2 className='text-lg font-medium text-gray-900 mb-4'>Delete Organization</h2>
      <p className='text-sm text-gray-700 mb-4'>Are you sure to delete organization?</p>
      <button
        className='px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-700 cursor-pointer focus:outline-none'
        onClick={() => setIsModalOpen(true)}
      >
        Delete Organization
      </button>
      <Modal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        style={customModalStyles}
        ariaHideApp={false}
      >
        <h3 className='text-lg font-medium text-gray-900 mb-4'>Confirm Delete</h3>
        <p className='text-sm text-gray-700 mb-6'>Are you sure you want to delete this organization?</p>
        <div className='flex justify-end gap-4'>
          <button
            className='px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 focus:outline-none'
            onClick={() => setIsModalOpen(false)}
          >
            Cancel
          </button>
          <button
            className='px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-700 focus:outline-none'
            onClick={handleDelete}
          >
            Confirm
          </button>
        </div>
      </Modal>
    </div>
  );
}
