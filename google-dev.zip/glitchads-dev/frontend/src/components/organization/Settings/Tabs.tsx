import { Tab, TabGroup, TabList, TabPanels, TabPanel } from '@headlessui/react';
import GeneralSettings from './General';
import Member from './Members';
import Advanced from './Advanced';
import { OrganizationDataWithUsersMembership } from '@/lib/types';

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}

type tabProps = {
  organization: OrganizationDataWithUsersMembership;
};

export default function Tabs({ organization }: tabProps) {
  const tabs = ['General', 'Members', 'Advanced'];

  return (
    <TabGroup>
      <TabList className='flex space-x-6 border-b border-gray-200 mb-6'>
        {tabs.map((tab) => (
          <Tab
            key={tab}
            className={({ selected }) =>
              classNames(
                'px-4 py-2 text-sm font-medium',
                selected ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700',
              )
            }
          >
            {tab}
          </Tab>
        ))}
      </TabList>
      <TabPanels>
        <TabPanel>
          <GeneralSettings organization={organization} />
        </TabPanel>
        <TabPanel>
          <Member />
        </TabPanel>
        <TabPanel>
          <Advanced organization={organization} />
        </TabPanel>
      </TabPanels>
    </TabGroup>
  );
}
