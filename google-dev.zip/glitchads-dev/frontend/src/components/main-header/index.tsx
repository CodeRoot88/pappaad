import { Fragment } from 'react';

import {
  Disclosure,
  DisclosureButton,
  DisclosurePanel,
  Transition,
  Menu,
  MenuButton,
  MenuItems,
  MenuItem,
} from '@headlessui/react';
import clsx from 'clsx';
import { Bars3Icon, BellIcon, XMarkIcon } from '@heroicons/react/24/outline';
import logo from '/logo_lightbg.svg';
import { Badge } from '@/components/catalyst/badge';
import { Link, useNavigate } from '@tanstack/react-router';
import { GoogleAdsAccountSelect } from './google-ad-account-select';
import { deleteAccessTokenCookie } from '@/lib/auth';
import { useUserProfile } from '@/contexts/user.context';
import { navigation, userNavigation } from './constants';
import { UserRole } from '@/lib/types';
import { useQueryClient } from '@tanstack/react-query';

const MainHeader = () => {
  const { user } = useUserProfile();
  const queryClient = useQueryClient();
  const { email, picture, name, role, impersonating_email } = user;
  const filteredNavigation = userNavigation.filter(({ allowedRoles, impersonate }) => {
    const roleMatch = allowedRoles.includes(role || UserRole.USER);
    const impersonationMatch = impersonate ? role === UserRole.ADMIN && !!impersonating_email : true;
    return roleMatch && impersonationMatch;
  });

  const navigate = useNavigate({ from: '/' });

  const logout = () => {
    deleteAccessTokenCookie();
    queryClient.invalidateQueries();
    navigate({ to: '/login', replace: true });
  };

  return (
    <Disclosure as='nav' className='border-b border-gray-200 bg-white'>
      {({ open }) => (
        <>
          <div className='mx-auto px-4 sm:px-6 lg:px-8'>
            <div className='flex h-16 justify-between'>
              <div className='flex'>
                <div className='flex flex-shrink-0 items-center mr-12'>
                  <img className='block h-8 w-auto lg:hidden' src={logo} alt='Your Company' />
                  <img className='hidden h-8 w-auto lg:block' src={logo} alt='Your Company' />
                </div>
                <div className='hidden sm:-my-px sm:ml-6 sm:flex sm:space-x-8'>
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={clsx(
                        'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700',
                        'inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium',
                      )}
                      aria-current={undefined}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>
              <div className='flex items-center justify-end gap-2'>
                {impersonating_email && (
                  <Badge
                    color='red'
                    className='!px-2 !py-1.5 !text-sm'
                  >{`Danger: Impersonating user: ${impersonating_email}`}</Badge>
                )}
                <div>
                  <GoogleAdsAccountSelect />
                </div>
                <div className='hidden sm:ml-6 sm:flex sm:items-center'>
                  {/* Profile dropdown */}
                  <Menu as='div' className='relative ml-3'>
                    <div>
                      <MenuButton className='relative flex max-w-xs items-center rounded-full bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'>
                        <span className='absolute -inset-1.5' />
                        <span className='sr-only'>Open user menu</span>
                        <img
                          className='h-8 w-8 rounded-full'
                          src={picture}
                          alt='profile picture'
                          referrerPolicy='no-referrer'
                        />
                      </MenuButton>
                    </div>
                    <Transition
                      as={Fragment}
                      enter='transition ease-out duration-200'
                      enterFrom='transform opacity-0 scale-95'
                      enterTo='transform opacity-100 scale-100'
                      leave='transition ease-in duration-75'
                      leaveFrom='transform opacity-100 scale-100'
                      leaveTo='transform opacity-0 scale-95'
                    >
                      <MenuItems className='absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none'>
                        {filteredNavigation.map((item) => (
                          <MenuItem key={item.name}>
                            {({ focus }) => {
                              if (item.name === 'Sign out') {
                                return (
                                  <button
                                    onClick={logout}
                                    className={clsx(
                                      focus ? 'bg-gray-100' : '',
                                      'block px-4 py-2 text-sm text-gray-700 w-full text-left',
                                    )}
                                  >
                                    {item.name}
                                  </button>
                                );
                              }
                              return (
                                <Link
                                  to={item.href}
                                  className={clsx(focus ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                  state={{ impersonate: { action: item.name.startsWith('Logout') ? 'logout' : '' } }}
                                >
                                  {item.name}
                                </Link>
                              );
                            }}
                          </MenuItem>
                        ))}
                      </MenuItems>
                    </Transition>
                  </Menu>
                </div>
              </div>
              <div className='-mr-2 flex items-center sm:hidden'>
                {/* Mobile menu button */}
                <DisclosureButton className='relative inline-flex items-center justify-center rounded-md bg-white p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'>
                  <span className='absolute -inset-0.5' />
                  <span className='sr-only'>Open main menu</span>
                  {open ? (
                    <XMarkIcon className='block h-6 w-6' aria-hidden='true' />
                  ) : (
                    <Bars3Icon className='block h-6 w-6' aria-hidden='true' />
                  )}
                </DisclosureButton>
              </div>
            </div>
          </div>

          <DisclosurePanel className='sm:hidden'>
            <div className='space-y-1 pb-3 pt-2'>
              {navigation.map((item) => (
                <DisclosureButton
                  key={item.name}
                  as='a'
                  href={item.href}
                  className={clsx(
                    'border-transparent text-gray-600 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-800',
                    'block border-l-4 py-2 pl-3 pr-4 text-base font-medium',
                  )}
                >
                  {item.name}
                </DisclosureButton>
              ))}
            </div>
            <div className='border-t border-gray-200 pb-3 pt-4'>
              <div className='flex items-center px-4'>
                <div className='flex-shrink-0'>
                  <img
                    className='h-10 w-10 rounded-full'
                    src={picture}
                    alt='profile picture'
                    referrerPolicy='no-referrer'
                  />
                </div>
                <div className='ml-3'>
                  <div className='text-base font-medium text-gray-800'>{name}</div>
                  <div className='text-sm font-medium text-gray-500'>{email}</div>
                </div>
                <button
                  type='button'
                  className='relative ml-auto flex-shrink-0 rounded-full bg-white p-1 text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'
                >
                  <span className='absolute -inset-1.5' />
                  <span className='sr-only'>View notifications</span>
                  <BellIcon className='h-6 w-6' aria-hidden='true' />
                </button>
              </div>
              <div className='mt-3 space-y-1'>
                {userNavigation.map((item) => {
                  if (item.name === 'Sign out') {
                    return (
                      <DisclosureButton
                        key={item.name}
                        onClick={logout}
                        className='block px-4 py-2 text-base font-medium text-gray-500 hover:bg-gray-100 hover:text-gray-800'
                      >
                        {item.name}
                      </DisclosureButton>
                    );
                  }
                  return (
                    <DisclosureButton
                      key={item.name}
                      as='a'
                      href={item.href}
                      className='block px-4 py-2 text-base font-medium text-gray-500 hover:bg-gray-100 hover:text-gray-800'
                    >
                      {item.name}
                    </DisclosureButton>
                  );
                })}
              </div>
            </div>
          </DisclosurePanel>
        </>
      )}
    </Disclosure>
  );
};

export default MainHeader;
