import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';

import { useSetAtom } from 'jotai';

import { googleAdsCustomerIdAtom } from '@/store';

import { Listbox, ListboxOption, ListboxLabel } from '@/components/catalyst/listbox';
import { googleAdsAccountsQueryOptions, useSetGoogleAdsCustomerIdMutationOptions } from '@/lib/query-options';
import { useToast } from '@/components/ui/use-toast';
import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { useUserProfile } from '@/contexts/user.context';

export function GoogleAdsAccountSelect() {
  const currentLocation = useLocation();
  const { toast } = useToast();
  const navigate = useNavigate({ from: '/' });
  const { isLoading, data: accounts = [] } = useSuspenseQuery(googleAdsAccountsQueryOptions());
  const { user } = useUserProfile();

  useLoadingOverlay(isLoading);

  const googleAdsCustomerMutation = useSetGoogleAdsCustomerIdMutationOptions();
  const setGoogleAdsCustomerId = useSetAtom(googleAdsCustomerIdAtom);
  const [selectedAccount, setSelectedAccount] = useState<number | null>(null);

  useEffect(() => {
    if (accounts.length > 0) {
      let selected = accounts.filter((account) => account.selected);
      if (selected.length > 0) {
        setSelectedAccount(selected[0].googleads_account_id);
        setGoogleAdsCustomerId(selected[0].googleads_account_id);
      }
    } else {
      if (user && user.email) {
        toast({
          title: 'No Google Ads Account',
          description: `${user.email} does not have a Google Ads account associated with it.`,
        });
      } else {
        toast({
          title: 'No Google Ads Account',
          description: 'Your account does not have a Google Ads account associated with it.',
        });
      }
    }
  }, [accounts, user, toast]);

  useEffect(() => {
    if (accounts.length > 0) {
      let selected = accounts.filter((account) => account.selected);
      if (selected.length === 0) {
        navigate({ to: '/' });
      } else {
        setSelectedAccount(selected[0].googleads_account_id);
        setGoogleAdsCustomerId(selected[0].googleads_account_id);
        navigate({ to: '/campaigns' });
      }
    } else {
      toast({
        title: 'No accounts',
        description: (
          <>
            Sign Up at{' '}
            <a href='https://ads.google.com' target='_blank' rel='noopener noreferrer' style={{ color: '#0000EE' }}>
              Google
            </a>{' '}
            or Email: team@glitchads.ai
          </>
        ),
      });
    }
  }, [accounts]);

  const handleChange = async (value: number) => {
    setSelectedAccount(value);
    setGoogleAdsCustomerId(value);
    let res = await googleAdsCustomerMutation.mutateAsync({ adsCustomerId: value });
    if (res) {
      if (currentLocation.pathname === '/') {
        location.reload();
      } else {
        navigate({ to: '/' });
      }
    }
  };

  if (!accounts) {
    return null;
  }

  if (!selectedAccount) {
    return null;
  }

  return (
    <Listbox className='w-full' value={selectedAccount || accounts?.[0].googleads_account_id} onChange={handleChange}>
      {accounts.map((account) => (
        <ListboxOption key={account.googleads_account_id} value={account.googleads_account_id}>
          <ListboxLabel>
            {account.name} - {account.googleads_account_id}
          </ListboxLabel>
        </ListboxOption>
      ))}
    </Listbox>
  );
}
