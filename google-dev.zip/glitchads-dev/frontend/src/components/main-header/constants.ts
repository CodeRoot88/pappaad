import { UserRole } from '@/lib/types';

export const navigation = [{ name: 'Campaigns', href: '/campaigns/' }];
export const userNavigation = [
  { name: 'Your Profile', href: '/profile', allowedRoles: [UserRole.ADMIN, UserRole.USER] },
  { name: 'Sign out', href: '#', allowedRoles: [UserRole.ADMIN, UserRole.USER] },
  { name: 'Organizations', href: '/organizations', allowedRoles: [UserRole.ADMIN] },
  { name: 'Impersonate', href: '/impersonate', allowedRoles: [UserRole.ADMIN] },
  { name: 'Logout as Impersonator', href: '/impersonate', allowedRoles: [UserRole.ADMIN], impersonate: true },
  { name: 'Ad Accounts', href: '/providers', allowedRoles: [UserRole.ADMIN] },
];
