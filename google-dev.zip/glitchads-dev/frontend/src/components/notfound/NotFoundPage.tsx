import { Link } from '@tanstack/react-router';
import { Helmet } from 'react-helmet';

export function NotFoundPage() {
  return (
    <>
      <Helmet>
        <title>404 - Page Not Found</title>
        <meta name="description" content="The requested page could not be found" />
      </Helmet>
      <main 
        className="flex h-screen flex-col items-center justify-center"
        role="main"
        aria-labelledby="error-title"
      >
        <h1 
          id="error-title"
          className="text-4xl font-bold"
        >
          404
        </h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Page not found
        </p>
        <Link 
          to="/" 
          className="mt-4 text-primary hover:underline"
          aria-label="Return to home page"
        >
          Go back home
        </Link>
      </main>
    </>
  );
}
