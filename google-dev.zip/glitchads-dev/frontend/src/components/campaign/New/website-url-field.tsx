import { BaseField } from '@/form-fields/styled-base-form-field';
import { Input } from '@/components/catalyst/input';
import { FieldPropsType } from '@/form-fields/field-type';

export function WebsiteUrlField({ field, error, disabled, onChange }: { field: FieldPropsType; error?: string; disabled: boolean, onChange: (value: string) => void }) {
	const { name, state, handleChange, handleBlur } = field;
	const label = 'Choose what landing page you would like the ad to go to';
	const description = 'What website address would you like users to visit?';

	return (
		<BaseField label={label} description={description} htmlFor={name} errors={state.meta.touchedErrors}>
			<div className='flex my-3'>
				<span className='inline-flex items-center rounded-l-md border border-r-0 border-gray-300 px-3 text-gray-500 sm:text-sm bg-gray-100'>
					https://
				</span>
				<Input
					name={name}
					defaultValue={state.value}
					onChange={(e) => {
						if (e.target.value.startsWith("https://")) {
							e.target.value = e.target.value.slice(8)
						}
						if (/\/+$/.test(e.target.value) && (!e.target.value.startsWith("https:") && !e.target.value.startsWith("https:/"))) {
							e.target.value = e.target.value.replace(/\/+$/, '');
						}
						handleChange(`https://${e.target.value}`);
						onChange(`https://${e.target.value}`);
					}}
					onBlur={handleBlur}
					placeholder='mysite.com'
					disabled={disabled}
				/>
			</div>
			{error && <p className='text-base/6 text-red-600 data-[disabled]:opacity-50 sm:text-sm/6 dark:text-red-500'>{error}</p>}
		</BaseField>
	);
}