import {
  BanknotesIcon,
  PresentationChartLineIcon,
  // CursorArrowRippleIcon,
  // TvIcon
} from '@heroicons/react/24/solid';

export type GoalType = {
  name: string;
  value: 'prospecting' | 'focused' | 'specific' | 'engagement';
  description: string;
  icon: React.ReactNode;
};

export const goals: GoalType[] = [
  {
    name: 'Prospecting',
    value: 'prospecting',
    description: 'Find your Audience by using multiple pages from your site.',
    icon: <BanknotesIcon className='size-6 text-blue-500' />,
  },
  {
    name: 'Focused',
    value: 'focused',
    description: 'Create a campaign of five Ads focused on a single page. ',
    icon: <PresentationChartLineIcon className='size-6 text-blue-500' />,
  },
  // {
  //     name: 'Specific',
  //     value: 'specific',
  //     description: 'Give a quick description of your goal',
  //     icon: <CursorArrowRippleIcon className='size-6 text-blue-500' />,
  // },
  // {
  //     name: 'Engagement',
  //     value: 'engagement',
  //     description: 'Get more views and engagement on Youtube',
  //     icon: <TvIcon className='size-6 text-blue-500' />,
  // },
];
