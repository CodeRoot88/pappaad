import { Textarea } from '@/components/catalyst/textarea';
import { FieldPropsType } from '@/form-fields/field-type';

export const BusinessInfoField = ({ field }: { field: FieldPropsType }) => {
  const { name, state, handleChange, handleBlur } = field;

  return (
    <>
      <p className='text-sm leading-2 text-gray-500'>Our AI's focus for this Campaign</p>
      <Textarea
        name={name}
        className='h-40'
        resizable={false}
        defaultValue={state.value}
        onChange={(e) => {
          handleChange(e.target.value);
        }}
        onBlur={handleBlur}
      />
    </>
  );
};
