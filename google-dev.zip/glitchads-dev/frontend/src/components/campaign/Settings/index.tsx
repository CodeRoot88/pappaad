import { Link } from '@tanstack/react-router';
import { usePostHog } from 'posthog-js/react';
import { useForm } from '@tanstack/react-form';
import { zodValidator } from '@tanstack/zod-form-adapter';
import { useQueryClient } from '@tanstack/react-query';
import { LinkIcon } from '@heroicons/react/24/outline';
import clsx from 'clsx';
import { z } from 'zod';

import { Button } from '@/components/catalyst/button';
import { Field, FieldGroup, Fieldset } from '@/components/catalyst/fieldset';
import { CampaignNameField } from '@/form-fields/setup/campaign-name';
import { LocationTargetingSelectField } from '@/form-fields/setup/location-targeting';
import { BusinessInfoField } from '@/form-fields/setup/business-description';
import { PhoneNumberField } from '@/form-fields/setup/phone-number';
import { TCPAField } from '@/form-fields/tcpa';
import { useToast } from '@/components/ui/use-toast';

import { useTcpaRegenerateMutation } from '@/lib/query-options';

import { ACTION_STATE, APPROVAL_STATE, CampaignData, CampaignUpdate } from '@/lib/types';
import { useCampaignMutationOptions } from '@/lib/query-options';
import { getGoogleAdsCampaignLink } from '@/lib/utils';
import { TCPAExplanationField } from '@/form-fields/setup/tcpa-explanation';
import { Title } from '@radix-ui/react-toast';
import { useAtomValue } from 'jotai';
import { campaignTaskTrackingAtom } from '@/store';
import { useEffect } from 'react';
import { TextSpinner } from '@/components/ui/text-spinner';

type SettingsProps = { campaign: CampaignData; refetchCampaign: () => void };

export function CampaignSettings({ campaign, refetchCampaign }: SettingsProps) {
  const posthog = usePostHog();
  const queryClient = useQueryClient();
  const campaignSettingsMutation = useCampaignMutationOptions();

  const { toast } = useToast();

  const campaignTaskTracking = useAtomValue(campaignTaskTrackingAtom);

  const tcpaGeneration = campaignTaskTracking?.tcpa_generation;

  const form = useForm({
    defaultValues: {
      websiteUrl: campaign.website_url,
      business_desc: campaign.business_desc,
      campaignName: campaign.name,
      locationTargeting: campaign.target_locations,
      phoneNumber: campaign.phone_numbers[0]?.value || '',
      target_cpa: campaign.target_cpa,
      target_cpa_explanation: campaign.target_cpa_explanation,
    },

    onSubmit: async (form) => {
      const newCampaign = {
        ...campaign,
        website_url: form.value.websiteUrl,
        business_desc: form.value.business_desc,
        name: form.value.campaignName,
        target_cpa: form.value.target_cpa,
        target_cpa_explanation: form.value.target_cpa_explanation,
        target_locations: form.value.locationTargeting,
        phone_numbers: [form.value.phoneNumber],
      };
      updateCampaignSettings(newCampaign, ACTION_STATE.UPDATED);
    },

    validatorAdapter: zodValidator(),
  });

  const { setFieldValue } = form;

  useEffect(() => {
    if (tcpaGeneration && refetchCampaign) {
      refetchCampaign();
    }
  }, [tcpaGeneration, refetchCampaign]);

  useEffect(() => {
    setFieldValue('target_cpa_explanation', campaign?.target_cpa_explanation ?? '');
  }, [campaign.target_cpa_explanation]);

  const updateCampaignSettings = async (newCampaign: CampaignUpdate, state: ACTION_STATE) => {
    let res = await campaignSettingsMutation.mutateAsync(newCampaign);
    if (res) {
      queryClient.invalidateQueries({ queryKey: ['campaigns', 'update'] });
      if (refetchCampaign) {
        refetchCampaign();
      }
      toast({ description: `Settings ${state} 🎉` });
      posthog?.capture(`settings_${state}`, {
        campaignId: campaign.id,
      });
    }
  };

  const {
    websiteUrl,
    business_desc,
    campaignName,
    target_cpa,
    target_cpa_explanation,
    locationTargeting,
    phoneNumber,
  } = form.useStore((state) => state.values);

  const handleApproveSettings = () => {
    let newCampaign: CampaignUpdate = {
      ...campaign,
      website_url: websiteUrl,
      business_desc: business_desc,
      name: campaignName,
      target_cpa,
      target_cpa_explanation,
      target_locations: locationTargeting,
      phone_numbers: [phoneNumber],
      settings_state: APPROVAL_STATE.APPROVED,
    };
    updateCampaignSettings(newCampaign, ACTION_STATE.APPROVED);
  };

  const handleFieldChange = <T,>(fieldName: string, value: T) => {
    posthog?.capture('field_changed', { fieldName, value });
  };

  const tcpaRegenerateMutation = useTcpaRegenerateMutation();

  const regenerateTcpa = () => {
    tcpaRegenerateMutation.mutate(campaign.id);
  };

  const googleAdsCampaignLink = getGoogleAdsCampaignLink(campaign);
  return (
    <>
      <div className='relative min-h-screen'>
        {campaign.settings_state === 'draft' && (
          <Button onClick={handleApproveSettings} color='green' className='mb-8'>
            Approve Settings
          </Button>
        )}
        {googleAdsCampaignLink && (
          <Link
            to={googleAdsCampaignLink}
            className='mb-4 inline-flex items-center text-indigo-600 hover:text-indigo-800'
            target='_blank'
            rel='noopener noreferrer'
          >
            <LinkIcon className='w-4 h-4 mr-2' />
            View in Google Ads
          </Link>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            e.stopPropagation();
            form.handleSubmit();
          }}
        >
          <Fieldset>
            <div className='flex flex-row justify-between'>
              <FieldGroup className='w-1/2'>
                <form.Field
                  validators={{
                    onChange: z.string().trim().min(1, 'Campaign Name is required'),
                  }}
                  name='campaignName'
                >
                  {(field) => (
                    <CampaignNameField
                      field={field}
                      onFieldChange={(value) => handleFieldChange('campaignName', value)}
                    />
                  )}
                </form.Field>
                <form.Field
                  validators={{
                    onChange: z.string().min(1, 'Phone number is required'),
                  }}
                  name='phoneNumber'
                >
                  {(field) => (
                    <PhoneNumberField
                      field={field}
                      onFieldChange={(value) => handleFieldChange('phoneNumber', value)}
                    />
                  )}
                </form.Field>
                <form.Field
                  validators={{
                    onChange: z.number().gt(0),
                  }}
                  name='target_cpa'
                >
                  {(field) => (
                    <div className='space-y-2'>
                      <TCPAField field={field} onFieldChange={(value) => handleFieldChange('target_cpa', value)} />
                    </div>
                  )}
                </form.Field>
                <Field>
                  <label className=''>What Locations are you looking to target?</label>

                  <form.Field
                    validators={{
                      onChange: z
                        .array(
                          z.object({
                            canonical_name: z.string(),
                            country_code: z.string(),
                            criteria_id: z.number(),
                            name: z.string(),
                            status: z.string(),
                            target_type: z.string(),
                          }),
                        )
                        .nonempty('Location Targeting is required'),
                    }}
                    name='locationTargeting'
                  >
                    {(field) => (
                      <LocationTargetingSelectField
                        field={field}
                        onFieldChange={(value) => handleFieldChange('locationTargeting', value)}
                      />
                    )}
                  </form.Field>
                </Field>
              </FieldGroup>
              <FieldGroup className='w-1/2 pl-4'>
                <Title className='text-lg font-bold'>Our AI's Understanding of your Campaign</Title>
                <div className='flex items-start space-x-4'>
                  <img
                    src='https://cdn.midjourney.com/a0c7ccca-c826-4eda-9b49-34f3f2f3a7eb/0_1.png'
                    alt='Avatar'
                    className='w-20 h-20 rounded-full'
                    // style={{ transform: 'scaleX(-1)' }}
                  />

                  <div className='w-full space-y-4'>
                    <form.Field
                      validators={{
                        onChange: z.string().trim().min(1, 'Business description is required'),
                      }}
                      name='business_desc'
                    >
                      {(field) => (
                        <BusinessInfoField
                          field={field}
                          onFieldChange={(value) => handleFieldChange('description', value)}
                        />
                      )}
                    </form.Field>

                    {tcpaGeneration?.total === 0 || (tcpaGeneration && tcpaGeneration.in_progress > 0) ? (
                      <TextSpinner message='Generating Target CPA explanation...' />
                    ) : (
                      <form.Field
                        validators={{
                          onChange: z.string().trim().min(1, 'Business description is required'),
                        }}
                        name='target_cpa_explanation'
                      >
                        {(field) => (
                          <TCPAExplanationField
                            field={field}
                            onFieldChange={(value) => handleFieldChange('target_cpa_explanation', value)}
                          />
                        )}
                      </form.Field>
                    )}
                    <Button
                      onClick={(e) => {
                        e.preventDefault();
                        regenerateTcpa();
                      }}
                      disabled={(tcpaGeneration?.in_progress ?? 0) > 0}
                      color='indigo'
                    >
                      <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'>
                        <path
                          fill='none'
                          stroke='currentColor'
                          stroke-linecap='round'
                          stroke-linejoin='round'
                          stroke-width='2'
                          d='M4 4v5h.582m15.356 2A8.001 8.001 0 0 0 4.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 0 1-15.357-2m15.357 2H15'
                        />
                      </svg>
                      {(tcpaGeneration?.in_progress ?? 0) > 0 ? 'Regenerating...' : 'New TCPA'}
                    </Button>
                  </div>
                </div>
              </FieldGroup>
            </div>
          </Fieldset>
          <div className='flex flex-row justify-between mt-8'>
            <form.Subscribe
              selector={(state) => [state.canSubmit, state.isSubmitting]}
              children={([canSubmit, isSubmitting]) => {
                return (
                  <Button
                    color='indigo'
                    className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                    type='submit'
                    disabled={!canSubmit}
                    onClick={() => posthog?.capture('save_settings_clicked')}
                  >
                    {isSubmitting ? '...' : 'Save'}
                  </Button>
                );
              }}
            />
          </div>
        </form>
      </div>
    </>
  );
}
