import { CampaignRecommendation } from '@/lib/types';

interface CampaignRecommendationDetailProps {
  campaignRecommendation: CampaignRecommendation;
  websiteUrl: string;
  onCampaignInstantFix: () => void;
}

export const CampaignRecommendationDetail = ({
  campaignRecommendation,
  websiteUrl,
  onCampaignInstantFix,
}: CampaignRecommendationDetailProps) => {
  const { description, ad_recommendations } = campaignRecommendation;
  const total = ad_recommendations.reduce((acc, adRec) => {
    return acc + adRec.keyword_recommendations.filter((keyRec) => !keyRec.keyword.is_deleted).length;
  }, 0);
  return (
    <>
      <div className='improvement-title text-3xl font-bold '>{campaignRecommendation.title}</div>
      <div className='improvement-title text-base mt-4 underline cursor-pointer text-blue-500'>{websiteUrl}</div>
      <div className='improvement-title text-base mt-4' style={{ color: '#757575' }}>
        {description}
      </div>
      {campaignRecommendation.recommendation_type === 'underperforming_keyword' ? (
        <div className='flex justify-start ml-0 mt-4 gap-4'>
          <dt
            className='op-item inline-flex items-center rounded-sm bg-[#5c5c5c] border border-[#5c5c5c] px-4 py-2.5 text-sm font-medium text-white ring-1 ring-inset ring-pink-500/10 cursor-pointer'
            onClick={onCampaignInstantFix}
          >
            Instant fix: Delete these {total} Keywords
          </dt>
          <dt className='op-item inline-flex items-center rounded-sm bg-white border border-[#5c5c5c] px-4 py-2.5 text-sm font-medium text-gray-600 ring-0 ring-inset ring-pink-500/10 cursor-pointer'>
            Manual fix: Delete Keywords in Google Ads
          </dt>
        </div>
      ) : null}
    </>
  );
};
