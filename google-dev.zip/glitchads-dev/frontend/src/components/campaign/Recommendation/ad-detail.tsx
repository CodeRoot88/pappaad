import { Link } from '@tanstack/react-router';

import { BadgeButton } from '@/components/catalyst/badge';
import { AdRecommendation, KeywordRecommendation } from '@/lib/types';
import { isResolvedState } from '@/lib/utils';
import { XMarkIcon } from '@heroicons/react/24/outline';

type AdRecommendationDetailsProps = {
  campaignSlug: string;
  adRecommendation: AdRecommendation;
  onAdInstantFix: () => void;
  setSelectedAdRecommendation: (adRec: AdRecommendation) => void;
  onKeywordInstantFix: () => void;
  setSelectedKeywordRecommendation: (keywordRec: KeywordRecommendation) => void;
};

export const AdRecommendationDetail = ({
  campaignSlug,
  adRecommendation,
  onAdInstantFix,
  setSelectedAdRecommendation,
  onKeywordInstantFix,
  setSelectedKeywordRecommendation,
}: AdRecommendationDetailsProps) => {
  const {
    keyword_recommendations: keywordRecommendations = [],
    ad_id,
    description,
    ad: { slug },
  } = adRecommendation;

  return !isResolvedState(adRecommendation.state) ? (
    <div className='w-100 flex flex-col'>
      <div className='mt-4 bg-slate-100 px-4 py-3 flex flex-col gap-2 rounded-lg'>
        <Link to={`/campaigns/${campaignSlug}/ads/${slug}`}>
          <div className='font-semibold text-base'>{`Ad Group ${ad_id} has ${adRecommendation.title}`}</div>
          <p className='text-sm text-[#757575]'>{description}</p>
        </Link>
        <div className='divide-y'>
          {keywordRecommendations
            .filter(({ keyword }) => !keyword.is_deleted)
            .map((keywordRecommendation, index) => (
              <BadgeButton
                key={index}
                color='blue'
                className='m-1'
                onClick={() => {
                  setSelectedKeywordRecommendation(keywordRecommendation);
                  onKeywordInstantFix();
                }}
              >
                {keywordRecommendation.keyword.text} {/* Display the keyword text */}
                <XMarkIcon className='h-3 ml-1' />
              </BadgeButton>
            ))}
        </div>
        {adRecommendation.recommendation_type === 'underperforming_keyword' ? (
          <button
            className='cursor-pointer bg-[#5c5c5c] text-white border rounded-lg text-sm mr-auto py-2.5 px-6 font-medium'
            onClick={() => {
              setSelectedAdRecommendation(adRecommendation);
              onAdInstantFix();
            }}
          >
            Apply instant fix
          </button>
        ) : null}
      </div>
    </div>
  ) : (
    <></>
  );
};
