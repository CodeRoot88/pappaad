import {
  campaignRecommendationsQueryOptions,
  useAdRecommendationsFixMutationOptions,
  useCampaignRecommendationsFixMutationOptions,
  useKeywordRecommendationsFixMutationOptions,
} from '@/lib/query-options';
import { AdRecommendation, CampaignData, KeywordRecommendation, CampaignRecommendation } from '@/lib/types';
import { useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { Recommendation as CampaignRecommendationItem } from './campaign-recommendation';
import { CampaignRecommendationDetail } from './campaign-detail';
import { AdRecommendationDetail } from './ad-detail';
import { useToast } from '@/components/ui/use-toast';
import { useState } from 'react';
import { Card } from '@/components/ui/card';

type RecommendationsProps = {
  campaign: CampaignData;
};

const CampaignRecommendations = ({ campaign }: RecommendationsProps) => {
  const { id: campaignId, slug: campaignSlug, website_url } = campaign;
  const { data, refetch } = useSuspenseQuery(campaignRecommendationsQueryOptions(campaignId));
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const campaignRecommendations = data?.recommendations ?? [];
  const [selectedRecommendation, setSelectedRecommendation] = useState<CampaignRecommendation | null>(null);
  const [selectedAdRecommendation, setSelectedAdRecommendation] = useState<AdRecommendation>();
  const [selectedKeywordRecommendation, setSelectedKeywordRecommendation] = useState<KeywordRecommendation>();

  const campaignRecommendationMutation = useCampaignRecommendationsFixMutationOptions(
    campaignId,
    selectedRecommendation?.id ?? -1,
  );

  const adRecommendationMutation = useAdRecommendationsFixMutationOptions(
    campaignId,
    selectedAdRecommendation?.id ?? -1,
  );

  const keywordRecommendationMutation = useKeywordRecommendationsFixMutationOptions(
    campaignId,
    selectedKeywordRecommendation?.id ?? -1,
  );

  const onCampaignInstantFix = async () => {
    if (!selectedRecommendation) return;
    try {
      await campaignRecommendationMutation.mutateAsync();
      queryClient.invalidateQueries({
        queryKey: ['campaignRecommendations', campaignId, selectedRecommendation.id],
      });
      await refetch();
      toast({ description: '🎉 Underperforming keywords deleted from the campaign.' });
    } catch (error) {
      console.error(error);
    }
  };

  const onAdInstantFix = async () => {
    try {
      await adRecommendationMutation.mutateAsync();
      queryClient.invalidateQueries({
        queryKey: ['adRecommendations', campaignId, selectedAdRecommendation?.id ?? -1],
      });
      await refetch();
      toast({ description: '🎉 Underperforming keywords deleted from the ad.' });
    } catch (error) {
      console.error(error);
    }
  };

  const onKeywordInstantFix = async () => {
    try {
      await keywordRecommendationMutation.mutateAsync();
      queryClient.invalidateQueries({
        queryKey: ['keywordRecommendations', campaignId, selectedKeywordRecommendation?.id ?? -1],
      });
      await refetch();
      toast({ description: '🎉 Underperforming keywords deleted from the keywords.' });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className='mx-auto mt-4'>
      <h3 className='text-base font-semibold leading-6 text-gray-900 mb-4'>Campaign Recommendations</h3>
      {!campaignRecommendations || campaignRecommendations.length === 0 ? (
        <Card className='mt-5 p-6'>
          <p className='text-center text-lg font-semibold text-gray-700'>More recommendations coming soon</p>
        </Card>
      ) : (
        <div className='flex'>
          <div className='w-1/3 pr-4 border-r border-gray-200'>
            {campaignRecommendations.map((recommendation) => (
              <CampaignRecommendationItem
                key={recommendation.id}
                campaignSlug={campaignSlug}
                campaignRecommendation={recommendation}
                handleClick={setSelectedRecommendation}
                isSelected={selectedRecommendation?.id === recommendation.id}
              />
            ))}
          </div>
          <div className='w-2/3 pl-4'>
            {selectedRecommendation ? (
              <>
                <CampaignRecommendationDetail
                  onCampaignInstantFix={onCampaignInstantFix}
                  campaignRecommendation={selectedRecommendation}
                  websiteUrl={website_url}
                />
                <div className='mt-6'>
                  <h4 className='text-lg font-semibold mb-4'>Ad Recommendations</h4>
                  {selectedRecommendation.ad_recommendations.length > 0 ? (
                    selectedRecommendation.ad_recommendations.map((adRec, index) => (
                      <AdRecommendationDetail
                        key={`ad-recommendation-detail-${index}`}
                        campaignSlug={campaignSlug}
                        adRecommendation={adRec}
                        onAdInstantFix={onAdInstantFix}
                        setSelectedAdRecommendation={setSelectedAdRecommendation}
                        onKeywordInstantFix={onKeywordInstantFix}
                        setSelectedKeywordRecommendation={setSelectedKeywordRecommendation}
                      />
                    ))
                  ) : (
                    <p className='text-gray-500'>No ad recommendations available for this campaign recommendation.</p>
                  )}
                </div>
              </>
            ) : (
              <p className='text-gray-500 text-center mt-8'>Select a recommendation to view details</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CampaignRecommendations;
