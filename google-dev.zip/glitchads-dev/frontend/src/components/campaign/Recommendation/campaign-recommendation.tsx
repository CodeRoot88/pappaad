import { CampaignRecommendation } from '@/lib/types';

type RecommendationProps = {
  campaignSlug: string;
  campaignRecommendation: CampaignRecommendation;
  handleClick: (campaignRecommendation: CampaignRecommendation) => void;
  isSelected: boolean;
};

export const Recommendation = ({
  campaignRecommendation,
  campaignSlug,
  handleClick,
  isSelected,
}: RecommendationProps) => {
  const { title, severity } = campaignRecommendation;
  return (
    <div
      className={`p-4 flex flex-col border rounded-xl mb-2 hover:bg-slate-100 cursor-pointer ${isSelected ? 'bg-slate-100' : ''}`}
      onClick={() => handleClick(campaignRecommendation)}
    >
      <div className='improvement-title text-base'>{title}</div>
      <div className='w-100 flex justify-between mt-2'>
        <div className='campaign-name text-base' style={{ color: '#757575' }}>
          <p>Campaign: {campaignSlug}</p>
        </div>
        <div className='campaign-name flex'>
          <dt className='op-item m-1 inline-flex items-center rounded-md bg-pink-50 px-2 py-1 text-xs font-medium text-gray-600 ring-1 ring-inset ring-pink-500/10'>
            {severity}
          </dt>
        </div>
      </div>
    </div>
  );
};
