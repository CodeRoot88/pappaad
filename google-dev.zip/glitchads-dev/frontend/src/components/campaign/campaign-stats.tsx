const stats = [
  { name: 'Total Impressions', stat: '10,000' },
  { name: 'Total Interactions', stat: '500' },
  { name: 'Interaction Rate', stat: '5%' },
  { name: 'Average Cost', stat: '$1.00' },
  { name: 'Total Cost', stat: '$500.00' },
  { name: 'Total Conversions', stat: '50' },
  { name: 'Cost per Conversion', stat: '$10.00' },
  { name: 'Optimization Score', stat: '75%' },
];

export const CampaignStats = () => {
  return (
    <div className='mx-auto'>
      <h3 className='text-base font-semibold leading-6 text-gray-900'>Last 30 days</h3>
      <dl className='mt-5 grid grid-cols-1 gap-5 sm:grid-cols-4'>
        {stats.map((item) => (
          <div key={item.name} className='overflow-hidden rounded-lg shadow pl-4 py-2'>
            <dt className='truncate text-sm font-medium text-gray-500'>{item.name}</dt>
            <dd className='mt-1 text-2xl font-semibold tracking-tight text-gray-900'>{item.stat}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}