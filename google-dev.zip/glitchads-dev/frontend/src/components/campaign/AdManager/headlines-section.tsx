import { usePostHog } from 'posthog-js/react';

import { PlusIcon, TrashIcon } from '@heroicons/react/16/solid';
import { Headline } from '@/lib/types';
import { Input } from '@/components/catalyst/input';
import { Button } from '@/components/catalyst/button';
import { containsEmoji } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

interface HeadlinesSectionProps {
  headlines: Headline[];
  setHeadlines: React.Dispatch<React.SetStateAction<Headline[]>>;
  adslug: string;
  campaignId: number;
  adId: number;
}

const HeadlineInput: React.FC<{
  value: string;
  onChange: (value: string) => void;
}> = ({ value, onChange }) => {
  return (
    <div className='flex flex-col w-full'>
      <Input value={value} onChange={(e) => onChange(e.target.value)} className='mr-8' maxLength={30} />
      <span className='text-sm text-gray-500 mt-1'>{value.length} / 30</span>
    </div>
  );
};

export const HeadlinesSection: React.FC<HeadlinesSectionProps> = ({ headlines, setHeadlines, adslug }) => {
  const posthog = usePostHog();
  const { toast } = useToast();

  const addHeadline = () => {
    if (headlines.length < 15) {
      setHeadlines([...headlines, { text: '' }]);
      posthog?.capture('headline_added', { adslug });
    }
  };

  const removeHeadline = (index: number) => {
    setHeadlines(headlines.filter((_, i) => i !== index));
    posthog?.capture('headline_removed', { adslug, index });
  };

  const changeHeadline = async (index: number, value: string) => {
    if (containsEmoji(value)) {
      toast({ description: 'Emoji is not allowed in deadline.', variant: 'destructive' });
      return;
    }
    if (value.length > 30) return;
    const updatedHeadlines = [...headlines];
    updatedHeadlines[index] = { ...updatedHeadlines[index], text: value };
    setHeadlines(updatedHeadlines);
    posthog?.capture('headline_updated', { adslug, index, value });
  };

  return (
    <div className='mb-8'>
      <h2 className='text-lg font-semibold leading-7 text-gray-900 mb-4'>Headlines</h2>
      {headlines.map((headline, index) => (
        <div key={index} className='flex flex-row mt-2'>
          <HeadlineInput value={headline.text} onChange={(value) => changeHeadline(index, value)} />
          <Button
            outline
            onClick={() => removeHeadline(index)}
            className='ml-4 flex items-center'
            style={{ height: '100%' }}
          >
            <TrashIcon className='h-full' />
          </Button>
        </div>
      ))}
      {headlines.length < 15 && (
        <Button className='mt-4' outline onClick={addHeadline}>
          <PlusIcon className='mr-2' />
          Add Headline
        </Button>
      )}
    </div>
  );
};
