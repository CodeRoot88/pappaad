import { usePostHog } from 'posthog-js/react';

import { PlusIcon, TrashIcon } from '@heroicons/react/16/solid';
import { Description } from '@/lib/types';
import { Input } from '@/components/catalyst/input';
import { Button } from '@/components/catalyst/button';
import { containsEmoji } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

interface DescriptionsSectionProps {
  descriptions: Description[];
  setDescriptions: React.Dispatch<React.SetStateAction<Description[]>>;
  adslug: string;
  campaignId: number;
  adId: number;
}

const DescriptionInput: React.FC<{
  value: string;
  onChange: (value: string) => void;
}> = ({ value, onChange }) => {
  return (
    <div className='flex flex-col w-full'>
      <Input value={value} onChange={(e) => onChange(e.target.value)} className='mr-2' maxLength={90} />
      <span className='text-sm text-gray-500 mt-1'>{value.length} / 90</span>
    </div>
  );
};

export const DescriptionsSection: React.FC<DescriptionsSectionProps> = ({ descriptions, setDescriptions, adslug }) => {
  const posthog = usePostHog();
  const { toast } = useToast();

  const addDescription = () => {
    if (descriptions.length < 4) {
      setDescriptions([...descriptions, { text: '' }]);
      posthog?.capture('description_added', { adslug });
    }
  };

  const removeDescription = (index: number) => {
    setDescriptions(descriptions.filter((_, i) => i !== index));
    posthog?.capture('description_removed', { adslug, index });
  };

  const changeDescription = async (index: number, value: string) => {
    if (containsEmoji(value)) {
      toast({ description: 'Emoji is not allowed in description.', variant: 'destructive' });
      return;
    }
    if (value.length > 90) return;
    const updatedDescriptions = [...descriptions];
    updatedDescriptions[index] = { ...updatedDescriptions[index], text: value };
    setDescriptions(updatedDescriptions);
    posthog?.capture('description_updated', { adslug, index, value });
  };

  return (
    <div className='mb-8'>
      <h2 className='text-lg font-semibold leading-7 text-gray-900 mb-4'>Descriptions</h2>
      {descriptions.map((description, index) => (
        <div key={index} className='flex flex-row mt-2'>
          <DescriptionInput value={description.text} onChange={(value) => changeDescription(index, value)} />
          <Button
            outline
            className='ml-4 flex items-center'
            style={{ height: '100%' }}
            onClick={() => removeDescription(index)}
          >
            <TrashIcon className='h-full' />
          </Button>
        </div>
      ))}
      {descriptions.length < 4 && (
        <Button className='mt-4' outline onClick={addDescription}>
          <PlusIcon className='mr-2' />
          Add Description
        </Button>
      )}
    </div>
  );
};
