import React, { useMemo } from 'react';
import phoneScreen from '/iphone_frame.svg';

import { Ad } from '@/lib/types';
interface AdPreviewOnPhoneProps {
  adData: Ad;
}

export const AdPreviewOnPhone: React.FC<AdPreviewOnPhoneProps> = React.memo(({ adData }) => {
  const firstNumber = Math.floor(Math.random() * adData?.headlines.length);
  let secondNumber: number | undefined;
  if (adData?.headlines.length > 1) {
    do {
      secondNumber = Math.floor(Math.random() * adData?.headlines.length);
    } while (secondNumber === firstNumber);
  }

  const randomDescriptionIdx = Math.floor(Math.random() * adData?.descriptions.length);
  const headlineOnPhone = useMemo(() => {
    return adData?.headlines.length > 0
      ? `${adData?.headlines[firstNumber]?.text}${secondNumber !== undefined ? ' - ' + adData?.headlines[secondNumber]?.text : ''}`
      : '-'
  }, [adData.descriptions, adData.headlines])

  return (
    <div className='relative flex justify-center items-center pt-12'>
      <img className='hidden md:block w-4/6' src={phoneScreen} alt='iPhone Frame' />
      <div className='absolute top-32 left-1/2 transform -translate-x-1/2 w-80'>
        <div className='border rounded-lg p-2 bg-white shadow-sm'>
          <div className='flex items-center mb-2'>
            <span className='text-xs font-semibold text-gray-700'>Sponsored</span>
            <span className='mx-2 w-2 h-2 rounded-full bg-gray-300'></span>
            <a href={adData?.url} className='text-xs text-blue-600 hover:underline truncate ...'>
              {adData?.url}
            </a>
          </div>
          <div className='mb-2'>
            <a href={adData?.url} className='text-md text-blue-700 font-medium hover:underline'>
              {headlineOnPhone}
            </a>
          </div>
          <p className='text-sm text-gray-600'>{adData?.descriptions?.[randomDescriptionIdx]?.text || 'No description available'}</p>
        </div>
      </div>
    </div>
  );
});
