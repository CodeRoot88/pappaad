import { usePostHog } from 'posthog-js/react';

import { XMarkIcon } from '@heroicons/react/16/solid';
import { AlternativeKeyword, Keyword } from '@/lib/types';
import { Input } from '@/components/catalyst/input';
import { Button } from '@/components/catalyst/button';
import { BadgeButton } from '@/components/catalyst/badge';
import { useToast } from '@/components/ui/use-toast';
import { containsEmoji } from '@/lib/utils';

interface KeywordsSectionProps {
  keywords: Keyword[];
  setKeywords: React.Dispatch<React.SetStateAction<Keyword[]>>;
  alternativeKeywords: AlternativeKeyword[];
  setAlternativeKeywords: React.Dispatch<React.SetStateAction<AlternativeKeyword[]>>;
  customKeyword: string;
  setCustomKeyword: React.Dispatch<React.SetStateAction<string>>;
  adslug: string;
}

export const KeywordsSection: React.FC<KeywordsSectionProps> = ({
  keywords,
  setKeywords,
  alternativeKeywords,
  setAlternativeKeywords,
  customKeyword,
  setCustomKeyword,
  adslug,
}) => {
  const posthog = usePostHog();
  const { toast } = useToast();

  const removeKeyword = (keyword: Keyword) => {
    setKeywords(keywords.filter((k) => k.text !== keyword.text));
    posthog?.capture('keyword_removed', { adslug, keyword });
  };

  const addAlternativeKeyword = (altKeyword: AlternativeKeyword) => {
    if (containsEmoji(altKeyword.text)) {
      toast({ description: 'Emoji is not allowed in keywords.', variant: 'destructive' });
      return;
    }
    if (keywords.length === 15) {
      toast({ description: 'A maximum of 15 keywords can be added.', variant: 'destructive' });
      return;
    }
    if (!keywords.some((k) => k.text === altKeyword.text)) {
      setKeywords([...keywords, { text: altKeyword.text }]);
      setAlternativeKeywords(alternativeKeywords.filter((k) => k.id !== altKeyword.id));
      posthog?.capture('alternative_keyword_added', { adslug, text: altKeyword.text });
    }
  };

  const addCustomKeyword = () => {
    console.log("containsEmoji(customKeyword)", customKeyword, containsEmoji(customKeyword))
    if (containsEmoji(customKeyword)) {
      toast({ description: 'Emoji is not allowed in keywords.', variant: 'destructive' });
      return;
    }
    if (keywords.length === 15) {
      toast({ description: 'A maximum of 15 keywords can be added.', variant: 'destructive' });
      return;
    }
    if (customKeyword && !keywords.some((k) => k.text === customKeyword)) {
      setKeywords([...keywords, { text: customKeyword }]);
      setCustomKeyword('');
      posthog?.capture('custom_keyword_added', { adslug, customKeyword });
    }
  };

  return (
    <div className='mb-8'>
      <h2 className='text-lg font-semibold leading-7 text-gray-900 mb-4'>Keywords</h2>
      <div className='flex items-center flex-row mb-2'>
        <Input
          value={customKeyword}
          onChange={(e) => setCustomKeyword(e.target.value)}
          placeholder='Enter custom keyword'
          className='mr-2'
        />
        <Button outline onClick={addCustomKeyword} className='basis-1/4'>
          New Keyword
        </Button>
      </div>
      <div className='mb-4'>
        <h3 className='text-md font-semibold mb-2'>{`Current Keywords  (${keywords.length} / 15)`}</h3>
        {keywords.map((keyword, index) => (
          <BadgeButton key={index} color='blue' className='m-1' onClick={() => removeKeyword(keyword)}>
            {keyword.text}
            <XMarkIcon className='h-3 ml-1' />
          </BadgeButton>
        ))}
      </div>

      <div className='mb-4'>
        <h3 className='text-md font-semibold mb-2'>Alternative Keywords</h3>
        {alternativeKeywords.map((keyword, index) => (
          <BadgeButton key={index} color='zinc' className='m-1' onClick={() => addAlternativeKeyword(keyword)}>
            {keyword.text}
          </BadgeButton>
        ))}
      </div>
    </div>
  );
};
