import { Badge } from '@/components/catalyst/badge';
import { Heading, Subheading } from '@/components/catalyst/heading';
import { Button } from '@/components/catalyst/button';
import { AD_STATE } from '@/lib/types';
import { useState } from 'react';
import ConfirmationModal from '@/components/catalyst/confirmation-modal';

interface HeadProps {
  isAdDirty: boolean;
  url: string;
  state: AD_STATE;
  isSavePending: boolean;
  handleSaveSettings: () => void;
  handleApproveSettings: () => void;
  handleDeleteAd: () => void;
}

export const Header: React.FC<HeadProps> = ({
  isAdDirty,
  url,
  state,
  handleApproveSettings,
  handleDeleteAd,
  handleSaveSettings,
  isSavePending,
}) => {
  const isDraft = state === AD_STATE.DRAFT;
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);

  return (
    <div className='mb-8 flex w-full flex-wrap items-end justify-between gap-4 pb-6'>
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDeleteAd}
        title='Delete Ad'
        description='Are you sure you want to delete this ad?'
      />
      <div>
        <Heading>{url}</Heading>
        <Subheading className='flex gap-2'>
          <Badge color={isDraft ? 'yellow' : 'green'}>{isDraft ? 'Review needed' : 'Reviewed'}</Badge>
          {isAdDirty && <Badge color='zinc'>Draft</Badge>}
        </Subheading>
      </div>
      <div className='flex gap-6'>
        <Button color='indigo' onClick={handleSaveSettings} disabled={!isAdDirty || isSavePending}>
          Save Changes
        </Button>
        {isDraft && (
          <Button color='emerald' onClick={handleApproveSettings} disabled={isAdDirty}>
            Approve
          </Button>
        )}
        <Button color='rose' onClick={() => setDeleteModalOpen(true)}>
          Delete
        </Button>
      </div>
    </div>
  );
};
