import { addDays, startOfDay } from 'date-fns';

import {
  ChartContextProvider,
  ChartDateRange,
  ChartForecastToggle,
  ChartMetrics,
  DateRange,
  FORECAST_DAYS,
  LineChart,
} from '@/components/Charts';

export const CampaignChart = ({
  campaignId,
  forecastEnabled,
  forecastOnly,
}: {
  campaignId: number;
  forecastEnabled?: boolean;
  forecastOnly?: boolean;
})  => {
  const initialDateRange = forecastOnly
    ? ({
        start: startOfDay(new Date()).getTime(),
        end: startOfDay(addDays(new Date(), FORECAST_DAYS)).getTime(),
      } as DateRange)
    : undefined;
  return (
    <ChartContextProvider
      forecastEnabled={forecastEnabled || forecastOnly}
      dateRange={initialDateRange}
      campaignIds={[campaignId.toString()]}
    >
      <div className='flex flex-col w-full gap-4 my-8'>
        <h3 className='text-base font-semibold leading-6 text-gray-900'>
          {forecastOnly ? 'Forecasted ' : ''}Campaign Performance
        </h3>
        <div className='flex items-center w-full justify-between'>
          <ChartMetrics variant='subtle' size='md' />
          <div className='flex flex-col items-end gap-5 -mb-3 -mt-4'>
            <ChartDateRange labelPosition='left' />
            {!forecastOnly && <ChartForecastToggle />}
          </div>
        </div>
        <LineChart />
      </div>
    </ChartContextProvider>
  );
}