import clsx from 'clsx';
import { Link, useLocation, useNavigate } from '@tanstack/react-router';
import { Badge } from '@/components/catalyst/badge';

type TabsProps = { tabs: { name: string; href: string; state: string }[] };

export function Tabs({ tabs }: TabsProps) {
  const { href } = useLocation();
  const navigate = useNavigate();
  const currentTab = tabs.find((tab) => tab.href === href);

  return (
    <div className='mb-12'>
      <div className='sm:hidden'>
        <label htmlFor='tabs' className='sr-only'>
          Select a tab
        </label>
        <select
          id='tabs'
          name='tabs'
          className='block w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500'
          defaultValue={currentTab ? currentTab.name : ''}
          onChange={(e) => {
            const selectedTab = tabs.find((tab) => tab.name === e.target.value);
            if (selectedTab) {
              navigate({ to: selectedTab.href });
            }
          }}
        >
          {tabs.map((tab) => (
            <option key={tab.name}>{tab.name}</option>
          ))}
        </select>
      </div>
      <div className='hidden sm:block'>
        <div className='border-b border-gray-200'>
          <nav className='-mb-px flex' aria-label='Tabs'>
            {tabs.map((tab) => {
              const isActive = tab.href === href;
              return (
                <Link
                  key={tab.name}
                  to={tab.href}
                  className={clsx(
                    isActive
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700',
                    'w-1/4 border-b-2 py-4 px-1 text-center text-sm font-medium',
                  )}
                  aria-current={isActive ? 'page' : undefined}
                >
                  {tab.name}
                  {tab.state === 'draft' && (
                    <Badge color='yellow' className='ml-2'>
                      Review needed
                    </Badge>
                  )}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
