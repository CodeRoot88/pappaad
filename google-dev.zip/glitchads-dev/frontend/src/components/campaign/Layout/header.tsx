import { useState } from 'react';
import { useAtomValue } from 'jotai';
import { useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { useNavigate } from '@tanstack/react-router';
import { LinkIcon } from '@heroicons/react/24/outline';

import { Badge } from '@/components/catalyst/badge';
import { Button } from '@/components/catalyst/button';
import { Heading, Subheading } from '@/components/catalyst/heading';
import { Confirm } from '@/components/glitch-ui/send-campaign-to-google-confirm';
import { useToast } from '@/components/ui/use-toast';
import {
  campaignsQueryOptions,
  useCampaignDeleteMutationOptions,
  useCampaignStateMutationOptions,
  useUpdateGoogleCampaignMutationOptions,
} from '@/lib/query-options';
import { CAMPAIGN_STATE, CampaignData } from '@/lib/types';

import ConfirmationModal from '@/components/catalyst/confirmation-modal';
import { googleAdsCustomerIdAtom } from '@/store';
import { getGoogleAdsCampaignLink, isAdmin } from '@/lib/utils';
import { useUserProfile } from '@/contexts/user.context';

type HeaderProps = {
  campaign: CampaignData;
  refetchCampaign?: () => void;
};

export function Header({ campaign, refetchCampaign }: HeaderProps) {
  const queryClient = useQueryClient();

  if (!campaign) {
    return null;
  }
  const { toast } = useToast();
  const { name, website_url, state, id } = campaign;

  const navigate = useNavigate();

  const { user } = useUserProfile();
  const campaignStateMutation = useCampaignStateMutationOptions(id);
  const campaignDeleteMutation = useCampaignDeleteMutationOptions(id);
  const googleCampaignUpdateMutation = useUpdateGoogleCampaignMutationOptions(id);
  const { refetch: refetchCampaigns } = useSuspenseQuery(campaignsQueryOptions());

  const googleAdsCustomerId = useAtomValue(googleAdsCustomerIdAtom);

  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);

  const handleAction = async () => {
    if (!googleAdsCustomerId) return;

    // Convert enum state to string value for API
    const newState = (() => {
      switch (campaign.state) {
        case CAMPAIGN_STATE.LIVE:
          return CAMPAIGN_STATE.LIVE;
        case CAMPAIGN_STATE.PAUSED:
        case CAMPAIGN_STATE.DRAFT:
          return CAMPAIGN_STATE.PAUSED;
        default:
          return campaign.state;
      }
    })();
    try {
      await campaignStateMutation.mutateAsync(newState);

      if (newState === CAMPAIGN_STATE.LIVE || newState === CAMPAIGN_STATE.PAUSED) {
        const res = await googleCampaignUpdateMutation.mutateAsync();
        if (res) {
          toast({ description: 'Campaign launched in Google Ads 🥳' });
        }
      }

      const action = campaign.state === CAMPAIGN_STATE.PAUSED ? 'resumed' : 'paused';
      toast({ description: `Campaign ${action} successfully` });

      queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
      if (refetchCampaign) {
        refetchCampaign();
      }
    } catch (error) {
      toast({
        description: 'Failed to update campaign. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleGoLive = async () => {
    if (!googleAdsCustomerId) return;

    // Convert enum state to string value for API
    const newState = (() => {
      switch (campaign.state) {
        case CAMPAIGN_STATE.LIVE:
          return CAMPAIGN_STATE.PAUSED;
        case CAMPAIGN_STATE.PAUSED:
        case CAMPAIGN_STATE.DRAFT:
          return CAMPAIGN_STATE.LIVE;
        default:
          return campaign.state;
      }
    })();
    try {
      await campaignStateMutation.mutateAsync(newState);

      if (newState === CAMPAIGN_STATE.LIVE || newState === CAMPAIGN_STATE.PAUSED) {
        const res = await googleCampaignUpdateMutation.mutateAsync();
        if (res) {
          toast({ description: 'Campaign launched in Google Ads 🥳' });
        }
      }

      const action = campaign.state === CAMPAIGN_STATE.PAUSED ? 'resumed' : 'paused';
      toast({ description: `Campaign ${action} successfully` });

      queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
      if (refetchCampaign) {
        refetchCampaign();
      }
    } catch (error) {
      toast({
        description: 'Failed to update campaign. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteCampaign = async () => {
    setDeleteModalOpen(false);
    try {
      await campaignDeleteMutation.mutateAsync();
      toast({ description: 'Campaign deleted successfully' });
      queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
      refetchCampaigns();
      navigate({ to: '/campaigns' });
    } catch (error) {
      toast({ description: 'Failed to delete campaign', variant: 'destructive' });
    }
  };
  const stateColor =
    campaign.state === 'draft'
      ? 'zinc'
      : campaign.state === 'paused'
        ? 'yellow'
        : campaign.state === 'error'
          ? 'rose'
          : 'green';
  const googleAdsCampaignLink = getGoogleAdsCampaignLink(campaign);
  return (
    <>
      <Confirm
        isOpen={isConfirmModalOpen}
        setIsOpen={setConfirmModalOpen}
        onConfirm={handleAction}
        campaign={campaign}
        isLoading={campaignStateMutation.isPending || googleCampaignUpdateMutation.isPending}
      />
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDeleteCampaign}
        title='Delete Campaign'
        description='Are you sure you want to delete campaign?'
      />
      <div className='mb-8 flex w-full flex-wrap items-end justify-between gap-4  pb-6 dark:border-white/10'>
        <div>
          <Heading>{name}</Heading>
          <Subheading>
            <span className='mr-2 text-slate-500'>{website_url}</span>
            <Badge color={stateColor}>{state}</Badge>
            {(campaign.state === 'paused' || campaign.state === 'live') && (
              <Button
                className='ml-2'
                color={campaign.state === 'paused' ? 'emerald' : 'yellow'}
                disabled={campaignStateMutation.isPending || googleCampaignUpdateMutation.isPending}
                onClick={handleGoLive}
              >
                {campaign.state === 'paused' ? 'Go Live' : 'Pause'}
              </Button>
            )}
            {googleAdsCampaignLink && (
              <a
                href={googleAdsCampaignLink}
                className='inline-flex items-center'
                target='_blank'
                rel='noopener noreferrer'
              >
                <LinkIcon className='w-4 h-4' />
              </a>
            )}
          </Subheading>
        </div>
        <div className='flex gap-4'>
          {user?.role && isAdmin(user.role) && (
            <Button
              className='cursor-pointer'
              color='emerald'
              onClick={() => setConfirmModalOpen(true)}
              disabled={campaignStateMutation.isPending || googleCampaignUpdateMutation.isPending}
            >
              {campaign.state === 'draft' ? 'Send Campaign to Google' : 'Update Campaign in google'}
            </Button>
          )}

          <Button
            className='cursor-pointer'
            color='rose'
            onClick={() => setDeleteModalOpen(true)}
            disabled={campaignStateMutation.isPending || googleCampaignUpdateMutation.isPending}
          >
            Delete Campaign
          </Button>
        </div>
      </div>
    </>
  );
}
