import { usePostHog } from 'posthog-js/react';
import { useForm } from '@tanstack/react-form';
import { useQueryClient } from '@tanstack/react-query';
import { zodValidator } from '@tanstack/zod-form-adapter';
import clsx from 'clsx';
import { z } from 'zod';

import { Button } from '@/components/catalyst/button';
import { FieldGroup, Fieldset } from '@/components/catalyst/fieldset';
import { ACTION_STATE, APPROVAL_STATE, CampaignData, CampaignUpdate } from '@/lib/types';
import { useCampaignMutationOptions } from '@/lib/query-options';
import { useToast } from '@/components/ui/use-toast';
import { BudgetField } from '@/form-fields/budget';
import { FetchCampaign } from '@/store';

type BudgetProps = {
  campaign: CampaignData;
  refetchCampaign: FetchCampaign;
};

export function CampaignBudget({ campaign, refetchCampaign }: BudgetProps) {
  const queryClient = useQueryClient();
  const campaignSettingsMutation = useCampaignMutationOptions();

  const { toast } = useToast();
  const posthog = usePostHog();

  const updateCampaignSettings = async (newCampaign: CampaignUpdate, state: ACTION_STATE) => {
    let res = await campaignSettingsMutation.mutateAsync(newCampaign);
    if (res) {
      queryClient.invalidateQueries({ queryKey: ['campaigns', 'update'] });
      if (refetchCampaign) {
        refetchCampaign();
      }
      toast({ description: `Settings ${state} 🎉` });
      posthog?.capture(`budget_settings_${state}`, {
        campaignId: campaign.id,
      });
    }
  };

  const form = useForm({
    defaultValues: {
      budget: campaign.budget,
    },
    onSubmit: (form) => {
      const newCampaign = {
        ...campaign,
        phone_numbers: [campaign.phone_numbers[0]?.value || ''],
        budget: form.value.budget,
      };
      updateCampaignSettings(newCampaign, ACTION_STATE.UPDATED);
    },
    validatorAdapter: zodValidator(),
  });

  const { budget } = form.useStore((state) => state.values);

  const handleApproveSettings = () => {
    let newCampaign = {
      ...campaign,
      phone_numbers: [campaign.phone_numbers[0]?.value || ''],
      budget_state: APPROVAL_STATE.APPROVED,
      budget,
    };
    updateCampaignSettings(newCampaign, ACTION_STATE.APPROVED);
  };

  const handleFieldChange = (fieldName: string, value: number) => {
    posthog?.capture('field_changed', { fieldName, value });
  };

  return (
    <>
      <div className='relative min-h-screen max-w-2xl'>
        {campaign.budget_state === 'draft' && (
          <Button
            onClick={() => {
              handleApproveSettings();
              posthog?.capture('approve_budget_clicked', { campaignId: campaign.id });
            }}
            color='green'
            className='mb-8'
          >
            Approve Budget
          </Button>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            e.stopPropagation();
            form.handleSubmit();
          }}
        >
          <Fieldset>
            <FieldGroup>
              <form.Field
                validators={{
                  onChange: z.number().gt(0),
                }}
                name='budget'
              >
                {(field) => (
                  <BudgetField
                    field={field}
                    onFieldChange={(value) => handleFieldChange('budget_field_changed', value)}
                  />
                )}
              </form.Field>
            </FieldGroup>
          </Fieldset>
          <div className='flex flex-row justify-between mt-8'>
            <form.Subscribe
              selector={(state) => [state.canSubmit, state.isSubmitting]}
              children={([canSubmit, isSubmitting]) => {
                const handleSubmit = () => {
                  posthog?.capture('save_budget_clicked', { campaignId: campaign.id });
                  form.handleSubmit();
                };
                return (
                  <Button
                    color='indigo'
                    className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                    type='submit'
                    disabled={!canSubmit}
                    onClick={handleSubmit}
                  >
                    {isSubmitting ? '...' : 'Save'}
                  </Button>
                );
              }}
            />
          </div>
        </form>
      </div>
    </>
  );
}
