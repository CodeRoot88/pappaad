import { Button } from '@/components/catalyst/button';
import { Callouts } from '@/components/glitch-ui/callouts';
// import { Prices } from '@/components/glitch-ui/price';
import { SiteLinks } from '@/components/glitch-ui/site-links';
// import { StructuredSnippets } from '@/components/glitch-ui/structured-snippets';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useToast } from '@/components/ui/use-toast';
import { useCampaignMutationOptions } from '@/lib/query-options';
import { APPROVAL_STATE, CampaignData, CampaignUpdate } from '@/lib/types';
import { Loader2 } from 'lucide-react';
import { useAtomValue } from 'jotai';
import { campaignTaskTrackingAtom } from '@/store';

type AssetsProps = {
  campaign: CampaignData;
  refetchCampaign: () => void;
};

const assetSections = (campaign: CampaignData, refetchCampaign: () => void) => [
  {
    name: 'Site Links',
    component: <SiteLinks siteLinks={campaign.site_links} refetchCampaign={refetchCampaign} campaignId={campaign.id} />,
  },
  {
    name: 'Callouts',
    component: <Callouts callouts={campaign.callouts} refetchCampaign={refetchCampaign} campaignId={campaign.id} />,
  },
  // {
  //   name: 'Structured Snippets',
  //   component: (
  //     <StructuredSnippets
  //       snippets={campaign.structured_snippets}
  //       refetchCampaign={refetchCampaign}
  //       campaignId={campaign.id}
  //     />
  //   ),
  // },
  // {
  //   name: 'Prices',
  //   component: <Prices prices={campaign.prices} refetchCampaign={refetchCampaign} campaignId={campaign.id} />,
  // },
];

function AssetsGeneratingMessage() {
  return (
    <div className='flex items-center justify-center p-8 rounded-md'>
      <Loader2 className='w-6 h-6 text-blue-500 animate-spin mr-3' />
      <span className='text-blue-700 font-medium'>Assets are being generated. Please wait...</span>
    </div>
  );
}

export function CampaignAssets({ campaign, refetchCampaign }: AssetsProps) {
  const campaignTaskTracking = useAtomValue(campaignTaskTrackingAtom);
  const campaignSettingsMutation = useCampaignMutationOptions();
  const { toast } = useToast();

  const sections = assetSections(campaign, refetchCampaign);
  const handleApproveAssets = async () => {
    let newCampaign: CampaignUpdate = {
      ...campaign,
      phone_numbers: [campaign.phone_numbers[0]?.value || ''],
      assets_state: APPROVAL_STATE.APPROVED,
    };
    let res = await campaignSettingsMutation.mutateAsync(newCampaign);
    if (res) {
      if (refetchCampaign) {
        refetchCampaign();
      }
      toast({ description: 'Assets Approved 🎉' });
    }
  };

  const siteLinkGeneration = campaignTaskTracking?.site_link_generation;

  const isGeneratingAssets = () => {
    return siteLinkGeneration && (siteLinkGeneration.completed === 0 || siteLinkGeneration.in_progress > 0);
  };

  return (
    <>
      <div className='container bg-white rounded-md'>
        {campaign.assets_state === 'draft' && (
          <Button onClick={handleApproveAssets} color='green' className='mb-8'>
            Approve Assets
          </Button>
        )}
        {isGeneratingAssets() ? (
          <AssetsGeneratingMessage />
        ) : (
          <Accordion type='single' collapsible>
            {sections.map((section) => {
              return (
                <AccordionItem className='border-0' value={section.name} key={section.name}>
                  <div className='flex flex-row justify-content items-center'>
                    {section.name}
                    <AccordionTrigger className='ml-1'></AccordionTrigger>
                  </div>
                  <AccordionContent>{section.component}</AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        )}
      </div>
    </>
  );
}
