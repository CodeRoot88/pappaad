import * as Dialog from '@radix-ui/react-dialog';
import { motion } from 'framer-motion';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmText?: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ isOpen, onClose, onConfirm, title, description, confirmText }) => {
  return (
    <Dialog.Root open={isOpen} onOpenChange={onClose}>
      <Dialog.Trigger asChild />
      <Dialog.Portal>
        <Dialog.Overlay className='fixed inset-0 bg-black/50' />

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className='fixed inset-0 flex items-center justify-center'
        >
          <Dialog.Content className='bg-white p-6 rounded-lg max-w-md mx-auto'>
            <Dialog.Title className='text-xl font-semibold'>{title}</Dialog.Title>
            <Dialog.Description className='mt-2 text-sm text-gray-500'>{description}</Dialog.Description>

            <div className='mt-4 flex justify-end space-x-4'>
              <button onClick={onClose} className='bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300'>
                Cancel
              </button>
              <button onClick={onConfirm} className='bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700'>
                {confirmText ? confirmText : 'Confirm'}
              </button>
            </div>
          </Dialog.Content>
        </motion.div>
      </Dialog.Portal>
    </Dialog.Root>
  );
};

export default ConfirmationModal;
