import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import {
  CircleCheckIcon,
  InfoIcon,
  OctagonAlertIcon,
  TriangleAlertIcon,
} from "lucide-react";
import clsx from "clsx";

const alertVariants = cva(
  "relative w-full rounded-md px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7",
  {
    variants: {
      variant: {
        default: "bg-white bg-opacity-[0.08] text-foreground",
        information:
          "bg-blue-500 bg-opacity-[0.08] text-blue-500 [&>svg]:text-blue-500",
        success:
          "bg-green-500 bg-opacity-[0.08] text-green-500 [&>svg]:text-green-500",
        warning:
          "bg-orange-500 bg-opacity-[0.08] text-orange-500 [&>svg]:text-orange-500",
        destructive:
          "bg-red-500 bg-opacity-[0.08] text-red-500 [&>svg]:text-red-500",
        gray: "bg-gray-400 bg-opacity-[0.08] text-gray-400 [&>svg]:text-gray-400",
        purple:
          "bg-purple-500 bg-opacity-[0.08] text-purple-500 [&>svg]:text-purple-500",
        rose: "bg-rose-500 bg-opacity-[0.08] text-rose-500 [&>svg]:text-rose-500",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

const alertIcons = (variant: string | null | undefined) => {
  const iconSize = 20;
  const storeWidth = 2;
  switch (variant) {
    case "information":
      return <InfoIcon strokeWidth={storeWidth} size={iconSize} />;
    case "success":
      return <CircleCheckIcon strokeWidth={storeWidth} size={iconSize} />;
    case "warning":
      return <OctagonAlertIcon strokeWidth={storeWidth} size={iconSize} />;
    case "destructive":
      return <TriangleAlertIcon strokeWidth={storeWidth} size={iconSize} />;
    default:
      return <InfoIcon strokeWidth={storeWidth} size={iconSize} />;
  }
};

const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(({ className, variant, ...props }, ref) => (
  <div
    ref={ref}
    role="alert"
    className={clsx("flex flex-row gap-2", alertVariants({ variant }), className)}
    {...props}
  >
    <div className="mt-[2px]">{alertIcons(variant)}</div>
    <div className="w-full">{props.children}</div>
  </div>
));
Alert.displayName = "Alert";

const AlertTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h5 className={clsx("font-semibold", className)} ref={ref} {...props} />
));
AlertTitle.displayName = "AlertTitle";

const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={clsx(
      "w-full text-base font-light opacity-90 [&_p]:leading-relaxed",
      className,
    )}
    {...props}
  />
));
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription };
