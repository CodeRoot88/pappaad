import { differenceInDays, endOfDay, subDays, subYears } from 'date-fns';
import { DateRange, StrictDateRange } from '../contexts/types';
import { ALL_TIME_START_DATE } from '../contexts/constants';
import { Range as PickerDateRange } from 'react-date-range';

export const getStrictDateRangeForComparisonRange = (comparisonRange: DateRange, primaryRange: DateRange) => {
  let strictDateRange;
  if (!comparisonRange.comparisonType) {
    strictDateRange = getStrictDateRange(comparisonRange);
  } else if (comparisonRange.comparisonType === 'custom') {
    strictDateRange = {
      start: comparisonRange.start!,
      end: comparisonRange.end!,
    };
  } else {
    strictDateRange = getComparisonRange(comparisonRange.comparisonType, getStrictDateRange(primaryRange));
  }
  return strictDateRange;
};

const dateRangeAttributes: (keyof DateRange)[] = ['start', 'end', 'comparisonType', 'persistedStart', 'persistedEnd'];
export const dateRangesEqual = (a: DateRange, b: DateRange) =>
  dateRangeAttributes.every((attributeKey) => a[attributeKey] === b[attributeKey]);

/**
 * Helper to take an optionally ambiguous date range (with optional start/end dates)
 * and fill in the blanks to make it a strict date range (with the oldest possible date at the start)
 * and the current day as the end
 */
export const getStrictDateRange = (dateRange: DateRange): StrictDateRange => {
  let startDate = dateRange.start;
  let endDate = dateRange.end;

  if (!startDate) {
    startDate = ALL_TIME_START_DATE.getTime();
  }
  if (!endDate) {
    endDate = endOfDay(new Date()).getTime();
  }
  return {
    start: startDate,
    end: endDate,
  };
};

export const covertDateRangeToPickerRange = (dateRange: StrictDateRange): PickerDateRange => ({
  startDate: new Date(dateRange.start),
  endDate: new Date(dateRange.end),
});

export const getComparisonRange = (comparisonType: 'period' | 'year', dateRange: StrictDateRange): StrictDateRange => {
  let startDate: Date;
  let endDate: Date;
  if (comparisonType === 'period') {
    const rangeDays = differenceInDays(dateRange.end, dateRange.start);
    startDate = subDays(dateRange.start, rangeDays + 1);
    endDate = subDays(dateRange.end, rangeDays + 1);
  } else {
    startDate = subYears(dateRange.start, 1);
    endDate = subYears(dateRange.end, 1);
  }
  return {
    start: startDate.getTime(),
    end: endDate.getTime(),
  };
};
