import { endOfDay, milliseconds, startOfDay } from 'date-fns';
import {
  ALL_METRICS,
  ChartData,
  ChartDatum,
  ChartMetric,
  ChartMetricDataAccessor,
  DateRange,
  DEFAULT_DATE_RANGE,
  RawChartData,
  StrictDateRange,
} from '../contexts/ChartContext';
import { getStrictDateRangeForComparisonRange } from './dateHelpers';

const getEmptyDatum = (dataSetIndex: number) => {
  const emptyDatum: Omit<ChartDatum, 'date'> = {};
  ALL_METRICS.forEach((metric) => {
    emptyDatum[`${metric}_${dataSetIndex}`] = 0;
  });
  return emptyDatum;
};

export const getDataIntervalFromRange = (dateRange: StrictDateRange) => {
  let rangeInterval;
  const rangeMilliseconds = endOfDay(dateRange.end).getTime() - dateRange.start;

  if (rangeMilliseconds <= milliseconds({ days: 1 })) {
    rangeInterval = milliseconds({ hours: 1 });
  } else if (rangeMilliseconds <= milliseconds({ days: 30 })) {
    rangeInterval = milliseconds({ days: 1 });
  } else if (rangeMilliseconds <= milliseconds({ months: 6 })) {
    rangeInterval = milliseconds({ weeks: 1 });
  } else if (rangeMilliseconds <= milliseconds({ years: 2 })) {
    rangeInterval = milliseconds({ months: 1 });
  } else if (rangeMilliseconds <= milliseconds({ years: 10 })) {
    rangeInterval = milliseconds({ months: 3 });
  } else {
    rangeInterval = milliseconds({ years: 1 });
  }
  return rangeInterval;
};

/**
 * Helper to parse an API provided date string into milliseconds
 * Needs condition to check for presence of timestamp in the date string
 * since Date.parse might automatically add an hour to the parsed time if not specified
 * (e.g. Date.parse("2024-05,22") might yield a time of 01:00), which throws off our graph rendering
 *
 * IFF the date string DOESN'T have a timestamp, we set the time to 00:00.
 * If it does, we respect the time and leave it intact
 */
export const parseRawDate = (dateString: string) => {
  const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(dateString);
  const parsedDate = new Date(dateString);
  if (isDateOnly) {
    parsedDate.setHours(0, 0, 0, 0);
  }
  return parsedDate.getTime();
};

/**
 * Helper to take raw data from the API and adapt it to suit the chart
 * Primarily
 *  - Adapts the date values from strings to ms number values
 *  - Formats data from future dates into "forecast" values, where the metrics are suffixed with "_forecast"
 *  - Populates it with missing data (metrics not included in each datum, missing datums for date range)
 */
const formatRawChartData = (rawData: RawChartData, dataSetIndex: number) => {
  // Used to quickly check which metrics we've encountered that have forecast data encountered already
  const metricsWithForecastData: Partial<Record<ChartMetric, boolean>> = {};
  // Used to store reference to the _previous_ datum encountered for each metric, so we can retroactively modify them
  const lastDatumForMetricLookup: Partial<Record<ChartMetric, ChartDatum>> = {};

  return rawData.map((datum) => {
    const { date, ...metrics } = datum;
    const dateNumber = parseRawDate(date);
    const isFutureDate = dateNumber > Date.now();
    const cleanedDatum: ChartDatum = {
      ...(isFutureDate ? undefined : getEmptyDatum(dataSetIndex)),
      date: dateNumber,
    };

    Object.entries(metrics).forEach(([metricKey, metricValue]) => {
      const baseMetric = metricKey as ChartMetric;
      const baseMetricWithDataIndex = `${baseMetric}_${dataSetIndex}` as ChartMetricDataAccessor;
      if (isFutureDate) {
        let forecastMetricWithDataIndex: ChartMetricDataAccessor = `${baseMetric}_forecast_${dataSetIndex}`;
        // The datum is for a forecasted future date
        if (!metricsWithForecastData[baseMetric] && lastDatumForMetricLookup[baseMetric]) {
          // We've never dealt with a forecasted value for this metric
          // Go back and set the previous datum for this metric to include a starting off "forecast" point
          // @ts-ignore
          lastDatumForMetricLookup[baseMetric][forecastMetricWithDataIndex] =
            lastDatumForMetricLookup[baseMetric][baseMetricWithDataIndex];
          metricsWithForecastData[baseMetric] = true;
        }
        cleanedDatum[forecastMetricWithDataIndex] = metricValue;
      } else {
        lastDatumForMetricLookup[baseMetric] = cleanedDatum;
        cleanedDatum[baseMetricWithDataIndex] = metricValue;
      }
    });
    return cleanedDatum;
  }) as ChartData;
};

/**
 * Helper to extend the list of chart data with dummy values
 * that fills the specified date range.
 * Note: this was largely required for testing and might not actually
 * be required in production with live data. Depends on whether or not the
 * API gives us entries for EVERY point in the date-range, even if there's no data for the point,
 * or if it only yields valid data and thus needs padding
 */
const padData = (chartData: ChartData, dateRange: StrictDateRange, dataSetIndex: number) => {
  let paddedData: ChartData = [];

  const firstDateInList = chartData.length ? startOfDay(chartData[0].date).getTime() : null;
  const secondDateInList = chartData.length > 1 ? startOfDay(chartData[1].date).getTime() : null;
  const lastDateInList = chartData.length ? startOfDay(chartData[chartData.length - 1].date).getTime() : null;
  // @ts-ignore
  const startDate = startOfDay(dateRange.start || firstDateInList || DEFAULT_DATE_RANGE.start).getTime();
  let endDate = startOfDay(dateRange.end || new Date()).getTime();
  const rangeIsSingleDay = startDate === endDate;

  if (rangeIsSingleDay) {
    // If range is over a single day, set endDate to the end of the day (unless that's the future)
    endDate = Math.min(endOfDay(endDate).getTime(), Date.now());
  }
  let datumInterval;
  if (firstDateInList && secondDateInList && firstDateInList !== lastDateInList) {
    // If we have multiple points of data, derive interval from them
    datumInterval = secondDateInList - firstDateInList;
  } else {
    // If we have no data to go by, guess the server response interval based on full range
    datumInterval = getDataIntervalFromRange({
      start: startDate,
      end: endDate,
    });
  }

  for (let i = startDate; (!firstDateInList || i < firstDateInList) && i < endDate; i += datumInterval) {
    paddedData.push({
      ...getEmptyDatum(dataSetIndex),
      date: i,
    });
  }
  paddedData.push(...chartData);

  if (paddedData.length) {
    for (let i = paddedData[paddedData.length - 1].date + datumInterval; i <= endDate; i += datumInterval) {
      paddedData.push({
        ...getEmptyDatum(dataSetIndex),
        date: i,
      });
    }
  }
  return paddedData;
};

/**
 * Helper to help combine multiple data sets into a single, ordered list
 * Since multiple data sets are joined, flat, with different metric keys, and some overlapping dates,
 * we need the full combined list to be sorted, and when multiple datums point to the same date,
 * their data needs to be spread onto the same entry
 */
const sortAndDedupeData = (data: ChartData) => {
  const sorted = data.sort((a, b) => a.date - b.date);
  let lastDedupedIndex = -1;
  const deduped: ChartData = [];
  sorted.forEach((datum) => {
    if (lastDedupedIndex >= 0 && datum.date === deduped[lastDedupedIndex].date) {
      deduped[lastDedupedIndex] = {
        ...deduped[lastDedupedIndex],
        ...datum,
      };
    } else {
      deduped.push(datum);
      lastDedupedIndex = deduped.length - 1;
    }
  });
  return deduped;
};

/**
 * Helper to format RawChartData from the API into a more useful ChartData format
 * and apply some additional cleanup (e.g. padding with empty values to allow the chart
 * to represent the full date-range, even if no data exists for this time
 */
export const cleanChartData = (
  rawDataSets: RawChartData[],
  dateRanges: DateRange[],
  comparisonRangeEnabled: boolean,
) => {
  let mergedData: ChartData = [];
  rawDataSets.forEach((rawData, dataSetIndex) => {
    if (dataSetIndex > 0 && !comparisonRangeEnabled) {
      return;
    }
    let cleanedData = formatRawChartData(rawData, dataSetIndex);
    const strictDateRange = getStrictDateRangeForComparisonRange(dateRanges[dataSetIndex], dateRanges[0]);
    // This padData call _may_ not be needed in production. Depends on how sparse the data from the API is
    // i.e. if we only have data for 10th-20th and we ask for 1st-31st, does the API give us empty entries for the empty days?
    cleanedData = padData(cleanedData, strictDateRange, dataSetIndex);
    mergedData = [...mergedData, ...cleanedData];
  });

  mergedData = sortAndDedupeData(mergedData);

  return mergedData;
};
