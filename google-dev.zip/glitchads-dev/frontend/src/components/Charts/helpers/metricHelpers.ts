import { FORECAST_DRAW_ANIMATION_DELAY, METRIC_LOOKUP, UNKNOWN_METRIC_CONFIG } from '../contexts/constants';
import {
  ChartData,
  ChartMetric,
  ChartMetricConfig,
  ChartMetricDataAccessor,
  ChartMetricWithForecasts,
  DateRange,
} from '../contexts/types';

type ChartMetricCellData = {
  dateRange: DateRange;
  chartData: ChartData;
  metric: ChartMetric;
  dataSetIndex: number;
};

// Seems currency code is hardcoded around the app. Unsure if this can be pulled from the user config
const CURRENCY_CODE = '€';
const MILLION = 1000000;
const THOUSAND = 1000;

export const dateIsInRange = (date: number, dateRange: DateRange) => {
  return (!dateRange.start || date >= dateRange.start) && (!dateRange.end || date <= dateRange.end);
};

export const getTotalValueForMetric = ({ dateRange, chartData, metric, dataSetIndex }: ChartMetricCellData): number => {
  const { isAverage } = getMetricConfig(metric);
  let total = 0;
  let count = 0;
  chartData.forEach((datum) => {
    const forecastKey = `${metric}_forecast` as ChartMetricWithForecasts;
    const dataKey: ChartMetricDataAccessor = `${forecastKey in datum ? forecastKey : metric}_${dataSetIndex}`;
    if (datum[dataKey] && dateIsInRange(datum.date, dateRange)) {
      count += 1;
      // @ts-ignore
      total += datum[dataKey];
    }
  });
  return isAverage ? total / count : total;
};

export const formatMetricValue = (
  value: number,
  config: ChartMetricConfig,
  shorten: boolean = true,
  noValueMessage?: string,
) => {
  const rawValue = typeof value === 'number' && !isNaN(value) ? value : 0;
  if (!rawValue && noValueMessage) {
    return noValueMessage;
  }
  let valueUnit = '';
  let scaledValue = rawValue;
  let formattedValue: string;
  if (shorten && rawValue > THOUSAND) {
    if (rawValue > MILLION) {
      valueUnit = 'M';
      scaledValue = rawValue / MILLION;
    } else if (rawValue > THOUSAND) {
      valueUnit = 'K';
      scaledValue = rawValue / THOUSAND;
    }
  } else {
    // No division going on, apply formatting (10000 => 10,000)
  }
  // Round to 2 places and trim trailing ".00"
  const optionalMinus = scaledValue < 0 ? '−' : '';
  formattedValue = parseFloat(Math.abs(scaledValue).toFixed(2)).toLocaleString('en');

  return `${optionalMinus}${config.type === 'currency' ? CURRENCY_CODE : ''}${formattedValue}${valueUnit}`;
};

export const getMetricConfig = (metric: ChartMetricWithForecasts) => {
  const isForecast = metric.endsWith('_forecast');
  const lookupKey = (isForecast ? metric.replace('_forecast', '') : metric) as ChartMetric;
  let config = METRIC_LOOKUP[lookupKey];
  if (!config) {
    const lowerCaseLabel = metric.toLowerCase();
    config = {
      ...UNKNOWN_METRIC_CONFIG,
      label: lowerCaseLabel.charAt(0).toLocaleUpperCase() + lowerCaseLabel.slice(1),
    };
  } else if (isForecast) {
    config = {
      ...config,
      label: `${config.label} (Forecasted)`,
      animationBegin: FORECAST_DRAW_ANIMATION_DELAY,
    };
  }
  return config;
};
