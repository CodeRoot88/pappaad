import { format, milliseconds } from 'date-fns';
import {
  ChartDatum,
  ChartMetric,
  ChartMetricDataAccessor,
  ChartMetricWithForecasts,
  StrictDateRange,
} from '../contexts/ChartContext';
import { formatMetricValue, getMetricConfig } from './metricHelpers';

const DATE_FORMATTER_STRINGS = {
  hourly: {
    short: 'HH:mm',
    long: 'HH:mm do MMM',
  },
  daily: {
    short: 'do MMM',
    long: 'do MMMM y',
  },
  weekly: {
    short: "do MMM ''yy",
    long: "'Week of' do MMMM y",
  },
  monthly: {
    short: "MMM ''yy",
    long: 'MMMM y',
  },
  quarterly: {
    short: "qqqq ''yy",
    long: 'qqqq y',
  },
  yearly: {
    short: 'y',
    long: 'y',
  },
};

const getDateFormatterString = (interval: number, size: 'long' | 'short') => {
  let formatterString;
  if (interval <= milliseconds({ hours: 1 })) {
    formatterString = DATE_FORMATTER_STRINGS.hourly[size];
  } else if (interval <= milliseconds({ days: 1 })) {
    formatterString = DATE_FORMATTER_STRINGS.daily[size];
  } else if (interval <= milliseconds({ weeks: 1 })) {
    formatterString = DATE_FORMATTER_STRINGS.weekly[size];
  } else if (interval <= milliseconds({ months: 1 })) {
    formatterString = DATE_FORMATTER_STRINGS.monthly[size];
  } else if (interval <= milliseconds({ months: 3 })) {
    formatterString = DATE_FORMATTER_STRINGS.quarterly[size];
  } else {
    formatterString = DATE_FORMATTER_STRINGS.yearly[size];
  }
  return formatterString;
};

export const formatTooltipDate = (interval: number, value: number) => {
  const formatterString = getDateFormatterString(interval, 'long');
  return format(value, formatterString);
};

export const formatAxisTickDate = (interval: number, value: number) => {
  const formatterString = getDateFormatterString(interval, 'short');
  return format(value, formatterString);
};

const getDataAccessorWithoutIndex = (metricAccessor: ChartMetricDataAccessor) => {
  return metricAccessor.replace(/_\d+$/, '') as ChartMetricWithForecasts;
};

export const formatTooltipValue = (
  focusedMetric: ChartMetric | undefined,
  value: number,
  metric: ChartMetricDataAccessor,
  { payload: datum }: { payload?: ChartDatum },
) => {
  const datumKeys = datum ? (Object.keys(datum).filter((key) => key !== 'date') as ChartMetricDataAccessor[]) : [];
  const isHidden = metric.includes('hidden');
  const isForecast = metric.includes('forecast');
  const focusedMetricInDatum =
    !!focusedMetric &&
    datumKeys.some((datumKey) => {
      const datumKeyWithoutDataIndex = getDataAccessorWithoutIndex(datumKey);
      return [focusedMetric, `${focusedMetric}_forecast`].includes(datumKeyWithoutDataIndex);
    });
  const metricWithoutIndex = getDataAccessorWithoutIndex(metric);
  let baseMetric = metricWithoutIndex.replace('_hidden', '').replace('_forecast', '') as ChartMetric;

  let isForecastWithRealValue = false;
  if (isForecast) {
    // If we have a forecast value, ensure we don't also have a real value for this period
    isForecastWithRealValue =
      datumKeys.some((datumKey) => {
        return metricWithoutIndex === getDataAccessorWithoutIndex(datumKey);
      }) &&
      datumKeys.some((datumKey) => {
        return baseMetric === getDataAccessorWithoutIndex(datumKey);
      });
  }

  const isFocused = focusedMetric === baseMetric;
  const shouldShow = !isHidden && !isForecastWithRealValue && (!focusedMetric || isFocused || !focusedMetricInDatum);
  const metricConfig = getMetricConfig(metricWithoutIndex);

  return shouldShow ? [formatMetricValue(value, metricConfig, false), metricConfig.label] : [null, null];
};

export const formatDateRangeDate = (date: number | Date) => format(date, "do MMM ''yy");

export const formatDateRange = (dateRange: StrictDateRange) => {
  let startDate: number | Date | undefined = dateRange.start;
  let endDate: number | Date | undefined = dateRange.end;

  return [formatDateRangeDate(startDate), formatDateRangeDate(endDate)];
};
