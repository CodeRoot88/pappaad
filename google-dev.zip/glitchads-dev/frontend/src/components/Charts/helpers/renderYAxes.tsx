import { YAxis } from 'recharts';
import { ALL_METRICS, ChartContextValue } from '../contexts/ChartContext';

type YAxesProps = ChartContextValue & {
  showYAxis?: boolean;
};

// I'd love for this to be a real component but Recharts has a strict component hierarchy
// See: https://github.com/recharts/recharts/issues/4017#issuecomment-1851099486
// - so the best we can do is use a function that returns JSX.
// Downside is we can't use hooks to access context, so that has to be passed in as arguments
const renderYAxes = (props: YAxesProps) => {
  let hasActiveAxis = false;

  // Have to mount an axis for each possible metric or it breaks animations
  // when metrics are toggled on/off
  return ALL_METRICS.map((metric, index) => {
    const isActive = props.metrics.includes(metric);
    const isFirstActiveAxis = isActive && !hasActiveAxis;
    if (isActive) {
      hasActiveAxis = true;
    }
    return (
      <YAxis
        key={`${metric}_axis`}
        includeHidden={false}
        orientation={isFirstActiveAxis ? 'left' : 'right'}
        yAxisId={index}
        domain={([dataMin, dataMax]) => {
          const relativeBottomPadding = (dataMax - dataMin) / 10;
          const relativeTopPadding = (dataMax - dataMin) / 20;
          return [dataMin - relativeBottomPadding, dataMax === dataMin ? dataMax + 1 : dataMax + relativeTopPadding];
        }}
        tickMargin={0}
        tickLine={false}
        hide={!isActive || props.metrics.length > 2 || props.showYAxis === undefined || !props.showYAxis}
      />
    );
  });
};

export default renderYAxes;
