// @ts-nocheck
import { XAxis, XAxisProps } from 'recharts';
import { ChartContextValue } from '../contexts/ChartContext';
import { startOfDay } from 'date-fns';
import { formatAxisTickDate } from './formatters';
import { getStrictDateRangeForComparisonRange } from './dateHelpers';

type CommonAxisProps = Pick<
  ChartContextValue,
  'chartDataSets' | 'chartData' | 'dateRanges' | 'comparisonRangeEnabled'
> & {
  tickInterval: number;
};
type SingleAxisProps = XAxisProps & CommonAxisProps & { index: number };
type RenderXAxesProps = CommonAxisProps & { comparisonRangeEnabled: boolean };
const renderXAxis = ({
  chartData,
  dateRanges,
  tickInterval,
  index,
  comparisonRangeEnabled,
  ...overrideProps
}: SingleAxisProps) => {
  const dateRange = dateRanges[index] || dateRanges[0];
  const strictDateRange = getStrictDateRangeForComparisonRange(dateRange, dateRanges[0]);
  const domainStart = startOfDay(strictDateRange.start).getTime();
  const domainEnd = startOfDay(strictDateRange.end).getTime();
  const isSingleDayRange = domainStart === domainEnd;

  return (
    <XAxis
      xAxisId={index}
      key={`x_axis_${index}`}
      allowDataOverflow // allow domain to clamp visible data
      dataKey='date'
      type='number'
      scale='time'
      includeHidden
      hide={index > 0 || (comparisonRangeEnabled && !isSingleDayRange)}
      orientation={index === 0 ? 'bottom' : 'top'}
      padding={{ left: 10, right: 10 }}
      ticks={chartData
        .filter((datum) => {
          const datumDate = new Date(datum.date);
          return startOfDay(datumDate).getTime() >= strictDateRange.start && datumDate.getTime() <= strictDateRange.end;
        })
        .map((datum) => datum.date)}
      domain={([dataMin]) => {
        // By default, domain end is the start of the last day
        // If using hourly intervals, we have to set it to the end of day
        let modifiedEndTime = domainEnd;
        if (isSingleDayRange) {
          const modifiedEndDate = new Date(domainEnd);
          modifiedEndDate.setHours(23);
          modifiedEndTime = modifiedEndDate.getTime();
        }
        return [dateRange.start ? domainStart : dataMin, modifiedEndTime];
      }}
      interval='preserveStartEnd'
      tickFormatter={formatAxisTickDate.bind(null, tickInterval)}
      {...overrideProps}
    />
  );
};

// I'd love for this to be a real component but Recharts has a strict component hierarchy
// See: https://github.com/recharts/recharts/issues/4017#issuecomment-1851099486
// - so the best we can do is use a function that returns JSX.
// Downside is we can't use hooks to access context, so that has to be passed in as arguments
const renderXAxes = (props: RenderXAxesProps) => {
  return props.chartDataSets.map((_chartDataSet, index) =>
    renderXAxis({
      ...props,
      index,
    }),
  );
};

export default renderXAxes;
