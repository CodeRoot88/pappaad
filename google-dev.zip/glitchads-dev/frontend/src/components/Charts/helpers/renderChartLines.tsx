import { ReactNode } from 'react';
import {
  ALL_METRICS,
  CHART_COLORS,
  ChartContextValue,
  ChartMetric,
  ChartMetricWithForecasts,
} from '../contexts/ChartContext';
import { LineChartProps } from '../components/LineChart';
import { Line, LineProps } from 'recharts';
import ChartLineLabel, { ChartLineLabelProps } from '../components/ChartLineLabel';
import { getMetricConfig } from './metricHelpers';

type GetLinePropsOptions = {
  dataSetIndex: number;
  isVisible: boolean;
  hasForecastData: boolean;
};

const DASHED_STROKE = '10 3';

export const getLineProps = (
  metric: ChartMetricWithForecasts,
  context: ChartContextValue,
  overrideProps: LineChartProps,
  options: GetLinePropsOptions,
) => {
  const { focusedMetric, metrics, forecastEnabled, clearFocusedMetric, setFocusedMetric } = context;
  const { dataSetIndex, isVisible = true, hasForecastData } = options;

  const isForecast = metric.endsWith('_forecast');
  const baseMetric = (isForecast ? metric.slice(0, -9) : metric) as ChartMetric;
  const isActive = metrics.includes(baseMetric);
  const isFocused = focusedMetric === baseMetric;
  const isAnimationActive = isActive && (!forecastEnabled || isForecast || !hasForecastData);
  const shouldRenderMetric = isActive || isFocused;
  const shouldRenderLine = shouldRenderMetric;
  const metricConfig = getMetricConfig(metric);
  let strokeOpacity = 1;
  const focusedMetricIsActive = focusedMetric && metrics.includes(focusedMetric);
  if (focusedMetricIsActive && !isFocused) {
    strokeOpacity = 0.5;
  } else if (isFocused && !isActive) {
    strokeOpacity = 0.25;
  }
  if (dataSetIndex > 0) {
    // Make comparison lines more transparent
    strokeOpacity = strokeOpacity / 4;
  }
  const onFocus = () => setFocusedMetric(baseMetric);

  const props: Omit<LineProps, 'ref'> = {
    ...metricConfig,
    connectNulls: true,
    id: isFocused && isActive ? 'focused-active' : undefined,
    type: overrideProps.lineCurve || 'monotone', // "bump" or "linear" are also possibilities
    legendType: 'none',
    dot: isFocused && isActive,
    label:
      isFocused && isActive
        ? (props: ChartLineLabelProps) => (
            <ChartLineLabel {...props} metricConfig={metricConfig} hasYAxisOffset={overrideProps.showYAxis} />
          )
        : undefined,
    strokeOpacity,
    dataKey: `${metric}_${dataSetIndex}`,
    strokeWidth: isFocused ? overrideProps.focusedLineWidth || 4 : overrideProps.lineWidth || 3,
    hide: !shouldRenderLine,
    isAnimationActive,
  };

  if (!isVisible) {
    // "Invisible" lines act as the interaction target, as they can have a wider width (hitbox) than the actual rendered lines
    props.onMouseEnter = onFocus;
    props.onMouseLeave = clearFocusedMetric;
    props.isAnimationActive = false;
    props.label = false;
    props.strokeWidth = 20;
    props.strokeOpacity = 0;
    props.dot = false;
    props.name = `${metric}_hidden`;
  }

  return props;
};

// I'd love for this to be a real component but Recharts has a strict component hierarchy
// See: https://github.com/recharts/recharts/issues/4017#issuecomment-1851099486
// - so the best we can do is use a function that returns JSX.
// Downside is we can't use hooks to access context, so that has to be passed in as arguments
const renderChartLinesForDataSet = (
  dataSetIndex: number,
  context: ChartContextValue,
  overrideLineProps: LineChartProps,
) => {
  const dataSet = context.chartDataSets[dataSetIndex];
  const hasForecastData = !!dataSet.length && new Date(dataSet[dataSet.length - 1].date).getTime() > Date.now();
  const forecastLines: JSX.Element[] = [];
  // Have to mount a Line for each possible metric or animations break when toggling new metrics on/off
  // Otherwise, changes to the lines mounted will shift indexes and lead to lines re-mounting and reanimating
  const historicLines = ALL_METRICS.map((metric, metricIndex) => {
    const renderLine = ({ isVisible, isForecast }: { isVisible: boolean; isForecast?: boolean }) => {
      const metricWithForecast = `${metric}${isForecast ? '_forecast' : ''}` as ChartMetricWithForecasts;
      const lineProps = getLineProps(metricWithForecast, context, overrideLineProps, {
        dataSetIndex,
        isVisible,
        hasForecastData,
      });
      const isComparison = dataSetIndex > 0;
      const strokeDashArray = isVisible && (isForecast || isComparison) ? DASHED_STROKE : undefined;
      return (
        <Line
          key={`${metricWithForecast}${dataSetIndex}${isVisible ? '' : '_hidden'}`}
          {...lineProps}
          stroke={CHART_COLORS[metricIndex] || '#222222'}
          xAxisId={dataSetIndex}
          yAxisId={metricIndex}
          strokeDasharray={strokeDashArray}
        />
      );
    };

    // If forecasts enabled, must render 2 separate lines to allow dashed appearance as separate line
    if (context.forecastEnabled && hasForecastData) {
      forecastLines.push(
        renderLine({ isVisible: true, isForecast: true }),
        renderLine({ isVisible: false, isForecast: true }),
      );
    }
    // Render 2 lines for each metric - one visible but not interactive, and one hidden but interactive
    return [renderLine({ isVisible: true }), renderLine({ isVisible: false })];
  });

  // Forecast lines must be at end of list, or toggling on/off will break line animations
  return forecastLines.length ? [...historicLines, ...forecastLines] : historicLines;
};

const renderChartLines = (context: ChartContextValue, overrideLineProps: LineChartProps) => {
  const lines: ReactNode[] = [];
  context.chartDataSets.forEach((_dataSet, dataSetIndex) => {
    const dateRangeForSet = context.dateRanges[dataSetIndex];

    if (!dateRangeForSet.comparisonType || context.comparisonRangeEnabled) {
      lines.push(...renderChartLinesForDataSet(dataSetIndex, context, overrideLineProps));
    }
  });

  return lines;
};

export default renderChartLines;
