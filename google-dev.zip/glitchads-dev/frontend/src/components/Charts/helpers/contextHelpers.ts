import { DEFAULT_COMPARISON_RANGE, DEFAULT_DATE_RANGE } from '../contexts/constants';
import { ChartState } from '../contexts/types';
import { cleanChartData } from './dataHelpers';

export const getChartContextDefaultState = (): ChartState => {
  const defaultState: ChartState = {
    metrics: ['cost_per_click', 'impressions', 'clicks', 'cost'],
    dateRanges: [{ ...DEFAULT_DATE_RANGE }, { ...DEFAULT_COMPARISON_RANGE }],
    forecastEnabled: false,
    comparisonRangeEnabled: false,
    loadingStates: [false, false],
    chartData: [],
    chartDataSets: [[], []],
  };
  defaultState.chartData = cleanChartData(
    defaultState.chartDataSets,
    defaultState.dateRanges,
    defaultState.comparisonRangeEnabled,
  );
  return defaultState;
};
