import { addDays, endOfDay, format, milliseconds, startOfDay, subDays } from 'date-fns';
import { ALL_METRICS, ChartMetric, DateRange, RawChartData, RawChartDatum } from './contexts/ChartContext';
import { getStrictDateRange } from './helpers/dateHelpers';
import { getDataIntervalFromRange } from './helpers/dataHelpers';

const formatToRaw = (date: Date) => format(date, 'yyyy-MM-dd');
const currentDate = startOfDay(new Date());
const OLDEST_TIMESTAMP = new Date('01/01/2016').getTime();

type MetricRandomizerConfig = {
  upperLimit: number;
  includeDecimals: boolean;
  variance: number;
};
const METRIC_RANDOMIZER_CONFIGS: Record<(typeof ALL_METRICS)[number], MetricRandomizerConfig> = {
  cost_per_click: {
    variance: 2,
    upperLimit: 4,
    includeDecimals: true,
  },
  cost: {
    variance: 2,
    upperLimit: 20,
    includeDecimals: true,
  },
  conversions: {
    variance: 4,
    upperLimit: 100,
    includeDecimals: false,
  },
  clicks: {
    variance: 2,
    upperLimit: 500,
    includeDecimals: false,
  },
  impressions: {
    variance: 2,
    upperLimit: 10000,
    includeDecimals: false,
  },
};

export const getDummyChartData = (dateRange: DateRange, smoothingAmount: number = 3) => {
  const strictRange = getStrictDateRange(dateRange);
  const rangeInterval = getDataIntervalFromRange(strictRange);
  const dateHasTimestamp = rangeInterval === milliseconds({ hours: 1 });

  const chartData: RawChartData = [];

  const endCutOff = endOfDay(new Date()).getTime() === strictRange.end ? Date.now() : strictRange.end;

  const lastRandomValueForMetric: Partial<Record<ChartMetric, number>> = {};

  for (let dateTime = strictRange.start; dateTime <= endCutOff; dateTime += rangeInterval) {
    if (dateTime < OLDEST_TIMESTAMP) {
      continue;
    }
    const datum: RawChartDatum = {
      date: format(dateTime, dateHasTimestamp ? 'yyy-MM-dd, HH:mm' : 'yyyy-MM-dd'),
    };
    ALL_METRICS.forEach((metric) => {
      const { variance, upperLimit, includeDecimals } = METRIC_RANDOMIZER_CONFIGS[metric];
      if (!lastRandomValueForMetric[metric]) {
        lastRandomValueForMetric[metric] = upperLimit / 2;
      }
      let randomValue = Math.random() * upperLimit;
      const previousValue = lastRandomValueForMetric[metric];

      for (let smoothingIteration = 0; smoothingIteration < smoothingAmount; smoothingIteration++) {
        let sum = previousValue;
        if (!sum) {
          sum = 0;
        }
        let partsCount = 1;
        for (let varianceIteration = 0; varianceIteration < variance; varianceIteration++) {
          sum += randomValue;
          partsCount++;
        }
        randomValue = sum / partsCount;
      }
      lastRandomValueForMetric[metric] = randomValue;
      const cappedValue = includeDecimals ? parseFloat(randomValue.toFixed(2)) : Math.round(randomValue);
      datum[metric] = cappedValue;
    });
    chartData.push(datum);
  }

  return chartData;
};

export const sampleChartData: RawChartData = [
  {
    date: '2019-01-01',
    clicks: 88,
    impressions: 8911,
    cost_per_click: 0.03,
    cost: 3.02,
  },
  {
    date: '2019-01-02',
    clicks: 0,
    impressions: 0,
    cost_per_click: 0,
    cost: 0,
  },
  {
    date: '2019-01-03',
    clicks: 0,
    impressions: 0,
    cost_per_click: 0,
    cost: 0,
  },
  {
    date: '2019-01-04',
    clicks: 76,
    impressions: 2692,
    cost_per_click: 0.01,
    cost: 0.64,
  },
  {
    date: '2019-01-05',
    clicks: 378,
    impressions: 19586,
    cost_per_click: 0.01,
    cost: 5.47,
  },
  {
    date: '2019-01-06',
    clicks: 179,
    impressions: 10169,
    cost_per_click: 0.02,
    cost: 3.05,
  },
  {
    date: '2019-01-07',
    clicks: 151,
    impressions: 8027,
    cost_per_click: 0.02,
    cost: 3.1,
  },
  {
    date: '2019-01-08',
    clicks: 229,
    impressions: 12329,
    cost_per_click: 0.01,
    cost: 3.03,
  },
  {
    date: '2019-01-09',
    clicks: 155,
    impressions: 6998,
    cost_per_click: 0.02,
    cost: 2.95,
  },
  {
    date: '2019-01-10',
    clicks: 234,
    impressions: 10810,
    cost_per_click: 0.01,
    cost: 3.04,
  },
  {
    date: '2019-01-11',
    clicks: 163,
    impressions: 6295,
    cost_per_click: 0.02,
    cost: 3.02,
  },
  {
    date: '2019-01-12',
    clicks: 124,
    impressions: 4021,
    cost_per_click: 0.02,
    cost: 2.98,
  },
  {
    date: '2019-01-13',
    clicks: 143,
    impressions: 4152,
    cost_per_click: 0.02,
    cost: 2.98,
  },
  {
    date: '2019-01-14',
    clicks: 207,
    impressions: 6466,
    cost_per_click: 0.03,
    cost: 5.32,
  },
  {
    date: '2019-01-15',
    clicks: 196,
    impressions: 5262,
    cost_per_click: 0.02,
    cost: 4.23,
  },
  {
    date: '2019-01-16',
    clicks: 242,
    impressions: 5886,
    cost_per_click: 0.02,
    cost: 4.01,
  },
  {
    date: '2019-01-17',
    clicks: 288,
    impressions: 8169,
    cost_per_click: 0.01,
    cost: 3.77,
  },
  {
    date: '2019-01-18',
    clicks: 3,
    impressions: 129,
    cost_per_click: 0.01,
    cost: 0.03,
  },
  {
    date: '2019-01-19',
    clicks: 731,
    impressions: 20606,
    cost_per_click: 0.01,
    cost: 8.14,
  },
  {
    date: '2019-01-20',
    clicks: 326,
    impressions: 7544,
    cost_per_click: 0.01,
    cost: 3.73,
  },
  {
    date: '2019-01-21',
    clicks: 310,
    impressions: 8669,
    cost_per_click: 0.01,
    cost: 4.3,
  },
  {
    date: '2019-01-22',
    clicks: 157,
    impressions: 3801,
    cost_per_click: 0.01,
    cost: 1.84,
  },
  {
    date: '2019-01-23',
    clicks: 454,
    impressions: 11659,
    cost_per_click: 0.01,
    cost: 6.33,
  },
  {
    date: '2019-01-24',
    clicks: 199,
    impressions: 4584,
    cost_per_click: 0.01,
    cost: 2.36,
  },
  {
    date: '2019-01-25',
    clicks: 0,
    impressions: 7,
    cost_per_click: 0,
    cost: 0,
  },
  {
    date: '2019-01-26',
    clicks: 5,
    impressions: 211,
    cost_per_click: 0.01,
    cost: 0.07,
  },
  {
    date: '2019-01-27',
    clicks: 157,
    impressions: 7792,
    cost_per_click: 0.01,
    cost: 1.82,
  },
  {
    date: '2019-01-28',
    clicks: 414,
    impressions: 12690,
    cost_per_click: 0.01,
    cost: 5.38,
  },
  {
    date: '2019-01-29',
    clicks: 295,
    impressions: 8537,
    cost_per_click: 0.02,
    cost: 4.95,
  },
  {
    date: '2019-01-30',
    clicks: 338,
    impressions: 8596,
    cost_per_click: 0.01,
    cost: 4.82,
  },
  {
    date: '2019-01-31',
    clicks: 417,
    impressions: 12130,
    cost_per_click: 0.01,
    cost: 5.09,
  },
  {
    date: '2019-02-01',
    clicks: 471,
    impressions: 15251,
    cost_per_click: 0.01,
    cost: 5.47,
  },
  {
    date: '2019-02-02',
    clicks: 417,
    impressions: 14239,
    cost_per_click: 0.01,
    cost: 5.51,
  },
  {
    date: '2019-02-03',
    clicks: 88,
    impressions: 2531,
    cost_per_click: 0.01,
    cost: 1.08,
  },
  {
    date: '2019-02-04',
    clicks: 795,
    impressions: 25746,
    cost_per_click: 0.01,
    cost: 9.99,
  },
  {
    date: '2019-02-05',
    clicks: 58,
    impressions: 1672,
    cost_per_click: 0.01,
    cost: 0.69,
  },
  {
    date: '2019-02-06',
    clicks: 338,
    impressions: 9985,
    cost_per_click: 0.01,
    cost: 4.69,
  },
  {
    date: '2019-02-07',
    clicks: 156,
    impressions: 5388,
    cost_per_click: 0.02,
    cost: 2.52,
  },
  {
    date: '2019-02-08',
    clicks: 147,
    impressions: 4040,
    cost_per_click: 0.02,
    cost: 2.5,
  },
  {
    date: '2019-02-09',
    clicks: 173,
    impressions: 5344,
    cost_per_click: 0.01,
    cost: 2.51,
  },
  {
    date: '2019-02-10',
    clicks: 158,
    impressions: 4776,
    cost_per_click: 0.02,
    cost: 2.49,
  },
  {
    date: '2019-02-11',
    clicks: 91,
    impressions: 2377,
    cost_per_click: 0.01,
    cost: 1.2,
  },
  {
    date: '2019-02-12',
    clicks: 295,
    impressions: 8170,
    cost_per_click: 0.01,
    cost: 3.94,
  },
  {
    date: '2019-02-13',
    clicks: 44,
    impressions: 1352,
    cost_per_click: 0.01,
    cost: 0.52,
  },
  {
    date: '2019-02-14',
    clicks: 280,
    impressions: 7945,
    cost_per_click: 0.01,
    cost: 3.51,
  },
  {
    date: '2019-02-15',
    clicks: 264,
    impressions: 7319,
    cost_per_click: 0.01,
    cost: 3.48,
  },
  {
    date: '2019-02-16',
    clicks: 202,
    impressions: 4347,
    cost_per_click: 0.01,
    cost: 2.51,
  },
  {
    date: '2019-02-17',
    clicks: 195,
    impressions: 4932,
    cost_per_click: 0.01,
    cost: 2.5,
  },
  {
    date: '2019-02-18',
    clicks: 134,
    impressions: 1772,
    cost_per_click: 0.01,
    cost: 1.43,
  },
  {
    date: '2019-02-19',
    clicks: 336,
    impressions: 4912,
    cost_per_click: 0.01,
    cost: 3.72,
  },
  {
    date: '2019-02-20',
    clicks: 88,
    impressions: 1091,
    cost_per_click: 0.01,
    cost: 0.98,
  },
  {
    date: '2019-02-21',
    clicks: 321,
    impressions: 4137,
    cost_per_click: 0.01,
    cost: 3.97,
  },
  {
    date: '2019-02-22',
    clicks: 206,
    impressions: 2543,
    cost_per_click: 0.01,
    cost: 2.46,
  },
  {
    date: '2019-02-23',
    clicks: 197,
    impressions: 2637,
    cost_per_click: 0.01,
    cost: 2.46,
  },
  {
    date: '2019-02-24',
    clicks: 217,
    impressions: 3486,
    cost_per_click: 0.01,
    cost: 2.47,
  },
  {
    date: '2019-02-25',
    clicks: 211,
    impressions: 3095,
    cost_per_click: 0.01,
    cost: 2.6,
  },
  {
    date: '2019-02-26',
    clicks: 209,
    impressions: 3156,
    cost_per_click: 0.01,
    cost: 2.38,
  },
  {
    date: '2019-02-27',
    clicks: 246,
    impressions: 3959,
    cost_per_click: 0.01,
    cost: 2.67,
  },
  {
    date: '2019-02-28',
    clicks: 44,
    impressions: 1241,
    cost_per_click: 0.01,
    cost: 0.58,
  },
  {
    date: formatToRaw(subDays(currentDate, 35)),
    clicks: 3,
    impressions: 15,
    conversions: 0,
    cost_per_click: 9.4,
    cost: 28.2,
  },
  {
    date: formatToRaw(subDays(currentDate, 30)),
    clicks: 2,
    impressions: 8,
    conversions: 0,
    cost_per_click: 9.905,
    cost: 19.81,
  },
  {
    date: formatToRaw(subDays(currentDate, 25)),
    clicks: 2,
    impressions: 33,
    conversions: 0,
    cost_per_click: 9.99,
    cost: 19.98,
  },
  {
    date: formatToRaw(subDays(currentDate, 20)),
    clicks: 3,
    impressions: 30,
    conversions: 0,
    cost_per_click: 7.8933333333333335,
    cost: 23.68,
  },
  {
    date: formatToRaw(subDays(currentDate, 15)),
    clicks: 2,
    impressions: 50,
    conversions: 0,
    cost_per_click: 9.875,
    cost: 19.75,
  },
  {
    date: formatToRaw(subDays(currentDate, 10)),
    clicks: 0,
    impressions: 16,
    conversions: 0,
    cost_per_click: 0,
    cost: 0,
  },
  {
    date: formatToRaw(subDays(currentDate, 5)),
    clicks: 15,
    impressions: 278,
    conversions: 0,
    cost_per_click: 2.2393333333333336,
    cost: 33.59,
  },
  {
    clicks: 2780,
    impressions: 3908,
    cost_per_click: 0.03,
    date: formatToRaw(currentDate),
  },
  {
    clicks: 2980,
    impressions: 2008,
    cost_per_click: 0.02,
    date: formatToRaw(addDays(currentDate, 5)),
  },
  {
    clicks: 3080,
    impressions: 2508,
    cost_per_click: 0.1,
    date: formatToRaw(addDays(currentDate, 10)),
  },
  {
    clicks: 3380,
    impressions: 2208,
    cost_per_click: 0.01,
    date: formatToRaw(addDays(currentDate, 15)),
  },
  {
    clicks: 2780,
    impressions: 2508,
    cost_per_click: 0.01,
    date: formatToRaw(addDays(currentDate, 20)),
  },
  {
    clicks: 2280,
    impressions: 2908,
    cost_per_click: 0.02,
    date: formatToRaw(addDays(currentDate, 25)),
  },
  {
    clicks: 2380,
    impressions: 3008,
    cost_per_click: 0.02,
    date: formatToRaw(addDays(currentDate, 30)),
  },
];
// export const chartData: ChartData = [
//   {
//     clicks: 6000,
//     impressions: 1400,
//     cost_per_click: 0.01,
//     date: currentDate - MILLIS_IN_DAY * 7,
//   },
//   {
//     clicks: 4000,
//     impressions: 2400,
//     cost_per_click: 0.02,
//     date: currentDate - MILLIS_IN_DAY * 6,
//   },
//   {
//     clicks: 5500,
//     // impressions: 2000,
//     cost_per_click: 0.01,
//     date: currentDate - MILLIS_IN_DAY * 5,
//   },
//   {
//     clicks: 4500,
//     impressions: 2100,
//     cost_per_click: 0.02,
//     date: currentDate - MILLIS_IN_DAY * 4,
//   },
//   {
//     clicks: 2400,
//     impressions: 2400,
//     cost_per_click: 2400,
//     date: currentDate - MILLIS_IN_DAY * 3,
//   },
//   {
//     clicks: 3000,
//     impressions: 1398,
//     cost_per_click: 2210,
//     date: currentDate - MILLIS_IN_DAY * 2,
//   },
//   {
//     clicks: 2000,
//     impressions: 9800,
//     cost_per_click: 2290,
//     date: currentDate - MILLIS_IN_DAY * 1,
//   },
//   {
//     clicks: 2780,
//     impressions: 3908,
//     cost_per_click: 2000,
//     clicks_forecast: 2780,
//     impressions_forecast: 3908,
//     cpc_forecast: 2000,
//     date: currentDate,
//   },
//   {
//     clicks_forecast: 2980,
//     impressions_forecast: 2008,
//     cpc_forecast: 1890,
//     date: currentDate + MILLIS_IN_DAY * 5,
//   },
//   {
//     clicks_forecast: 3080,
//     impressions_forecast: 2508,
//     cpc_forecast: 2390,
//     date: currentDate + MILLIS_IN_DAY * 10,
//   },
//   {
//     clicks_forecast: 3380,
//     impressions_forecast: 2208,
//     cpc_forecast: 3490,
//     date: currentDate + MILLIS_IN_DAY * 15,
//   },
//   {
//     clicks_forecast: 2780,
//     impressions_forecast: 2508,
//     cpc_forecast: 3690,
//     date: currentDate + MILLIS_IN_DAY * 20,
//   },
//   {
//     clicks_forecast: 2280,
//     impressions_forecast: 2908,
//     cpc_forecast: 3890,
//     date: currentDate + MILLIS_IN_DAY * 25,
//   },
//   {
//     clicks_forecast: 2380,
//     impressions_forecast: 3008,
//     cpc_forecast: 4290,
//     date: currentDate + MILLIS_IN_DAY * 30,
//   },
// ];
