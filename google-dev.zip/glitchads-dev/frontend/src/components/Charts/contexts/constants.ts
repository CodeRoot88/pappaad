import { milliseconds, startOfDay, subDays } from 'date-fns';
import {
  ChartContextActionType,
  ChartContextValue,
  ChartMetric,
  ChartMetricConfig,
  ChartMetricType,
  DateRange,
} from './types';

export const DEFAULT_INTERVAL_MS = milliseconds({ days: 1 });
export const FORECAST_LEADING_DAYS = 7;
export const FORECAST_DAYS = 30;
export const DEFAULT_DATE_RANGE_DAYS = 30;
export const CHART_LINE_ANIMATION_DELAY = 500;
export const CHART_DRAW_ANIMATION_TIME = 900;
export const FORECAST_DRAW_ANIMATION_DELAY = CHART_LINE_ANIMATION_DELAY;

export const ALL_METRICS = ['clicks', 'impressions', 'cost_per_click', 'cost', 'conversions'] as const;

export const METRIC_TYPES = ['currency', 'number'] as const;
// Affects colors of lines, metrics, and date-ranges
export const CHART_COLORS = ['#3182ce', '#E29A2C', '#E08A9A', '#49BB70', '#770c56'];

// Earliest possible date for the date range picker. Preferably, this would be overridden by actual account data
export const ALL_TIME_START_DATE = new Date(0);

const baseMetricConfig = {
  animationBegin: CHART_LINE_ANIMATION_DELAY,
  animationDuration: CHART_DRAW_ANIMATION_TIME,
  yAxisId: 0,
  type: 'number' as ChartMetricType,
  isAverage: false,
};

export const METRIC_LOOKUP: Record<ChartMetric, ChartMetricConfig> = {
  cost_per_click: {
    ...baseMetricConfig,
    label: 'Average CPC',
    type: 'currency',
    isAverage: true,
  },
  impressions: {
    ...baseMetricConfig,
    label: 'Impressions',
    yAxisId: 1,
  },
  clicks: {
    ...baseMetricConfig,
    label: 'Clicks',
  },
  conversions: {
    ...baseMetricConfig,
    label: 'Conversions',
  },
  cost: {
    ...baseMetricConfig,
    label: 'Cost',
    type: 'currency',
  },
};
export const UNKNOWN_METRIC_CONFIG = { ...baseMetricConfig };

// Allows checking if an action should re-enable chart animations
export const ANIMATING_ACTIONS: ChartContextActionType[] = [
  'setDateRange',
  'setChartData',
  'addMetric',
  'removeMetric',
  'toggleForecast',
];

export const DEFAULT_DATE_RANGE: DateRange = {
  start: startOfDay(subDays(new Date(), DEFAULT_DATE_RANGE_DAYS)).getTime(),
};
export const DEFAULT_COMPARISON_RANGE: DateRange = {
  comparisonType: 'period',
};

const noop = () => {};
export const CHART_CONTEXT_DEFAULT_VALUE: Partial<ChartContextValue> = {
  loading: false,
  setFocusedMetric: noop,
  clearChartData: noop,
  clearFocusedMetric: noop,
  addMetric: noop,
  removeMetric: noop,
  setLoading: noop,
  setDateRange: noop,
  toggleForecast: noop,
  toggleComparisonRange: noop,
  setChartData: noop,
};
