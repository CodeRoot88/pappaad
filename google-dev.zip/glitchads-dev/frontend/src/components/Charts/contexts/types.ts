import { ALL_METRICS, METRIC_TYPES } from './constants';

export type ChartMetric = (typeof ALL_METRICS)[number];
export type ChartMetricType = (typeof METRIC_TYPES)[number];
export type ChartMetricWithForecasts = ChartMetric | `${ChartMetric}_forecast`;
export type ChartMetricDataAccessor = `${ChartMetricWithForecasts}_${number}`;

export type RawChartDatum = {
  [key in ChartMetric]?: number;
} & { date: string };
export type ChartDatum = {
  [key in ChartMetricDataAccessor]?: number;
} & { date: number };

export type RawChartData = RawChartDatum[];
export type ChartData = ChartDatum[];

export type ChartMetricConfig = {
  label: string;
  type: ChartMetricType;
  yAxisId: string | number;
  animationBegin?: number;
  animationDuration?: number;
  isAverage: boolean;
};

export type ComparisonType = 'period' | 'year' | 'custom';
export type DateRange = {
  // Start time optional to allow "all time"
  start?: number;
  // End time optional to fall back to "current time"
  end?: number;
  // Persist chosen start/end dates when temporarily overriding it (i.e. when enabling forecast)
  persistedStart?: number;
  persistedEnd?: number;
  // If a range is for comparing, store what type of comparison it is
  comparisonType?: ComparisonType;
};
export type StrictDateRange = {
  start: number;
  end: number;
};

export type ChartState = {
  chartData: ChartData;
  chartDataSets: RawChartData[];
  loadingStates: boolean[];
  dateRanges: DateRange[];
  metrics: ChartMetric[];
  focusedMetric?: ChartMetric;
  forecastEnabled: boolean;
  comparisonRangeEnabled: boolean;
};

export type ChartContextValue = Omit<ChartState, 'loadingStates'> & {
  loading: boolean;
  addMetric: (metric: ChartMetric) => void;
  clearChartData: (dataIndex: number) => void;
  removeMetric: (metric: ChartMetric) => void;
  setDateRange: (rangeIndex: number, range: DateRange) => void;
  setFocusedMetric: (metric: ChartMetric) => void;
  clearFocusedMetric: () => void;
  toggleForecast: (shouldBeEnabled?: boolean) => void;
  toggleComparisonRange: (shouldBeEnabled?: boolean) => void;
  setChartData: (dataIndex: number, chartData: RawChartData) => void;
  setLoading: (dataIndex: number, isLoading: boolean) => void;
};
export type ChartContextActionType =
  | 'setDateRange'
  | 'setChartData'
  | 'addMetric'
  | 'removeMetric'
  | 'setFocusedMetric'
  | 'clearFocusedMetric'
  | 'toggleComparisonRange'
  | 'toggleForecast'
  | 'setLoading'
  | 'clearChartData';

export type ChartContextAction = {
  type: ChartContextActionType;
  payload?: any;
};
