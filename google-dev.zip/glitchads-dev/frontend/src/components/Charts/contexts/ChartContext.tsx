import { createContext } from 'react';
import { ChartContextValue } from './types';
import { CHART_CONTEXT_DEFAULT_VALUE } from './constants';
import { getChartContextDefaultState } from '../helpers/contextHelpers';
export * from './types';
export * from './constants';

const ChartContext = createContext<ChartContextValue>({
  ...CHART_CONTEXT_DEFAULT_VALUE,
  ...getChartContextDefaultState(),
} as ChartContextValue);

export default ChartContext;
