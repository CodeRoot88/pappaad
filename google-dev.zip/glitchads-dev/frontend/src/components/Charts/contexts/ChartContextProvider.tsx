import { PropsWithChildren, Reducer, useCallback, useMemo, useReducer } from 'react';
import ChartContext, {
  ChartContextAction,
  ChartContextValue,
  ChartMetric,
  ChartState,
  DateRange,
  FORECAST_DAYS,
  FORECAST_LEADING_DAYS,
  RawChartData,
  DEFAULT_DATE_RANGE,
} from './ChartContext';
import { cleanChartData } from '../helpers/dataHelpers';
import { addDays, startOfDay, subDays } from 'date-fns';
import ChartDataLoader from '../components/ChartDataLoader';
import { dateRangesEqual, getComparisonRange } from '../helpers/dateHelpers';
import { getChartContextDefaultState } from '../helpers/contextHelpers';

const chartContextReducer: Reducer<ChartState, ChartContextAction> = (prevState, action) => {
  // Create shallow copy now to mitigate risk of mutation
  let newState = {
    ...prevState,
    chartDataSets: [...prevState.chartDataSets],
    dateRanges: [...prevState.dateRanges],
    loadingStates: [...prevState.loadingStates],
  };

  switch (action.type) {
    case 'toggleForecast':
      newState.forecastEnabled = action.payload === undefined ? !prevState.forecastEnabled : action.payload;
      if (newState.forecastEnabled && !prevState.forecastEnabled) {
        newState.comparisonRangeEnabled = false;
        // When enabling forecast, adjust start/end times and persist previous values
        newState.dateRanges[0] = {
          start: startOfDay(subDays(new Date(), FORECAST_LEADING_DAYS)).getTime(),
          end: startOfDay(addDays(new Date(), FORECAST_DAYS)).getTime(),
          persistedStart: prevState.dateRanges[0].start,
          persistedEnd: prevState.dateRanges[0].end,
        };
      } else if (!newState.forecastEnabled && prevState.forecastEnabled) {
        const defaultDateRange = DEFAULT_DATE_RANGE;
        // When disabling forecast, restore previous start/end values
        newState.dateRanges[0] = {
          start: prevState.dateRanges[0].persistedStart || defaultDateRange.start,
          end: prevState.dateRanges[0].persistedEnd || defaultDateRange.end,
        };
      }
      break;
    case 'toggleComparisonRange':
      newState.comparisonRangeEnabled =
        action.payload === undefined ? !prevState.comparisonRangeEnabled : action.payload;
      break;
    case 'setFocusedMetric':
      newState.focusedMetric = action.payload;
      break;
    case 'clearFocusedMetric':
      newState.focusedMetric = undefined;
      break;
    case 'addMetric':
      if (newState.metrics.includes(action.payload)) {
        // Already in list, skip this action and use old state
        newState = prevState;
      } else {
        newState.metrics = [...newState.metrics, action.payload];
      }
      break;
    case 'removeMetric':
      if (!newState.metrics.includes(action.payload)) {
        // Not in list, skip this action and use old state
        newState = prevState;
      } else {
        newState.metrics = newState.metrics.filter((metric) => metric !== action.payload);
      }
      break;
    case 'setDateRange':
      const { index: modifiedIndex, value: newDateRange } = action.payload;
      // Shallow copy at the start to avoid mutations
      newState.dateRanges = [...newState.dateRanges];
      newState.dateRanges[modifiedIndex] = {
        ...newState.dateRanges[modifiedIndex],
        ...newDateRange,
      };
      if (dateRangesEqual(newState.dateRanges[modifiedIndex], prevState.dateRanges[modifiedIndex])) {
        newState = prevState;
        break;
      }

      if (modifiedIndex > 0) {
        const prevRange = prevState.dateRanges[modifiedIndex];
        const newRange = newState.dateRanges[modifiedIndex];
        if (
          newRange.comparisonType === 'custom' &&
          prevRange.comparisonType !== 'custom' &&
          !(newRange.start || newRange.end)
        ) {
          // If switching to custom, and we don't have specified date ranges, find some based on last range type
          const newComparisonRange = getComparisonRange(prevRange.comparisonType!, {
            start: newRange.start || DEFAULT_DATE_RANGE.start!,
            end: newRange.end || new Date().getTime(),
          });
          newState.dateRanges[modifiedIndex] = {
            ...newRange,
            ...newComparisonRange,
          };
        }
      } else if (!newState.dateRanges[0].start) {
        newState.comparisonRangeEnabled = false;
      }

      break;
    case 'setChartData':
      newState.chartDataSets[action.payload.index] = action.payload.value as RawChartData;
      newState.chartData = cleanChartData(newState.chartDataSets, newState.dateRanges, newState.comparisonRangeEnabled);
      break;
    case 'setLoading':
      newState.loadingStates[action.payload.index] = action.payload.value;
      if (newState.loadingStates[action.payload.index] === prevState.loadingStates[action.payload.index]) {
        newState = prevState;
      }
      break;
    case 'clearChartData':
      const hadData = !!newState.chartDataSets[action.payload].length;
      if (hadData) {
        newState.chartDataSets[action.payload] = [];
        newState.chartData = cleanChartData(
          newState.chartDataSets,
          newState.dateRanges,
          newState.comparisonRangeEnabled,
        );
      } else {
        newState = prevState;
      }
      break;
    default:
      // If no valid action found, return old reference
      newState = prevState;
  }

  // For some reason, recharts doesn't animate changes to the graph unless the data set changes
  // If we have changed ANYTHING (otherwise, we'd revert to previous reference) in state, shallow copy the data set to trigger redraw
  // if (newState !== prevState) {
  //   newState.chartData = [...newState.chartData];
  // }

  return newState;
};

export type ChartContextProviderProps = PropsWithChildren & {
  campaignIds: string[];
  forecastEnabled?: boolean;
  dateRange?: Pick<DateRange, 'start' | 'end'>;
};

const getInitialReducerState = (props: ChartContextProviderProps) => {
  const initialState = getChartContextDefaultState();

  if (props.forecastEnabled !== undefined) {
    initialState.forecastEnabled = true;
  }
  if (props.dateRange) {
    initialState.dateRanges[0] = props.dateRange;
  }

  return initialState;
};

const ChartContextProvider = (props: ChartContextProviderProps) => {
  const [
    {
      comparisonRangeEnabled,
      chartData,
      chartDataSets,
      dateRanges,
      focusedMetric,
      forecastEnabled,
      loadingStates,
      metrics,
    },
    dispatch,
  ] = useReducer(chartContextReducer, props, getInitialReducerState);

  const addMetric = useCallback((metric: ChartMetric) => dispatch({ type: 'addMetric', payload: metric }), []);
  const clearFocusedMetric = useCallback(() => dispatch({ type: 'clearFocusedMetric' }), []);
  const removeMetric = useCallback((metric: ChartMetric) => dispatch({ type: 'removeMetric', payload: metric }), []);
  const setChartData = useCallback((dataSetIndex: number, chartData: RawChartData) => {
    dispatch({
      type: 'setChartData',
      payload: { index: dataSetIndex, value: chartData },
    });
  }, []);
  const setDateRange = useCallback(
    (dataSetIndex: number, range: DateRange) =>
      dispatch({
        type: 'setDateRange',
        payload: { index: dataSetIndex, value: range },
      }),
    [],
  );
  const setLoading = useCallback((dataSetIndex: number, isLoading: boolean) => {
    dispatch({
      type: 'setLoading',
      payload: { index: dataSetIndex, value: isLoading },
    });
  }, []);
  const clearChartData = useCallback((dataIndex: number) => {
    dispatch({ type: 'clearChartData', payload: dataIndex });
  }, []);
  const setFocusedMetric = useCallback(
    (metric: ChartMetric) => dispatch({ type: 'setFocusedMetric', payload: metric }),
    [],
  );
  const toggleComparisonRange = useCallback((shouldBeEnabled?: boolean) => {
    dispatch({ type: 'toggleComparisonRange', payload: shouldBeEnabled });
  }, []);
  const toggleForecast = useCallback((shouldBeEnabled?: boolean) => {
    dispatch({ type: 'toggleForecast', payload: shouldBeEnabled });
  }, []);

  const contextValue = useMemo<ChartContextValue>(
    () => ({
      comparisonRangeEnabled,
      chartDataSets,
      chartData: [...chartData], // have to create new reference for recharts to animate chart changes
      focusedMetric,
      forecastEnabled,
      metrics,
      dateRanges,
      loading: loadingStates.some(Boolean),
      addMetric,
      clearChartData,
      clearFocusedMetric,
      removeMetric,
      setChartData,
      setDateRange,
      setFocusedMetric,
      setLoading,
      toggleComparisonRange,
      toggleForecast,
    }),
    [
      comparisonRangeEnabled,
      chartDataSets,
      chartData,
      clearChartData,
      dateRanges,
      focusedMetric,
      forecastEnabled,
      loadingStates,
      metrics,
      addMetric,
      clearFocusedMetric,
      removeMetric,
      setChartData,
      setDateRange,
      setFocusedMetric,
      setLoading,
      toggleComparisonRange,
      toggleForecast,
    ],
  );

  return (
    <ChartContext.Provider value={contextValue}>
      <ChartDataLoader campaignIds={props.campaignIds} />
      {props.children}
    </ChartContext.Provider>
  );
};

export default ChartContextProvider;
