import { useContext, useEffect, useMemo, useRef } from 'react';
import ChartContext, { ALL_TIME_START_DATE, RawChartData, StrictDateRange } from '../contexts/ChartContext';
import { getDummyChartData } from '../sampleChartData';
import { endOfDay } from 'date-fns';
import { getComparisonRange } from '../helpers/dateHelpers';

export const useMemoizedArray = (arr: any[]) => {
  const arrRef = useRef(arr);
  const arrayChanged = arrRef.current.length !== arr.length || !arr.every((arrEl) => arrRef.current.includes(arrEl));

  useEffect(() => {
    if (arrayChanged) {
      arrRef.current = arr;
    }
  }, [arrayChanged, arr]);

  return arrayChanged ? arr : arrRef.current;
};

export type LoadChartDataOptions = {
  dateRange: StrictDateRange;
  comparisonRange?: StrictDateRange;
};

// Dummy function - takes array of campaign IDs and context params to trigger new data load
const loadChartData = async (options: LoadChartDataOptions): Promise<RawChartData> => {
  return new Promise((resolve) =>
    setTimeout(() => {
      const data = getDummyChartData(options.dateRange, 10);
      resolve(data);
    }, 1000),
  );
};

export type ChartDataLoaderProps = {
  campaignIds: string[];
};

const DEBOUNCE_MS = 700;

// Component that returns null and does the job of loading the data in response to conext changing
const ChartDataLoader = (props: ChartDataLoaderProps) => {
  const memoizedCampaignIds = useMemoizedArray(props.campaignIds);
  const { comparisonRangeEnabled, dateRanges, clearChartData, setChartData, setLoading } = useContext(ChartContext);
  const primaryDateRange = dateRanges[0];
  const strictPrimaryDateRange = useMemo(
    () => ({
      start: primaryDateRange.start || ALL_TIME_START_DATE.getTime(),
      end: primaryDateRange.end || endOfDay(new Date()).getTime(),
    }),
    [primaryDateRange.start, primaryDateRange.end],
  );
  const comparisonRange = dateRanges[1];
  const strictComparisonRange = useMemo(() => {
    let strictComparisonRange: StrictDateRange | undefined = undefined;
    if (comparisonRange.comparisonType === 'custom') {
      strictComparisonRange = {
        start: comparisonRange.start!,
        end: comparisonRange.end!,
      };
    } else {
      strictComparisonRange = getComparisonRange(comparisonRange.comparisonType!, {
        start: strictPrimaryDateRange.start,
        end: strictPrimaryDateRange.end,
      });
    }
    return strictComparisonRange;
  }, [
    comparisonRange.end,
    comparisonRange.start,
    comparisonRange.comparisonType,
    strictPrimaryDateRange.start,
    strictPrimaryDateRange.end,
  ]);

  // When one of the key settings for querying data changes, trigger a data load (with debouncing and cancellation)
  useEffect(() => {
    let cancel = false;
    let loadingStateSet = false;
    let timeout: null | ReturnType<typeof setTimeout> = null;

    const loadData = async () => {
      if (memoizedCampaignIds.length) {
        setLoading(0, true);
        loadingStateSet = true;
        const data = await loadChartData({
          dateRange: strictPrimaryDateRange,
        });
        if (!cancel) {
          timeout = null;
          loadingStateSet = false;
          setChartData(0, data);
          setLoading(0, false);
        }
      } else {
        clearChartData(0);
      }
    };
    timeout = setTimeout(loadData, DEBOUNCE_MS);

    return () => {
      if (loadingStateSet) {
        setLoading(0, false);
      }
      if (timeout) {
        clearTimeout(timeout);
      }
      cancel = true;
    };
  }, [strictPrimaryDateRange, memoizedCampaignIds, clearChartData, setChartData, setLoading]);

  // Trigger separate loader for comparison data
  useEffect(() => {
    let cancel = false;
    let loadingStateSet = false;
    let timeout: null | ReturnType<typeof setTimeout> = null;

    if (comparisonRangeEnabled) {
      const loadData = async () => {
        if (memoizedCampaignIds.length) {
          setLoading(1, true);
          loadingStateSet = true;
          const data = await loadChartData({
            dateRange: {
              start: strictComparisonRange.start,
              end: strictComparisonRange.end,
            },
          });
          if (!cancel) {
            setLoading(1, false);
            loadingStateSet = false;
            timeout = null;
            setChartData(1, data);
          }
        } else {
          clearChartData(1);
        }
      };
      timeout = setTimeout(loadData, DEBOUNCE_MS);
    }
    return () => {
      if (loadingStateSet) {
        setLoading(1, false);
      }
      if (timeout) {
        clearTimeout(timeout);
      }
      cancel = true;
    };
  }, [strictComparisonRange, comparisonRangeEnabled, memoizedCampaignIds, clearChartData, setChartData, setLoading]);

  return null;
};

export default ChartDataLoader;
