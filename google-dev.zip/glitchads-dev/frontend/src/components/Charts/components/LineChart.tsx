import {
  CartesianGrid,
  LineChart as RechartLineChart,
  ResponsiveContainer,
  ResponsiveContainerProps,
  Tooltip,
} from 'recharts';
import { useContext } from 'react';
import ChartContext, { DEFAULT_INTERVAL_MS } from '../contexts/ChartContext';
import { formatTooltipDate } from '../helpers/formatters';
import styles from './styles.module.css';
import { CurveType } from 'recharts/types/shape/Curve';
import { formatTooltipValue } from '../helpers/formatters';
import renderChartLines from '../helpers/renderChartLines';
import renderYAxes from '../helpers/renderYAxes';
import { differenceInMilliseconds } from 'date-fns';
import ChartSpinner from './ChartSpinner';
import renderXAxes from '../helpers/renderXAxes';
import ChartEmptyState from './ChartEmptyState';

export type LineChartProps = {
  lineCurve?: CurveType;
  lineWidth?: string | number;
  focusedLineWidth?: string | number;
  showYAxis?: boolean;
  height?: ResponsiveContainerProps['height'];
  hideWhenNoData?: boolean;
  strokeDashArray?: string;
};

const LOADING_STYLE = {
  filter: 'blur(2px)',
};

/**
 * Component to render data from the ChartContext as a Line Chart
 * Takes a set of optional props to control appearance/behaviour
 */
const LineChart = ({
  lineCurve,
  lineWidth,
  focusedLineWidth,
  showYAxis,
  height = 300,
  hideWhenNoData,
}: LineChartProps) => {
  const context = useContext(ChartContext);
  const { chartData, clearFocusedMetric, focusedMetric, loading } = context;
  const showGraph = !!chartData.length || !hideWhenNoData;
  const tickInterval =
    chartData.length >= 2
      ? differenceInMilliseconds(new Date(chartData[1].date), new Date(chartData[0].date))
      : DEFAULT_INTERVAL_MS;

  return (
    <div
      style={{
        position: 'relative',
        height: '100%',
        width: '100%',
        overflow: 'hidden',
      }}
    >
      <ResponsiveContainer
        width='100%'
        height={showGraph ? height : 0}
        style={{
          userSelect: 'none',
          transition: 'all 0.5s ease',
          transform: `scaleY(${showGraph ? 1 : 0})`,
          ...(loading ? LOADING_STYLE : {}),
        }}
      >
        <RechartLineChart
          className={styles.lineChart}
          data={chartData}
          margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
          onMouseLeave={clearFocusedMetric}
        >
          {renderXAxes({
            ...context,
            tickInterval,
          })}
          {renderYAxes({
            ...context,
            showYAxis,
          })}
          <Tooltip
            labelClassName={styles.tooltipLabel}
            wrapperClassName={styles.tooltipWrapper}
            animationDuration={200}
            separator=': '
            formatter={formatTooltipValue.bind(null, focusedMetric)}
            labelFormatter={formatTooltipDate.bind(null, tickInterval)}
          />
          <CartesianGrid strokeOpacity={0.3} vertical={false} />
          {renderChartLines(context, {
            lineCurve,
            lineWidth,
            focusedLineWidth,
            showYAxis,
          })}
        </RechartLineChart>
      </ResponsiveContainer>
      <ChartSpinner />
      <ChartEmptyState />
    </div>
  );
};

export default LineChart;
