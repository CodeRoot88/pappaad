import { useContext } from 'react';
import ChartContext from '../contexts/ChartContext';
import styles from './styles.module.css';

const ChartEmptyState = () => {
  const { metrics, focusedMetric } = useContext(ChartContext);
  const classNames = [styles.emptyStateOverlay];
  const hasLinesToShow = !!(metrics.length || focusedMetric);

  if (!hasLinesToShow) {
    classNames.push(styles.visible);
  }

  return (
    <div className={classNames.join(' ')}>
      <span>No Data to Show</span>
      <span>Enable one or more metrics above to see their performance</span>
    </div>
  );
};

export default ChartEmptyState;
