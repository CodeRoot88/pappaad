import { CSSProperties, useCallback, useContext, useState } from 'react';
import { DateRangePicker, DateRangePickerProps, defaultStaticRanges, Range as PickerDateRange } from 'react-date-range';
import ChartContext, {
  CHART_COLORS,
  DateRange,
  ALL_TIME_START_DATE,
  ComparisonType,
  StrictDateRange,
} from '../contexts/ChartContext';
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { Popover, PopoverButton, PopoverPanel } from '@headlessui/react';
import { endOfDay, isEqual as datesEqual } from 'date-fns';
import { formatDateRange } from '../helpers/formatters';
import styles from './styles.module.css';
import { covertDateRangeToPickerRange, getComparisonRange, getStrictDateRange } from '../helpers/dateHelpers';
import { Switch } from '@/components/catalyst/switch';

type LabelPosition = 'top' | 'right' | 'bottom' | 'left';
const FLEX_DIRECTION_LABEL_POSITION_MAP: Record<LabelPosition, CSSProperties['flexDirection']> = {
  top: 'column',
  right: 'row-reverse',
  bottom: 'column-reverse',
  left: 'row',
};

export type ChartDateRangeProps = {
  disabled?: boolean;
  label?: string;
  labelPosition?: LabelPosition;
  hideWhenNoData?: boolean;
};

const RANGE_BUTTON_COPY_LOOKUP: Record<ComparisonType, string> = {
  period: 'Previous Period',
  year: 'Previous Year',
  custom: 'Custom',
};
const ComparisonRangeButton = ({ type, rangeIndex = 1 }: { type: ComparisonType; rangeIndex?: number }) => {
  const { dateRanges, setDateRange } = useContext(ChartContext);
  const isSelected = dateRanges[rangeIndex].comparisonType === type;

  return (
    <button
      className={['rdrStaticRange', isSelected ? 'rdrStaticRangeSelected' : ''].join(' ')}
      onClick={isSelected ? undefined : () => setDateRange(rangeIndex, { comparisonType: type })}
    >
      <span className='rdrStaticRangeLabel'>{RANGE_BUTTON_COPY_LOOKUP[type]}</span>
    </button>
  );
};

/**
 * Date range picker component. Wraps the off-the-shelf "react-date-range" component and provides popover behaviour from Chakra
 */
const ChartDateRange = ({
  hideWhenNoData,
  disabled,
  label = 'Showing Dates:',
  labelPosition = 'top',
}: ChartDateRangeProps) => {
  const {
    chartData,
    dateRanges,
    setDateRange,
    forecastEnabled,
    loading,
    comparisonRangeEnabled,
    toggleComparisonRange,
  } = useContext(ChartContext);
  const [showDisabledTooltip, setShowDisabledTooltip] = useState(false);
  const primaryDateRange = dateRanges[0];
  // If the user selects all time, we default toa fixed ancient date
  // But when we get data back, show it as the oldest datum
  const hasAllTimeOldestData = !primaryDateRange.start && !!chartData.length && !loading;
  const allTimeStartPoint = hasAllTimeOldestData ? new Date(chartData[0].date) : ALL_TIME_START_DATE;
  const comparisonDateRange = comparisonRangeEnabled && dateRanges[1];
  const strictPrimaryDateRange = getStrictDateRange(primaryDateRange);
  const [formattedStartDate, formattedEndDate] = formatDateRange({
    ...strictPrimaryDateRange,
    start: hasAllTimeOldestData ? allTimeStartPoint.getTime() : strictPrimaryDateRange.start,
  });

  const showComparisonRange = !!(comparisonDateRange && comparisonDateRange.comparisonType !== undefined);
  let strictComparisonDateRange: StrictDateRange | null = null;
  if (showComparisonRange) {
    if (comparisonDateRange.comparisonType === 'custom') {
      strictComparisonDateRange = {
        start: comparisonDateRange.start!,
        end: comparisonDateRange.end!,
      };
    } else {
      strictComparisonDateRange = getComparisonRange(comparisonDateRange.comparisonType!, strictPrimaryDateRange);
    }
  }
  const formattedComparisonDateRange = showComparisonRange ? formatDateRange(strictComparisonDateRange!) : null;
  const [mouseOverTrigger, setMouseOverTrigger] = useState(false);
  const currentDate = endOfDay(new Date());

  const showMetrics = !!chartData.length || !hideWhenNoData;
  const showEndDate = formattedEndDate !== formattedStartDate;
  const showComparisonEndDate =
    formattedComparisonDateRange && formattedComparisonDateRange[0] !== formattedComparisonDateRange[1];

  const onChangeDateRange = useCallback<NonNullable<DateRangePickerProps['onChange']>>(
    (rangeUpdates) => {
      Object.entries(rangeUpdates).forEach(([rangeName, rangeValue]) => {
        const updatedIndex = parseInt(rangeName.replace('range', '')) - 1;
        // If comparison is updated, primary is undefined, and vice versa
        const updatedRange: DateRange = {};

        if (rangeValue.startDate) {
          if (datesEqual(rangeValue.startDate, ALL_TIME_START_DATE)) {
            updatedRange.start = undefined;
          } else {
            updatedRange.start = rangeValue.startDate.getTime();
          }
        }
        if (rangeValue.endDate) {
          if (rangeValue.endDate.getTime() <= Date.now()) {
            const endDate = endOfDay(rangeValue.endDate);
            updatedRange.end = endDate.getTime();
          } else {
            updatedRange.end = undefined;
          }
        }
        if (updatedIndex > 0) {
          updatedRange.comparisonType = 'custom';
        }
        setDateRange(updatedIndex, updatedRange);
      });
    },
    [setDateRange],
  );

  const primaryPickerRange: PickerDateRange = {
    startDate: primaryDateRange.start ? new Date(primaryDateRange.start) : allTimeStartPoint,
    endDate: primaryDateRange.end ? new Date(primaryDateRange.end) : currentDate,
  };
  const pickerDateRanges: PickerDateRange[] = [primaryPickerRange];

  if (comparisonRangeEnabled) {
    for (let comparisonIndex = 1; comparisonIndex < dateRanges.length; comparisonIndex++) {
      const comparisonRange = dateRanges[comparisonIndex];
      let comparisonPickerRange: PickerDateRange;
      if (comparisonRange.comparisonType === 'custom') {
        comparisonPickerRange = {
          startDate: new Date(comparisonRange.start!),
          endDate: new Date(comparisonRange.end!),
        };
      } else {
        comparisonPickerRange = covertDateRangeToPickerRange(
          getComparisonRange(comparisonRange.comparisonType!, {
            start: primaryPickerRange.startDate!.getTime(),
            end: primaryPickerRange.endDate!.getTime(),
          }),
        );
      }
      pickerDateRanges.push(comparisonPickerRange);
    }
  }
  const disableDropdown = disabled || forecastEnabled;

  let dropdownTrigger = (
    <PopoverButton
      className={styles.datePickerTargetButton}
      style={{
        gridTemplateColumns: showEndDate ? '1fr auto 1fr' : '1fr',
        overflow: showMetrics ? undefined : 'hidden',
        maxHeight: showMetrics ? 250 : 0,
      }}
      disabled={disableDropdown}
      onMouseEnter={() => setMouseOverTrigger(true)}
      onMouseLeave={() => setMouseOverTrigger(false)}
    >
      <span
        style={{
          background: mouseOverTrigger ? 'unset' : undefined,
        }}
        className={styles.datePickerTargetDate}
      >
        {formattedStartDate}
      </span>
      {showEndDate && (
        <>
          {' - '}
          <span
            style={{
              background: mouseOverTrigger ? 'unset' : undefined,
            }}
            className={styles.datePickerTargetDate}
          >
            {formattedEndDate}
          </span>
        </>
      )}
    </PopoverButton>
  );

  if (forecastEnabled) {
    dropdownTrigger = (
      <div
        onMouseEnter={() => setShowDisabledTooltip(true)}
        onMouseLeave={() => setShowDisabledTooltip(false)}
        onFocus={() => setShowDisabledTooltip(true)}
        onBlur={() => setShowDisabledTooltip(false)}
        className='relative'
        tabIndex={0}
      >
        {dropdownTrigger}
        {showDisabledTooltip && (
          <span className='absolute left-0 bg-gray-100 mt-2 rounded-md p-2 z-10'>
            Cannot change date range when forecast is enabled
          </span>
        )}
      </div>
    );
  }

  return (
    <div
      style={{
        display: 'flex',
        gap: 10,
        alignItems: ['left', 'right'].includes(labelPosition) ? 'center' : undefined,
        flexDirection: FLEX_DIRECTION_LABEL_POSITION_MAP[labelPosition],
      }}
    >
      {!!label && <label>{label}</label>}
      <Popover>
        <div className={styles.comparisonRangeDisplays}>
          {dropdownTrigger}
          {formattedComparisonDateRange && (
            <span className={styles.comparisonRangeLabel}>
              {`Comparing: ${formattedComparisonDateRange[0]}${
                showComparisonEndDate ? ` - ${formattedComparisonDateRange[1]}` : ''
              }`}
            </span>
          )}
        </div>
        <PopoverPanel anchor='bottom' className={styles.datePickerWrapper + ' border shadow'}>
          <DateRangePicker
            calendarFocus='backwards'
            shownDate={primaryPickerRange.endDate}
            onChange={onChangeDateRange}
            moveRangeOnFirstSelection={false}
            maxDate={currentDate}
            inputRanges={[]}
            direction='vertical'
            rangeColors={CHART_COLORS}
            retainEndDateOnFirstSelection
            ranges={pickerDateRanges}
            staticRanges={[
              ...defaultStaticRanges,
              {
                label: 'All Time',
                isSelected: (range) => {
                  const startDateMatches = range.startDate && datesEqual(range.startDate, allTimeStartPoint);
                  const endDateMatches = range.endDate && datesEqual(endOfDay(range.endDate), currentDate);
                  return !!(startDateMatches && endDateMatches);
                },
                range: (props) => {
                  const endDate = currentDate;
                  return {
                    color: props?.rangeColors && props.rangeColors[0],
                    startDate: ALL_TIME_START_DATE,
                    endDate,
                  };
                },
              },
            ]}
            footerContent={
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 10,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: -6,
                    paddingBottom: 11,
                  }}
                  className='rdrStaticRange'
                >
                  <label htmlFor='dateRangeComparisonToggle' style={{ margin: 0 }}>
                    Compare
                  </label>
                  <Switch
                    id='dateRangeComparisonToggle'
                    disabled={!primaryDateRange.start}
                    checked={comparisonRangeEnabled}
                    onChange={toggleComparisonRange}
                  />
                </div>
                {comparisonRangeEnabled && (
                  <>
                    <ComparisonRangeButton type='period' />
                    <ComparisonRangeButton type='year' />
                    <ComparisonRangeButton type='custom' />
                  </>
                )}
              </div>
            }
            // Can't enable infinite scroll due to bug with windowing (https://github.com/hypeserver/react-date-range/issues/577)
            // scroll={{ enabled: true }}
          />
        </PopoverPanel>
      </Popover>
    </div>
  );
};

export default ChartDateRange;
