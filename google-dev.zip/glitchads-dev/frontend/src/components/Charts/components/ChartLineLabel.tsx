import { LabelProps } from 'recharts';
import { ChartMetricConfig } from '../contexts/ChartContext';
import { formatMetricValue } from '../helpers/metricHelpers';
import styles from './styles.module.css';

export type ChartLineLabelProps = LabelProps & {
  metricConfig: ChartMetricConfig;
  value: number;
  hasYAxisOffset?: boolean;
};

const Y_AXIS_OFFSET = 60;
const HORIZONTAL_PADDING = 20;
const VERTICAL_PADDING = 50;

/**
 * Component to override rendering of the Label shown above points on the graph lines.
 * Implements the same default behaviour as the built-in solution but with
 * conditional logic to check if it's outside the visible bounds (a bug would occur when showing
 * y-Axes where points would render outside hypothetical cut-off)
 */
const ChartLineLabel = ({ hasYAxisOffset, metricConfig, value, offset, x, y }: ChartLineLabelProps) => {
  const xPos = (x && (typeof x === 'string' ? parseFloat(x) : x)) || 0;
  const yPos = (y && (typeof y === 'string' ? parseFloat(y) : y)) || 0;
  const yAxisOffset = hasYAxisOffset ? Y_AXIS_OFFSET : 0;
  const offChart = xPos < yAxisOffset;
  const textAnchor = xPos < yAxisOffset + HORIZONTAL_PADDING ? 'right' : 'middle';

  return !(value >= 0) || offChart ? null : (
    <text
      offset={offset}
      x={x}
      y={yPos < VERTICAL_PADDING ? yPos + 30 : y}
      textAnchor={textAnchor}
      className={styles.chartLineLabel}
    >
      <tspan dy='-0.8em'>{formatMetricValue(value, metricConfig)}</tspan>
    </text>
  );
};

export default ChartLineLabel;
