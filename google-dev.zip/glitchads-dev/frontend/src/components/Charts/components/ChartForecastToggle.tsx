import { useContext } from 'react';
import ChartContext from '../contexts/ChartContext';
import { Switch } from '@/components/catalyst/switch';
// import { Switch, Tooltip } from '@chakra-ui/react';
// import { InfoIcon } from '@chakra-ui/icons';

type LabelPosition = 'top' | 'bottom' | 'left' | 'right';

export type ChartForecastToggleProps = {
  label?: boolean | string;
  labelPosition?: LabelPosition;
  hideWhenNoData?: boolean;
};

const FLEX_DIRECTION_MAP = {
  top: 'column',
  bottom: 'column-reverse',
  left: 'row',
  right: 'row-reverse',
} as const;

/**
 * Basic toggle component wrapping Chakra's switch component.#
 * Used to update context to enable/disable forecasts
 */
const ChartForecastToggle = ({ label = true, labelPosition = 'left', hideWhenNoData }: ChartForecastToggleProps) => {
  const { forecastEnabled, toggleForecast, chartData } = useContext(ChartContext);
  const labelText = typeof label === 'string' ? label : 'Show Forecast';

  if (!chartData.length && hideWhenNoData) {
    return null;
  }
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        flexDirection: FLEX_DIRECTION_MAP[labelPosition],
      }}
    >
      {label && (
        <label htmlFor='chartForecastToggle'>
          {labelText}{' '}
          {/* <Tooltip
            label="Show forecasted data for the selected campaign(s)."
            hasArrow
            placement="left"
          >
            <span>
              <InfoIcon w={3} h={3} cursor="pointer" />
            </span>
          </Tooltip> */}
        </label>
      )}
      <Switch
        id='chartForecastToggle'
        className='cursor-pointer hover:outline-current focus:outline-current'
        checked={forecastEnabled}
        onChange={toggleForecast}
      />
    </div>
  );
};

export default ChartForecastToggle;
