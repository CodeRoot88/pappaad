import { DetailedHTMLProps, HTMLAttributes, useContext } from 'react';
import ChartContext, { ChartMetric, ALL_METRICS, CHART_COLORS } from '../contexts/ChartContext';
import styles from './styles.module.css';
import { formatMetricValue, getMetricConfig, getTotalValueForMetric } from '../helpers/metricHelpers';

export type ChartMetricCellProps = {
  metric: ChartMetric;
  variant?: 'solid' | 'subtle';
  size?: 'sm' | 'md' | 'lg';
};

const DEFAULT_VARIANT = 'subtle';
const DEFAULT_SIZE = 'md';

/**
 * Toggle component for an individual Chart metric
 * Only prop is the unique metric. All data/handlers come from context
 */
export const ChartMetricCell = ({ metric, variant = DEFAULT_VARIANT, size = DEFAULT_SIZE }: ChartMetricCellProps) => {
  const {
    chartData,
    dateRanges,
    metrics,
    addMetric,
    removeMetric,
    focusedMetric,
    setFocusedMetric,
    comparisonRangeEnabled,
    clearFocusedMetric,
  } = useContext(ChartContext);
  const isActive = metrics.includes(metric);
  const metricIndex = ALL_METRICS.findIndex((m) => metric === m);
  const cellValue = getTotalValueForMetric({
    dateRange: dateRanges[0],
    chartData,
    metric,
    dataSetIndex: 0,
  });
  const comparisonValue =
    comparisonRangeEnabled && dateRanges[1]
      ? getTotalValueForMetric({
          dateRange: dateRanges[1],
          chartData,
          metric,
          dataSetIndex: 1,
        })
      : null;
  const cellDiffValue = cellValue && comparisonValue ? cellValue - comparisonValue : null;
  const metricConfig = getMetricConfig(metric);
  const isFocused = focusedMetric === metric;
  const classNames = [styles.metricCell, styles[variant], styles[size]];
  if (isActive) {
    classNames.push(styles.active);
  }
  if (isFocused) {
    classNames.push(styles.focused);
  } else if (!!focusedMetric) {
    classNames.push(styles.notFocused);
  }

  const onToggle = () => {
    isActive ? removeMetric(metric) : addMetric(metric);
  };

  return (
    <button
      tabIndex={0}
      style={{ color: CHART_COLORS[metricIndex] }}
      className={classNames.join(' ')}
      onFocus={() => setFocusedMetric(metric)}
      onBlur={clearFocusedMetric}
      onMouseEnter={() => setFocusedMetric(metric)}
      onMouseLeave={clearFocusedMetric}
      onClick={onToggle}
    >
      <span>{metricConfig.label}</span>
      <strong>{formatMetricValue(cellValue, metricConfig, true)}</strong>
      <span
        style={{
          display: 'flex',
          width: '100%',
          justifyContent: 'space-between',
        }}
      >
        {!cellDiffValue ? (
          ' '
        ) : (
          <>
            <span>{cellDiffValue > 0 ? '🠉' : '🠋'}</span>
            <span>{formatMetricValue(cellDiffValue, metricConfig)}</span>
            <span style={{ width: 12 }} />
          </>
        )}
      </span>
    </button>
  );
};

export type ChartMetricsProps = DetailedHTMLProps<HTMLAttributes<HTMLDivElement>, HTMLDivElement> & {
  hideWhenNoData?: boolean;
} & Pick<ChartMetricCellProps, 'size' | 'variant'>;

// Rough values for setting upper-limit of the list's height.
// Only used when animating the reveal if (hideWhenNoData is true)
// Doesn't need to be exact as it's the upper-limit to allow transitioning max-height
const CELL_MAX_HEIGHT = 100;
const MAX_CONTAINER_HEIGHT = ALL_METRICS.length * CELL_MAX_HEIGHT;

/**
 * Wrapper component to display all metrics in a list (each rendered as their own ChartMetricCell component)
 */
const ChartMetrics = ({
  hideWhenNoData,
  variant = DEFAULT_VARIANT,
  size = DEFAULT_SIZE,
  ...divProps
}: ChartMetricsProps) => {
  const { chartData } = useContext(ChartContext);
  const classNames = [styles.metricsContainer, styles[size]];
  if (divProps.className) {
    classNames.push(divProps.className);
  }

  const showMetrics = !!chartData.length || !hideWhenNoData;
  return (
    <div
      {...divProps}
      style={{
        overflow: showMetrics ? undefined : 'hidden',
        transition: 'max-height 0.5s ease',
        maxHeight: showMetrics ? MAX_CONTAINER_HEIGHT : 0,
        ...divProps.style,
      }}
      className={classNames.join(' ')}
    >
      {ALL_METRICS.map((metric) => (
        <ChartMetricCell key={metric} metric={metric} variant={variant} size={size} />
      ))}
    </div>
  );
};

export default ChartMetrics;
