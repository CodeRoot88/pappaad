import { CSSProperties, useContext } from 'react';
import styles from './styles.module.css';
import ChartContext from '../contexts/ChartContext';

export type ChartSpinnerProps = {
  loadingText?: string;
  color?: CSSProperties['color'];
  style?: CSSProperties;
};

const ChartSpinner = ({ color = 'rgba(0, 0, 0, 0.2)', style = {}, loadingText = 'Loading...' }: ChartSpinnerProps) => {
  const { loading } = useContext(ChartContext);
  return (
    <div
      style={{ color, ...style }}
      className={[styles.spinner, loading ? styles.spinnerVisible : styles.spinnerHidden].join(' ')}
    >
      {loadingText}
    </div>
  );
};

export default ChartSpinner;
