import React, { useState } from "react"
import { cn } from "@/lib/utils"

import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Trash } from "lucide-react"

interface Keyword {
  id: string
  text: string
}

interface OptionalHeadline {
  id: string
  text: string
  keywords: Keyword[]
}

interface OptionalAd {
  title: string
  description: string
  headlines: OptionalHeadline[]
  needReview: boolean
}

interface HeadlineItemProps extends React.HTMLAttributes<HTMLDivElement> {
  ad: OptionalAd
  headline: OptionalHeadline
  onDelete: () => void
}

export function DetailedHeadlineItem({
  ad,
  headline,
  onDelete,
  className,
  ...props
}: HeadlineItemProps) {
  const [showKeywords, setShowKeywords] = useState(false)

  return (
    <Card
      className={cn(
        "grid grid-cols-2 gap-4 p-4 bg-white border-purple-100 hover:border-purple-200 transition-colors",
        className
      )}
      {...props}
    >
      <CardContent className="p-2 bg-slate-100 rounded-lg">
        <div className='flex flex-col bg-white size-full rounded-lg justify-center items-start p-3'>
          <h2
            className="text-lg font-semibold text-[#4339ca] w-4/5 truncate"
            title={ad.title}
          >
            {ad.title}
          </h2>
          <p className="text-[#6b7280] wrap">{ad.description}</p>
        </div>
      </CardContent>
      <CardContent className="flex flex-col justify-start p-2">
        <div className="flex flex-row justify-between items-center space-x-6 pr-2">
          <Input
            type="text"
            className="!ring-inset !ring-transparent"
            value={headline.text}
            readOnly
          />
          <Trash className="h-5 w-5 text-slate-400 cursor-pointer" />
        </div>
        <p
          className="text-slate-400 mt-4 mb-2 w-fit cursor-pointer hover:text-slate-700"
          onClick={() => setShowKeywords(!showKeywords)}
        >
          {showKeywords ? "Hide keywords" : "Show keywords"}
        </p>
        {showKeywords && (
          <div className="flex flex-wrap gap-x-1 gap-y-1">
            {headline.keywords.map(({ text }, index) => (
              <span key={index} className='text-indigo-700'>
                {text}
                {index < headline.keywords.length - 1 && (
                  <span className="text-[#6b7280]"> , </span>
                )}{" "}
              </span>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

