import React from 'react';
import { TaskCard } from './task-card';
import { NumberBadge } from '@/components/redesign/glitch-ui/number-badge';
import { StringBadge } from '@/components/redesign/glitch-ui/string-badge';
import { TaskSectionProps } from '@/lib/types';

export const TaskSection: React.FC<TaskSectionProps> = ({ title, badge, tasks, isLast = false }) => {
  return (
    <div className='space-y-8 mb-8'>
      <div
        className={`relative pl-8 ${!isLast && 'before:absolute before:left-2.5 before:top-3 before:h-[calc(100%-12px)] before:w-1 before:bg-purple-200 before:rounded-lg before:mt-6'}`}
      >
        <div className='absolute left-0 top-0 h-6 w-6 rounded-full bg-purple-100 flex items-center justify-center'>
          {tasks && tasks.length > 0 && <div className='h-2 w-2 rounded-full bg-violet-500' />}
        </div>
        <div className='flex flex-row justify-start space-x-2'>
          <h3 className='font-medium mb-4'>{title}</h3>
          {badge && 'number' in badge ? (
            <NumberBadge number={badge.number} size={badge.size} className={badge.className} />
          ) : badge && 'string' in badge ? (
            <StringBadge string={badge.string} size={badge.size} className={badge.className} />
          ) : null}
        </div>
        {tasks && (
          <div className='space-y-2 p-2 rounded-lg bg-slate-100'>
            {tasks.map(({ title, content, buttons, icon }, index) => (
              <TaskCard key={index} title={title} content={content} buttons={buttons} icon={icon} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
