"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { cn } from "@/lib/utils"
import type { CampaignGoal } from "@/lib/types"

interface GoalSelectionProps {
  goals: CampaignGoal[]
  onChange?: (selectedGoals: string[]) => void
  defaultSelected?: string[]
}

export function CampaingGoalItem({ goals, onChange, defaultSelected = [] }: GoalSelectionProps) {
  const [selectedGoals, setSelectedGoals] = React.useState<string[]>(defaultSelected)

  const handleGoalToggle = (goalId: string) => {
    const updatedGoals = selectedGoals.includes(goalId)
      ? selectedGoals.filter((id) => id !== goalId)
      : [...selectedGoals, goalId]

    setSelectedGoals(updatedGoals)
    onChange?.(updatedGoals)
  }

  return (
    <div className="grid grid-cols-2 gap-2">
      {goals.map(({ id, title, icon, className }) => (
        <Card
          key={id}
          className={cn(
            "transition-all cursor-pointer hover:border-indigo-700",
            selectedGoals.includes(id) && "border-indigo-500"
          )}
          onClick={() => handleGoalToggle(id)}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={cn("flex h-10 w-10 items-center justify-center rounded-lg", className)}>
                  {icon}
                </div>
                <span className="text-base font-medium">{title}</span>
              </div>
              <Checkbox
                checked={selectedGoals.includes(id)}
                onCheckedChange={() => handleGoalToggle(id)}
                className="bg-white border-none data-[state=checked]:bg-indigo-500 data-[state=checked]:text-white"
              />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

