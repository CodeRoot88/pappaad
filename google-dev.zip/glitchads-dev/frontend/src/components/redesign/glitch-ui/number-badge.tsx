import { NumberBadgeProps } from "@/lib/types"
import { cn } from "@/lib/utils"

export function NumberBadge({
  number,
  size = "sm",
  className
}: NumberBadgeProps) {
  const sizeClasses = {
    sm: "w-6 h-6 text-sm",
    md: "w-8 h-8 text-base",
    lg: "w-10 h-10 text-lg"
  }

  return (
    <div
      className={cn(
        "rounded-full bg-purple-50 text-purple-600 font-medium flex items-center justify-center",
        sizeClasses[size],
        className
      )}
    >
      {number}
    </div>
  )
}

