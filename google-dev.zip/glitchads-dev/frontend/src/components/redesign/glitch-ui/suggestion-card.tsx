import { cn } from '@/lib/utils';
import { Sparkle } from 'lucide-react';

export type SuggestionCardProps = {
  id: number;
  buttonStyle?: string;
  iconStyle?: string;
  title: string;
  content: string;
  onClick: (id: number) => void;
};

export const SuggestionCard: React.FC<SuggestionCardProps> = ({
  id,
  buttonStyle,
  iconStyle,
  title,
  content,
  onClick,
}) => {
  return (
    <div
      className='bg-white flex row justify-between items-center shadow-md rounded-lg p-6 border border-gray-200 cursor-pointer hover:bg-slate-50'
      onClick={() => onClick(id)}
    >
      <div className='flex row justify-between items-center gap-2'>
        <div className={cn('w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center', buttonStyle)}>
          <Sparkle className={cn('h-5 w-5', iconStyle)} />
        </div>
        <div className='ml-4'>
          <h3 className='text-md font-semibold text-gray-500 my-2'>{title}</h3>
          <p className='text-md text-black mb-2'>{content}</p>
        </div>
      </div>
    </div>
  );
};
