import { StringBadgeProps } from "@/lib/types"
import { cn } from "@/lib/utils"

export function StringBadge({
  string,
  size = "md",
  className
}: StringBadgeProps) {
  const sizeClasses = {
    sm: "h-6 text-sm",
    md: "h-8 text-base",
    lg: "h-10 text-lg"
  }

  return (
    <div
      className={cn(
        "rounded-full bg-purple-50 p-2 text-purple-600 font-medium flex items-center justify-center",
        sizeClasses[size],
        className
      )}
    >
      {string}
    </div>
  )
}

