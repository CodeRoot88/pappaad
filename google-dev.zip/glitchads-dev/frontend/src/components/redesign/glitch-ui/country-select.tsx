"use client"

import { useState, useEffect, useCallback } from "react"
import { X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command"
import { useDebounce } from "use-debounce"
import { useQuery } from "@tanstack/react-query"
import { locationsQueryOptions } from "@/lib/query-options"
import type { Location, Position } from "@/lib/types"

interface CountrySelectProps {
  inputPosition?: Position
  onSelect?: (countries: Location[]) => void
  initialSelected?: Location[]
}

export function CountrySelect({
  inputPosition = "UP",
  onSelect = () => { },
  initialSelected = [],
}: CountrySelectProps) {
  const [query, setQuery] = useState<string>("")
  const [selected, setSelected] = useState<Location[]>(initialSelected) // Initialize with passed values  
  const [debouncedQuery] = useDebounce(query, 500)
  const locationQuery = useQuery(locationsQueryOptions(debouncedQuery))
  const locations = locationQuery.data || []

  const [isOpen, setIsOpen] = useState(false)

  const handleSelect = useCallback((country: Location) => {
    setSelected((prev) => {
      const isSelected = prev.find(
        (item) => item.canonical_name === country.canonical_name
      )
      if (isSelected) {
        return prev.filter(
          (item) => item.canonical_name !== country.canonical_name
        )
      }
      return [...prev, country]
    })
    setQuery("")
    setIsOpen(false)
  }, [])

  const handleRemove = useCallback((country: Location) => {
    setSelected((prev) =>
      prev.filter((item) => item.canonical_name !== country.canonical_name)
    )
  }, [])

  useEffect(() => {
    onSelect(selected)
  }, [selected, onSelect])

  const filteredLocations = locations.filter(
    (item) =>
      item.name.toLocaleLowerCase().includes(query.toLocaleLowerCase().trim()) &&
      !selected.some(
        (selectedItem) =>
          selectedItem.canonical_name === item.canonical_name
      )
  )

  return (
    <div className="flex flex-col gap-4 w-full">
      <Command
        className={`overflow-visible bg-white rounded-lg border shadow-sm relative ${inputPosition === "UP" ? "order-1" : "order-2"
          }`}
      >
        <CommandInput
          value={query}
          onValueChange={(value) => {
            setQuery(value)
            setIsOpen(value.length > 0)
          }}
          onFocus={() => setIsOpen(query.length > 0)}
          onBlur={() => setTimeout(() => setIsOpen(false), 200)}
          placeholder="Search countries..."
          className="border-0"
        />
        {locationQuery && locationQuery.isLoading && (
          <div className="absolute left-0 right-0 mt-1 z-10 bg-white border border-gray-200 rounded-b-lg shadow-lg top-full">
            <div className="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
              <ul className="block w-full ">
                <li className="p-2 text-gray-500">Loading...</li>
              </ul>
            </div>
          </div>
        )}
        {isOpen && locationQuery && !locationQuery.isLoading && (
          <div className="absolute left-0 right-0 mt-1 z-10 bg-white border border-gray-200 rounded-b-lg shadow-lg top-full">
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup className="p-2">
              <div className="flex justify-between px-4 py-2 text-sm text-muted-foreground">
                <span>Country</span>
                <span>Reach</span>
              </div>
              {filteredLocations.map((location, index) => (
                <CommandItem
                  key={index}
                  value={location.canonical_name}
                  onSelect={() => handleSelect(location)}
                  className="flex justify-between cursor-pointer"
                >
                  <span>{location.canonical_name}</span>
                  <span className="text-muted-foreground">{location.reach}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </div>
        )}
      </Command>

      {selected.length > 0 && (
        <div
          className={`flex flex-wrap gap-1 bg-slate-100 p-1 rounded-lg ${inputPosition === "UP" ? "order-2" : "order-1"
            }`}
        >
          {selected.map((country) => (
            <Badge
              key={country.canonical_name}
              variant="secondary"
              className="flex items-center gap-1 px-3 py-2 border border-slate-300 text-sm cursor-pointer bg-white hover:bg-slate-50"
            >
              {country.name}
              <button
                className="ml-1 ring-offset-background rounded-full outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleRemove(country)
                  }
                }}
                onMouseDown={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                }}
                onClick={() => handleRemove(country)}
              >
                <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  )
}