import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MetricButton } from '@/components/ui/metric-button';
import { StatusSectionProps } from '@/lib/types';

export function StatusSection({ title, description, metrics, className }: StatusSectionProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className='space-y-4'>
        <p className='text-sm text-gray-600'>{description}</p>
        <div className='grid bg-indigo-50 p-1 rounded-lg gap-1 sm:grid-cols-2'>
          {metrics.map(({ label, value, icon }, index) => (
            <MetricButton key={index} label={label} value={value} icon={icon} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
