import { CardHeader, CardTitle } from "@/components/ui/card"

export interface HeaderProps {
  title: string
  subTitle?: string
}

export const CampaignCreationCardHeader = ({ title, subTitle = "" }: HeaderProps) => {
  return (
    <CardHeader>
      < CardTitle className='text-2xl font-semibold' > {title}</CardTitle >
      {subTitle !== "" && (
        <p className="text-sm text-muted-foreground">
          {subTitle}
        </p>
      )
      }
    </CardHeader >
  )
}