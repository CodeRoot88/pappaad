import { MetricCardProps } from "@/lib/types";

export function MetricCard({ label, value }: MetricCardProps) {
  return (
    <div className="flex flex-col space-y-1 px-4">
      <p className="text-3xl font-semibold text-[#334155]">{value}</p>
      <p className="text-sm text-[#64748b]">{label}</p>
    </div>
  )
}