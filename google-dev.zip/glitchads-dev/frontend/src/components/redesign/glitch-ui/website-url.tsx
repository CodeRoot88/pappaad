import { Url } from '@/lib/types'
import { X } from 'lucide-react'

interface UrlProps {
  url: Url
  onRemove: (id: string) => void
}

export function WebsiteUrl({ url, onRemove }: UrlProps) {
  return (
    <div className="flex items-center gap-2 rounded-lg border bg-white p-2 pr-3 shadow-sm">
      <div className="flex items-center gap-2 flex-1 min-w-0">
        <span className="shrink-0">
          <svg
            viewBox="0 0 170 170"
            className="h-6 w-6 text-black"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M127.25 84.31c-.08-8.81 3.68-13.75 11.31-20.72-4.37-6.27-10.87-9.68-19.43-10.31-8.15-.62-16.87 4.8-20.12 4.8-3.37 0-11.12-4.68-18.25-4.68-9.37 0-18 5.62-22.81 14.31-4.93 8.75-4.12 25.18 3.87 37.06 3.12 4.68 7.18 10 12.31 10 4.93 0 6.81-3.12 12.75-3.12s7.68 3.12 12.68 3.12c5.06 0 8.25-4.56 11.37-9.18 3.5-5.12 4.93-10.06 5-10.31-.12-.06-9.62-3.68-9.68-14.97zm-9.06-27.5c4.43-5.31 7.43-12.68 6.62-20.06-6.43.31-14.18 4.31-18.75 9.68-4.06 4.68-7.68 12.18-6.68 19.37 7.12.56 14.43-3.68 18.81-8.99z"
              fill="currentColor"
            />
          </svg>
        </span>
        <span className="truncate text-sm">{url.url}</span>
      </div>
      <button
        onClick={() => onRemove(url.id)}
        className="rounded-full p-1 hover:bg-gray-100 transition-colors"
      >
        <X className="h-4 w-4 text-gray-500" />
        <span className="sr-only">Remove URL</span>
      </button>
    </div>
  )
}

