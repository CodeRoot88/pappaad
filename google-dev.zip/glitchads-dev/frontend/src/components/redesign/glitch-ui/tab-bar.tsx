import { useEffect } from "react"
import { Link, useLocation } from "@tanstack/react-router"
import {
  Tabs,
  TabsList,
} from "@/components/ui/tabs"

import { TabsProps } from "@/lib/types"
import type { CampaignTabValue, SettingsTabValue } from "@/lib/types"
import { cn, isCampaignTabValue, isSettingsTabValue } from "@/lib/utils"
import clsx from "clsx"

export function TabBar({ tabs, currentTab, setCurrentTab, className }: TabsProps) {
  const location = useLocation();

  const handleClick = (tab_id: CampaignTabValue | SettingsTabValue) => {
    if (tab_id !== undefined && ((isCampaignTabValue && isCampaignTabValue(tab_id)) || (isSettingsTabValue && isSettingsTabValue(tab_id)))) {
      if (setCurrentTab) {
        setCurrentTab(tab_id)
      }
    }
  }

  useEffect(() => {
    const pathSegments = location.pathname.split("/");
    const currentPathSegment = pathSegments[pathSegments.length - 1];

    if (setCurrentTab) {
      setCurrentTab(currentPathSegment as CampaignTabValue | SettingsTabValue);
    }
  }, [location.pathname])

  return (
    <Tabs
      value={currentTab || tabs[0]?.id}
      className={cn("w-full", className)}
    >
      <TabsList className="h-12 w-full justify-start rounded-none border-b bg-transparent p-0">
        {tabs.map(({ id, href, name }) => (
          <Link
            key={id}
            to={href}
            onClick={() => handleClick(id)}
            className={clsx(id === currentTab ? "!border-primary !text-foreground !bg-transparent !shadow-none " : "",
              "relative h-12 rounded-none border-b-2 border-transparent bg-transparent px-4 pb-3 pt-2 font-medium text-muted-foreground shadow-none transition-none"
            )}
          >
            {name}
          </Link>
        ))}
      </TabsList>
    </Tabs >
  )
}
