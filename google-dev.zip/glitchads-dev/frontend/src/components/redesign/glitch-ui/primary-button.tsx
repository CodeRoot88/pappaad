import { Button } from '@/components/ui/button';

import type { ButtonProps } from '@/components/ui/button';

interface ExtendedButtonProps extends ButtonProps {
  label: string;
}

export function PrimaryButton({ label, variant = 'default', onClick, className, ...props }: ExtendedButtonProps) {
  return (
    <Button onClick={onClick} className={`bg-indigo-500 hover:bg-indigo-700 ${className}`} variant={variant} {...props}>
      {label}
    </Button>
  );
}
