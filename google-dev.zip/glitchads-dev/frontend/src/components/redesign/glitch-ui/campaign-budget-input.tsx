import React from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import type { BudgetInputProps } from '@/lib/types';

export function CampaignBudgetInput({
  value,
  setValue,
  currency = 'USD',
  placeholder = '0',
  className,
  ...props
}: BudgetInputProps & React.InputHTMLAttributes<HTMLInputElement>) {

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;

    const numericValue = parseFloat(inputValue);
    if (setValue) {
      setValue(!isNaN(numericValue) ? numericValue : 0);
    }
  };

  const formattedValue = value !== undefined && !isNaN(value) ? value.toString() : '';

  return (
    <div className='relative'>
      <div className='absolute left-3 top-1/2 -translate-y-1/2'>$</div>

      <Input
        type='text'
        {...props}
        onChange={handleChange}
        value={formattedValue}
        className={cn('pl-6 pr-16 !ring-inset !ring-transparent budget-input', className)}
        placeholder={placeholder}
      />

      <div className='absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground'>{currency}</div>
    </div>
  );
}