import React from "react"
import { TrashIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

import { SectionHeader } from "./section-header"

interface ImageGalleryProps {
  title: string
  images: string[]
  maxImages?: number
  baseText?: string
  buttonText?: string
  onImagesChange?: (images: string[]) => void
}

export const ImageGallery = ({
  title = "Images",
  images = [],
  maxImages = 15,
  baseText = "Based on your URL",
  buttonText = "Add Image",
  onImagesChange,
}: ImageGalleryProps) => {

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (files && files.length > 0) {
      const newImages = Array.from(files).map(file => URL.createObjectURL(file))
      if ((images.length + newImages.length) <= maxImages) {
        onImagesChange?.([...images, ...newImages])
      }
    }
  }

  const handleRemoveImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index)
    onImagesChange?.(newImages)
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <SectionHeader title={title} badgeProps={{ string: images.length + "/" + maxImages }} />
        <p className="mb-4 text-sm text-gray-500">{baseText}</p>
      </CardHeader>
      <CardContent>
        {images && images.length > 0 && (
          <div className="mb-4 grid grid-cols-5 gap-4 overflow-x-auto space-x p-2 bg-slate-100 rounded-lg">
            {images.map((image, index) => (
              <div key={index} className="relative flex-none first:ml-0">
                <img
                  src={image}
                  alt={`Gallery image ${index + 1}`}
                  className="w-full aspect-square rounded-lg object-cover"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 size-full opacity-100 text-transparent hover:bg-opacity-50 hover:bg-black hover:text-white"
                  onClick={() => handleRemoveImage(index)}
                >
                  <TrashIcon className='h-5 w-5' /> <p className="text-lg ml-2">Remove</p>
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter>
        <div>
          <Button
            variant="outline"
            className="text-sm"
            onClick={() => document.getElementById(`${title}-upload`)?.click()}
            disabled={images.length >= maxImages}
          >
            {buttonText}
          </Button>
          <input
            type="file"
            id={`${title}-upload`}
            className="hidden"
            accept="image/*"
            multiple
            onChange={handleImageUpload}
          />
        </div>
      </CardFooter>
    </Card>
  )
}

