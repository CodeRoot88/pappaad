import React from 'react';
import { Link, useLocation } from '@tanstack/react-router';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';

export function GlitchBreadcrumb() {
  const location = useLocation();

  const generateBreadcrumbItems = (): React.ReactNode => {
    const pathname = location.pathname;
    const pathSegments = pathname.split('/').filter((segment) => segment);

    return pathSegments.map((segment, index) => {
      const isLast = index === pathSegments.length - 1;
      const href = '/' + pathSegments.slice(0, index + 1).join('/');

      return (
        <React.Fragment key={href}>
          <BreadcrumbItem>
            {isLast ? (
              <BreadcrumbPage>{decodeURIComponent(segment)}</BreadcrumbPage>
            ) : (
              <Link href={index === 2 ? (pathSegments[2] !== 'new' ? href + '/overview' : href + '/landing') : href}>
                {decodeURIComponent(segment)}
              </Link>
            )}
          </BreadcrumbItem>
          {!isLast && <BreadcrumbSeparator />}
        </React.Fragment>
      );
    });
  };

  return (
    <Breadcrumb>
      <BreadcrumbList>{generateBreadcrumbItems()}</BreadcrumbList>
    </Breadcrumb>
  );
}
