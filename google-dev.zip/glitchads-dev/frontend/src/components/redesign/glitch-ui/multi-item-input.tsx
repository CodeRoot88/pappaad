"use client"

import * as React from "react"
import { X } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { MultiSelectItemProps } from '@/lib/types'

export function MultiItemInput({
  selectedItems,
  onItemAdd,
  onItemRemove,
}: MultiSelectItemProps) {
  const [inputValue, setInputValue] = React.useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputValue.trim()) {
      onItemAdd({
        id: Math.random().toString(36).substr(2, 9),
        name: inputValue.trim()
      })
      setInputValue("")
    }
  }

  return (
    <div className="space-y-4">
      {selectedItems && selectedItems.length > 0 && (
        <div className="flex flex-wrap gap-1 rounded-lg border border-input p-1 bg-gray-50">
          {selectedItems.map(({ id, name }) => (
            <Badge
              key={id}
              variant="outline"
              className="flex items-center gap-3 px-3 py-2 rounded-lg bg-white hover:bg-gray-50"
            >
              {name}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-auto p-0 hover:bg-transparent"
                onClick={() => onItemRemove(id)}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Remove {name}</span>
              </Button>
            </Badge>
          ))}
        </div>
      )}
      <form onSubmit={handleSubmit} className="flex-1">
        <Input
          type="text"
          className="!ring-inset !ring-transparent"
          placeholder="Enter ..."
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
      </form>
    </div>
  )
}

