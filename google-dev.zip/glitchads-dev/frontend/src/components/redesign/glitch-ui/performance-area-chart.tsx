'use client';

import { Area, AreaChart, CartesianGrid, XAxis } from 'recharts';

import { Card, CardContent } from '@/components/ui/card';
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';

const chartData = [
  { month: 'Jan', performance: 434 },
  { month: 'FEb', performance: 257 },
  { month: 'Mar', performance: 657 },
  { month: 'Apr', performance: 434 },
  { month: 'May', performance: 332 },
  { month: 'Jun', performance: 434 },
  { month: 'Jul', performance: 411 },
  { month: 'Aug', performance: 334 },
  { month: 'Sep', performance: 419 },
  { month: 'Oct', performance: 333 },
  { month: 'Nov', performance: 434 },
  { month: 'Dec', performance: 434 },
];

const chartConfig = {
  visitors: {
    label: 'Visitors',
  },
  performance: {
    label: 'Performance',
    color: 'hsl(var(--chart-1))',
  },
} satisfies ChartConfig;

export function PerformanceAreaChart() {
  return (
    <Card>
      <CardContent className='px-2 pt-4 sm:px-6 sm:pt-6'>
        <ChartContainer config={chartConfig} className='aspect-auto h-[250px] w-full'>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id='fillDesktop' x1='0' y1='0' x2='0' y2='1'>
                <stop offset='5%' stopColor='#a855f7' stopOpacity={0.8} />
                <stop offset='95%' stopColor='#e9d5ff' stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} />
            <XAxis dataKey='month' tickLine={false} axisLine={false} tickMargin={8} minTickGap={32} />
            <ChartTooltip
              cursor={false}
              content={
                <ChartTooltipContent
                  labelFormatter={(value) => {
                    return value;
                  }}
                  indicator='dot'
                />
              }
            />
            <Area
              dataKey='performance'
              type='natural'
              fill='url(#fillDesktop)'
              stroke='var(--color-desktop)'
              stackId='a'
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
