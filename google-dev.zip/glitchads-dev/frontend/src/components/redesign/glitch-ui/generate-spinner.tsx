"use client"

import { CardContent } from "@/components/ui/card"
import { CampaignGoalLoadingState } from "@/components/redesign/glitch-ui/campaign-goal-loading-state"

export function GenerateSpinner({ text }: { text: string }) {

  return (
    <CardContent className="p-6 mx-6 rounded-md bg-gradient-to-b from-[#F9F8FF] to-[#FFFFFF]">
      <CampaignGoalLoadingState message={text} />
    </CardContent>
  )
}

