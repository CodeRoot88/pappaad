import * as React from "react"
import { cn } from "@/lib/utils"

import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Trash } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface HeadlineItemProps extends React.HTMLAttributes<HTMLDivElement> {
  id: string,
  keyword: string
  headline: string
  onDelete: () => void
}

export function HeadlineItem({
  id,
  keyword,
  headline,
  onDelete,
  className,
  ...props
}: HeadlineItemProps) {

  return (
    <Card
      className={cn(
        "bg-white border-purple-100 hover:border-purple-200 transition-colors",
        className
      )}
      {...props}
    >
      <CardContent className="pt-6">
        <div className="flex flex-row justify-between items-center space-x-6 pr-2">
          <Input
            type="text"
            className="!ring-inset !ring-transparent"
            value={keyword}
            disabled
          />
          <Trash className="h-5 w-5 text-slate-400 cursor-pointer" />
        </div>
        <p className="text-slate-400 my-4">keywords</p>
        <div className="flex flex-wrap gap-1 rounded-lg border border-input p-1 bg-gray-50">
          <Badge
            key={id}
            variant="outline"
            className="flex items-center gap-3 px-3 py-2 rounded-lg bg-white hover:bg-gray-50"
          >
            {headline}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}

