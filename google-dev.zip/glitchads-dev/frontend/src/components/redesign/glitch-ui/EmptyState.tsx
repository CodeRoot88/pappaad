import { Card, CardContent } from "@/components/ui/card"
import { Inbox } from 'lucide-react'

interface EmptyStateProps {
  icon?: React.ReactNode
  title: string
  description: string
  className?: string
}

export const EmptyState = ({
  icon = <Inbox className="w-12 h-12 text-muted-foreground/60" />,
  title,
  description,
  className = ""
}: EmptyStateProps) => {
  return (
    <Card className={`w-full border-none shadow-none ${className}`}>
      <CardContent className="flex flex-col items-center justify-center py-12 text-center">
        {icon}
        <h3 className="mt-4 text-base font-medium text-muted-foreground">
          {title}
        </h3>
        <p className="text-sm text-muted-foreground/60">
          {description}
        </p>
      </CardContent>
    </Card>
  )
}

