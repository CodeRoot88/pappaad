import { CircleHelp } from 'lucide-react'
import { cn } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"
import { StatusCardProps } from "@/lib/types"

export function StatusCard({
  title,
  description,
  values,
  icon = <CircleHelp className="h-5 w-5 text-purple-600" />,
  className,
  ...props
}: StatusCardProps) {
  const renderDescription = () => {
    const parts = description.split(/(\{[0-9]+\})/)
    return parts.map((part, index) => {
      const match = part.match(/\{([0-9]+)\}/)
      if (match) {
        const valueIndex = parseInt(match[1], 10)
        return (
          <span key={index} className="font-medium text-purple-600">
            {values[valueIndex]}
          </span>
        )
      }
      return part
    })
  }

  return (
    <Card
      className={cn(
        "bg-purple-50/50 border-purple-100 hover:border-purple-200 transition-colors",
        className
      )}
      {...props}
    >
      <CardContent className="pt-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            {icon}
            <h3 className="font-semibold text-purple-900">{title}</h3>
          </div>
          <p className="text-sm text-gray-600">{renderDescription()}</p>
        </div>
      </CardContent>
    </Card>
  )
}

