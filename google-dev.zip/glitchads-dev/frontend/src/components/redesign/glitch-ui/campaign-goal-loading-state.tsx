import { Loader2 } from 'lucide-react'

interface LoadingStateProps {
  message: string
}

export function CampaignGoalLoadingState({ message }: LoadingStateProps) {
  return (
    <div className="flex flex-row items-center justify-center py-2 space-y-2 text-muted-foreground">
      <Loader2 className="h-8 w-8 animate-spin" />
      <p className='ml-10 text-indigo-500'>{message}</p>
    </div>
  )
}