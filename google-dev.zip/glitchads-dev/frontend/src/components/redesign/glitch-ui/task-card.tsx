import { Button } from "@/components/ui/button"
import type { TaskCardProps } from "@/lib/types"

export const TaskCard: React.FC<TaskCardProps> = ({ icon, title, content, buttons }) => {
  return (
    <div className="bg-white flex row justify-between items-center shadow-md rounded-lg p-6 border border-gray-200">
      <div className="flex row justify-between items-center gap-2">
        <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
          {icon ? (
            <img
              src={icon}
              alt="Avatar"
              className="w-8 h-8 rounded-full"
            />
          ) : null}
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800 my-2">{title}</h3>
          <p className="text-sm text-gray-600 mb-2">{content}</p>
        </div>
      </div>
      {buttons && (
        <div className="flex row justify-end items-center space-x-4">
          {buttons.map(({ label, style, onClick }, index) => (
            <Button
              key={index}
              onClick={onClick}
              className={`px-4 py-2 rounded-md text-white bg-indigo-500 hover:bg-indigo-700 transition ${style || ''
                }`}
            >
              {label}
            </Button>
          ))}
        </div>
      )}
    </div>
  )
}