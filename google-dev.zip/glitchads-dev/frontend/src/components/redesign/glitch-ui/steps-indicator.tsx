import { cn } from '@/lib/utils';

interface Step {
  currentStep: number;
  totalSteps: number;
}
export function StepsIndicator({ currentStep, totalSteps }: Step) {
  return (
    <div className='flex gap-2 w-full'>
      {Array.from(Array(totalSteps).keys()).map((i) => (
        <div key={`steps-indicator-${i}`} className='flex-1'>
          <div className={cn('h-1 rounded-full transition-all', i <= currentStep ? 'bg-indigo-700' : 'bg-indigo-200')} />
        </div>
      ))}
    </div>
  );
}
