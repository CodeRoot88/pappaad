import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { SummaryCardProps } from '@/lib/types';

export function SummaryCard({ title = 'Summary', content }: SummaryCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className='text-2xl'>{title}</CardTitle>
      </CardHeader>
      <CardContent className='space-y-6 text-md text-muted-foreground flex flex-col'>
        <div className='flex row gap-2 items-center flex-wrap'>
          {content.map((text, index) => (
            <p
              key={index}
              className={
                index % 2 === 0
                  ? 'text-nowrap'
                  : 'bg-white shadow-md border border-1 px-3 py-0.5 rounded-md text-nowrap'
              }
            >
              {text}
            </p>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
