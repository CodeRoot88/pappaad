import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Check } from 'lucide-react'
import { cn, getInitialUserName } from "@/lib/utils"
import type { UserListItemProps } from "@/lib/types"

export function GoogleAdsAccountItem({ user, selected, onSelect }: UserListItemProps) {

  return (
    <div
      className={cn(
        "flex items-center justify-between bg-white p-4 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer",
        selected && "bg-slate-200"
      )}
      onClick={() => onSelect?.(user)}
      role="button"
      tabIndex={0}
      aria-selected={selected}
    >
      <div className="flex items-center gap-3">
        <Avatar className="bg-slate-200">
          <AvatarImage src={""} alt={user.name} />
          <AvatarFallback>{getInitialUserName(user.name)}</AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <span className="text-sm font-medium">{user.name}</span>
          <span className="text-sm text-muted-foreground">{"user.email"}</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "rounded-full w-6 h-6 border border-2 border-slate-200",
            selected ? "bg-primary border-primary" : "border-input"
          )}
          onClick={(e) => {
            e.stopPropagation()
            onSelect?.(user)
          }}
        >
          {selected && <Check className="h-3 w-3 text-primary-foreground" />}
          <span className="sr-only">Select {user.name}</span>
        </Button>
      </div>
    </div>
  )
}

