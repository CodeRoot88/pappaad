import React from 'react';
import { NumberBadge } from './number-badge';
import { StringBadge } from './string-badge';
import { Button } from '@/components/ui/button';
import { SectionHeaderProps } from '@/lib/types';
import { cn } from '@/lib/utils';

export const SectionHeader = ({
  title,
  badgeProps,
  buttonProps,
  className,
}: SectionHeaderProps & React.InputHTMLAttributes<HTMLInputElement>) => {
  return (
    <div className="flex justify-between">
      <div className='flex flex-row justify-center items-end gap-4'>
        <h2 className={cn("text-2xl font-semibold", className)}>{title}</h2>
      </div>
      <div className='mr-auto ml-4 mt-auto mb-1'>
        {badgeProps && ('number' in badgeProps ? <NumberBadge {...badgeProps} /> : <StringBadge {...badgeProps} />)}
      </div>
      <div className="flex flex-row gap-2">
        {buttonProps &&
          buttonProps.map(({ label, variant, onClick, className }, index) => (
            <Button  
              key={index}
              onClick={onClick}
              variant={variant || 'default'}
              className={className}
            >
              {label}
            </Button>
          ))}
      </div>
    </div>
  );
};

