import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"

type SelectItemProps = {
  id: string
  name: string
  onRemove: () => void
  className?: string
}

export const SelectItem = ({ id, name, onRemove, className }: SelectItemProps) => {
  return (
    <Badge
      key={id}
      variant="secondary"
      className={cn("flex items-center gap-1 px-3 py-1 text-sm", className)}
    >
      {name}
      <button
        className="ml-1 ring-offset-background rounded-full outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        onMouseDown={(e) => {
          e.preventDefault()
          e.stopPropagation()
        }}
        onClick={onRemove}
      >
        <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
      </button>
    </Badge>
  )
}