import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ChevronsRight, Sparkle } from 'lucide-react';

interface ChatbarProps {
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export function Chatbar({ collapsed, setCollapsed }: ChatbarProps) {
  return (
    <div className={cn('relative h-full transition-all duration-300 bg-white', collapsed ? 'w-[60px]' : 'w-[480px]')}>
      {collapsed ? (
        <Button
          variant='ghost'
          size='icon'
          onClick={() => setCollapsed(!collapsed)}
          className='absolute top-4 transform translate-x-0 border border-slate-200'
        >
          <div className='h-full w-full flex items-center justify-center'>
            <Sparkle className='h-5 w-5 text-[#8b5cf6]' />
          </div>
        </Button>
      ) : (
        <div className='p-4'>
          <div className='flex items-center justify-between mb-4'>
            <div className='flex items-center gap-x-2'>
              <Button
                variant='ghost'
                size='icon'
                onClick={() => setCollapsed(!collapsed)}
                className='transform translate-x-0 border border-slate-200 mr-2'
              >
                <div className='h-full w-full flex items-center justify-center'>
                  <ChevronsRight className='h-5 w-5 text-grey-400' />
                </div>
              </Button>
              <Sparkle className='h-4 w-4 text-[#8b5cf6]' />
              <p className='font-medium text-[#8b5cf6]'>Ask AI</p>
            </div>
            <div>
              <p></p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
