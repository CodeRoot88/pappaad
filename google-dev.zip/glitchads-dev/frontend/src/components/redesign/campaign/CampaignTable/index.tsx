'use client';

import { useNavigate } from '@tanstack/react-router';
import { Copy, MoreHorizontal, Trash } from 'lucide-react';
import {
  ColumnDef,
  ColumnFiltersState,
  PaginationState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';

import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CampaignData } from '@/lib/types';
import { useEffect, useState } from 'react';
import { Modal } from '../../glitch-ui/modal';
import { campaignsQueryOptions, useCampaignCopyMutation, useCampaignDeleteMutationOptions } from '@/lib/query-options';
import { useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';

export type RowData = {
  id: string;
  date: string;
  campaign: CampaignData;
  nclick: number;
  conversions: number;
  cpa: number;
  spend: number;
};

export const generateColumns = ({ setIsModalOpen, setActionType, setCampaign }: {
  setIsModalOpen: (isModalOpen: boolean) => void;
  setActionType: (actionType: 'copy' | 'delete' | null) => void;
  setCampaign: (campaign: CampaignData | null) => void;
}): ColumnDef<RowData>[] => {
  return [
    {
      accessorKey: 'date',
      header: 'Date',
      cell: ({ row }) => {
        const date = row.getValue('date')?.toString().split(' ')[0];
        const time = row.getValue('date')?.toString().split(' ')[1];
        return (
          <div className='capitalize'>
            <p>{date}</p>
            <p className='text-slate-400'>{time}</p>
          </div>
        );
      },
    },
    {
      accessorKey: 'campaign',
      header: 'Campaign',
      cell: ({ row }) => {
        const name = Object(row.getValue('campaign'))?.name;
        const url = Object(row.getValue('campaign'))?.url;
        return (
          <div className='capitalize'>
            <p>{name}</p>
            <p className='text-slate-400'>{url}</p>
          </div>
        );
      },
    },
    {
      accessorKey: 'nclick',
      header: () => <div className='text-start'>N. of clicks</div>,
      cell: ({ row }) => {
        return <div className='font-medium text-start'>{row.getValue('nclick')}</div>;
      },
    },
    {
      accessorKey: 'conversions',
      header: () => <div className='text-start'>Conversions</div>,
      cell: ({ row }) => {
        return <div className='font-medium text-start'>{row.getValue('conversions')}</div>;
      },
    },
    {
      accessorKey: 'cpa',
      header: () => <div className='text-start'>CPA</div>,
      cell: ({ row }) => {
        return <div className='font-medium text-start'>{row.getValue('cpa')}</div>;
      },
    },
    {
      accessorKey: 'spend',
      header: () => <div className='text-start'>Spend</div>,
      cell: ({ row }) => {
        return <div className='font-medium text-start'>{row.getValue('spend')}</div>;
      },
    },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const rowData = row.original;

        const handleAction = (type: 'copy' | 'delete') => {
          setActionType(type);
          setIsModalOpen(true);
          setCampaign(rowData.campaign);
        };

        return (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant='ghost' className='h-8 w-8 p-0'>
                  <span className='sr-only'>Open menu</span>
                  <MoreHorizontal />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align='end'>
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  handleAction('copy');
                }} className='cursor-pointer'><Copy className='h-5 w-5 shrink-0 mr-2' />Copy</DropdownMenuItem>
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  handleAction('delete');
                }} className='cursor-pointer'><Trash className='h-5 w-5 shrink-0 mr-2' />Delete</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        );
      },
    },
  ];
}

interface CampaignTableProps {
  campaigns: CampaignData[];
}

export function CampaignTable({ campaigns }: CampaignTableProps) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = useState({});
  const navigate = useNavigate({ from: '/redesign/campaigns' });
  const [data, setData] = useState<RowData[]>([]);

  useEffect(() => {
    const data = campaigns.map((campaign) => {
      return {
        id: campaign.slug,
        date: '01.01.2025 17.26',
        campaign: campaign,
        nclick: 0,
        conversions: 0,
        cpa: campaign.target_cpa,
        spend: 0,
      };
    });
    setData(data);
  }, [campaigns]);

  const [campaign, setCampaign] = useState<CampaignData | null>(null);

  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 5,
  });


  const [isModalOpen, setIsModalOpen] = useState(false);
  const [actionType, setActionType] = useState<'copy' | 'delete' | null>(null);

  const campaignDeleteMutation = useCampaignDeleteMutationOptions(campaign?.id || 0);
  const campaignCopyMutation = useCampaignCopyMutation(campaign?.id || 0);
  const { refetch: refetchCampaigns } = useSuspenseQuery(campaignsQueryOptions());
  const { toast } = useToast();

  const queryClient = useQueryClient();

  const handleDeleteCampaign = async () => {
    if (campaign && campaignDeleteMutation) {
      try {
        await campaignDeleteMutation.mutateAsync();
        toast({ description: 'Campaign deleted successfully' });
        queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
        refetchCampaigns();
      } catch (error) {
        toast({ description: 'Failed to delete campaign', variant: 'destructive' });
      }
    }
  };

  const handleCopyCampaign = async () => {
    if (campaign && campaignCopyMutation) {
      try {
        await campaignCopyMutation.mutateAsync();
        toast({ description: 'Campaign copied successfully' });
        queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
        refetchCampaigns();
      } catch (error) {
        toast({ description: 'Failed to copy campaign', variant: 'destructive' });
      }
    }
  };

  const handleConfirm = () => {
    if (campaign && actionType) {
      if (actionType === 'copy') {
        handleCopyCampaign();
      } else if (actionType === 'delete') {
        handleDeleteCampaign();
      }
    }
  }

  const columns = generateColumns({ setIsModalOpen, setActionType, setCampaign });

  const table = useReactTable({
    data,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    onPaginationChange: setPagination,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
      pagination,
    },
  });

  return (
    <div className='w-full'>
      <div className='flex flex-row justify-between'>
        <h2 className='my-4 text-lg font-medium'>All campaigns</h2>
        <Button onClick={() => setPagination({ pageIndex: 0, pageSize: campaigns.length })} variant='outline' className='default my-auto'>
          All Websites
        </Button>
      </div>
      <div className='rounded-md border-none !bg-white p-4'>
        <Table className='bg-white rounded-xl'>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && 'selected'}
                  onClick={() => navigate({ to: '/redesign/campaigns/' + row.original.id + '/overview' })}
                  className='cursor-pointer'
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className='h-24 text-center'>
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <div className='flex items-center justify-between space-x-2 py-4'>
        <div className='flex items-center gap-2'>
          <span className='flex items-center gap-1'>
            <div>Page</div>
            <strong>
              {table.getState().pagination.pageIndex + 1} of {table.getPageCount().toLocaleString()}
            </strong>
          </span>
        </div>
        <div className='space-x-2'>
          <Button
            variant='outline'
            size='sm'
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            Previous
          </Button>
          <Button variant='outline' size='sm' onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
            Next
          </Button>
        </div>
      </div>
      <Modal
        isOpen={isModalOpen}
        onOpenChange={setIsModalOpen}
        title={actionType === 'copy' ? 'Confirm Copy' : 'Confirm Delete'}
        content={
          actionType === 'copy'
            ? 'Are you sure you want to copy this campaign ID to clipboard?'
            : 'Are you sure you want to delete this campaign? This action cannot be undone.'
        }
        onConfirm={handleConfirm}
        onCancel={() => setIsModalOpen(false)}
        confirmText={actionType === 'copy' ? 'Copy' : 'Delete'}
        cancelText='Cancel'
      />
    </div>
  );
}
