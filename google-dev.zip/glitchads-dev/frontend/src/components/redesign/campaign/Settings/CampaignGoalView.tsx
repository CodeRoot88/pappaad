import { Card, CardContent } from "@/components/ui/card"
import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"
import { useEffect, useRef } from "react"

interface CampaignGoalViewProps {
  goal: string
  setGoal: (value: string) => void
}

export const CampaignGoalView: React.FC<CampaignGoalViewProps> = ({ goal, setGoal }) => {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null)

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto"
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`
    }
  }, [goal])

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setGoal(e.target.value)
  }

  return (
    <div>
      <SectionHeader title="The goal of this campaign" className="my-2" />
      <Card>
        <CardContent className="p-6">
          <textarea
            ref={textareaRef}
            value={goal}
            onChange={handleChange}
            className="w-full text-slate-400 bg-transparent border border-slate-200 rounded-lg p-2 resize-none overflow-hidden focus:outline-none"
            style={{
              fontSize: "inherit",
              lineHeight: "inherit",
              fontFamily: "inherit"
            }}
            rows={1}
          />
        </CardContent>
      </Card>
    </div>
  )
}