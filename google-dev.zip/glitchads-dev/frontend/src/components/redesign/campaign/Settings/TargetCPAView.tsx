import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"
import { CampaignBudgetInput } from "@/components/redesign/glitch-ui/campaign-budget-input"
import { StatusCard } from "@/components/redesign/glitch-ui/status-card"
import { statusCardDataWithRealValue } from "@/components/redesign/utils/constants"

interface TargetCPAViewProps {
  name: string
  cpa: number
  setCpa: (value: number) => void
}

export const TargetCPAView: React.FC<TargetCPAViewProps> = ({ name, cpa, setCpa }) => {

  return (
    <div>
      <SectionHeader title="Target CPA" className="my-2" />

      <Card>
        <CardHeader>
          {name}
        </CardHeader>
        <CardContent>
          <CampaignBudgetInput
            value={cpa}
            setValue={setCpa}
            placeholder="0"
            className="bg-white"
          />
        </CardContent>
      </Card>

      <Card className="mt-2">
        <CardContent className="p-1">
          <div className="notify-items space-y-4">
            <StatusCard
              icon={statusCardDataWithRealValue.icon}
              title={statusCardDataWithRealValue.title}
              description={statusCardDataWithRealValue.description}
              values={statusCardDataWithRealValue.values}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}