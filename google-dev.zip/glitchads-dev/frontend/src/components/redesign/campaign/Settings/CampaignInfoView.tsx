import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"

// Props interface for the component  
interface CampaignInfoViewProps {
  campaignName: string
  setCampaignName: (value: string) => void
  phoneNumber: string
  setPhoneNumber: (value: string) => void
}

export const CampaignInfoView: React.FC<CampaignInfoViewProps> = ({
  campaignName,
  setCampaignName,
  phoneNumber,
  setPhoneNumber
}) => {
  const formatPhoneNumber = (value: string) => {
    const cleaned = value.replace(/\D/g, "")

    const match = cleaned.match(/^(\d{0,1})(\d{0,3})(\d{0,2})(\d{0,3})$/)

    if (!match) return value

    const [, countryCode, firstPart, secondPart, thirdPart] = match

    let formatted = ""
    if (countryCode) formatted += `+${countryCode}`
    if (firstPart) formatted += ` ${firstPart}`
    if (secondPart) formatted += ` ${secondPart}`
    if (thirdPart) formatted += ` ${thirdPart}`

    return formatted.trim()
  }

  const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value.length > 13) return;
    const formatted = formatPhoneNumber(e.target.value)
    setPhoneNumber(formatted)
  }

  const handleCampaignNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCampaignName(e.target.value)
  }

  return (
    <div>
      <SectionHeader title="Campaign Info" className="my-2" />
      <Card className="flex flex-row gap-2 justify-between">
        <div className="w-full">
          <CardHeader className="pb-2">Campaign Name</CardHeader>
          <CardContent>
            <Input
              value={campaignName}
              onChange={handleCampaignNameChange}
              className="!ring-inset !ring-transparent"
            />
          </CardContent>
        </div>

        <div className="w-full">
          <CardHeader className="pb-2">Phone Number</CardHeader>
          <CardContent>
            <Input
              value={phoneNumber}
              onChange={handlePhoneNumberChange}
              placeholder="+0 000 00 000"
              className="!ring-inset !ring-transparent"
            />
          </CardContent>
        </div>
      </Card>
    </div>
  )
}