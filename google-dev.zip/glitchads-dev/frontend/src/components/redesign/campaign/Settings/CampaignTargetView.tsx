import { Card, CardContent } from "@/components/ui/card"
import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"
import { CountrySelect } from "../../glitch-ui/country-select"
import type { Location } from "@/lib/types"

interface CampaignTargetViewProps {
  locations: Location[]
  setLocations: (locations: Location[]) => void
}

export const CampaignTargetView: React.FC<CampaignTargetViewProps> = ({ locations, setLocations }) => {

  const handleChange = (locations: Location[]) => {
    setLocations(locations);
  };

  return (
    <div>
      <SectionHeader title="What locations are you looking to target?" className="my-2" />
      <Card className="flex flex-row gap-2 justify-between p-6">
        <CardContent className="p-1 w-full flex flex-wrap space-x-1 bg-slate-100 rounded-lg">
          <CountrySelect
            initialSelected={locations}
            inputPosition="DOWN"
            onSelect={handleChange}
          />
        </CardContent>
      </Card>
    </div>
  )
}