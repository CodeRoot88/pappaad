import { HeadlineItem } from '@/components/redesign/glitch-ui/headline-item';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

export interface Headline {
  id: string;
  keyword: string;
  headline: string;
}

export const HeadlineManagement1 = ({ headlines }: { headlines: Headline[] }) => {
  const handleHeadlineDelete = (id: string) => {
    console.log(id);
  };

  return (
    <div>
      {headlines.map(({ id, keyword, headline }, index) => (
        <HeadlineItem
          key={index}
          id={id}
          keyword={keyword}
          headline={headline}
          onDelete={() => handleHeadlineDelete(id)}
          className='my-2'
        />
      ))}
      <div className='flex flex-row justify-end space-x-2 my-4'>
        <PrimaryButton
          className='bg-white hover:bg-slate-100'
          onClick={() => console.log('clicked')}
          variant='outline'
          label='Approve'
        />
        <PrimaryButton onClick={() => console.log('clicked')} label='Save Changes' />
      </div>
    </div>
  );
};
