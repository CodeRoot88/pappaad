import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PrimaryButton } from "../../glitch-ui/primary-button";

interface AdCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  campaignUrl: string;
  setPrefixedUrl: (prefixedUrl: string) => void;
  handleCreateAd: () => void;
}

export const AdCreateModal = ({
  isOpen,
  onClose,
  campaignUrl,
  setPrefixedUrl,
  handleCreateAd,
}: AdCreateModalProps) => {
  const [url, setUrl] = campaignUrl ? useState(campaignUrl) : useState('');
  const [error, setError] = useState("");

  const validateUrl = (input: string) => {
    try {
      const inputUrl = new URL(input);
      const campaignUrlObj = new URL(campaignUrl);
      return inputUrl.hostname === campaignUrlObj.hostname;
    } catch {
      return false;
    }
  };

  const handleCreate = () => {
    onClose();
    handleCreateAd()
  };

  useEffect(() => {
    if (campaignUrl) {
      if (!validateUrl(url)) {
        setError("URL must be from the same domain as the campaign URL");
        return;
      }
      setError("");
      try {
        const urlObj = new URL(url);
        const campaignUrlObj = new URL(campaignUrl);
        setPrefixedUrl(`${campaignUrlObj.protocol}//${campaignUrlObj.hostname}${urlObj.pathname}`);
      } catch {
        setPrefixedUrl("");
      }
    }
  }, [url, campaignUrl]);

  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create New Ad</DialogTitle>
          <DialogDescription>
            Enter the URL for your new ad. It must be from the same domain as the campaign URL.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Input
            id="url"
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter URL"
          />
          {error && <p className="text-red-600 text-sm">{error}</p>}
        </div>
        <DialogFooter>
          <div className="flex flex-row justify-end space-x-2">
            <PrimaryButton
              className="bg-white hover:bg-slate-100"
              variant="outline"
              label="Cancel"
              onClick={onClose}
            />
            <PrimaryButton
              label="Create Ad"
              onClick={handleCreate}
              disabled={!validateUrl(url) || !!error}
            />
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
