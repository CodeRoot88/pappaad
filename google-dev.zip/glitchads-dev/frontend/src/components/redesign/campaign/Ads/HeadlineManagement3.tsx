import { PlusIcon, Trash } from 'lucide-react';

import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

import { StringBadge } from '@/components/redesign/glitch-ui/string-badge';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

import { cn, containsEmoji } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/catalyst/button';
import { HeadlineManagerProps } from '@/lib/types';

export const HeadlineManager = ({
  title,
  description,
  headlines,
  maxHeadlines,
  setHeadlines,
  handleSave,
  handleApprove,
  isAdDirty,
  isHeadlineDirty,
  className,
  ...props
}: HeadlineManagerProps) => {
  const { toast } = useToast();

  const addHeadline = () => {
    if (headlines.length < 15) {
      setHeadlines([...headlines, { text: '' }]);
    }
  };

  const removeHeadline = (index: number) => {
    setHeadlines(headlines.filter((_, i) => i !== index));
  };

  const changeHeadline = async (index: number, value: string) => {
    if (containsEmoji(value)) {
      toast({ description: 'Emoji is not allowed in deadline.', variant: 'destructive' });
      return;
    }
    if (value.length > 30) return;
    const updatedHeadlines = [...headlines];
    updatedHeadlines[index] = { ...updatedHeadlines[index], text: value };
    setHeadlines(updatedHeadlines);
  };

  return (
    <div className='flex flex-col'>
      <Card
        className={cn('p-6 bg-white border-purple-100 hover:border-purple-200 transition-colors', className)}
        {...props}
      >
        <div className='space-y-2'>
          <div className='relative'>
            <div className='flex flex-row justify-start space-x-2'>
              <h3 className='font-medium mb-4'>Headlines</h3>
              <StringBadge string={headlines.length + '/' + maxHeadlines} size='sm' />
            </div>
          </div>
        </div>
        <CardContent className='p-2 bg-slate-100 rounded-lg'>
          <div className='flex flex-col bg-white size-full rounded-lg justify-center items-start p-3'>
            <h2 className='text-lg font-semibold text-[#4339ca] w-4/5 truncate' title={title}>
              {title}
            </h2>
            <p className='text-[#6b7280] wrap'>{description}</p>
          </div>
        </CardContent>
        {headlines.map((headline, index) => (
          <div key={index} className='flex flex-row justify-between items-center my-3'>
            <Input
              type='text'
              className='!ring-inset !ring-transparent'
              value={headline.text}
              onChange={(e) => changeHeadline(index, e.target.value)}
            />
            <Trash
              className='h-5 w-5 mx-4 text-slate-400 hover:text-slate-300 cursor-pointer'
              onClick={() => removeHeadline(index)}
            />
          </div>
        ))}
        {headlines.length < 15 && (
          <Button className='mt-4 cursor-pointer' outline onClick={addHeadline}>
            <PlusIcon className='mr-2' />
            Add Headline
          </Button>
        )}
      </Card>
      <div className='flex flex-row justify-end space-x-2 my-4'>
        <PrimaryButton
          className='bg-white hover:bg-slate-100'
          onClick={handleApprove}
          variant='outline'
          label='Approve'
          disabled={isAdDirty}
        />
        <PrimaryButton onClick={handleSave} disabled={!isHeadlineDirty} label='Save Changes' />
      </div>
    </div>
  );
};
