'use client';

import { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import type { Keyword, KeywordManagerProps } from '@/lib/types';
import { StringBadge } from '../../glitch-ui/string-badge';
import { PrimaryButton } from '../../glitch-ui/primary-button';

export function KeywordManager({
  keywords,
  setKeywords,
  alternativeKeywords,
  setAlternativeKeywords,
  customKeyword,
  setCustomKeyword,
  maxKeywords,
  handleSave,
  handleApprove,
  isAdDirty,
  isKeywordDirty
}: KeywordManagerProps) {
  const [showInput, setShowInput] = useState(false);
  const [showAllAlternatives, setShowAllAlternatives] = useState(false);

  const handleAddKeyword = () => {
    if (customKeyword.trim() && keywords.length < maxKeywords) {
      const newKeyword: Keyword = {
        id: Date.now(),
        text: customKeyword.trim(),
      };
      setKeywords((prev) => [...prev, newKeyword]);
      setCustomKeyword('');
      setShowInput(false);
    }
  };

  const handleRemoveKeyword = (id: number, type: 'current' | 'alternative') => {
    if (type === 'current') {
      setKeywords((prev) => prev.filter((k) => k.id !== id));
    } else {
      setAlternativeKeywords((prev) => prev.filter((k) => k.id !== id));
    }
  };

  const handleSwapKeyword = (keyword: Keyword, fromType: 'current' | 'alternative') => {
    if (fromType === 'current') {
      setKeywords((prev) => prev.filter((k) => k.id !== keyword.id));
      setAlternativeKeywords((prev) => [...prev, keyword]);
    } else if (keywords.length < maxKeywords) {
      setAlternativeKeywords((prev) => prev.filter((k) => k.id !== keyword.id));
      setKeywords((prev) => [...prev, keyword]);
    }
  };

  const renderKeyword = (keyword: Keyword, type: 'current' | 'alternative') => (
    <Badge
      key={keyword.id}
      variant='default'
      className={`flex items-center text-slate-900 cursor-pointer bg-white gap-1 px-3 py-1.5 hover:bg-slate-300`}
      onClick={() => {
        if ((type === 'alternative' && keywords.length < maxKeywords) || type === 'current') {
          handleSwapKeyword(keyword, type);
        }
      }}
    >
      {keyword.text}
      <Button
        variant='ghost'
        size='icon'
        className='h-4 w-4 p-0 hover:bg-transparent'
        onClick={(e) => {
          e.stopPropagation();
          handleRemoveKeyword(keyword.id || -1, type);
        }}
      >
        <X className='h-3 w-3' />
        <span className='sr-only'>Remove {keyword.text}</span>
      </Button>
    </Badge>
  );

  return (
    <div className='space-y-6 rounded-lg bg-white p-6'>
      <div className='space-y-4'>
        <div className='flex items-center justify-between'>
          <div className='flex items-center gap-2'>
            <h2 className='text-base font-semibold'>Current Keywords</h2>
            <StringBadge string={keywords.length + '/' + maxKeywords} size='sm' />
          </div>
          {!showInput && (
            <Button
              variant='link'
              className='text-blue-600 hover:text-blue-700'
              onClick={() => setShowInput(true)}
              disabled={keywords.length >= maxKeywords}
            >
              Add keywords
            </Button>
          )}
        </div>
        <div className='flex flex-wrap gap-2 bg-slate-100 rounded-lg p-2'>
          {keywords.map((keyword) => renderKeyword(keyword, 'current'))}
          {showInput && (
            <div className='flex gap-2'>
              <Input
                value={customKeyword}
                onChange={(e) => setCustomKeyword(e.target.value)}
                placeholder='Enter keyword'
                className='h-9 bg-white 1ring !ring-transparent'
              />
              <Button size='sm' onClick={handleAddKeyword}>
                Save
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className='space-y-4'>
        <h2 className='text-base font-semibold'>Alternative Keywords</h2>
        <div className='flex flex-wrap gap-2 bg-slate-100 rounded-lg p-2'>
          {(showAllAlternatives ? alternativeKeywords : alternativeKeywords.slice(0, 4)).map((keyword) =>
            renderKeyword(keyword, 'alternative'),
          )}
          {!showAllAlternatives && alternativeKeywords.length > 4 && (
            <Button
              variant='link'
              className='text-sm text-muted-foreground'
              onClick={(e) => {
                e.preventDefault();
                setShowAllAlternatives(true);
              }}
            >
              +{alternativeKeywords.length - 4} more
            </Button>
          )}
          {showAllAlternatives && alternativeKeywords.length > 4 && (
            <Button
              variant='link'
              className='text-sm text-muted-foreground'
              onClick={(e) => {
                e.preventDefault();
                setShowAllAlternatives(false);
              }}
            >
              Show less
            </Button>
          )}
        </div>
      </div>
      <div className='flex flex-row justify-end space-x-2 my-4'>
        <PrimaryButton
          className='bg-white hover:bg-slate-100'
          onClick={handleApprove}
          variant='outline'
          label='Approve'
          disabled={isAdDirty}
        />
        <PrimaryButton onClick={handleSave} disabled={!isKeywordDirty} label='Save Changes' />
      </div>
    </div>
  );
}
