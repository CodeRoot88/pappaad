import { DetailedHeadlineItem } from '@/components/redesign/glitch-ui/detailed-headline-item';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

export interface Keyword {
  id: string;
  text: string;
}

export interface OptionalHeadline {
  id: string;
  text: string;
  keywords: Keyword[];
}

export interface OptionalAd {
  title: string;
  description: string;
  headlines: OptionalHeadline[];
  needReview: boolean;
}

export const HeadlineManagement2 = ({ headlines, ad }: { headlines: OptionalHeadline[]; ad: OptionalAd }) => {
  const handleHeadlineDelete = (id: string) => {
    console.log(id);
  };

  return (
    <div>
      {headlines.map((headline, index) => (
        <DetailedHeadlineItem
          key={index}
          ad={ad}
          headline={headline}
          onDelete={() => handleHeadlineDelete(headline.id)}
        />
      ))}
      <div className='flex flex-row justify-end space-x-2 my-4'>
        <PrimaryButton
          className='bg-white hover:bg-slate-100'
          onClick={() => console.log('clicked')}
          variant='outline'
          label='Approve'
        />
        <PrimaryButton onClick={() => console.log('clicked')} label='Save Changes' />
      </div>
    </div>
  );
};
