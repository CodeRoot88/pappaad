import { Clock, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

import { Action, ButtonVariant } from '@/lib/types';
import { Modal } from '../../glitch-ui/modal';
import { useState } from 'react';

interface PageHeaderProps {
  title: string;
  actions?: Action[];
  status?: {
    label: string;
    icon?: React.ComponentType<{ className?: string }>;
    variant?: ButtonVariant;
  };
  showMoreActions?: boolean;
  onMoreActionsClick?: () => void;
}

export function PageHeader({ title, actions, status, showMoreActions, onMoreActionsClick }: PageHeaderProps) {

  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className='flex items-center justify-between py-4'>
      <h1 className='text-2xl font-semibold text-[#0f172a]'>{title}</h1>
      <div className='flex items-center gap-3'>
        {status && (
          <div className='flex items-center gap-2 rounded-full border border-indigo-500 bg-white px-4 py-2 text-sm text-[#6366f1]'>
            {status.icon && <Clock className='h-4 w-4' />}
            <span>{status.label}</span>
          </div>
        )}
        {actions?.map(({ label, variant, onClick }, index) => (
          <Button
            key={index}
            onClick={onClick}
            variant={variant}
            className={variant === 'default' ? 'bg-[#6366f1] hover:bg-[#6366f1]/90' : undefined}
          >
            {label}
          </Button>
        ))}
        {showMoreActions && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant='ghost' className='h-8 w-8 p-0'>
                <MoreHorizontal className='h-5 w-5' />
                <span className='sr-only'>More actions</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align='end'>
              <DropdownMenuItem className='cursor-pointer' onClick={() => setIsModalOpen(true)}>Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
      <Modal
        isOpen={isModalOpen}
        onOpenChange={setIsModalOpen}
        title='Confirm Delete'
        content='Are you sure you want to delete this campaign? This action cannot be undone.'
        onConfirm={onMoreActionsClick}
        onCancel={() => setIsModalOpen(false)}
        confirmText='Delete'
        cancelText='Cancel'
      />
    </div>
  );
}
