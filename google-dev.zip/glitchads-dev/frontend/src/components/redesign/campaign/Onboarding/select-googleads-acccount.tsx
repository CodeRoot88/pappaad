import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';
import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { GoogleAdsAccountItem } from '@/components/redesign/glitch-ui/googleads-account-item';
import type { GoogleAdsAccounts } from '@/lib/types';
import { useSuspenseQuery } from '@tanstack/react-query';
import { googleAdsAccountsQueryOptions, useSetGoogleAdsCustomerIdMutationOptions } from '@/lib/query-options';
import { useSetAtom } from 'jotai';
import { googleAdsCustomerIdAtom } from '@/store';

interface SelectGoogleAdsAccountProps {
  onNext: () => void;
}
export const SelectGoogleAdsAccount = ({ onNext }: SelectGoogleAdsAccountProps) => {
  const { data: accounts = [] } = useSuspenseQuery(googleAdsAccountsQueryOptions());
  const googleAdsCustomerMutation = useSetGoogleAdsCustomerIdMutationOptions();
  const setGoogleAdsCustomerId = useSetAtom(googleAdsCustomerIdAtom);

  const [selectedAccount, setSelectedAccount] = useState<GoogleAdsAccounts | undefined>();

  const handleAccountSelect = (account: GoogleAdsAccounts) => {
    setSelectedAccount(account);
  };

  const handleApprove = async () => {
    if (selectedAccount) {
      try {
        await googleAdsCustomerMutation.mutateAsync({ adsCustomerId: selectedAccount.googleads_account_id });
        setGoogleAdsCustomerId(selectedAccount.googleads_account_id);
      } catch (error) {
        //Todo: handle error case
      }
      onNext();
    }

  };

  return (
    <div className='campaign-goal-select flex-row space-y-6'>
      <div className='py-5'>
        <Card className='border-none shadow-none'>
          <CampaignCreationCardHeader
            title='Choose the Google Ad account'
            subTitle='Choose your Google Ad account to continue'
          />
          <CardContent className='m-6 p-2 space-y-6 rounded-xl'>
            <div className='bg-slate-100 rounded-xl p-1 space-y-1'>
              {accounts &&
                accounts.map((user) => (
                  <GoogleAdsAccountItem
                    key={user.googleads_account_id}
                    user={user}
                    selected={selectedAccount?.googleads_account_id === user.googleads_account_id}
                    onSelect={handleAccountSelect}
                  />
                ))}
            </div>
            <div className='space-y-6'>
              <div className='flex justify-end'>
                <PrimaryButton
                  type='submit'
                  onClick={handleApprove}
                  label='Approve and continue'
                  disabled={selectedAccount === undefined}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
