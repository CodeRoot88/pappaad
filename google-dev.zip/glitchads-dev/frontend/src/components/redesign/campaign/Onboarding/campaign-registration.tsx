import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

import logo from '/logo_lightbg.svg';
import registration from '/registration.png';

interface CampaignRegistrationProps {
  onSubmit: () => Promise<void>;
}

export const CampaignRegistration = ({ onSubmit }: CampaignRegistrationProps) => {
  return (
    <div className='set-campaign-url flex-row space-y-6 aligns-center'>
      <Card className='border-none shadow-none'>
        <CardHeader className='p-6'>
          <img className='hidden h-8 m-2 mr-auto w-auto lg:block' src={logo} alt='Glitch' />
        </CardHeader>
        <CardContent className='space-y-4'>
          <img src={registration} alt='registration' />
          <p className='text-4xl font-bold pt-4'>Great, we understand your business!</p>
          <p className='text-slate-500'>
            Glitch is your AI Growth Engine. Onboard in minutes, and our AI will help you get more leads for less.
          </p>
        </CardContent>
        <CardFooter className='flex justify-end'>
          <PrimaryButton onClick={async () => { await onSubmit() }} label='Complete registration' />
        </CardFooter>
      </Card>
    </div>
  );
};
