import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';

import { CampaignBudgetInput } from '@/components/redesign/glitch-ui/campaign-budget-input';

import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { PrimaryButton } from '../../glitch-ui/primary-button';

interface CampaignOnboardingBudgetProps {
  onNext: () => void;
  initialBudget: number;
  setCampaignBudget: (budget: number) => void;
}

export function CampaignOnboardingBudget({ onNext, initialBudget, setCampaignBudget }: CampaignOnboardingBudgetProps) {
  const [budget, setBudget] = useState(initialBudget);

  const handleApprove = () => {
    setCampaignBudget(budget);
    onNext();
  };
  return (
    <div className='campaign-goal-generate flex-row space-y-6'>
      <Card className='!border-none !shadow-none'>
        <CampaignCreationCardHeader
          title='What is your budget?'
          subTitle='How much do you expect to spend on Google Ads at the start?'
        />
        <CardContent className='space-y-6'>
          <CampaignBudgetInput value={budget} setValue={setBudget} placeholder='Enter budget.' />
          <div className='space-y-6'>
            <div className='flex justify-end'>
              <PrimaryButton onClick={handleApprove} label='Approve and continue' disabled={budget === 0} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
