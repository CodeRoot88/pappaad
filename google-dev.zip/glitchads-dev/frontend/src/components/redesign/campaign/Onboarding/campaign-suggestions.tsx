import { Card, CardContent } from '@/components/ui/card';
import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { SuggestionCard } from '../../glitch-ui/suggestion-card';

const suggestions = [
  {
    id: 1,
    buttonStyle: 'bg-indigo-100',
    iconStyle: 'text-indigo-400',
    title: 'Suggestion1',
    content: 'I want it to take all actions without me',
  },
  {
    id: 2,
    buttonStyle: 'bg-violet-100',
    iconStyle: 'text-violet-400',
    title: 'Suggestion2',
    content: 'I want it to take obvious actions without my intput',
  },
  {
    id: 3,
    buttonStyle: 'bg-blue-100',
    iconStyle: 'text-blue-400',
    title: 'Suggestion3',
    content: 'I want to review every improvement before the system applies it',
  },
];

interface CampaignSuggestionsProps {
  onNext: () => void;
  setBusinessSuggestion: (suggestion: string) => void;
}
export const CampaignSuggestions = ({ onNext, setBusinessSuggestion }: CampaignSuggestionsProps) => {
  const handleClick = (id: number) => {
    console.log(id)
    setBusinessSuggestion(suggestions[id].title);
    onNext();
  };

  return (
    <div className='campaign-goal-select flex-row space-y-6'>
      <div className='py-2'>
        <Card className='border-none shadow-none'>
          <CampaignCreationCardHeader
            title='How much would you prefer the Al do?'
            subTitle='This action is indicative only and will not lead to unexpected actions, ensuring full control over Al behaviour.'
          />
          <CardContent className='m-6 p-2 space-y-2 rounded-xl bg-slate-100'>
            {suggestions &&
              suggestions.map(({ id, buttonStyle, iconStyle, title, content }, index) => (
                <SuggestionCard
                  key={index}
                  id={id}
                  buttonStyle={buttonStyle}
                  iconStyle={iconStyle}
                  title={title}
                  content={content}
                  onClick={handleClick}
                />
              ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
