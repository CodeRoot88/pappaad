export enum CAPMPAIGN_ONBOARDING_STEP {
  SELECT_GOOGLE_AD_ACCOUNT,
  BUSINESS_URL,
  SELECT_BUSINESS_GOAL,
  GENERATE_BUSINESS_DESCRIPTION,
  ADJUST_BUSINESS_DESCRIPTION,
  // SUGGESTION,
  // COMPETITORS,
  SELECT_COUNTRY,
  SET_BUDGE,
  REGISTRATION,
}

export const CAMPAIGN_ONBOARDING_STEP_LOOKUP: Record<
  CAPMPAIGN_ONBOARDING_STEP,
  {
    id: CAPMPAIGN_ONBOARDING_STEP;
    stepIndicator: number;
    title: string;
    backStep: CAPMPAIGN_ONBOARDING_STEP;
    backLabel: string;
  }
> = {
  [CAPMPAIGN_ONBOARDING_STEP.SELECT_GOOGLE_AD_ACCOUNT]: {
    id: CAPMPAIGN_ONBOARDING_STEP.SELECT_GOOGLE_AD_ACCOUNT,
    stepIndicator: 0,
    title: 'Select Google Ad Account',
    backStep: CAPMPAIGN_ONBOARDING_STEP.SELECT_GOOGLE_AD_ACCOUNT, // No back step for the first step
    backLabel: '',
  },
  [CAPMPAIGN_ONBOARDING_STEP.BUSINESS_URL]: {
    id: CAPMPAIGN_ONBOARDING_STEP.BUSINESS_URL,
    stepIndicator: 1,
    title: 'Business URL',
    backStep: CAPMPAIGN_ONBOARDING_STEP.SELECT_GOOGLE_AD_ACCOUNT,
    backLabel: 'Change Google Ad Account',
  },
  [CAPMPAIGN_ONBOARDING_STEP.SELECT_BUSINESS_GOAL]: {
    id: CAPMPAIGN_ONBOARDING_STEP.SELECT_BUSINESS_GOAL,
    stepIndicator: 2,
    title: 'Select Business Goal',
    backStep: CAPMPAIGN_ONBOARDING_STEP.BUSINESS_URL,
    backLabel: 'Change Business URL',
  },
  [CAPMPAIGN_ONBOARDING_STEP.GENERATE_BUSINESS_DESCRIPTION]: {
    id: CAPMPAIGN_ONBOARDING_STEP.GENERATE_BUSINESS_DESCRIPTION,
    stepIndicator: 3,
    title: 'Generate Business Description',
    backStep: CAPMPAIGN_ONBOARDING_STEP.SELECT_BUSINESS_GOAL,
    backLabel: 'Change Business Goal',
  },
  [CAPMPAIGN_ONBOARDING_STEP.ADJUST_BUSINESS_DESCRIPTION]: {
    id: CAPMPAIGN_ONBOARDING_STEP.ADJUST_BUSINESS_DESCRIPTION,
    stepIndicator: 3,
    title: 'Adjust Business Description',
    backStep: CAPMPAIGN_ONBOARDING_STEP.SELECT_BUSINESS_GOAL,
    backLabel: 'Select Business Goal',
  },
  // [CAPMPAIGN_ONBOARDING_STEP.SUGGESTION]: {
  //   id: CAPMPAIGN_ONBOARDING_STEP.SUGGESTION,
  //   stepIndicator: 5,
  //   title: 'Suggestions',
  //   backStep: CAPMPAIGN_ONBOARDING_STEP.ADJUST_BUSINESS_DESCRIPTION,
  //   backLabel: 'Adjust Description',
  // },
  // [CAPMPAIGN_ONBOARDING_STEP.COMPETITORS]: {
  //   id: CAPMPAIGN_ONBOARDING_STEP.COMPETITORS,
  //   stepIndicator: 6,
  //   title: 'Competitors',
  //   backStep: CAPMPAIGN_ONBOARDING_STEP.SUGGESTION,
  //   backLabel: 'Suggestions',
  // },
  [CAPMPAIGN_ONBOARDING_STEP.SELECT_COUNTRY]: {
    id: CAPMPAIGN_ONBOARDING_STEP.SELECT_COUNTRY,
    stepIndicator: 4,
    title: 'Select Country',
    backStep: CAPMPAIGN_ONBOARDING_STEP.ADJUST_BUSINESS_DESCRIPTION,
    backLabel: 'Competitors',
  },
  [CAPMPAIGN_ONBOARDING_STEP.SET_BUDGE]: {
    id: CAPMPAIGN_ONBOARDING_STEP.SET_BUDGE,
    stepIndicator: 5,
    title: 'Set Budget',
    backStep: CAPMPAIGN_ONBOARDING_STEP.SELECT_COUNTRY,
    backLabel: 'Select Country',
  },
  [CAPMPAIGN_ONBOARDING_STEP.REGISTRATION]: {
    id: CAPMPAIGN_ONBOARDING_STEP.REGISTRATION,
    stepIndicator: 6,
    title: 'Registration',
    backStep: CAPMPAIGN_ONBOARDING_STEP.SET_BUDGE,
    backLabel: 'Set Budget',
  },
};
