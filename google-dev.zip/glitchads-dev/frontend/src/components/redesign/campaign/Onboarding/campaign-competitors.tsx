import { useState, KeyboardEvent } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';

import type { Url } from '@/lib/types';

import { Input } from '@/components/ui/input';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';
import { isValidUrl } from '@/lib/utils';
import { WebsiteUrl } from '../../glitch-ui/website-url';

interface CampaignCompetitorsProps {
  onNext: () => void;
  setCampaignCompetitors: (competitors: string[]) => void;
}
export const CampaignCompetitors = ({ onNext, setCampaignCompetitors }: CampaignCompetitorsProps) => {
  const [urls, setUrls] = useState<Url[]>([]);
  const [inputValue, setInputValue] = useState('https://');
  const [error, setError] = useState<string | null>(null);

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (inputValue == '' || inputValue === 'https://') {
        setError('Business URL is required');
        return;
      }

      if (!isValidUrl(inputValue) || !inputValue.startsWith('https://')) {
        setError('URL is not valid');
        return;
      }

      const newUrl: Url = {
        id: crypto.randomUUID(),
        url: inputValue,
      };
      setUrls((prev) => [...prev, newUrl]);
      setInputValue('https://');
      setError(null);
    }
  };

  const handleRemoveUrl = (id: string) => {
    setUrls((prev) => prev.filter((url) => url.id !== id));
  };

  const handleApprove = () => {
    setCampaignCompetitors(urls.map((url) => url.url));
    onNext();
  };

  return (
    <div className='campaign-goal-select flex-row space-y-6'>
      <div className='py-5'>
        <Card className='border-none shadow-none'>
          <CampaignCreationCardHeader
            title='Are these your competitors?'
            subTitle='Remove ones which are not your competitors or add ones we are missing.'
          />
          <CardContent className='m-6 p-0 space-y-6'>
            <div className='flex flex-col bg-slate-100 rounded-lg'>
              {urls && urls.length > 0 && (
                <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg'>
                  {urls.map((url) => (
                    <WebsiteUrl key={url.id} url={url} onRemove={handleRemoveUrl} />
                  ))}
                </div>
              )}
              <div className='relative'>
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className='w-full bg-transparent !ring-inset !ring-transparent border-none shadow-none'
                  placeholder='Enter website URL'
                />
                {error && <p className='text-sm text-destructive m-1 px-1'>{error}</p>}
              </div>
            </div>
            <div className='space-y-6'>
              <div className='flex justify-end'>
                <PrimaryButton onClick={handleApprove} label='Approve and continue' />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
