import { useState } from 'react';
import { Trash } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/catalyst/button';

import { SectionHeader } from '@/components/redesign/glitch-ui/section-header';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

import { cn } from '@/lib/utils';

interface Description {
  id: string;
  text: string;
}

interface DescriptionsProps {
  descriptions: Description[];
  onChange: (updatedDescriptions: Description[]) => void;
  max_description_count?: number;
}

export const Descriptions = ({
  descriptions: initialDescriptions,
  onChange,
  max_description_count = 15,
}: DescriptionsProps) => {
  const [descriptions, setDescriptions] = useState<Description[]>(initialDescriptions);
  const [showInput, setShowInput] = useState(false);
  const [newDescription, setNewDescription] = useState('');
  const [error, setError] = useState('');

  const handleAddDescription = () => {
    if (newDescription.trim().length < 10) {
      setError('Description must be at least 10 characters long');
      return;
    }

    if (newDescription.trim().length > 100) {
      setError('Description must be less than 100 characters');
      return;
    }

    const newId = (descriptions.length + 1).toString();
    const updatedDescriptions = [...descriptions, { id: newId, text: newDescription.trim() }];
    setDescriptions(updatedDescriptions);
    onChange(updatedDescriptions);
    setNewDescription('');
    setShowInput(false);
    setError('');
  };

  const handleDeleteDescription = (id: string) => {
    const updatedDescriptions = descriptions.filter((desc) => desc.id !== id);
    setDescriptions(updatedDescriptions);
    onChange(updatedDescriptions);
  };

  const handleCancel = () => {
    setShowInput(false);
    setNewDescription('');
    setError('');
  };

  return (
    <Card className='overflow-hidden'>
      <CardHeader>
        <SectionHeader
          title='Current Descriptions'
          badgeProps={{
            string: `${descriptions.length}/${max_description_count}`,
          }}
        />
      </CardHeader>
      <CardContent>
        <div className='space-y-4'>
          {descriptions &&
            descriptions.map(({ id, text }, index) => (
              <div className='flex flex-row justify-between items-center space-x-6 pr-2' key={index}>
                <Input type='text' className='!ring-inset !ring-transparent' value={text} readOnly />
                <Trash onClick={() => handleDeleteDescription(id)} className='h-5 w-5 text-slate-400 cursor-pointer' />
              </div>
            ))}
        </div>
      </CardContent>
      <CardFooter className='block w-full'>
        {showInput ? (
          <div className='mt-6 space-y-4'>
            <div className='space-y-2'>
              <Input
                id='description'
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder='Enter your description'
                className={cn('!ring-inset !ring-transparent w-full', error ? 'border-red-500' : '')}
              />
              {error && <p className='text-sm text-red-500'>{error}</p>}
            </div>
            <div className='flex gap-2'>
              <PrimaryButton label='Save' onClick={handleAddDescription} className='' />
              <Button outline onClick={handleCancel} className='cursor-pointer'>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          descriptions.length < max_description_count && (
            <Button outline className='mt-6' onClick={() => setShowInput(true)}>
              Add description
            </Button>
          )
        )}
      </CardFooter>
    </Card>
  );
};
