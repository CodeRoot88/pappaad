import { Link } from '@tanstack/react-router'
import { Card, CardContent } from "@/components/ui/card"
import { AssetsAdCardProps } from '@/lib/types'

export const AssetsAdCard = ({
  url,
  title,
  description,
  image,
  locations = [],
}: AssetsAdCardProps) => {
  return (
    <Card className="overflow-hidden p-5">
      <CardContent className="p-2 flex gap-4 border border-slate-200">
        <div className="flex-1 min-w-0">
          <div className="space-y-4">
            <div>
              <div className='flex flex-row justify-start items-center space-x-2'>
                <div className='w-5 h-5 bg-slate-200 rounded-md' />
                <Link
                  to={url}
                  className="text-sm text-muted-foreground hover:underline truncate block text-emerald-400"
                >
                  {url}
                </Link>
              </div>
              <p className="text-xl text-blue-700 line-clamp-1 mt-3">
                {title}
              </p>
            </div>

            <p className="text-sm text-muted-foreground line-clamp-2">
              {description}
            </p>

            {locations.length > 0 && (
              <div className="flex flex-wrap gap-3">
                {locations.map((location, index) => (
                  <div
                    key={`${location}-${index}`}
                    className="flex items-center gap-1 text-sm text-blue-600"
                  >
                    {location}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex-shrink-0">
          {image && image.trim() !== "" ? (
            <img
              src={image}
              alt="Thumbnail"
              className="rounded-lg object-cover w-[150px] h-[150px]"
            />
          ) : (
            <div className="w-[150px] h-[150px] bg-gray-200 rounded-lg flex items-center justify-center">
              <span className="text-gray-400">No image</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

