import React, { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"

interface ExtensionsFormProps {
  phone: string
  address: string
  onPhoneChange?: (phone: string) => void
  onAddressChange?: (address: string) => void
}

export const ExtensionsForm = ({
  phone,
  address,
  onPhoneChange,
  onAddressChange,
}: ExtensionsFormProps) => {
  const [isPhoneValid, setIsPhoneValid] = useState(true)
  const [formattedPhone, setFormattedPhone] = useState(phone.startsWith('+') ? phone : `+${phone}`)

  const formatPhoneNumber = (value: string): string => {
    // Remove all non-digit characters except the leading '+'
    let cleaned = value.replace(/[^\d+]/g, '')

    // Ensure the number always starts with '+'
    cleaned = cleaned.startsWith('+') ? cleaned : `+${cleaned}`

    // Format: +0 000 00 000
    const formatted = cleaned.replace(/^(\+\d{0,1})(\d{0,3})(\d{0,2})(\d{0,3}).*/, (_, p1 = '+', p2 = '', p3 = '', p4 = '') => {
      let parts = [p1]
      if (p2) parts.push(p2)
      if (p3) parts.push(p3)
      if (p4) parts.push(p4)
      return parts.join(' ').trim()
    })

    return formatted
  }

  const validatePhone = (input: string): boolean => {
    // Allow +, spaces, and numbers, but require at least one digit after '+'
    return /^\+(?=.*\d)[+\d\s]*$/.test(input)
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    const formatted = formatPhoneNumber(newValue)
    const isValid = validatePhone(formatted)

    setIsPhoneValid(isValid)
    setFormattedPhone(formatted)

    if (isValid) {
      onPhoneChange?.(formatted)
    }
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <SectionHeader title="Extensions" />
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-sm text-gray-600">
              Phone Number
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none">+</span>
              <Input
                id="phone"
                value={formattedPhone.slice(1)}
                onChange={handlePhoneChange}
                placeholder="0 000 00 000"
                className="h-10 bg-white text-gray-900 pl-6 !ring !ring-transparent"
                aria-invalid={!isPhoneValid}
                maxLength={13}
              />
            </div>
            {!isPhoneValid && (
              <p className="text-xs text-red-500">
                Phone number must contain at least one digit
              </p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="address" className="text-sm text-gray-600">
              Address
            </Label>
            <Input
              id="address"
              value={address}
              onChange={(e) => onAddressChange?.(e.target.value)}
              placeholder="Address"
              className="h-10 bg-white text-gray-900 !ring !ring-transparent"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

