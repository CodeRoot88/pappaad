import * as React from 'react';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

import { SectionHeader } from '@/components/redesign/glitch-ui/section-header';

import { cn, isValidInput } from '@/lib/utils';

interface CTAInputProps {
  value: string;
  onChange?: (value: string) => void;
}

export function CTAInput({ value, onChange }: CTAInputProps) {
  const [isValid, setIsValid] = React.useState(true);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    const isValid = isValidInput(newValue);
    setIsValid(isValid);

    if (isValid) {
      onChange?.(newValue);
    }
  };

  return (
    <Card className='overflow-hidden'>
      <CardHeader>
        <SectionHeader title="Call to action (CTA)" />
      </CardHeader>
      <CardContent>
        <Input
          value={value}
          onChange={handleChange}
          placeholder='Order now'
          className={cn(
            'h-8 rounded-md bg-white px-2 py-1 text-gray-900 !ring !ring-transparent',
            !isValid && 'ring-red-500 focus-visible:ring-red-500',
          )}
          aria-invalid={!isValid}
        />
        {!isValid && (
          <p className='mt-2 text-xs text-red-500'>
            Input can only contain letters, numbers, hyphens, underscores, and spaces.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
