import * as React from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"

import { isValidSegment } from "@/lib/utils"

interface PathDisplayProps {
  url: string
  onChange?: (newUrl: string) => void
}

export const PathDisplay = ({ url, onChange }: PathDisplayProps) => {
  const [basePath, ...pathSegments] = React.useMemo(() => {
    try {
      const urlObj = new URL(url)
      const pathWithoutLeadingSlash = urlObj.pathname.replace(/^\//, '')
      return [urlObj.origin, ...pathWithoutLeadingSlash.split('/').filter(Boolean)]
    } catch (e) {
      return [url]
    }
  }, [url])

  const [invalidSegments, setInvalidSegments] = React.useState<boolean[]>([])

  const handleSegmentChange = (index: number, newValue: string) => {
    const isValid = isValidSegment(newValue)
    setInvalidSegments(prev => {
      const newInvalid = [...prev]
      newInvalid[index] = !isValid
      return newInvalid
    })

    if (isValid) {
      const newSegments = [...pathSegments]
      newSegments[index] = newValue
      const newUrl = `${basePath}/${newSegments.join('/')}`
      onChange?.(newUrl)
    }
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <SectionHeader title="Display path" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 overflow-x-auto text-sm text-gray-500">
          <span className="text-gray-600 whitespace-nowrap">{basePath}</span>
          {pathSegments.map((segment, index) => (
            <React.Fragment key={index}>
              {"/"}
              <Input
                value={segment}
                onChange={(e) => handleSegmentChange(index, e.target.value)}
                className="h-8 rounded-md bg-white px-2 py-1 text-gray-900 !ring-inset !ring-transparent"
                aria-invalid={invalidSegments[index]}
              />
            </React.Fragment>
          ))}
        </div>
        {invalidSegments.some(Boolean) && (
          <p className="mt-2 text-xs text-red-500">
            Segments can only contain letters, numbers, hyphens, and underscores.
          </p>
        )}
      </CardContent>
    </Card>
  )
}

