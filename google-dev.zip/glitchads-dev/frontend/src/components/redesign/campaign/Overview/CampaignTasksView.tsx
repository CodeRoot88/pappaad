import { Card } from '@/components/ui/card';
import { SectionHeader } from '@/components/redesign/glitch-ui/section-header';
import { TaskSection } from '@/components/redesign/glitch-ui/task-section';

import { ButtonProps, TaskCardProps } from '@/lib/types';
import { useNavigate } from '@tanstack/react-router';

export const CampaignTasksView = ({ campaignSlug }: { campaignSlug: string }) => {

  const navigate = useNavigate({ from: "/redesign/campaigns" });

  const tasksButtons: ButtonProps[] = [
    {
      label: 'View all',
      onClick: () => { },
      variant: 'outline',
      className: 'default',
    },
  ];

  const createCardData: TaskCardProps[] = [
    {
      title: 'All ads are ready to review',
      content: 'Reach new audiences by directing them to various pages on your site',
      buttons: [
        {
          label: 'Review',
          onClick: () => {
            navigate({ to: `/redesign/campaigns/${campaignSlug}/ads` });
          },
        },
      ],
    },
    {
      title: 'All assets are ready to review',
      content: 'Reach new audiences by directing them to various pages on your site',
      buttons: [
        {
          label: 'Review',
          onClick: () => {
            navigate({ to: `/redesign/campaigns/${campaignSlug}/assets` });
          },
        },
      ],
    },
  ];

  return (
    <div className='flex flex-col mt-4'>
      <SectionHeader title='Tasks' className='mb-8' buttonProps={tasksButtons} />
      <Card className='p-6'>
        <TaskSection title='Review your first Campaign' badge={{ number: 2, size: 'sm' }} tasks={createCardData} />
      </Card>
    </div>
  );
};
