import { Card } from "@/components/ui/card"
import { GenerateSpinner } from "@/components/redesign/glitch-ui/generate-spinner"

export const CampaignAdsGenerateSpinner = () => {
  return (
    <Card className="py-6">
      <GenerateSpinner text='Creating tailored Ads to meet your goals...:' />
    </Card>
  )
}