import { PerformanceAreaChart } from "@/components/redesign/glitch-ui/performance-area-chart"
import { MetricCard } from "@/components/redesign/glitch-ui/metric-card"
import { SectionHeader } from "@/components/redesign/glitch-ui/section-header"

const metrics = [
  { label: "N. of clicks", value: "120" },
  { label: "Conversions", value: "15" },
  { label: "CPA", value: "00" },
  { label: "Spend", value: "500$" },
]

export const PerformanceChart = () => {
  return (
    <>
      <SectionHeader title='Overall Performance' className='font-medium text-lg' />
      <div className="rounded-lg border bg-white p-6">
        <div className="mb-8 grid grid-cols-4 gap-4">
          {metrics.map(({ label, value }) => (
            <MetricCard
              key={label}
              label={label}
              value={value}
            />
          ))}
        </div>
        <PerformanceAreaChart />
      </div>
    </>
  )
}