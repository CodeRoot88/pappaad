'use client';

import { useNavigate, useRouter } from '@tanstack/react-router';
import { AlertCircle } from 'lucide-react';

import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Ad } from '@/lib/types';

export function AdCard({ ad }: { ad: Ad }) {
  const navigate = useNavigate({ from: '/redesign/campaigns/$campaignslug/ads' });
  const router = useRouter();
  const handleClick = () => {
    const toPath = router.state.location.pathname;
    navigate({ to: toPath + '/' + ad.slug });
  };

  return (
    <Card className='w-full bg-white shadow-sm cursor-pointer hover:bg-slate-50' onClick={handleClick}>
      <CardHeader className='space-y-6 pb-4'>
        <div className='flex items-start justify-between gap-4 border p-3 rounded-lg'>
          <div className='flex flex-col w-4/5'>
            <h2 className='text-lg font-semibold text-[#4339ca] w-4/5 truncate'>
              {ad.headlines[0]?.text + ' | ' + ad.headlines[1]?.text + ' | ' + ad.headlines[2]?.text + '...'}
            </h2>
            <p className='text-[#6b7280] wrap'>{ad.descriptions[0]?.text}</p>
          </div>
          {ad.state !== 'approved' && (
            <div className='flex items-center gap-1 rounded-full border border-purple-500 bg-purple-50 px-2 py-1 text-sm text-purple-500 cursor-pointer'>
              <AlertCircle className='h-4 w-4' />
              <span>Review needed</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className='space-y-3'>
          <h3 className='text-sm font-medium text-[#374151]'>Keywords</h3>
          <div className='flex flex-wrap gap-x-1 gap-y-2'>
            {ad.keywords.map((keyword, index) => (
              <span key={index} className='text-indigo-700'>
                {keyword.text}
                {index < ad.keywords.length - 1 && <span className='text-[#6b7280]'> , </span>}{' '}
              </span>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
