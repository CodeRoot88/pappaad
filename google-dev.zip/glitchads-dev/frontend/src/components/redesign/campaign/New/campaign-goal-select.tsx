import { Card, CardContent } from '@/components/ui/card';
import { CampaingGoalItem } from '@/components/redesign/glitch-ui/campaign-goal-item';
import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';

import { campaignGoals } from '@/components/redesign/utils/constants';

interface CampaignGoalSelectProps {
  onNext: () => void;
  setBusinessGoal: (goal: string) => void;
}

export const CampaignGoalSelect = ({ onNext, setBusinessGoal }: CampaignGoalSelectProps) => {
  const handleGoalsChange = (selectedGoals: string[]) => {
    setBusinessGoal(selectedGoals[0]);
    onNext();
  };

  return (
    <div className='campaign-goal-select flex-row space-y-6'>
      <div className='py-5'>
        <Card className='border-none shadow-none'>
          <CampaignCreationCardHeader title="What's the goal of this Campaign?" />
          <CardContent className='m-6 p-2 space-y-6 rounded-xl bg-slate-100'>
            <CampaingGoalItem goals={campaignGoals} onChange={handleGoalsChange} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
