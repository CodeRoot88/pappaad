export enum CAPMPAIGN_CREATION_STEP {
  BUSINESS_URL,
  SELECT_BUSINESS_GOAL,
  GENERATE_BUSINESS_DESCRIPTION,
  ADJUST_BUSINESS_DESCRIPTION,
  SELECT_COUNTRY,
  SET_BUDGE,
}

export const CAMPAIGN_CREATION_STEP_LOOKUP: Record<
  CAPMPAIGN_CREATION_STEP,
  {
    id: CAPMPAIGN_CREATION_STEP;
    stepIndicator: number;
    title: string;
    backStep: CAPMPAIGN_CREATION_STEP;
    backLabel: string;
  }
> = {
  [CAPMPAIGN_CREATION_STEP.BUSINESS_URL]: {
    id: CAPMPAIGN_CREATION_STEP.BUSINESS_URL,
    stepIndicator: 0,
    title: 'Business URL',
    backStep: CAPMPAIGN_CREATION_STEP.BUSINESS_URL,
    backLabel: '',
  },
  [CAPMPAIGN_CREATION_STEP.SELECT_BUSINESS_GOAL]: {
    id: CAPMPAIGN_CREATION_STEP.SELECT_BUSINESS_GOAL,
    stepIndicator: 1,
    title: 'Select Goal',
    backStep: CAPMPAIGN_CREATION_STEP.BUSINESS_URL,
    backLabel: 'Change Business URL',
  },
  [CAPMPAIGN_CREATION_STEP.GENERATE_BUSINESS_DESCRIPTION]: {
    id: CAPMPAIGN_CREATION_STEP.GENERATE_BUSINESS_DESCRIPTION,
    stepIndicator: 2,
    title: 'Generate Description',
    backStep: CAPMPAIGN_CREATION_STEP.SELECT_BUSINESS_GOAL,
    backLabel: 'Change goal',
  },
  [CAPMPAIGN_CREATION_STEP.ADJUST_BUSINESS_DESCRIPTION]: {
    id: CAPMPAIGN_CREATION_STEP.ADJUST_BUSINESS_DESCRIPTION,
    stepIndicator: 2,
    title: 'Adjust Goal',
    backStep: CAPMPAIGN_CREATION_STEP.SELECT_BUSINESS_GOAL,
    backLabel: 'Change goal',
  },
  [CAPMPAIGN_CREATION_STEP.SELECT_COUNTRY]: {
    id: CAPMPAIGN_CREATION_STEP.SELECT_COUNTRY,
    stepIndicator: 3,
    title: 'Targets',
    backStep: CAPMPAIGN_CREATION_STEP.ADJUST_BUSINESS_DESCRIPTION,
    backLabel: 'Change goal',
  },
  [CAPMPAIGN_CREATION_STEP.SET_BUDGE]: {
    id: CAPMPAIGN_CREATION_STEP.SET_BUDGE,
    stepIndicator: 4,
    title: 'Budget',
    backStep: CAPMPAIGN_CREATION_STEP.SELECT_COUNTRY,
    backLabel: 'Change business description',
  },
};
