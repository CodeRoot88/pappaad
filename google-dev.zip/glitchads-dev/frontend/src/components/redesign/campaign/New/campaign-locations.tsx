'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';

import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

import { CountrySelect } from '@/components/redesign/glitch-ui/country-select';
import { Location } from '@/lib/types';

interface CampaignLocationsProps {
  onNext: () => void;
  setLocations: (locations: any[]) => void;
}

export function CampaignLocations({ onNext, setLocations: setTargetLocations }: CampaignLocationsProps) {
  const [locations, setLocations] = useState<Location[]>([]);

  const handleChange = (locations: Location[]) => {
    setLocations(locations);
  };

  const handleApprove = () => {
    setTargetLocations(locations);
    onNext();
  };

  return (
    <div className='campaign-goal-generate flex-row space-y-6'>
      <Card className='!border-none !shadow-none'>
        <CampaignCreationCardHeader
          title='What locations are you looking to target?'
          subTitle='We suggest targeting a country or for a state.'
        />
        <CardContent className='space-y-6'>
          <CountrySelect inputPosition='DOWN' onSelect={handleChange} />
          <div className='space-y-6'>
            <div className='flex justify-end'>
              <PrimaryButton onClick={handleApprove} label='Approve and continue' disabled={locations.length === 0} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
