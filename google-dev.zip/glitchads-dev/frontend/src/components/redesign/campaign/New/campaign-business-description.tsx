'use client';

import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { Textarea } from '@/components/catalyst/textarea';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

interface CampaignBusinessDescriptionProps {
  businessDescription: string;
  onNext: () => void;
  setBusinessDescription: (description: string) => void;
}

export function CampaignBusinessDescription({ businessDescription, onNext, setBusinessDescription }: CampaignBusinessDescriptionProps) {
  const [description, setDescription] = useState<string>(businessDescription);
  const [enableAdjust, setEnableAdjust] = useState(false);

  const handleAdjust = () => {
    setEnableAdjust(!enableAdjust);
  };

  const handleApprove = () => {
    setBusinessDescription(description);
    onNext();
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    e.preventDefault();
    setDescription(e.target.value);
  };

  return (
    <div className='campaign-goal-generate flex-row space-y-6'>
      <Card className='!border-none !shadow-none'>
        <CampaignCreationCardHeader title='Given your goal and your business description we recommend creating 1 discovery campaign' />
        <CardContent className='space-y-6'>
          <div className='space-y-4'>
            <div className='flex items-start gap-2 text-sm text-muted-foreground'>
              <Sparkles className='h-5 w-5 shrink-0 text-indigo-500' />
              <p>Here&apos;s how AI sees your Campaign</p>
            </div>
            <Card>
              {enableAdjust ? (
                <Textarea
                  name={'description'}
                  className='h-40 p-4 text-sm leading-relaxed text-muted-foreground'
                  resizable={false}
                  defaultValue={description}
                  onChange={handleChange}
                />
              ) : (
                <CardContent className='p-4 text-sm leading-relaxed text-muted-foreground'>{description}</CardContent>
              )}
            </Card>
          </div>
          <div className='space-y-6'>
            <div className='flex justify-end gap-4'>
              <PrimaryButton
                className='bg-slate-white hover:bg-slate-100'
                onClick={handleAdjust}
                variant='outline'
                label={enableAdjust ? 'Update' : 'Adjust'}
              />
              <PrimaryButton onClick={handleApprove} label='Approve and continue' />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
