import { useState } from 'react';
import { Input } from '@/components/ui/input';

import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { PrimaryButton } from '@/components/redesign/glitch-ui/primary-button';

import { isValidUrl } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { campaignDescriptionQueryOptions } from '@/lib/query-options';

interface CampaignUrlProps {
  onNext: () => void;
  setBusinessUrl: (url: string) => void;
}
export const CampaignUrl = ({ onNext, setBusinessUrl }: CampaignUrlProps) => {
  const [url, setUrl] = useState('https://');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    error: campaignDescriptionError,
  } = useQuery(campaignDescriptionQueryOptions(url, isValidUrl(url)));

  const handleSubmit = async () => {
    if (!url) {
      setError('Business URL is required');
      return;
    }

    if (!isValidUrl(url)) {
      setError('URL is not valid');
      return;
    }

    if (campaignDescriptionError) {
      setError(campaignDescriptionError.message);
      return;
    }

    try {
      setIsSubmitting(true);
      setError(null);
      setBusinessUrl(url);
      onNext();
    } catch (error) {
      setError('Please enter a valid URL');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className='set-campaign-url flex-row space-y-6 aligns-center'>
      <CampaignCreationCardHeader
        title="What's your businesses URL?"
        subTitle='Are we sending these users to your homepage, or do you want to put
          in a specific landing page to focus on a sub part of your business.'
      />
      <div className='space-y-2 mx-6'>
        <Input
          placeholder='https://tryglitch.ai/'
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className='text-base !ring-inset !ring-transparent'
          disabled={isSubmitting}
        />
        {error && <p className='text-sm text-destructive'>{error}</p>}
      </div>
      <div className='flex justify-end mr-6'>
        <PrimaryButton
          onClick={handleSubmit}
          size='lg'
          className='px-6'
          disabled={isSubmitting}
          label={isSubmitting ? 'Validating...' : 'Approve and continue'}
        />
      </div>
    </div>
  );
};
