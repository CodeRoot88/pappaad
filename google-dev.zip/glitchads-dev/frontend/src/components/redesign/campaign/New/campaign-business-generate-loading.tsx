'use client';

import { Card } from '@/components/ui/card';
import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { GenerateSpinner } from '@/components/redesign/glitch-ui/generate-spinner';
import { useQuery } from '@tanstack/react-query';
import { campaignDescriptionQueryOptions } from '@/lib/query-options';
import { useEffect } from 'react';

interface CampaignGoalGenerateProps {
  businessUrl: string;
  setBusinssDescription: (businessDescription: string) => void;
  onNext: () => void;
}

export function CampaignBusinessGenerateLoading({ businessUrl, setBusinssDescription, onNext }: CampaignGoalGenerateProps) {

  const {
    isLoading,
    isSuccess,
    data: campaignDescription,
  } = useQuery(campaignDescriptionQueryOptions(businessUrl, true));

  useEffect(() => {
    if (!isLoading && isSuccess && campaignDescription?.description !== "") {
      setBusinssDescription(campaignDescription?.description ?? '');
      onNext();
    }
  }, [isLoading, isSuccess])

  return isLoading && (<div className='campaign-goal-generate flex-row space-y-6'>
    <Card className='!border-none !shadow-none'>
      <CampaignCreationCardHeader title='Review the goal of this campaign' />
      <GenerateSpinner text='Generating a campaign goal...' />
    </Card>
  </div>
  );
}
