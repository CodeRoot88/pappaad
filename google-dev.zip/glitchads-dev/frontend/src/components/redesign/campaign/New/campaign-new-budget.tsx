'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';

import { CampaignBudgetInput } from '../../glitch-ui/campaign-budget-input';

import { CampaignCreationCardHeader } from '@/components/redesign/glitch-ui/campaigncreationcardheader';
import { PrimaryButton } from '../../glitch-ui/primary-button';

interface CampaignNewBudgetProps {
  onSubmit: () => Promise<void>;
  initialBudget: number;
  setCampaignBudget: (budget: number) => void;
}
export function CampaignNewBudget({ onSubmit, initialBudget = 0, setCampaignBudget }: CampaignNewBudgetProps) {
  const [budget, setBudget] = useState(initialBudget);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit();
  };

  const handleChange = (budget: number) => {
    setBudget(budget);
    setCampaignBudget(budget);
  };

  return (
    <div className='campaign-goal-generate flex-row space-y-6'>
      <Card className='!border-none !shadow-none'>
        <CampaignCreationCardHeader
          title='What is your budget?'
          subTitle='How much do you expect to spend on Google Ads at the start?'
        />
        <CardContent className='space-y-6'>
          <form onSubmit={handleSubmit} className='space-y-6'>
            <CampaignBudgetInput value={budget} setValue={handleChange} placeholder='0' />
            <div className='space-y-6'>
              <div className='flex justify-end'>
                <PrimaryButton type='submit' label='Approve and continue' disabled={budget === 0} />
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
