import { useState } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface BillingCycleProps {
  onCycleChange?: (cycle: 'monthly' | 'annually') => void
  defaultCycle?: 'monthly' | 'annually'
  className?: string
}

export const BillingCycle = ({
  onCycleChange,
  defaultCycle = 'monthly',
  className
}: BillingCycleProps) => {
  const [selectedCycle, setSelectedCycle] = useState<'monthly' | 'annually'>(defaultCycle)

  const handleCycleChange = (value: 'monthly' | 'annually') => {
    setSelectedCycle(value)
    onCycleChange?.(value)
  }

  const options = [
    {
      value: 'monthly',
      title: 'Monthly ($130 / month)',
      subtitle: '$1560 per year'
    },
    {
      value: 'annually',
      title: 'Annually ($1440 / year)',
      subtitle: '$120 per month'
    }
  ]

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-xl font-medium">Billing cycle</CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={selectedCycle}
          onValueChange={handleCycleChange}
          className="space-y-2 border border-slate-200 p-2 rounded-xl bg-slate-100"
        >
          {options.map((option) => (
            <div
              key={option.value}
              className="relative bg-white rounded-xl border-none outline-none !ring !ring-transparent"
              onClick={() => handleCycleChange(option.value as 'monthly' | 'annually')}
            >
              <div
                className={cn(
                  "flex items-center rounded-xl space-x-4 order-none p-4 cursor-pointer transition-all",
                  "hover:border-none",
                  selectedCycle === option.value && "border-white bg-slate-50"
                )}
              >
                <RadioGroupItem
                  value={option.value}
                  id={option.value}
                  className="text-indigo-600 border-indigo-600 focus:ring-indigo-600"
                  onClick={(e) => e.stopPropagation()}
                />
                <div className="flex-1">
                  <Label
                    htmlFor={option.value}
                    className="text-base cursor-pointer"
                  >
                    {option.title}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {option.subtitle}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  )
}

