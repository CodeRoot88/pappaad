import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { GetStartedModal } from "./GetStartedModal"
import { StringBadge } from "../../glitch-ui/string-badge"

interface PricingTierProps {
  name: string
  price: number
  isRecommended?: boolean
  isSelected: boolean
  onSelect: () => void
  className?: string
}

export const PricingTier = ({
  name,
  price,
  isRecommended = false,
  isSelected,
  onSelect,
  className,
}: PricingTierProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false)

  return (
    <>
      <Card
        className={cn(
          "relative flex flex-col cursor-pointer",
          isSelected && "border-indigo-500",
          className
        )}
        onClick={onSelect}
      >
        <CardContent className="pt-6 pb-2">
          <div className="flex items-center justify-between mb-4">
            <Label htmlFor={`plan-${name.toLowerCase()}`} className="text-xl flex flex-row justify-start space-x-2 items-end font-medium">
              {name}
              {isRecommended && (
                <StringBadge string="Recommended" size='sm' />
              )}
            </Label>
            <RadioGroup value={isSelected ? name : undefined}>
              <RadioGroupItem value={name} id={`plan-${name.toLowerCase()}`} checked={isSelected} className="text-indigo-500 border-indigo-500 focus:ring-indigo-500" />
            </RadioGroup>
          </div>
          <div className="flex items-baseline">
            <span className="text-4xl font-bold">${price}</span>
            <span className="ml-1 text-sm text-muted-foreground">/ per month</span>
          </div>
        </CardContent>
        <CardFooter className="mt-auto pt-6">
          <Button
            onClick={(e) => {
              e.stopPropagation()
              setIsModalOpen(true)
            }}
            variant={isSelected ? "default" : "outline"}
            className={cn(
              "w-full",
              isSelected && "bg-indigo-500 text-white hover:bg-indigo-700"
            )}
          >
            Get started
          </Button>
        </CardFooter>
      </Card>
      <GetStartedModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        tierName={name}
        tierPrice={price}
      />
    </>
  )
}

