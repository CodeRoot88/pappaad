import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { useState } from "react"
import { BillingCycle } from "./BillingCycle"
import { CreditCardForm } from "./CreditCardForm"
import { PlanDetails } from "./PlanDetails"

interface GetStartedModalProps {
  isOpen: boolean
  onClose: () => void
  tierName: string
  tierPrice: number
}

export const GetStartedModal = ({ isOpen, onClose }: GetStartedModalProps) => {

  const [cycle, setCycle] = useState<'monthly' | 'annually'>('monthly')
  const planItems = [
    { label: "Monthly", amount: 130 },
    { label: "Tax", amount: 0 },
  ]

  const handleCycleChange = (newCycle: 'monthly' | 'annually') => {
    setCycle(newCycle)
    console.log('Selected billing cycle:', newCycle)
  }

  const handleSubmit = (data: {
    cardHolder: string
    cardNumber: string
    expiration: string
    cvc: string
    isDefault: boolean
  }) => {
    console.log('Form data:', data)
  }


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-lg shadow-lg">
        <DialogHeader className="p-2">
          <DialogTitle className="text-2xl font-semibold">Plan Pro</DialogTitle>
          <DialogDescription className="text-gray-500">
            Started on Jan 2, 2024
          </DialogDescription>
        </DialogHeader>
        <Separator className="my-2" />
        <div className="max-h-[60vh] overflow-y-auto px-6">
          <div className="mt-4">
            <BillingCycle
              onCycleChange={handleCycleChange}
              defaultCycle={cycle}
              className="w-full"
            />
          </div>
          <Separator className="my-2" />
          <div className="mt-4">
            <CreditCardForm
              onSubmit={handleSubmit}
              className="w-full max-w-2xl"
            />
          </div>
          <Separator className="my-2" />
          <div className="mt-4">
            <PlanDetails
              items={planItems}
              className="w-full max-w-2xl"
            />
          </div>
        </div>
        <div className="mt-6 flex justify-end space-x-4 px-6 pb-6">
          <Button variant="outline" onClick={onClose} className="px-4 py-2">
            Cancel
          </Button>
          <Button onClick={onClose} className="px-4 py-2 bg-indigo-500 text-white hover:bg-indigo-700">
            Start Plan
          </Button>
        </div>
      </DialogContent>
    </Dialog>

  )
}

