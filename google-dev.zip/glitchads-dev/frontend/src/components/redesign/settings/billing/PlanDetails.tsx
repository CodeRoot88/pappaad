import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface PlanDetailsProps {
  items: {
    label: string
    amount: number
  }[]
  className?: string
}

export const PlanDetails = ({ items, className }: PlanDetailsProps) => {
  const total = items.reduce((sum, item) => sum + item.amount, 0)

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-xl font-medium">Plan details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {items.map((item, index) => (
          <div
            key={index}
            className="flex items-center justify-between"
          >
            <span className="text-base text-muted-foreground">
              {item.label}
            </span>
            <span className="text-base">
              ${item.amount}
            </span>
          </div>
        ))}
        <div className="flex items-center justify-between pt-4 border-t">
          <span className="text-base font-medium">
            Total
          </span>
          <span className="text-base font-medium">
            ${total}
          </span>
        </div>
      </CardContent>
    </Card>
  )
}

