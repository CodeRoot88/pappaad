import { useState } from "react"
import { cn } from "@/lib/utils"
import { PricingTier } from "./PricingTier"
import { SectionHeader } from "../../glitch-ui/section-header"
import { Card, CardContent } from "@/components/ui/card"
import { EmptyState } from "../../glitch-ui/EmptyState"
import { Folder } from "lucide-react"

interface BiilingInfoProps {
  onSelect?: (tier: string) => void
  className?: string
}

export const BiilingInfo = ({
  onSelect,
  className
}: BiilingInfoProps) => {
  const [selectedTier, setSelectedTier] = useState<string | null>(null)

  const tiers = [
    { name: "Basic", price: 100 },
    { name: "Pro", price: 130, recommended: true },
    { name: "Business", price: 150 },
  ]

  const handleSelect = (tierName: string) => {
    setSelectedTier(tierName)
    onSelect?.(tierName)
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Billing Info" />
      <div className={cn("grid grid-cols-1 md:grid-cols-3 gap-6", className)}>
        {tiers.map((tier) => (
          <PricingTier
            key={tier.name}
            name={tier.name}
            price={tier.price}
            isRecommended={tier.recommended}
            isSelected={selectedTier === tier.name}
            onSelect={() => handleSelect(tier.name)}
          />
        ))}
      </div>
      <div className="flex flex-col space-y-6">
        <SectionHeader title="Billing History" />
        <Card className="w-full">
          <CardContent className="p-6 space-y-6">
            <EmptyState
              icon={<Folder className="w-12 h-12 text-muted-foreground/60" />}
              title="You don't have any billing history yet."
              description="Choose a plan."
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

