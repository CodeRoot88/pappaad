import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"

interface CreditCardFormProps {
  onSubmit?: (data: {
    cardHolder: string
    cardNumber: string
    expiration: string
    cvc: string
    isDefault: boolean
  }) => void
  className?: string
}

export const CreditCardForm = ({ className }: CreditCardFormProps) => {
  const [formData, setFormData] = useState({
    cardHolder: "",
    cardNumber: "",
    expiration: "",
    cvc: "",
    isDefault: false
  })

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    const groups = numbers.match(/.{1,4}/g) || []
    return groups.join("-").substr(0, 19) // 16 digits + 3 dashes
  }

  const formatExpiration = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    if (numbers.length >= 2) {
      return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}`
    }
    return numbers
  }

  const handleChange = (field: string, value: string | boolean) => {
    let formattedValue = value
    if (typeof value === "string") {
      if (field === "cardNumber") {
        formattedValue = formatCardNumber(value)
      } else if (field === "expiration") {
        formattedValue = formatExpiration(value)
      } else if (field === "cvc") {
        formattedValue = value.replace(/\D/g, "").substr(0, 3)
      }
    }

    setFormData(prev => ({
      ...prev,
      [field]: formattedValue
    }))
  }

  return (
    <Card className={className}>
      <CardContent className="p-6">
        <form className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cardHolder">Card holder</Label>
            <Input
              id="cardHolder"
              placeholder="Name Surname"
              value={formData.cardHolder}
              onChange={(e) => handleChange("cardHolder", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cardNumber">Card Number</Label>
            <Input
              id="cardNumber"
              placeholder="1234-1234-1234-1234"
              value={formData.cardNumber}
              onChange={(e) => handleChange("cardNumber", e.target.value)}
              maxLength={19}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="expiration">Expiration</Label>
              <Input
                id="expiration"
                placeholder="MM/YY"
                value={formData.expiration}
                onChange={(e) => handleChange("expiration", e.target.value)}
                maxLength={5}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cvc">CVC</Label>
              <Input
                id="cvc"
                type="password"
                placeholder="***"
                value={formData.cvc}
                onChange={(e) => handleChange("cvc", e.target.value)}
                maxLength={3}
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="isDefault"
              checked={formData.isDefault}
              className="bg-white data-[state=checked]:bg-indigo-500 data-[state=checked]:text-primary-foreground"
              onCheckedChange={(checked) => handleChange("isDefault", checked)}
            />
            <Label
              htmlFor="isDefault"
              className="text-sm font-normal leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Set as default
            </Label>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

