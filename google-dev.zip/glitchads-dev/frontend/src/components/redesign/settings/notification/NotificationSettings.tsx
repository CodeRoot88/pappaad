import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { useState } from "react"
import { SectionHeader } from "../../glitch-ui/section-header"

interface NotificationSetting {
  id: string
  label: string
  checked: boolean
}

interface NotificationSection {
  title: string
  items: NotificationSetting[]
}

interface NotificationSettingsProps {
  onSettingsChange?: (settings: Record<string, boolean>) => void
}

export const NotificationSettings = ({ onSettingsChange }: NotificationSettingsProps) => {
  const [settings, setSettings] = useState<NotificationSection[]>([
    {
      title: "Campaigns:",
      items: [
        { id: "newAssets", label: "New assets to review", checked: true },
        { id: "newAds", label: "New ads to review", checked: true },
        { id: "newTasks", label: "New tasks to review", checked: false },
      ],
    },
    {
      title: "Privacy & Safety:",
      items: [
        { id: "newAuth", label: "New authorisation", checked: true },
        { id: "passwordReset", label: "Password reseting", checked: false },
      ],
    },
    {
      title: "System:",
      items: [
        { id: "newFeatures", label: "New features or system updates", checked: false },
      ],
    },
  ])

  const handleCheckboxChange = (sectionIndex: number, itemIndex: number) => {
    const newSettings = [...settings]
    newSettings[sectionIndex].items[itemIndex].checked =
      !newSettings[sectionIndex].items[itemIndex].checked

    setSettings(newSettings)

    // Create a flat object of all settings for the callback
    const flatSettings = newSettings.reduce((acc, section) => {
      section.items.forEach(item => {
        acc[item.id] = item.checked
      })
      return acc
    }, {} as Record<string, boolean>)

    onSettingsChange?.(flatSettings)
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Email me about" />
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="space-y-6">
            {settings.map((section, sectionIndex) => (
              <div key={section.title} className="space-y-3">
                <h3 className="font-medium text-sm">{section.title}</h3>
                <div className="space-y-2">
                  {section.items.map((item, itemIndex) => (
                    <div key={item.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={item.id}
                        checked={item.checked}
                        className="bg-white data-[state=checked]:bg-indigo-500 data-[state=checked]:text-primary-foreground"
                        onCheckedChange={() => handleCheckboxChange(sectionIndex, itemIndex)}
                      />
                      <label
                        htmlFor={item.id}
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {item.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

