import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { SectionHeader } from "../../glitch-ui/section-header"
import { formatPhoneNumber, validatePhone } from "@/lib/utils"

interface CompanyInfoProps {
  name: string
  url: string
  email: string
  phone: string
  onNameChange?: (name: string) => void
  onUrlChange?: (url: string) => void
  onEmailChange?: (email: string) => void
  onPhoneChange?: (phone: string) => void
}

export const CompanyInfo = ({
  name,
  url,
  email,
  phone,
  onNameChange,
  onUrlChange,
  onEmailChange,
  onPhoneChange,
}: CompanyInfoProps) => {

  const [isPhoneValid, setIsPhoneValid] = useState(true)
  const [formattedPhone, setFormattedPhone] = useState(phone.startsWith('+') ? phone : `+${phone}`)

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    const formatted = formatPhoneNumber(newValue)
    const isValid = validatePhone(formatted)

    setIsPhoneValid(isValid)
    setFormattedPhone(formatted)

    if (isValid) {
      onPhoneChange?.(formatted)
    }
  }

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onNameChange?.(e.target.value)
  }

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUrlChange?.(e.target.value)
  }

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onEmailChange?.(e.target.value)
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Company Info" />
      <Card className='overflow-hidden'>
        <CardContent className="grid grid-cols-2 gap-4 p-6">
          <div className="space-y-2">
            <Label htmlFor="company-name" className="text-sm text-gray-600">
              Company Name
            </Label>
            <div className="relative">
              <Input
                id="company-name"
                value={name}
                onChange={handleNameChange}
                placeholder="Company Name"
                className="h-10 bg-white text-gray-900 !ring !ring-transparent"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="url" className="text-sm text-gray-600">
              Website
            </Label>
            <div className="relative">
              <Input
                id="url"
                value={url}
                onChange={handleUrlChange}
                className="h-10 bg-white text-gray-900 !ring !ring-transparent"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email" className="text-sm text-gray-600">
              Email
            </Label>
            <div className="relative">
              <Input
                id="email"
                value={email}
                onChange={handleEmailChange}
                className="h-10 bg-white text-gray-900 !ring !ring-transparent"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-sm text-gray-600">
              Phone Number
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none">+</span>
              <Input
                id="phone"
                value={formattedPhone.slice(1)}
                onChange={handlePhoneChange}
                placeholder="0 000 00 000"
                className="h-10 bg-white text-gray-900 pl-6 !ring !ring-transparent"
                aria-invalid={!isPhoneValid}
                maxLength={13}
              />
            </div>
            {!isPhoneValid && (
              <p className="text-xs text-red-500">
                Phone number must contain at least one digit
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}