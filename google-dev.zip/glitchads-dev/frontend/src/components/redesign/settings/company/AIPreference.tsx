import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { preferences } from "../../utils/constants"
import { SectionHeader } from "../../glitch-ui/section-header"

interface AIPreferenceProps {
  value: string
  onChange: (value: string) => void
}

export const AIPreference = ({ value, onChange }: AIPreferenceProps) => {
  return (
    <div className="space-y-6">
      <SectionHeader title="AI Settings" />
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-base font-normal">
            How much would you prefer the AI do?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup value={value} onValueChange={onChange}>
            {preferences.map((preference) => (
              <div key={preference.id} className="flex items-center space-x-2">
                <RadioGroupItem value={preference.id} className="text-indigo-500 border-indigo-500 focus:ring-indigo-500" id={preference.id} />
                <Label
                  htmlFor={preference.id}
                  className="text-sm font-normal leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {preference.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>
    </div>
  )
}

