import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { SectionHeader } from "../../glitch-ui/section-header"

interface LocationProps {
  country: string
  language: string
  onCountryChange?: (country: string) => void
  onLanguageChange?: (language: string) => void
}

export const Location = ({
  country,
  language,
  onCountryChange,
  onLanguageChange,
}: LocationProps) => {

  const handleCountryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onCountryChange?.(e.target.value)
  }

  const handleLanguageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onLanguageChange?.(e.target.value)
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Location" />
      <Card className='overflow-hidden'>
        <CardContent className="grid grid-cols-2 gap-4 p-6">
          <div className="space-y-2">
            <Label htmlFor="country" className="text-sm text-gray-600">
              Country
            </Label>
            <div className="relative">
              <Input
                id="country"
                value={country}
                onChange={handleCountryChange}
                placeholder="Country"
                className="h-10 bg-white text-gray-900 !ring !ring-transparent"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="language" className="text-sm text-gray-600">
              Language
            </Label>
            <div className="relative">
              <Input
                id="language"
                value={language}
                onChange={handleLanguageChange}
                placeholder="Language"
                className="h-10 bg-white text-gray-900 !ring !ring-transparent"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}