import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { SectionHeader } from "../../glitch-ui/section-header"

interface GoogleAdsIntegrationProps {
  enabled: boolean
  accountId: string
  onToggle: (enabled: boolean) => void
  onAccountIdChange: (accountId: string) => void
}

export const GoogleAdsIntegration = ({
  enabled,
  accountId,
  onToggle,
  onAccountIdChange,
}: GoogleAdsIntegrationProps) => {
  return (
    <div className="space-y-6">
      <SectionHeader title="Google Ads Info" />
      <Card className="w-full">
        <CardContent className="p-6 space-y-6">
          <div className="flex items-center justify-start">
            <Switch
              checked={enabled}
              onCheckedChange={onToggle}
              className="data-[state=checked]:bg-indigo-500 data-[state=checked]:text-indigo-50 focus-visible:ring-indigo-500"
              aria-label="Toggle Google Ads integration"
            />
            <div className="space-y-0.5 ml-3">
              <Label className="text-base">Google Ads Integration</Label>
              <p className="text-sm text-muted-foreground">
                The data is synchronised with your Google Ads account.
              </p>
            </div>
          </div>
          {enabled && (
            <div className="space-y-2">
              <Label htmlFor="accountId">Account ID</Label>
              <Input
                id="accountId"
                value={accountId}
                onChange={(e) => onAccountIdChange(e.target.value)}
                placeholder="123-456-7890"
                className="max-w-md"
              />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

