import { useState } from "react"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { SectionHeader } from "../../glitch-ui/section-header"

interface TwoFactorAuthProps {
  onToggle?: (enabled: boolean) => void
  onAdd?: () => void
  className?: string
}

export const TwoFactorAuth = ({
  onToggle,
  onAdd,
  className
}: TwoFactorAuthProps) => {
  const [enabled, setEnabled] = useState(false)

  const handleToggle = (checked: boolean) => {
    setEnabled(checked)
    onToggle?.(checked)
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Two-factor authentication (2FA)" />
      <Card className={className}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between gap-4">
            <Switch
              checked={enabled}
              onCheckedChange={handleToggle}
              className="data-[state=checked]:bg-indigo-500 data-[state=checked]:text-indigo-50 focus-visible:ring-indigo-500"
              aria-label="Toggle two-factor authentication"
            />
            <div className="flex-1">
              <h3 className="text-base font-medium">Two-factor authentication</h3>
              <p className="text-sm text-muted-foreground">
                We recommend requiring a verification code in addition to your password.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onAdd}
            >
              Add
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

