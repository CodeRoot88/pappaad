import { useState } from "react"
import { MoreHorizontal, Trash } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { SectionHeader } from "../../glitch-ui/section-header"
import { ButtonProps } from "@/lib/types"

interface ActivityLog {
  id: string
  date: string
  location: string
  ip: string
  activity: string
}

interface ActivityLogTableProps {
  logs: ActivityLog[]
  onActionSelect?: (action: string, log: ActivityLog) => void
  onDelete?: (log: ActivityLog) => void
}

export const ActivityLogTable = ({
  logs,
  onDelete
}: ActivityLogTableProps) => {
  const [currentPage, setCurrentPage] = useState(1)
  const [deleteDialog, setDeleteDialog] = useState<{
    isOpen: boolean
    log: ActivityLog | null
  }>({
    isOpen: false,
    log: null
  })

  const buttons: ButtonProps[] = [
    {
      label: "Download PDF",
      onClick: () => { },
      variant: "secondary",
      className: "default text-white bg-indigo-500 hover:bg-indigo-700 mt-auto"
    },
  ]

  const logsPerPage = 10
  const totalPages = Math.ceil(logs.length / logsPerPage)
  const startIndex = (currentPage - 1) * logsPerPage
  const endIndex = startIndex + logsPerPage
  const currentLogs = logs.slice(startIndex, endIndex)

  const handleDelete = (log: ActivityLog) => {
    setDeleteDialog({ isOpen: true, log })
  }

  const confirmDelete = () => {
    if (deleteDialog.log) {
      onDelete?.(deleteDialog.log)
      setDeleteDialog({ isOpen: false, log: null })
    }
  }

  return (
    <div className="w-full">
      <div className="space-y-6">
        <SectionHeader title="Logs" buttonProps={buttons} />
        <div className="rounded-xl border bg-white p-2">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Activity</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell>{log.date}</TableCell>
                  <TableCell>{log.location}</TableCell>
                  <TableCell>{log.ip}</TableCell>
                  <TableCell>{log.activity}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => handleDelete(log)}
                          className="text-destructive"
                        >
                          <Trash className="h-4 w-4 mr-2" />
                          Delete log
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="flex items-center justify-between space-x-2 py-4">
          <div className="text-sm text-muted-foreground">
            {logs.length === 0 ? (
              "No logs"
            ) : (
              `${startIndex + 1} of ${Math.min(logs.length, endIndex)} log(s)`
            )}
          </div>
          <div className="space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>

        <Dialog open={deleteDialog.isOpen} onOpenChange={(isOpen) =>
          setDeleteDialog(prev => ({ ...prev, isOpen }))
        }>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Log Entry</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete this log entry? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setDeleteDialog({ isOpen: false, log: null })}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={confirmDelete}
              >
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

