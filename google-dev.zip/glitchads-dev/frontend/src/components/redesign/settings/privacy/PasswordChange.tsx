import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { SectionHeader } from "../../glitch-ui/section-header"

interface PasswordFieldProps {
  onEdit?: (value: string) => void
  defaultValue?: string
  className?: string
}

export const PasswordField = ({
  onEdit,
  defaultValue = "",
  className
}: PasswordFieldProps) => {
  const [isEditing, setIsEditing] = useState(false)
  const [value, setValue] = useState(defaultValue)

  const handleEdit = () => {
    if (isEditing) {
      onEdit?.(value)
    }
    setIsEditing(!isEditing)
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Password" />
      <Card className={className}>
        <CardContent className="p-6">
          <div className="grid grid-cols-2 items-center gap-4">
            <div className="flex-1">
              <Label htmlFor="password" className="text-base">
                Password
              </Label>
              <div className="mt-1.5">
                {isEditing ? (
                  <Input
                    id="password"
                    type="password"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    autoFocus
                  />
                ) : (
                  <Input
                    id="password"
                    type="password"
                    value={defaultValue}
                    disabled
                  />
                )}
              </div>
            </div>
            <div className="flex flex-col items-end">
              <Button
                variant="outline"
                size="sm"
                className="mt-6 ml-auto"
                onClick={handleEdit}
              >
                {isEditing ? "Save" : "Edit"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

