import { Card, CardContent } from "@/components/ui/card"
import { SectionHeader } from "../../glitch-ui/section-header"
import { EmptyState } from "../../glitch-ui/EmptyState"
import { Folder } from 'lucide-react'
import { ButtonProps } from "@/lib/types"

export const Members = () => {

  const buttons: ButtonProps[] = [
    {
      label: "Invite team member",
      onClick: () => { },
      variant: "secondary",
      className: "default text-white bg-indigo-500 hover:bg-indigo-700 mt-auto"
    },
  ]

  return (
    <div className="space-y-6">
      <SectionHeader title="Members" buttonProps={buttons} />
      <Card className="w-full">
        <CardContent className="p-6 space-y-6">
          <EmptyState
            icon={<Folder className="w-12 h-12 text-muted-foreground/60" />}
            title="You don't have any members yet."
            description="Invite the first one."
          />
        </CardContent>
      </Card>
    </div>
  )
}

