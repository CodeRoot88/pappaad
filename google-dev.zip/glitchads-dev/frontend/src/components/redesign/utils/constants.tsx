import { CircleHelp, MousePointerClick, Sparkles } from "lucide-react"

import { StatusCardProps, StatusSectionProps, CampaignGoal } from "@/lib/types"

export const campaignGoals: CampaignGoal[] = [
  {
    id: "impression",
    title: "Impression",
    icon: <Sparkles className="h-5 w-5" />,
    className: "bg-indigo-50 text-indigo-400"
  },
  {
    id: "clicks",
    title: "Clicks",
    icon: <Sparkles className="h-5 w-5" />,
    className: "bg-cyan-50 text-cyan-400"
  },
  {
    id: "purchases",
    title: "Purchases",
    icon: <Sparkles className="h-5 w-5" />,
    className: "bg-violet-50 text-violet-400"
  },
  {
    id: "qualified_leads",
    title: "Qualified leads in CRM",
    icon: <Sparkles className="h-5 w-5" />,
    className: "bg-amber-50 text-amber-400"
  },
]

export const preferences = [
  {
    id: "all",
    label: "I want it to take all actions without me"
  },
  {
    id: "obvious",
    label: "I want it to take obvious actions without my input"
  },
  {
    id: "review",
    label: "I want to review every improvement before the system applies it"
  }
]

export const summaryContent = [
  "You have ads running for",
  "https://birdie.com/",
  ".This is a SASS business targeting.",
  "cooporate hot desking",
  "and",
  "car space management",
  ". We have been running ads for ",
  "9 months",
  ". We are using a strategy of",
  "2 cmpaigns to get more audience",
  "and",
  "1 campagn to convert",
]

export interface Ad {
  title: string
  description: string
  keywords: string[]
  needReview: boolean
}

export interface Headline {
  id: string
  keyword: string
  headline: string
}

export interface Keyword {
  id: string
  text: string
}

export interface OptionalHeadline {
  id: string
  text: string
  keywords: Keyword[]
}

export interface OptionalAd {
  title: string
  description: string
  headlines: OptionalHeadline[]
  needReview: boolean
}

export const ads: Ad[] = [
  {
    title:
      'Voit Digital Products I Accounting for Small Business I UpsellVoit Digital Products I Accounting for Small Business I Upsell',
    description:
      'We are an award-winning creative design agency from Ukraine. Manufacturer of Hard Material Products for Wear Protection and Cutting Tools.',
    keywords: [
      'best coffee shop near me',
      'coffee nearby opening a coffee shop',
      'coffee business',
      'friends coffee shop',
      'best coffee shop near me',
      'coffee nearby opening a coffee shop',
      'coffee business',
      'friends coffee shop',
      'best coffee shop near me',
      'friends coffee shop coffee business',
      'coffee nearby opening a coffee shop',
    ],
    needReview: true,
  },
]

export const headlines: Headline[] = [
  {
    id: 'headline-1',
    keyword: 'My keyword',
    headline: 'My headline',
  },
  {
    id: 'headline-1',
    keyword: 'My keyword',
    headline: 'My headline',
  },
]

export const ad: OptionalAd = {
  title:
    'Voit Digital Products I Accounting for Small Business IVoit Digital Products I Accounting for Small Business I',
  description:
    'We are an award-winning creative design agency from Ukraine. Manufacturer of Hard Material Products for Wear Protection and Cutting Tools.',
  headlines: [
    {
      id: 'headline-1',
      text: 'best coffee shop near me',
      keywords: [],
    },
    {
      id: 'headline-1',
      text: 'best coffee shop near me',
      keywords: [],
    },
    {
      id: 'headline-1',
      text: 'best coffee shop near me',
      keywords: [],
    },
  ],
  needReview: true,
}

export const optionalheadlines: OptionalHeadline[] = [
  {
    id: 'headline-1',
    text: 'My keyword',
    keywords: [
      {
        id: 'mykeyword-1',
        text: 'mykeyword',
      },
      {
        id: 'mykeyword-1',
        text: 'mykeyword',
      },
      {
        id: 'mykeyword-1',
        text: 'mykeyword',
      },
    ],
  },
]

export const statusCardData: StatusCardProps[] = [
  {
    icon: <CircleHelp className="h-5 w-5 text-purple-600" />,
    title: "How is it going",
    description: "Discovery campaigns are live, and we've already gathered valuable data on audience segments. Initial results show a {0} increase in engagement and {1} rise in clicks, helping us refine our targeting for the next phase.",
    values: ["X%", "Y%"],
  }
]

export const statusSectionData: StatusSectionProps[] = [
  {
    title: "How is it going?",
    description: "Discovery campaigns are live. These insights will refine our next phase.",
    metrics: [
      {
        label: "Engagement",
        value: "X%",
        icon: <Sparkles className="h-4 w-4" />
      },
      {
        label: "Clicks",
        value: "X%",
        icon: <MousePointerClick className="h-4 w-4" />
      }
    ]
  }
]

export const statusCardDataWithRealValue: StatusCardProps = {
  icon: <CircleHelp className="h-5 w-5 text-purple-600" />,
  title: "How is it going",
  description: "Discovery campaigns are live, and we've already gathered valuable data on audience segments. Initial results show a {0} increase in engagement and {1} rise in clicks, helping us refine our targeting for the next phase.",
  values: ["12%", "12%"],
}