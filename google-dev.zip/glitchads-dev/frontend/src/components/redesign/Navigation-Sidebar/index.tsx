import { BadgeCheck, ChevronsUpDown, LogOut } from 'lucide-react';
import { Link, useLocation, useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  useSidebar,
} from '@/components/ui/sidebar';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import logo from '/logo_lightbg.svg';
import { useUserProfile } from '@/contexts/user.context';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { navigation } from './constants';
import { defaultProfile, deleteAccessTokenCookie } from '@/lib/auth';

export function NavigationSidebar() {
  const location = useLocation();
  const { isMobile } = useSidebar();
  const { user, setUser } = useUserProfile();

  const queryClient = useQueryClient(); // React Query's query client
  const navigate = useNavigate();
  const logout = () => {
    deleteAccessTokenCookie();
    setUser(defaultProfile);
    queryClient.invalidateQueries();
    navigate({ to: '/redesign/login' });
  };

  return (
    <Sidebar collapsible='icon' className='bg-white border-none'>
      <SidebarHeader className='p-6'>
        <img className='hidden h-8 m-2 mr-auto w-auto lg:block' src={logo} alt='Glitch' />
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {navigation.map((item) => (
            <SidebarMenuItem key={item.name} className='ml-3 rounded-xl'>
              <SidebarMenuButton
                asChild
                className={`gap-3 text-lg py-5 px-4 font-medium rounded-xl outline-none border-none hover:bg-purple-50 ${location.pathname.startsWith(item.to) && 'bg-purple-100'}`}
              >
                <Link to={item.to}>
                  <item.icon className='!h-5 !w-5' />
                  <span>{item.name}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton
                  size='lg'
                  className='data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground'
                >
                  <Avatar className='h-8 w-8 rounded-lg'>
                    <AvatarImage src={user.picture} alt={user.name} />
                    <AvatarFallback className='rounded-lg'>CN</AvatarFallback>
                  </Avatar>
                  <div className='grid flex-1 text-left text-sm leading-tight'>
                    <span className='truncate font-semibold'>{user.name}</span>
                    <span className='truncate text-xs'>{user.email}</span>
                  </div>
                  <ChevronsUpDown className='ml-auto size-4' />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className='w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg'
                side={isMobile ? 'bottom' : 'right'}
                align='end'
                sideOffset={4}
              >
                <DropdownMenuLabel className='p-0 font-normal'>
                  <div className='flex items-center gap-2 px-1 py-1.5 text-left text-sm'>
                    <Avatar className='h-8 w-8 rounded-lg mr-2'>
                      <AvatarImage src={user.picture} alt={user.name} />
                      <AvatarFallback className='rounded-lg'>CN</AvatarFallback>
                    </Avatar>
                    <div className='grid flex-1 text-left text-sm leading-tight'>
                      <span className='truncate font-semibold'>{user.name}</span>
                      <span className='truncate text-xs'>{user.email}</span>
                    </div>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem>
                    <BadgeCheck className='mr-4' />
                    My Profile
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>
                  <LogOut className='mr-4' />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
