import { Home, ScanQrCode, ListTodo, Settings2 } from 'lucide-react'

export const navigation = [
  {
    name: "Home",
    to: "/redesign/home",
    icon: Home,
  },
  {
    name: "Tasks",
    to: "/redesign/tasks",
    icon: ListTodo,
  },
  {
    name: "Campaigns",
    to: "/redesign/campaigns",
    icon: ScanQrCode,
  },
  {
    name: "Settings",
    to: "/redesign/settings",
    icon: Settings2,
  },
]