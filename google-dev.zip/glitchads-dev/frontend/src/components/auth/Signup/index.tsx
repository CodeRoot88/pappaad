import { usePostHog } from 'posthog-js/react';
import { FieldGroup, Fieldset } from "@/components/catalyst/fieldset";
import { LockClosedIcon } from "@radix-ui/react-icons";
import { useForm } from "@tanstack/react-form";
import { Link, useNavigate } from "@tanstack/react-router";
import { zodValidator } from "@tanstack/zod-form-adapter";
import { useToast } from '@/components/ui/use-toast';
import { useUserAccountRegisterMutation } from '@/lib/query-options';
import { useState } from 'react';
import { setCookie } from '@/lib/utils';

export function Signup() {
	const posthog = usePostHog();
	const { toast } = useToast()
	const navigate = useNavigate({ from: '/' });
	const [userData, setUserData] = useState({
		name: "",
		email: "",
		password: ""
	})

	const userAccountRegisterMutation = useUserAccountRegisterMutation(userData.name, userData.email, userData.password);

	const form = useForm({
		defaultValues: {
			name: '',
			email: '',
			password: '',
			confirm_password: '',
		},

		onSubmit: async ({ value }) => {
			if (value.password !== value.confirm_password) {
				toast({ description: 'Passwords do not match.' })
				return
			}
			try {
				const res = await userAccountRegisterMutation.mutateAsync()
				setCookie('access_token', res.token, 1);
				toast({ description: res.message })
				navigate({ to: '/' });
			} catch (err) {
				toast({ description: 'User Email is already exist.', variant: 'destructive' });
			}
		},
		validatorAdapter: zodValidator(),
	});

	const handleFieldChange = <T,>(fieldName: string, value: T) => {
		posthog?.capture('field_changed', { fieldName, value });
	};

	return (
		<>
			<div className="flex w-full items-center justify-center px-4 sm:px-4 lg:px-4">
				<div className="w-full max-w-md space-y-4">
					<form className="mt-8 space-y-6 gap-x-2" onSubmit={(e) => { e.preventDefault(); e.stopPropagation(); form.handleSubmit(); }}>
						<Fieldset>
							<FieldGroup>
								<input type="hidden" name="remember" defaultValue="true" />
								<div className="-space-y-px rounded-md shadow-sm">
								<form.Field name='name'>
										{(field) => (
											<div className="pb-2">
												<label htmlFor="name" className="sr-only">
													User Name
												</label>
												<input
													name="name"
													type="name"
													required
													className="relative block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
													placeholder="User Name"
													onChange={(e) => { handleFieldChange("name", e.target.value); field.handleChange(e.target.value); setUserData({ ...userData, name: e.target.value }) }}
												/>
											</div>
										)}
									</form.Field>
									<form.Field name='email'>
										{(field) => (
											<div className="pb-2">
												<label htmlFor="email-address" className="sr-only">
													Email address
												</label>
												<input
													name="email"
													type="email"
													autoComplete="email"
													required
													className="relative block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
													placeholder="Email address"
													onChange={(e) => { handleFieldChange("email", e.target.value); field.handleChange(e.target.value); setUserData({ ...userData, email: e.target.value }) }}
												/>
											</div>
										)}
									</form.Field>

									<form.Field name='password'>
										{(field) => (
											<div className="pb-2">
												<label className="sr-only">Password</label>
												<input
													name="password"
													type="password"
													required
													className="relative block w-full appearance-none rounded-none  border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
													placeholder="Password"
													onChange={(e) => { handleFieldChange("password", e.target.value); field.handleChange(e.target.value); setUserData({ ...userData, password: e.target.value }) }}
												/>
											</div>
										)}
									</form.Field>
									<form.Field name="confirm_password">
										{(field) => (
											<div>
												<label className="sr-only">Confirm Password</label>
												<input
													name="confirm_password"
													type="password"
													required
													className="relative block w-full appearance-none rounded-none rounded-b-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
													placeholder="Confirm Password"
													onChange={(e) => { handleFieldChange("confirm_password", e.target.value); field.handleChange(e.target.value) }}
												/>
											</div>
										)}
									</form.Field>
								</div>

								<div>
									<button
										type="submit"
										disabled={false}
										className="group relative transition-colors flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
									>
										<span className="absolute inset-y-0 left-0 flex items-center pl-3">
											<LockClosedIcon
												className="h-5 w-5 text-indigo-500 group-hover:text-indigo-400"
												aria-hidden="true"
											/>
										</span>
										Sign up
									</button>
								</div>
							</FieldGroup>
						</Fieldset>
						<div className="text-sm text-center">
							<Link
								className="font-medium text-indigo-600 hover:text-indigo-500"
								to="/login"
							>
								Already have an account?
							</Link>
						</div>
					</form>
				</div>
			</div >
		</>
	)
}