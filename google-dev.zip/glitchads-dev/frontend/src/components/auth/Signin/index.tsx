import { usePostHog } from 'posthog-js/react';
import { FieldGroup, Fieldset } from '@/components/catalyst/fieldset';
import { LockClosedIcon } from '@radix-ui/react-icons';
import { useForm } from '@tanstack/react-form';
import { Link, useNavigate } from '@tanstack/react-router';
import { zodValidator } from '@tanstack/zod-form-adapter';
import { useToast } from '@/components/ui/use-toast';
import { useUserAccountLoginMutation } from '@/lib/query-options';
import { useState } from 'react';
import { setCookie } from '@/lib/utils';

export function Signin() {
  const posthog = usePostHog();
  const { toast } = useToast();
  const navigate = useNavigate({ from: '/' });
  const [userData, setUserData] = useState({
    email: '',
    password: '',
  });

  const userAccountLoginMutation = useUserAccountLoginMutation(userData.email, userData.password);

  const form = useForm({
    defaultValues: {
      email: '',
      password: '',
    },

    onSubmit: async ({ value }) => {
      if (value.password === '') {
        toast({ description: 'Please input your password.', variant: 'destructive' });
      }
      try {
        const res = await userAccountLoginMutation.mutateAsync();
        setCookie('access_token', res.token, 1);
        toast({ description: res.message });
        navigate({ to: '/' });
      } catch (err) {
        toast({ description: 'Email or Password is not correct.', variant: 'destructive' });
      }
    },
    validatorAdapter: zodValidator(),
  });

  const handleFieldChange = <T,>(fieldName: string, value: T) => {
    posthog?.capture('field_changed', { fieldName, value });
  };
  return (
    <>
      <div className='flex w-full items-center justify-center px-4 sm:px-4 lg:px-4'>
        <div className='w-full max-w-md space-y-4'>
          <form
            className='mt-8 space-y-6'
            onSubmit={(e) => {
              e.preventDefault();
              e.stopPropagation();
              form.handleSubmit();
            }}
          >
            <Fieldset>
              <FieldGroup>
                <input type='hidden' name='remember' defaultValue='true' />
                <div className='-space-y-px rounded-md shadow-sm'>
                  <form.Field name='email'>
                    {(field) => (
                      <div className='pb-2'>
                        <label htmlFor='email-address' className='sr-only'>
                          Email address
                        </label>
                        <input
                          id='email-address'
                          name='email'
                          type='email'
                          autoComplete='email'
                          required
                          className='relative block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm'
                          placeholder='Email address'
                          onChange={(e) => {
                            handleFieldChange('email', e.target.value);
                            field.handleChange(e.target.value);
                            setUserData({ ...userData, email: e.target.value });
                          }}
                        />
                      </div>
                    )}
                  </form.Field>
                  <form.Field name='password'>
                    {(field) => (
                      <div>
                        <label htmlFor='password' className='sr-only'>
                          Password
                        </label>
                        <input
                          id='password'
                          name='password'
                          type='password'
                          autoComplete='current-password'
                          required
                          className='relative block w-full appearance-none rounded-none rounded-b-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm'
                          placeholder='Password'
                          onChange={(e) => {
                            handleFieldChange('password', e.target.value);
                            field.handleChange(e.target.value);
                            setUserData({ ...userData, password: e.target.value });
                          }}
                        />
                      </div>
                    )}
                  </form.Field>
                </div>

                <div className='flex items-center justify-between'>
                  <div className='flex items-center'>
                    <input
                      id='remember-me'
                      name='remember-me'
                      type='checkbox'
                      className='h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500'
                    />
                    <label htmlFor='remember-me' className='ml-2 block text-sm text-gray-900'>
                      Remember me
                    </label>
                  </div>

                  <div className='text-sm'>
                    <Link to={'/campaigns'} className='font-medium text-indigo-600 hover:text-indigo-500'>
                      Forgot your password?
                    </Link>
                  </div>
                </div>

                <div>
                  <button
                    type='submit'
                    disabled={false}
                    className='group relative transition-colors flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'
                  >
                    <span className='absolute inset-y-0 left-0 flex items-center pl-3'>
                      <LockClosedIcon
                        className='h-5 w-5 text-indigo-500 group-hover:text-indigo-400'
                        aria-hidden='true'
                      />
                    </span>
                    Sign in
                  </button>
                </div>
              </FieldGroup>
            </Fieldset>
            <div className='text-sm text-center'>
              <Link to={'/signup'} className='font-medium text-indigo-600 hover:text-indigo-500'>
                Don't have an account?
              </Link>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
