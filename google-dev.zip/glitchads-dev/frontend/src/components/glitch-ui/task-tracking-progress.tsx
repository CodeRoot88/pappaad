import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cog } from 'lucide-react';
import { TaskTrackingSummary, TaskTrackingResponse } from '@/lib/types';

interface TaskTrackingProgressProps {
  interval?: number;
  taskTrackingData?: TaskTrackingResponse;
}

const generateTaskStatusText = (label: string, data: TaskTrackingSummary) => {
  if (data.in_progress === 0 && data.completed === 0) {
    return `${label} this job is in the queue...`;
  }
  let statusText = label;
  if (data.in_progress > 0) {
    if (label === 'Generating Keywords: ') {
      statusText += ` ${data.in_progress * 15} in progress`;
    } else if (label === 'Generating Descriptions: ') {
      statusText += ` ${data.in_progress * 4} in progress`;
    } else {
      statusText += ` ${data.in_progress} in progress`;
    }
  }
  if (data.completed > 0) {
    if (data.in_progress > 0) {
      statusText += ', ';
    }
    if (label === 'Generating Keywords: ') {
      statusText += ` ${data.completed * 15} completed`;
    } else if (label === 'Generating Descriptions: ') {
      statusText += ` ${data.completed * 4} completed`;
    } else {
      statusText += `${data.completed} completed`;
    }
  }
  return statusText;
};

export const TaskTrackingProgress: React.FC<TaskTrackingProgressProps> = ({ interval = 5000, taskTrackingData }) => {
  if (!taskTrackingData) {
    return null;
  }
  const loadingStates = [
    { label: 'Generating TCPA: ', data: taskTrackingData.tcpa_generation },
    { label: 'Generating Ads: ', data: taskTrackingData.ad_generation },
    { label: 'Generating Keywords: ', data: taskTrackingData.keywords_generation },
    { label: 'Generating Headlines: ', data: taskTrackingData.headline_generation },
    { label: 'Generating Descriptions: ', data: taskTrackingData.descriptions_generation },
  ];

  const [currentStateIndex, setCurrentStateIndex] = useState<number>(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentStateIndex((prevIndex) => (prevIndex + 1) % loadingStates.length);
    }, interval);

    return () => clearInterval(intervalId);
  }, [interval, loadingStates]);

  const currentTask = loadingStates[currentStateIndex];

  return (
    <div className='flex flex-col items-center space-y-4'>
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.5, ease: 'easeInOut' }}
        className='flex items-center space-x-4'
        role='status'
        aria-live='polite'
      >
        <Cog className='w-6 h-6 text-blue-500 animate-spin ' />
        <AnimatePresence mode='wait'>
          <motion.div
            key={currentStateIndex}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
          >
            <h2 className='text-xl font-bold text-blue-600'>
              {generateTaskStatusText(currentTask.label, currentTask.data)}
            </h2>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default TaskTrackingProgress;
