import { useState } from 'react';
import { usePostHog } from 'posthog-js/react';

import { Alert, AlertActions, AlertTitle } from '@/components/catalyst/alert';
import { Button } from '@/components/catalyst/button';
import { PlusIcon, EllipsisHorizontalIcon } from '@heroicons/react/24/solid';
import { Dropdown, DropdownButton, DropdownItem, DropdownMenu } from '@/components/catalyst/dropdown';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/catalyst/table';
import { SiteLink as SiteLinkType } from '@/lib/types';
import { SiteLinkForm } from './site-link-form';
import { useDeleteSiteLinkMutationOptions, useUpdateSiteLinkMutationOptions } from '@/lib/query-options';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';

export function SiteLinks({
  siteLinks,
  refetchCampaign,
  campaignId,
}: {
  siteLinks: SiteLinkType[];
  refetchCampaign: () => void;
  campaignId: number;
}) {
  const posthog = usePostHog();
  const { toast } = useToast();

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteSiteLinkId, setDeleteLinkId] = useState<number | null>(null);
  const [newSiteLinkOpen, setNewSiteLinkOpen] = useState(false);
  const siteLinkUpdateMutation = useUpdateSiteLinkMutationOptions();

  const handleSaveSiteLink = async (updatedSiteLink: SiteLinkType) => {
    try {
      await siteLinkUpdateMutation.mutateAsync({ campaignId, siteLink: updatedSiteLink });
      refetchCampaign();
      toast({ description: '🙌 Site link updated' });
      posthog?.capture('site_link_updated', updatedSiteLink);
    } catch (error) {
      console.error(error);
    }
  };

  const siteLinkDeleteMutation = useDeleteSiteLinkMutationOptions();

  const handleDeleteSiteLink = async () => {
    if (!deleteSiteLinkId) return;
    try {
      setDeleteConfirmOpen(false);
      await siteLinkDeleteMutation.mutateAsync({ campaignId, siteLinkId: deleteSiteLinkId });
      refetchCampaign();
      toast({ description: '🗑️ Site link deleted' });
      posthog?.capture('site_link_deleted', { siteLinkId: deleteSiteLinkId });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Toaster />
      <Alert open={deleteConfirmOpen} onClose={setDeleteConfirmOpen}>
        <AlertTitle>Are you sure you want to delete this link?</AlertTitle>
        <AlertActions>
          <Button plain onClick={() => setDeleteConfirmOpen(false)}>
            Cancel
          </Button>
          <Button color='rose' onClick={handleDeleteSiteLink}>
            Delete
          </Button>
        </AlertActions>
      </Alert>
      <div className='p-4'>
        <SiteLinkForm
          isOpen={newSiteLinkOpen}
          setIsOpen={setNewSiteLinkOpen}
          siteLink={{
            name: '',
            description1: '',
            description2: '',
            url: '',
          }}
          handleSaveSiteLink={handleSaveSiteLink}
        />
        <Table className='[--gutter:theme(spacing.6)] sm:[--gutter:theme(spacing.8)]'>
          <TableHead>
            <TableRow>
              <TableHeader>Name</TableHeader>
              <TableHeader>Description</TableHeader>
              <TableHeader>Link</TableHeader>
              <TableHeader className='relative w-0'>
                <span className='sr-only'>Actions</span>
              </TableHeader>
            </TableRow>
          </TableHead>
          <TableBody>
            {siteLinks.map((siteLink) => (
              <SiteLink
                key={siteLink.id}
                siteLink={siteLink}
                handleSaveSiteLink={handleSaveSiteLink}
                handleDeleteSiteLink={handleDeleteSiteLink}
                setDeleteConfirmOpen={setDeleteConfirmOpen}
                setDeleteLinkId={setDeleteLinkId}
              />
            ))}
          </TableBody>
        </Table>
        <div>
          <Button
            color='white'
            className='mt-4'
            onClick={() => {
              setNewSiteLinkOpen(true);
              posthog?.capture('add_site_link_clicked');
            }}
          >
            <PlusIcon className='text-slate-900' />
            Add Site Link
          </Button>
        </div>
      </div>
    </>
  );
}

function SiteLink({
  siteLink,
  handleSaveSiteLink,
  setDeleteConfirmOpen,
  setDeleteLinkId,
}: {
  siteLink: SiteLinkType;
  handleSaveSiteLink: (updatedSiteLink: SiteLinkType) => void;
  handleDeleteSiteLink: (siteLinkId: number) => void;
  setDeleteConfirmOpen: (open: boolean) => void;
  setDeleteLinkId: (id: number) => void;
}) {
  const posthog = usePostHog();
  const [edit, setEdit] = useState(false);

  const { name, description1, description2, url } = siteLink;
  const handleDelete = () => {
    if (!siteLink.id) return;
    setDeleteLinkId(siteLink.id);
    setDeleteConfirmOpen(true);
    posthog?.capture('delete_site_link_clicked', { siteLinkId: siteLink.id });
  };

  if (edit) {
    return (
      <SiteLinkForm isOpen={edit} setIsOpen={setEdit} siteLink={siteLink} handleSaveSiteLink={handleSaveSiteLink} />
    );
  }

  return (
    <>
      <TableRow key={name}>
        <TableCell className='font-medium'>{name}</TableCell>
        <TableCell>
          <div>{description1}</div>
          <div>{description2}</div>
        </TableCell>
        <TableCell>{url}</TableCell>
        <TableCell>
          <div className='-mx-3 -my-1.5 sm:-mx-2.5'>
            <Dropdown>
              <DropdownButton plain aria-label='More options'>
                <EllipsisHorizontalIcon />
              </DropdownButton>
              <DropdownMenu anchor='bottom end'>
                <DropdownItem
                  onClick={() => {
                    setEdit(true);
                    posthog?.capture('edit_site_link_clicked', { siteLinkId: siteLink.id });
                  }}
                >
                  Edit
                </DropdownItem>
                <DropdownItem className='text-rose-500' onClick={handleDelete}>
                  Delete
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </div>
        </TableCell>
      </TableRow>
    </>
  );
}
