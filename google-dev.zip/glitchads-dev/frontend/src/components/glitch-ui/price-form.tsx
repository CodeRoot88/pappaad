import { useEffect } from 'react';
import { usePostHog } from 'posthog-js/react';
import { useForm } from '@tanstack/react-form';
import clsx from 'clsx';
import { z } from 'zod';
import { zodValidator } from '@tanstack/zod-form-adapter';

import { Button } from '@/components/catalyst/button';
import { Dialog, DialogActions, DialogBody } from '@/components/catalyst/dialog';
import { Field, FieldGroup, Fieldset, Label, ErrorMessage } from '@/components/catalyst/fieldset';
import { Input } from '@/components/catalyst/input';
import { Listbox, ListboxOption, ListboxLabel } from '@/components/catalyst/listbox';
import { PriceType } from '@/lib/types';

const priceTypes = [
  { name: 'Brands', value: 'brands' },
  { name: 'Events', value: 'events' },
  { name: 'Locations', value: 'locations' },
  { name: 'Neighborhoods', value: 'neighborhoods' },
  { name: 'Product Categories', value: 'product categories' },
  { name: 'Product Tiers', value: 'product tiers' },
  { name: 'Services', value: 'services' },
  { name: 'Service Tiers', value: 'service tiers' },
];

const qualifiers = [
  { name: 'No Qualifier', value: 'no qualifier' },
  { name: 'From', value: 'from' },
  { name: 'Up To', value: 'up to' },
  { name: 'Average', value: 'average' },
];

const frequencies = [
  { name: 'No Units', value: 'no units' },
  { name: 'Per Hour', value: 'per hour' },
  { name: 'Per Day', value: 'per day' },
  { name: 'Per Week', value: 'per week' },
  { name: 'Per Month', value: 'per month' },
  { name: 'Per Year', value: 'per year' },
  { name: 'Per Night', value: 'per night' },
];

const currencies = [
  'USD',
  'CAD',
  'EUR',
  'GBP',
  'INR',
  'JPY',
  'CNY',
  'AUD',
  'NZD',
  'CHF',
  'BRL',
  'RUB',
  'SGD',
  'HKD',
  'MXN',
  'ZAR',
];

export function PriceForm({
  isOpen,
  setIsOpen,
  price,
  handleSavePrice,
}: {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  price: PriceType;
  handleSavePrice: (price: PriceType) => void;
}) {
  const posthog = usePostHog();

  useEffect(() => {
    if (isOpen) {
      posthog?.capture('price_form_opened', { priceId: price.id });
    }
  }, [isOpen]);

  const form = useForm({
    defaultValues: {
      type: price.type,
      currency: price.currency,
      qualifier: price.qualifier,
      header: price.header,
      value: price.value.toString(),
      frequency: price.frequency,
      description: price.description,
      final_url: price.final_url,
      mobile_url: price.mobile_url || '',
    },
    onSubmit: async ({ value }) => {
      const updatedPrice: PriceType = {
        ...price,
        ...value,
        value: parseFloat(value.value),
      };
      handleSavePrice(updatedPrice);
      setIsOpen(false);
      posthog?.capture('price_saved', { priceId: updatedPrice.id, ...updatedPrice });
    },
    validatorAdapter: zodValidator(),
  });

  const handleFieldChange = (fieldName: string, value: string) => {
    posthog?.capture('price_form_field_changed', { fieldName, value });
  };

  return (
    <Dialog open={isOpen} onClose={() => setIsOpen(false)}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          e.stopPropagation();
          void form.handleSubmit();
        }}
      >
        <DialogBody>
          <Fieldset>
            <FieldGroup>
              <form.Field
                name='type'
                validators={{
                  onChange: z.string().min(1, 'Type is required'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Type</Label>
                    <Listbox
                      name={field.name}
                      defaultValue={field.state.value}
                      onChange={(value) => {
                        field.handleChange(value);
                        handleFieldChange('type', value);
                      }}
                    >
                      {priceTypes.map((type) => (
                        <ListboxOption key={type.value} value={type.value}>
                          <ListboxLabel>{type.name}</ListboxLabel>
                        </ListboxOption>
                      ))}
                    </Listbox>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='currency'
                validators={{
                  onChange: z.string().min(1, 'Currency is required'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Currency</Label>
                    <Listbox
                      name={field.name}
                      defaultValue={field.state.value}
                      onChange={(value) => {
                        field.handleChange(value);
                        handleFieldChange('currency', value);
                      }}
                    >
                      {currencies.map((currency) => (
                        <ListboxOption key={currency} value={currency}>
                          <ListboxLabel>{currency}</ListboxLabel>
                        </ListboxOption>
                      ))}
                    </Listbox>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='qualifier'
                validators={{
                  onChange: z.string().min(1, 'Qualifier is required'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Qualifier</Label>
                    <Listbox
                      name={field.name}
                      defaultValue={field.state.value}
                      onChange={(value) => {
                        field.handleChange(value);
                        handleFieldChange('qualifier', value);
                      }}
                    >
                      {qualifiers.map((qualifier) => (
                        <ListboxOption key={qualifier.value} value={qualifier.value}>
                          <ListboxLabel>{qualifier.name}</ListboxLabel>
                        </ListboxOption>
                      ))}
                    </Listbox>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='header'
                validators={{
                  onChange: z.string().min(1, 'Header is required'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Header</Label>
                    <Input
                      name={field.name}
                      value={field.state.value}
                      onBlur={field.handleBlur}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('header', e.target.value);
                      }}
                      placeholder='Enter header'
                    />
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='value'
                validators={{
                  onChange: z
                    .string()
                    .min(1, 'Value is required')
                    .refine((val) => !isNaN(parseFloat(val)), 'Value must be a number'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Value</Label>
                    <Input
                      name={field.name}
                      value={field.state.value}
                      onBlur={field.handleBlur}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('value', e.target.value);
                      }}
                      type='number'
                      step='0.01'
                      placeholder='Enter value'
                    />
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='frequency'
                validators={{
                  onChange: z.string().min(1, 'Frequency is required'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Frequency</Label>
                    <Listbox
                      name={field.name}
                      defaultValue={field.state.value}
                      onChange={(value) => {
                        field.handleChange(value);
                        handleFieldChange('frequency', value);
                      }}
                    >
                      {frequencies.map((frequency) => (
                        <ListboxOption key={frequency.value} value={frequency.value}>
                          <ListboxLabel>{frequency.name}</ListboxLabel>
                        </ListboxOption>
                      ))}
                    </Listbox>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='description'
                validators={{
                  onChange: z.string().min(1, 'Description is required'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Description</Label>
                    <Input
                      name={field.name}
                      value={field.state.value}
                      onBlur={field.handleBlur}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('description', e.target.value);
                      }}
                      placeholder='Enter description'
                    />
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='final_url'
                validators={{
                  onChange: z.string().url('Must be a valid URL'),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Final URL</Label>
                    <Input
                      name={field.name}
                      value={field.state.value}
                      onBlur={field.handleBlur}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('final_url', e.target.value);
                      }}
                      placeholder='Enter final URL'
                    />
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              <form.Field
                name='mobile_url'
                validators={{
                  onChange: z.string().url('Must be a valid URL').optional(),
                }}
              >
                {(field) => (
                  <Field>
                    <Label>Mobile URL (Optional)</Label>
                    <Input
                      name={field.name}
                      value={field.state.value}
                      onBlur={field.handleBlur}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('mobile_url', e.target.value);
                      }}
                      placeholder='Enter mobile URL'
                    />
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>
            </FieldGroup>
          </Fieldset>
        </DialogBody>
        <DialogActions>
          <Button plain onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <form.Subscribe
            selector={(state) => [state.canSubmit, state.isSubmitting]}
            children={([canSubmit, isSubmitting]) => (
              <Button
                color='indigo'
                className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                type='submit'
                disabled={!canSubmit}
              >
                {isSubmitting ? '...' : 'Save'}
              </Button>
            )}
          />
        </DialogActions>
      </form>
    </Dialog>
  );
}

export default PriceForm;
