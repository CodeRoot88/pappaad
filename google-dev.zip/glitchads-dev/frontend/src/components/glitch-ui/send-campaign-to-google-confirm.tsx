import { usePostHog } from 'posthog-js/react';

import { CampaignData } from '@/lib/types';

import { Button } from '../catalyst/button';
import { Alert, AlertTitle, AlertDescription, AlertActions } from '../catalyst/alert';

export function Confirm({
  isOpen,
  setIsOpen,
  campaign,
  onConfirm,
  isLoading,
}: {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  campaign: CampaignData;
  onConfirm: () => void;
  isLoading: boolean;
}) {
  const posthog = usePostHog();
  if (isOpen) {
    posthog?.capture('confirm_dialog_opened', { campaignId: campaign.id });
  }

  const canConfirm =
    campaign.assets_state === 'approved' &&
    campaign.budget_state === 'approved' &&
    campaign.settings_state === 'approved' &&
    campaign.ads.every((ad) => ad.state === 'approved');

  return (
    <>
      <Alert
        open={isOpen}
        onClose={() => {
          setIsOpen(false);
          posthog?.capture('confirm_dialog_closed', { campaignId: campaign.id });
        }}
      >
        {canConfirm ? (
          <CanSendConfirm setIsOpen={setIsOpen} onConfirm={onConfirm} isLoading={isLoading} campaignId={campaign.id} />
        ) : (
          <MissingApprovals setIsOpen={setIsOpen} campaignId={campaign.id} />
        )}
      </Alert>
    </>
  );
}

function CanSendConfirm({
  setIsOpen,
  onConfirm,
  isLoading,
  campaignId,
}: {
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onConfirm: () => void;
  isLoading: boolean;
  campaignId: number;
}) {
  const posthog = usePostHog();
  return (
    <>
      <AlertTitle>Send to Google</AlertTitle>
      <AlertDescription>
        Make sure you are happy with the campaign settings before sending it to Google.
      </AlertDescription>
      <AlertActions>
        <Button
          plain
          onClick={() => {
            setIsOpen(false);
            posthog?.capture('confirm_dialog_cancelled', { campaignId });
          }}
          disabled={isLoading}
        >
          Cancel
        </Button>

        <Button
          onClick={() => {
            onConfirm();
            setIsOpen(false);
            posthog?.capture('confirm_dialog_confirmed', { campaignId });
          }}
          disabled={isLoading}
          color='emerald'
        >
          {isLoading ? 'Processing...' : 'Confirm'}
        </Button>
      </AlertActions>
    </>
  );
}

function MissingApprovals({
  setIsOpen,
  campaignId,
}: {
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  campaignId: number;
}) {
  const posthog = usePostHog();
  return (
    <>
      <AlertTitle>Missing Approvals</AlertTitle>
      <AlertDescription>Please make sure all sections are approved before sending to Google.</AlertDescription>
      <AlertActions>
        <Button
          plain
          onClick={() => {
            setIsOpen(false);
            posthog?.capture('missing_approvals_dialog_closed', { campaignId });
          }}
        >
          Cancel
        </Button>
      </AlertActions>
    </>
  );
}
