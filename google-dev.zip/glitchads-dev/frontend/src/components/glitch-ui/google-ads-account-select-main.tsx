import { useEffect } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';

import { useSetAtom } from 'jotai';

import { googleAdsCustomerIdAtom } from '@/store';

import { googleAdsAccountsQueryOptions, linkGoogleAdsCustomertMutationOptions } from '@/lib/query-options';
import { useToast } from '@/components/ui/use-toast';
import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { Table, TableBody, TableHead, TableRow, TableHeader, TableCell } from '@/components/catalyst/table';
import useGoogleSignUp from '@/hooks/useGoogleSignUp';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../catalyst/tabs';
import { Alert, AlertDescription } from '../catalyst/badge-alert';
export function GoogleAdsAccountSelectMain() {
  const { isLoading, data: accounts = [] } = useSuspenseQuery(googleAdsAccountsQueryOptions());
  const setGoogleAdsCustomerId = useSetAtom(googleAdsCustomerIdAtom);
  const linkCustomerMutation = linkGoogleAdsCustomertMutationOptions();
  const { toast } = useToast();
  const pendingAccounts = accounts.filter((account) => account.linked === 'PENDING');
  const unlinkedAccounts = accounts.filter((account) => account.linked === 'NOT_LINKED');
  const linkedAccounts = accounts.filter((account) => account.linked === 'LINKED');
  const { signupWithGoogle, isLoading: isSignupLoading } = useGoogleSignUp({
    redirectUrl: '/',
    fallbackUrl: '/signup',
  });
  useLoadingOverlay(isLoading || isSignupLoading);

  useEffect(() => {
    if (accounts.length == 0) {
      toast({
        title: 'No accounts',
        description: (
          <>
            Sign Up at{' '}
            <a href='https://ads.google.com' target='_blank' rel='noopener noreferrer' style={{ color: '#0000EE' }}>
              Google
            </a>{' '}
            or Email: team@glitchads.ai
          </>
        ),
      });
    }
  }, [accounts]);

  interface HandleClickParams {
    googleads_account_id: number;
    name: string;
  }

  const handleClick = async (value: HandleClickParams): Promise<void> => {
    setGoogleAdsCustomerId(value.googleads_account_id);
    try {
      await linkCustomerMutation.mutateAsync({
        googleAdsCustomerId: value.googleads_account_id,
        name: value.name,
      });
      location.reload();
    } catch (error) {
      toast({
        title: 'Failed to link the customer',
        description: 'Failed to link the customer. Please try again, contact team@glitchads.ai if this issue persists.',
      });
    }
  };

  const renderTable = (accounts: Array<{ googleads_account_id: number; name: string; linked: string }>) => (
    <div className='my-3'>
      <Table className='w-full relative flex flex-col w-full h-full text-gray-700 bg-white shadow-md rounded-lg bg-clip-border'>
        <TableHead className='text-xs text-gray-700 uppercase bg-gray-100 dark:bg-gray-700 dark:text-gray-400'>
          <TableRow>
            <TableHeader className='w-1/3 !p-4 border-b border-slate-300 bg-slate-50'>Account Name</TableHeader>
            <TableHeader className='w-1/2 !p-4 border-b border-slate-300 bg-slate-50'>Account Id</TableHeader>
            <TableHeader className='w-1/6 !p-4 border-b border-slate-300 bg-slate-50 text-center'>Action</TableHeader>
          </TableRow>
        </TableHead>

        {accounts?.length ? (
          <TableBody>
            {accounts.map((account) => (
              <TableRow key={account.googleads_account_id} className='cursor-pointer hover:bg-slate-50'>
                <TableCell className='!p-4 border-b border-slate-200'>{account.name}</TableCell>
                <TableCell className='!p-4 border-b border-slate-200'>{account.googleads_account_id}</TableCell>
                <TableCell className='!p-4 border-b border-slate-200 text-center'>
                  {account.linked === 'LINKED' ? (
                    <span className='bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-green-400 border border-green-400'>
                      Linked
                    </span>
                  ) : account.linked === 'NOT_LINKED' ? (
                    <span
                      onClick={() =>
                        handleClick({ googleads_account_id: account.googleads_account_id, name: account.name })
                      }
                      className='bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-purple-400 border border-purple-400'
                    >
                      Link
                    </span>
                  ) : account.linked === 'PENDING' ? (
                    <a
                      className='bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-blue-400 border border-blue-400'
                      target='_blank'
                      href='https://ads.google.com/aw/accountaccess/managers'
                    >
                      Accept invite in Google Ads
                    </a>
                  ) : null}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        ) : (
          <TableBody>
            <TableRow>
              <TableCell className='!p-4 border-b border-slate-200 text-center' colSpan={3}>
                No accounts found
              </TableCell>
            </TableRow>
          </TableBody>
        )}
      </Table>
    </div>
  );

  if (!accounts) {
    return null;
  }

  return (
    <div>
      <div className='flex py-4 justify-between items-center gap-4'>
        <Alert variant='default' className='flex-1'>
          <AlertDescription className='flex flex-row items-center gap-2'>
            Sync with Google to use newly linked accounts.
          </AlertDescription>
        </Alert>
        <button
          className='w-80 focus:outline-none focus:ring focus:border-blue-500 h-full'
          onClick={() => signupWithGoogle()}
        >
          <div className='flex items-center justify-center py-2 px-4 border border-gray-300 rounded-lg shadow-md hover:shadow-lg transition duration-200 ease-in-out'>
            <img
              src='https://img.icons8.com/?size=100&id=17949&format=png&color=000000'
              alt='Google Sign'
              className='w-8 h-8 mr-4'
            />
            <span className='text-sm font-semibold text-gray-800'>Sync with Google</span>
          </div>
        </button>
      </div>
      <Tabs defaultValue='unlinked' className='py-4'>
        <TabsList className='mb-2 !h-auto flex-wrap gap-2 text-4xl sm:gap-1'>
          <TabsTrigger className='flex-1 bg-black/15' value='unlinked'>
            Unlinked
          </TabsTrigger>
          <TabsTrigger className='flex-1 bg-black/15' value='pending'>
            Pending
          </TabsTrigger>
          <TabsTrigger className='flex-1 bg-black/15' value='linked'>
            Linked
          </TabsTrigger>
        </TabsList>
        <TabsContent className='flex flex-col gap-[--gap]' value='pending'>
          {pendingAccounts ? renderTable(pendingAccounts) : ''}
        </TabsContent>
        <TabsContent className='flex flex-col gap-[--gap]' value='unlinked'>
          {unlinkedAccounts ? renderTable(unlinkedAccounts) : ''}
        </TabsContent>
        <TabsContent className='flex flex-col gap-[--gap]' value='linked'>
          {linkedAccounts ? renderTable(linkedAccounts) : ''}
        </TabsContent>
      </Tabs>
    </div>
  );
}
