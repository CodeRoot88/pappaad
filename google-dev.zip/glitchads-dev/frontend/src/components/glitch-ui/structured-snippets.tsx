import { useState } from 'react';
import { Button } from '@/components/catalyst/button';
import { Dropdown, DropdownButton, DropdownItem, DropdownMenu } from '@/components/catalyst/dropdown';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/catalyst/table';
import { StructuredSnippetType } from '@/lib/types';
import { EllipsisHorizontalIcon } from '@heroicons/react/16/solid';
import { PlusIcon } from '@heroicons/react/24/solid';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';
import { Alert, AlertActions, AlertTitle } from '@/components/catalyst/alert';
import StructuredSnippetForm from './structured-snippet-form';
import {
  useUpdateStructuredSnippetMutationOptions,
  useDeleteStructuredSnippetMutationOptions,
} from '@/lib/query-options';

export function StructuredSnippets({
  snippets,
  refetchCampaign,
  campaignId,
}: {
  snippets: StructuredSnippetType[];
  refetchCampaign: () => void;
  campaignId: number;
}) {
  const { toast } = useToast();
  const [newSnippet, setNewSnippetOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteSnippetId, setDeleteSnippetId] = useState<number | null>(null);

  const updateStructuredSnippetMutation = useUpdateStructuredSnippetMutationOptions();
  const deleteStructuredSnippetMutation = useDeleteStructuredSnippetMutationOptions();

  const handleSaveSnippet = async (snippet: StructuredSnippetType) => {
    try {
      await updateStructuredSnippetMutation.mutateAsync({ campaignId, structuredSnippet: snippet });
      refetchCampaign();
      toast({ description: snippet.id ? '🙌 Structured snippet updated' : '🎉 Structured snippet added' });
    } catch (error) {
      console.error(error);
      toast({ description: 'Error saving structured snippet', variant: 'destructive' });
    }
  };

  const handleDeleteSnippet = async () => {
    if (!deleteSnippetId) return;
    try {
      setDeleteConfirmOpen(false);
      await deleteStructuredSnippetMutation.mutateAsync({ campaignId, structuredSnippetId: deleteSnippetId });
      refetchCampaign();
      toast({ description: '🗑️ Structured snippet deleted' });
    } catch (error) {
      console.error(error);
      toast({ description: 'Error deleting structured snippet', variant: 'destructive' });
    }
  };

  return (
    <>
      <Toaster />
      <Alert open={deleteConfirmOpen} onClose={setDeleteConfirmOpen}>
        <AlertTitle>Are you sure you want to delete this structured snippet?</AlertTitle>
        <AlertActions>
          <Button plain onClick={() => setDeleteConfirmOpen(false)}>
            Cancel
          </Button>
          <Button color='rose' onClick={handleDeleteSnippet}>
            Delete
          </Button>
        </AlertActions>
      </Alert>
      <StructuredSnippetForm
        isOpen={newSnippet}
        setIsOpen={setNewSnippetOpen}
        snippet={{ header_type: '', values: [] }}
        handleSaveSnippet={handleSaveSnippet}
      />
      <div className='p-4'>
        <Table className='[--gutter:theme(spacing.6)] sm:[--gutter:theme(spacing.8)]'>
          <TableHead>
            <TableRow>
              <TableHeader>Header Type</TableHeader>
              <TableHeader>Values</TableHeader>
              <TableHeader className='relative w-0'>
                <span className='sr-only'>Actions</span>
              </TableHeader>
            </TableRow>
          </TableHead>
          <TableBody>
            {snippets.map((snippet) => (
              <Snippet
                key={snippet.id}
                snippet={snippet}
                handleSaveSnippet={handleSaveSnippet}
                setDeleteConfirmOpen={setDeleteConfirmOpen}
                setDeleteSnippetId={setDeleteSnippetId}
              />
            ))}
          </TableBody>
        </Table>
        <Button color='white' className='mt-4' onClick={() => setNewSnippetOpen(true)}>
          <PlusIcon className='text-slate-900' />
          Add new Snippet
        </Button>
      </div>
    </>
  );
}

function Snippet({
  snippet,
  handleSaveSnippet,
  setDeleteConfirmOpen,
  setDeleteSnippetId,
}: {
  snippet: StructuredSnippetType;
  handleSaveSnippet: (updatedSnippet: StructuredSnippetType) => void;
  setDeleteConfirmOpen: (open: boolean) => void;
  setDeleteSnippetId: (id: number) => void;
}) {
  const [edit, setEdit] = useState(false);
  const { header_type: headerType, values } = snippet;

  const handleDelete = () => {
    if (!snippet.id) return;
    setDeleteSnippetId(snippet.id);
    setDeleteConfirmOpen(true);
  };

  if (edit) {
    return (
      <StructuredSnippetForm
        isOpen={edit}
        setIsOpen={setEdit}
        snippet={snippet}
        handleSaveSnippet={handleSaveSnippet}
      />
    );
  }

  return (
    <TableRow key={headerType}>
      <TableCell className='font-medium'>{headerType}</TableCell>
      <TableCell>
        {values.map((value, index) => (
          <span key={index}>{`${value.value} | `}</span>
        ))}
      </TableCell>
      <TableCell>
        <div className='-mx-3 -my-1.5 sm:-mx-2.5'>
          <Dropdown>
            <DropdownButton plain aria-label='More options'>
              <EllipsisHorizontalIcon />
            </DropdownButton>
            <DropdownMenu anchor='bottom end'>
              <DropdownItem onClick={() => setEdit(true)}>Edit</DropdownItem>
              <DropdownItem className='text-rose-500' onClick={handleDelete}>
                Delete
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>
      </TableCell>
    </TableRow>
  );
}
