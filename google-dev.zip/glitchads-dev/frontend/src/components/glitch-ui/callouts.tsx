import { useState } from 'react';
import { usePostHog } from 'posthog-js/react';
import { Alert, AlertActions, AlertTitle } from '@/components/catalyst/alert';
import { Button } from '@/components/catalyst/button';
import { PlusIcon } from '@heroicons/react/24/solid';
import { Dropdown, DropdownButton, DropdownItem, DropdownMenu } from '@/components/catalyst/dropdown';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/catalyst/table';
import { EllipsisHorizontalIcon } from '@heroicons/react/16/solid';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';
import { CalloutType } from '@/lib/types';
import { useUpdateCalloutMutationOptions, useDeleteCalloutMutationOptions } from '@/lib/query-options';

export function Callouts({
  callouts,
  refetchCampaign,
  campaignId,
}: {
  callouts: CalloutType[];
  refetchCampaign: () => void;
  campaignId: number;
}) {
  const posthog = usePostHog();
  const { toast } = useToast();

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteCalloutId, setDeleteCalloutId] = useState<number | null>(null);
  const [newCalloutOpen, setNewCalloutOpen] = useState(false);
  const calloutUpdateMutation = useUpdateCalloutMutationOptions();
  const calloutDeleteMutation = useDeleteCalloutMutationOptions();

  const handleSaveCallout = async (updatedCallout: CalloutType) => {
    if (containsEmoji(updatedCallout.text)) {
      toast({ description: '😅 Emojis are not allowed in callouts', variant: 'destructive' });
      return;
    }
    try {
      await calloutUpdateMutation.mutateAsync({ campaignId, callout: updatedCallout });
      refetchCampaign();
      toast({ description: '🙌 Callout updated' });
      posthog?.capture('callout_saved', { campaignId, calloutId: updatedCallout.id });
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteCallout = async () => {
    if (!deleteCalloutId) return;
    try {
      setDeleteConfirmOpen(false);
      await calloutDeleteMutation.mutateAsync({ campaignId, calloutId: deleteCalloutId });
      refetchCampaign();
      toast({ description: '🗑️ Callout deleted' });
      posthog?.capture('callout_deleted', { campaignId, calloutId: deleteCalloutId });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Toaster />
      <Alert open={deleteConfirmOpen} onClose={setDeleteConfirmOpen}>
        <AlertTitle>Are you sure you want to delete this callout?</AlertTitle>
        <AlertActions>
          <Button plain onClick={() => setDeleteConfirmOpen(false)}>
            Cancel
          </Button>
          <Button color='rose' onClick={handleDeleteCallout}>
            Delete
          </Button>
        </AlertActions>
      </Alert>
      <div className='p-4'>
        <CalloutForm
          isOpen={newCalloutOpen}
          setIsOpen={setNewCalloutOpen}
          callout={{ text: '' }}
          handleSaveCallout={handleSaveCallout}
        />
        <Table className='[--gutter:theme(spacing.6)] sm:[--gutter:theme(spacing.8)]'>
          <TableHead>
            <TableRow>
              <TableHeader>Text</TableHeader>
              <TableHeader className='relative w-0'>
                <span className='sr-only'>Actions</span>
              </TableHeader>
            </TableRow>
          </TableHead>
          <TableBody>
            {callouts.map((callout) => (
              <Callout
                key={callout.id}
                callout={callout}
                handleSaveCallout={handleSaveCallout}
                setDeleteConfirmOpen={setDeleteConfirmOpen}
                setDeleteCalloutId={setDeleteCalloutId}
              />
            ))}
          </TableBody>
        </Table>
        <div>
          <Button
            color='white'
            className='mt-4'
            onClick={() => {
              setNewCalloutOpen(true);
              posthog?.capture('add_callout_clicked', { campaignId });
            }}
          >
            <PlusIcon className='text-slate-900' />
            Add Callout
          </Button>
        </div>
      </div>
    </>
  );
}

function Callout({
  callout,
  handleSaveCallout,
  setDeleteConfirmOpen,
  setDeleteCalloutId,
}: {
  callout: CalloutType;
  handleSaveCallout: (updatedCallout: CalloutType) => void;
  setDeleteConfirmOpen: (open: boolean) => void;
  setDeleteCalloutId: (id: number) => void;
}) {
  const posthog = usePostHog();
  const [edit, setEdit] = useState(false);

  const { text } = callout;
  const handleDelete = () => {
    if (!callout.id) return;
    setDeleteCalloutId(callout.id);
    setDeleteConfirmOpen(true);
  };
  if (edit) {
    return <CalloutForm isOpen={edit} setIsOpen={setEdit} callout={callout} handleSaveCallout={handleSaveCallout} />;
  }
  return (
    <TableRow>
      <TableCell>{text}</TableCell>
      <TableCell>
        <div className='-mx-3 -my-1.5 sm:-mx-2.5'>
          <Dropdown>
            <DropdownButton plain aria-label='More options'>
              <EllipsisHorizontalIcon />
            </DropdownButton>
            <DropdownMenu anchor='bottom end'>
              <DropdownItem
                onClick={() => {
                  setEdit(true);
                  posthog?.capture('edit_callout_clicked', { calloutId: callout.id, calloutText: callout.text });
                }}
              >
                Edit
              </DropdownItem>
              <DropdownItem className='text-rose-500' onClick={handleDelete}>
                Delete
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>
      </TableCell>
    </TableRow>
  );
}

import { Dialog, DialogActions, DialogBody } from '@/components/catalyst/dialog';
import { Field, FieldGroup, Fieldset, Label, ErrorMessage } from '@/components/catalyst/fieldset';
import { Input } from '@/components/catalyst/input';
import { useForm } from '@tanstack/react-form';
import clsx from 'clsx';
import { z } from 'zod';
import { zodValidator } from '@tanstack/zod-form-adapter';
import { containsEmoji } from '@/lib/utils';

function CalloutForm({
  isOpen,
  setIsOpen,
  callout,
  handleSaveCallout,
}: {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  callout: CalloutType;
  handleSaveCallout: (callout: CalloutType) => void;
}) {
  const { text } = callout;

  const form = useForm({
    defaultValues: {
      text,
    },
    onSubmit: async (form) => {
      let updatedCallout = {
        ...callout,
        text: form.value.text,
      };
      handleSaveCallout(updatedCallout);
      setIsOpen(false);
    },
    validatorAdapter: zodValidator(),
  });

  return (
    <Dialog open={isOpen} onClose={setIsOpen}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          e.stopPropagation();
          form.handleSubmit();
        }}
      >
        <DialogBody>
          <Fieldset>
            <FieldGroup>
              <form.Field
                validators={{
                  onChange: z.string().trim().min(1, 'Text is required'),
                }}
                name='text'
                children={(field) => (
                  <Field className='mb-4'>
                    <Label>Text</Label>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                    <Input
                      name={field.name}
                      placeholder='Callout text'
                      autoFocus
                      value={field.state.value}
                      onChange={(e) => field.handleChange(e.target.value)}
                    />
                  </Field>
                )}
              />
            </FieldGroup>
          </Fieldset>
        </DialogBody>
        <DialogActions>
          <Button plain onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <form.Subscribe
            selector={(state) => [state.canSubmit, state.isSubmitting]}
            children={([canSubmit, isSubmitting]) => {
              return (
                <Button
                  color='indigo'
                  className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                  type='submit'
                  disabled={!canSubmit}
                >
                  {isSubmitting ? '...' : 'Save'}
                </Button>
              );
            }}
          />
        </DialogActions>
      </form>
    </Dialog>
  );
}
