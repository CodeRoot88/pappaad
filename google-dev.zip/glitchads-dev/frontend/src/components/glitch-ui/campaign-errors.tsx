import { usePostHog } from 'posthog-js/react';
import { XCircleIcon } from '@heroicons/react/20/solid';
import { Link } from '../catalyst/link';
import { CampaignError, CampaignData } from '@/lib/types';
import { useToast } from '@/components/ui/use-toast';
import { useCampaignErrorsDeleteMutationOptions } from '@/lib/query-options';

type CampaignErrorsProps = {
  campaign: CampaignData;
  refetchCampaign?: () => void;
};

export function CampaignErrors({ campaign, refetchCampaign }: CampaignErrorsProps) {
  const posthog = usePostHog();
  const { toast } = useToast();

  const errors: CampaignError[] = campaign.errors ?? [];
  const campaignErrorsDeleteMutation = useCampaignErrorsDeleteMutationOptions(campaign.id);

  const handleFixClick = (errorType: string, adSlug?: string) => {
    posthog?.capture('error_fix_clicked', { errorType, adSlug });
  };

  const handleMarkResolved = async () => {
    try {
      await campaignErrorsDeleteMutation.mutateAsync();
      toast({ description: 'Mark all errors successfully' });
      if (refetchCampaign) refetchCampaign();
      posthog?.capture('errors_marked_as_resolved', { campaignSlug: campaign.slug });
    } catch (error) {
      toast({ description: 'Failed to delete campaign errors', variant: 'destructive' });
      posthog?.capture('errors_marked_as_failed', { campaignSlug: campaign.slug });

    }
  };

  return (
    <div className='rounded-md bg-red-50 p-4'>
      <div className='flex'>
        <div className='flex-shrink-0'>
          <XCircleIcon aria-hidden='true' className='h-5 w-5 text-red-400' />
        </div>
        <div className='ml-3'>
          <h3 className='text-sm font-medium text-red-800'>There were {errors.length} errors with your submission</h3>
          <div className='mt-2 text-sm text-red-700'>
            <ul role='list' className='list-disc space-y-1 pl-5'>
              {errors.map((error, index) => (
                <li key={index}>
                  <div className='ml-3 flex-1 md:flex md:justify-between'>
                    <p className='text-sm text-red-700'>
                      {error.error_type === 'Ad'
                        ? `Headlines are too long for Ad ${error.error_data?.url}`
                        : `Errors in ${error.error_type}`}
                    </p>
                    <p
                      className='mt-3 text-sm md:ml-6 md:mt-0'
                      onClick={() => handleFixClick(error.error_type, error.error_data?.slug)}
                    >
                      <Link
                        className='whitespace-nowrap font-medium text-red-700 hover:text-red-600'
                        to={
                          error.error_type === 'Ad'
                            ? `/campaigns/$campaignslug/ads/$adslug`
                            : '/campaigns/$campaignslug/settings'
                        }
                        params={{
                          adslug: error.error_data?.slug,
                          campaignslug: campaign.slug,
                        }}
                      >
                        Fix
                        <span aria-hidden='true'> &rarr;</span>
                      </Link>
                    </p>
                  </div>
                </li>
              ))}
            </ul>
            <div className='mt-8'>
              <div className='-mx-2 -my-1.5'>
                <button
                  type='button'
                  className='border rounded-md bg-green-50 px-2 py-1.5 text-sm font-medium text-green-800 hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-green-600 focus:ring-offset-2 focus:ring-offset-green-50'
                  onClick={handleMarkResolved}
                  disabled={campaignErrorsDeleteMutation.isPending}
                >
                  Mark as resolved
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
