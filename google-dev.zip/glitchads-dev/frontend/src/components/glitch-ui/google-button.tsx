import { Button } from '../ui/button';

interface GoogleButtonProps {
  onClick: () => void;
}
export const GoogleButton = ({ onClick }: GoogleButtonProps) => {
  return (
    <Button variant='outline' className='py-2.5 px-4 h-fit' onClick={onClick}>
      <img
        src='https://img.icons8.com/?size=100&id=17949&format=png&color=000000'
        alt='Google Sign'
        className='w-6 h-6 mr-2'
      />
      <span className='text-base font-semibold text-gray-900'>Continue with Google</span>
    </Button>
  );
};
