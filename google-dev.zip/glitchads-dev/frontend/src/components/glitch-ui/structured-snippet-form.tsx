import { usePostHog } from 'posthog-js/react';
import { useState, useEffect } from 'react';
import { useForm } from '@tanstack/react-form';
import clsx from 'clsx';
import { z } from 'zod';
import { zodValidator } from '@tanstack/zod-form-adapter';
import { TrashIcon, PlusIcon } from '@heroicons/react/24/solid';

import { Button } from '@/components/catalyst/button';
import { Dialog, DialogActions, DialogBody } from '@/components/catalyst/dialog';
import { Field, FieldGroup, Fieldset, Label, ErrorMessage } from '@/components/catalyst/fieldset';
import { Input } from '@/components/catalyst/input';
import { Listbox, ListboxOption, ListboxLabel } from '@/components/catalyst/listbox';
import { StructuredSnippetType } from '@/lib/types';

const headerTypes = [
  { name: 'Amenities', value: 'amenities' },
  { name: 'Brands', value: 'brands' },
  { name: 'Courses', value: 'courses' },
  { name: 'Degree programs', value: 'degree programs' },
  { name: 'Destinations', value: 'destinations' },
  { name: 'Featured hotels', value: 'featured hotels' },
  { name: 'Insurance coverage', value: 'insurance coverage' },
  { name: 'Models', value: 'models' },
  { name: 'Neighborhoods', value: 'neighborhoods' },
  { name: 'Service catalog', value: 'service catalog' },
  { name: 'Shows', value: 'shows' },
  { name: 'Styles', value: 'styles' },
  { name: 'Types', value: 'types' },
  { name: 'Venues', value: 'venues' },
];

export function StructuredSnippetForm({
  isOpen,
  setIsOpen,
  snippet,
  handleSaveSnippet,
}: {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  snippet: StructuredSnippetType;
  handleSaveSnippet: (snippet: StructuredSnippetType) => void;
}) {
  const posthog = usePostHog();
  const [values, setValues] = useState(snippet.values.length > 0 ? snippet.values : [{ value: '' }]);

  useEffect(() => {
    if (isOpen) {
      posthog?.capture('structured_snippet_form_opened', { snippetId: snippet.id });
    }
  }, [isOpen]);

  const form = useForm({
    defaultValues: {
      headerType: snippet.header_type || headerTypes[0].value,
    },
    onSubmit: async (form) => {
      const updatedSnippet: StructuredSnippetType = {
        ...snippet,
        header_type: form.value.headerType,
        values: values.filter((v) => v.value.trim() !== ''),
      };
      handleSaveSnippet(updatedSnippet);
      setIsOpen(false);
      posthog?.capture('structured_snippet_saved', updatedSnippet);
    },
    validatorAdapter: zodValidator(),
  });

  const addNewValue = () => {
    if (values.length < 10) {
      setValues([...values, { value: '' }]);
      posthog?.capture('structured_snippet_value_added', { snippetId: snippet.id, valueCount: values.length + 1 });
    }
  };

  const removeValue = (index: number) => {
    const newValues = values.filter((_, i) => i !== index);
    setValues(newValues);
    posthog?.capture('structured_snippet_value_removed', { snippetId: snippet.id, valueCount: newValues.length });
  };

  const updateValue = (index: number, newValue: string) => {
    const newValues = [...values];
    newValues[index] = { value: newValue };
    setValues(newValues);
    posthog?.capture('structured_snippet_value_updated', { snippetId: snippet.id, index, newValue });
  };

  return (
    <Dialog open={isOpen} onClose={() => setIsOpen(false)}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          e.stopPropagation();
          form.handleSubmit();
        }}
      >
        <DialogBody>
          <Fieldset>
            <FieldGroup>
              <form.Field
                name='headerType'
                validators={{
                  onChange: z.string().min(1, 'Header type is required'),
                }}
              >
                {(field) => (
                  <Field className='mb-4'>
                    <Label>Header Type</Label>
                    <Listbox
                      name={field.name}
                      defaultValue={field.state.value}
                      onChange={(value) => {
                        field.handleChange(value);
                        posthog?.capture('structured_snippet_header_type_changed', {
                          snippetId: snippet.id,
                          headerType: value,
                        });
                      }}
                    >
                      {headerTypes.map((headerType) => (
                        <ListboxOption key={headerType.value} value={headerType.value}>
                          <ListboxLabel>{headerType.name}</ListboxLabel>
                        </ListboxOption>
                      ))}
                    </Listbox>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                  </Field>
                )}
              </form.Field>

              {values.map((value, index) => (
                <Field key={index} className='mb-4'>
                  <Label>Value {index + 1}</Label>
                  <div className='flex items-center'>
                    <Input
                      placeholder={`Enter value ${index + 1}`}
                      value={value.value}
                      onChange={(e) => updateValue(index, e.target.value)}
                      className='flex-grow mr-2'
                    />
                    <Button
                      type='button'
                      outline
                      onClick={() => removeValue(index)}
                      className='p-2 text-gray-400 hover:text-gray-600'
                    >
                      <TrashIcon className='h-5 w-5' />
                    </Button>
                  </div>
                </Field>
              ))}

              {values.length < 10 && (
                <Button type='button' onClick={addNewValue} className='mt-2'>
                  <PlusIcon className='h-5 w-5 mr-2' />
                  Add New Value
                </Button>
              )}
            </FieldGroup>
          </Fieldset>
        </DialogBody>
        <DialogActions>
          <Button plain onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <form.Subscribe
            selector={(state) => [state.canSubmit, state.isSubmitting]}
            children={([canSubmit, isSubmitting]) => (
              <Button
                color='indigo'
                className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                type='submit'
                disabled={!canSubmit}
              >
                {isSubmitting ? '...' : 'Save'}
              </Button>
            )}
          />
        </DialogActions>
      </form>
    </Dialog>
  );
}

export default StructuredSnippetForm;
