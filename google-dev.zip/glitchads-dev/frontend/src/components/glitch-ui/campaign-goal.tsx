import { usePostHog } from 'posthog-js/react';
import { useState } from 'react';
import { Radio, Description as RadioDescription, RadioGroup } from '@headlessui/react';
import clsx from 'clsx';
import { Input } from '@/components/catalyst/input';
import { GoalType, goals } from '../campaign/New';

type CampaignGoalProps = {
  selected: GoalType;
  setSelected: React.Dispatch<React.SetStateAction<GoalType>>;
  onCampaignGoalTextChange: (text: string) => void;
};

export function CampaignGoal({ selected, setSelected, onCampaignGoalTextChange }: CampaignGoalProps) {
  const posthog = usePostHog();
  const [campaignGoalText, setCampaignGoalText] = useState('');

  const handleGoalChange = (goal: GoalType) => {
    setSelected(goal);
    posthog?.capture('goal_selected', { goal: goal.name });
  };

  const handleCampaignGoalTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newText = e.target.value.slice(0, 280);
    setCampaignGoalText(newText);
    onCampaignGoalTextChange(newText);
  };

  return (
    <>
      <div className='mb-4'>
        <label className='text-xl'>What is the goal of this ad campaign?</label>
      </div>
      <RadioGroup value={selected} onChange={handleGoalChange}>
        <div className='space-y-4'>
          {goals.map((goal) => (
            <Radio
              key={goal.name}
              value={goal}
              className={({ focus }) =>
                clsx(
                  focus ? 'border-indigo-600 ring-2 ring-indigo-600' : 'border-gray-300',
                  'relative block cursor-pointer rounded-lg border bg-white px-6 py-4 shadow-sm focus:outline-none sm:flex sm:justify-between',
                )
              }
            >
              {({ checked, focus }) => (
                <>
                  <span className='flex items-center'>
                    <span className='flex flex-col text-sm'>
                      <span className='font-medium text-gray-900'>{goal.name}</span>
                      <RadioDescription as='span' className='text-gray-500'>
                        <span className='block sm:inline'>{goal.description}</span>{' '}
                      </RadioDescription>
                    </span>
                  </span>
                  <RadioDescription
                    as='span'
                    className='mt-2 flex text-sm sm:ml-4 sm:mt-0 sm:items-center sm:text-right'
                  >
                    {goal.icon}
                  </RadioDescription>
                  <span
                    className={clsx(
                      focus ? 'border' : 'border-2',
                      checked ? 'border-indigo-600' : 'border-transparent',
                      'pointer-events-none absolute -inset-px rounded-lg',
                    )}
                    aria-hidden='true'
                  />
                </>
              )}
            </Radio>
          ))}
        </div>
      </RadioGroup>

      {selected.value === 'specific' && (
        <div className='mb-4'>
          <label htmlFor='campaignGoal' className='block text-xl font-medium text-gray-700'>
            Campaign Goal
          </label>
          <Input
            id='campaignGoal'
            name='campaignGoal'
            type='textarea'
            value={campaignGoalText}
            onChange={handleCampaignGoalTextChange}
            className='mt-1 block w-full'
            placeholder='Enter your campaign goal (max 280 characters)'
            aria-describedby='campaignGoalDescription'
          />
          <p id='campaignGoalDescription' className='mt-2 text-sm text-gray-500'>
            Describe your campaign goal in 280 characters or less.
          </p>
        </div>
      )}
    </>
  );
}
