import { Badge } from '@/components/catalyst/badge';
import ConfirmationModal from '@/components/catalyst/confirmation-modal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import { campaignsQueryOptions, useCampaignDeleteMutationOptions, useCampaignCopyMutation } from '@/lib/query-options';
import { CampaignData } from '@/lib/types';
import { useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { Link } from '@tanstack/react-router';
import { Copy, MoreVertical, Trash } from 'lucide-react';
import { useState } from 'react';
import { Stepper } from './stepper';

function MoreOptionsMenu({
  isOpen,
  setIsOpen,
  handleCopy,
  handleDelete,
}: {
  isOpen: boolean;
  setIsOpen: (val: boolean) => void;
  handleCopy: () => void;
  handleDelete: () => void;
}) {
  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant='ghost' size='icon' onClick={() => setIsOpen(!isOpen)}>
          <MoreVertical className='h-4 w-4' />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align='end'>
        <DropdownMenuItem onClick={handleCopy}>
          <Copy className='mr-2 h-4 w-4' />
          <span>Copy</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleDelete}>
          <Trash className='mr-2 h-4 w-4' />
          <span>Delete</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
export function CampaignCard({ campaign }: { campaign: CampaignData }) {
  const campaignDeleteMutation = useCampaignDeleteMutationOptions(campaign.id);
  const campaignCopyMutation = useCampaignCopyMutation(campaign.id);
  const { refetch: refetchCampaigns } = useSuspenseQuery(campaignsQueryOptions());
  const { toast } = useToast();

  const queryClient = useQueryClient();
  const campaignSteps = () => {
    return [
      { name: 'Ads reviewed', status: campaign.ads.every((ad) => ad.state === 'approved') ? 'approved' : 'pending' },
      { name: 'Budget reviewed', status: campaign.budget_state },
      { name: 'Campaign settings reviewed', status: campaign.settings_state },
      { name: 'Campaign assets reviewed', status: campaign.assets_state },
    ];
  };
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [isCopyModalOpen, setCopyModalOpen] = useState(false);

  const triggerCopyModal = () => {
    setIsMenuOpen(false);
    setCopyModalOpen(true);
  };
  const triggerDeleteModal = () => {
    setIsMenuOpen(false);
    setDeleteModalOpen(true);
  };
  const handleDeleteCampaign = async () => {
    setDeleteModalOpen(false);
    try {
      await campaignDeleteMutation.mutateAsync();
      toast({ description: 'Campaign deleted successfully' });
      queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
      refetchCampaigns();
    } catch (error) {
      toast({ description: 'Failed to delete campaign', variant: 'destructive' });
    }
  };

  const handleCopyCampaign = async () => {
    setCopyModalOpen(false);
    try {
      await campaignCopyMutation.mutateAsync();
      toast({ description: 'Campaign Copied successfully' });
      queryClient.invalidateQueries({ queryKey: ['campaign', campaign.slug] });
      refetchCampaigns();
    } catch (error) {
      toast({ description: 'Failed to copy campaign', variant: 'destructive' });
    }
  };

  const stateColor =
    campaign.state === 'draft'
      ? 'zinc'
      : campaign.state === 'paused'
        ? 'yellow'
        : campaign.state === 'error'
          ? 'rose'
          : 'green';
  const steps = campaignSteps();
  return (
    <>
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDeleteCampaign}
        title='Delete Campaign'
        description='Are you sure you want to delete this campaign?'
      />
      <ConfirmationModal
        isOpen={isCopyModalOpen}
        onClose={() => setCopyModalOpen(false)}
        onConfirm={handleCopyCampaign}
        title='Copy Campaign'
        description='Are you sure you want to copy this campaign?'
      />

      <Card className='my-2'>
        <CardHeader>
          <CardTitle>
            <div className='flex justify-between items-center'>
              <Link to={`/campaigns/${campaign.slug}/ads`}>
                <span>{campaign.name}</span>
              </Link>
              <MoreOptionsMenu
                isOpen={isMenuOpen}
                setIsOpen={setIsMenuOpen}
                handleCopy={triggerCopyModal}
                handleDelete={triggerDeleteModal}
              />
            </div>
          </CardTitle>
          <CardDescription>
            <Link to={`/campaigns/${campaign.slug}/ads`}>
              {campaign.website_url}
              <Badge className='ml-2' color={stateColor}>
                {campaign.state.toUpperCase()}
              </Badge>
            </Link>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Link to={`/campaigns/${campaign.slug}/ads`}>
            {campaign.state === 'draft' && <Stepper steps={steps} />}
          </Link>
        </CardContent>
      </Card>
    </>
  );
}
