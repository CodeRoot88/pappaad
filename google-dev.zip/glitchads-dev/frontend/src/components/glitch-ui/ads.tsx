import { Badge } from '@/components/catalyst/badge';
import { Button } from '@/components/catalyst/button';
import { Dialog, DialogActions, DialogBody, DialogDescription, DialogTitle } from '@/components/catalyst/dialog';
import { ErrorMessage } from '@/components/catalyst/fieldset';
import { Input } from '@/components/catalyst/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/catalyst/table';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';
import { createAd } from '@/lib/apis';
import { Ad, Keyword, TaskTrackingResponse } from '@/lib/types';
import { isValidUrl } from '@/lib/utils';
import { fetchCampaignAtom, fetchCampaignTaskTrackingAtom } from '@/store';
import { useAtomValue } from 'jotai';
import { usePostHog } from 'posthog-js/react';
import { useEffect, useMemo, useState } from 'react';
import { TaskTrackingProgress } from './task-tracking-progress';

function AdComponent({
  url,
  headline1,
  headline2,
  description,
}: {
  url: string;
  headline1: string;
  headline2: string;
  description?: string;
}) {
  return (
    <div className='border rounded-lg p-4 bg-white shadow-sm'>
      <div className='flex items-center mb-2'>
        <span className='text-xs font-semibold text-gray-700'>Sponsored</span>
        <span className='mx-2 w-2 h-2 rounded-full bg-gray-300'></span>

        <a href={url} className='text-xs text-blue-600 hover:underline truncate max-w-sm' title={url}>
          {url}
        </a>
      </div>
      <div className='mb-2'>
        <a href={url} className='text-lg text-blue-700 font-medium hover:underline'>
          {headline1} | {headline2}
        </a>
      </div>
      <p className='text-sm text-gray-600'>{description}</p>
    </div>
  );
}

function Keywords({ keywords }: { keywords: Keyword[] }) {
  const keywordChunks = [];
  for (let i = 0; i < keywords.length; i += 4) {
    keywordChunks.push(keywords.slice(i, i + 4));
  }

  return (
    <div className='flex flex-wrap gap-2'>
      {keywords.map((keyword) => (
        <Badge
          key={keyword.id}
          color='zinc'
          className='overflow-hidden text-ellipsis whitespace-nowrap'
          style={{ maxWidth: '150px' }} // Adjust as needed
          title={keyword.text} // Shows full text on hover
        >
          {keyword.text}
        </Badge>
      ))}
    </div>
  );
}

function CreateAdModal({
  isOpen,
  onClose,
  campaignId,
  campaignUrl,
  onAdCreated,
}: {
  isOpen: boolean;
  onClose: () => void;
  campaignId: number;
  campaignUrl: string;
  onAdCreated: () => void;
}) {
  const [url, setUrl] = campaignUrl ? useState(campaignUrl) : useState('');
  const [prefixedUrl, setPrefixedUrl] = campaignUrl ? useState(campaignUrl) : useState(url);
  const [error, setError] = useState('');
  const { toast } = useToast();
  const posthog = usePostHog();

  const validateUrl = (input: string) => {
    try {
      const inputUrl = new URL(input);
      const campaignUrlObj = new URL(campaignUrl);
      return inputUrl.hostname === campaignUrlObj.hostname;
    } catch {
      return false;
    }
  };
  const fetchTracking = useAtomValue(fetchCampaignTaskTrackingAtom);
  const handleCreateAd = async () => {
    try {
      setUrl(campaignUrl);
      onClose();
      await createAd(campaignId, prefixedUrl);
      onAdCreated();
      if (fetchTracking) {
        fetchTracking();
      }
      posthog?.capture('ad_created', { campaignId: campaignId });
    } catch (error: any) {
      toast({ description: error?.message || 'Failed to create Ad', variant: 'destructive' });
      posthog?.capture('ad_creation_failed', { campaignId: campaignId, error });
    }
  };

  useEffect(() => {
    if (campaignUrl) {
      if (typeof url !== 'string' || !isValidUrl(url)) {
        setError('Invalid URL');
        return;
      }
      if (!validateUrl(url)) {
        setError('URL must be from the same domain as the campaign URL');
        posthog?.capture('ad_url_validation_failed', { campaignId: campaignId, url });
        return;
      }
      setError('');
      try {
        const urlObj = new URL(url);
        const campaignUrlObj = new URL(campaignUrl);
        setPrefixedUrl(`${campaignUrlObj.protocol}//${campaignUrlObj.hostname}${urlObj.pathname}`);
      } catch {
        setPrefixedUrl('');
      }
    } else {
      setPrefixedUrl('');
    }
  }, [url, campaignUrl]);

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle className='text-lg font-semibold leading-6 text-zinc-900 dark:text-white mb-4'>
        Create New Ad
      </DialogTitle>
      <DialogDescription className='text-sm text-zinc-500 dark:text-zinc-400 mb-4'>
        Enter the URL for your new ad. It must be from the same domain as the campaign URL.
      </DialogDescription>
      <DialogBody>
        <Input
          type='url'
          placeholder='Enter URL'
          value={url}
          onChange={(e) => {
            setUrl(e.target.value);
            posthog?.capture('ad_url_changed', { campaignId: campaignId });
          }}
          className='mb-2 w-full'
        />
        {error && <ErrorMessage>{error}</ErrorMessage>}
      </DialogBody>
      <DialogActions>
        <div className='mt-6 flex justify-end gap-3'>
          <Button onClick={onClose} color='zinc'>
            Cancel
          </Button>
          <Button onClick={handleCreateAd} disabled={typeof url !== 'string' || !isValidUrl(url) || !validateUrl(url)}>
            Create Ad
          </Button>
        </div>
      </DialogActions>
    </Dialog>
  );
}

function Ads({
  ads,
  campaignId,
  campaignslug,
  campaignUrl,
  onAdCreated,
  campaignTaskTracking,
}: {
  ads: Ad[];
  campaignId: number;
  campaignslug: string;
  campaignUrl: string;
  onAdCreated: () => void;
  campaignTaskTracking?: TaskTrackingResponse;
}) {
  const posthog = usePostHog();
  const [isCreateAdModalOpen, setIsCreateAdModalOpen] = useState(false);
  const adGeneration = campaignTaskTracking?.ad_generation;
  const maxAdsReached = ads.length + (adGeneration?.in_progress || 0) >= 8;
  const fetchCampaign = useAtomValue(fetchCampaignAtom);

  useEffect(() => {
    posthog?.capture('ads_component_loaded', { campaignId: campaignId });
  }, []);

  const areAllTasksCompleted = useMemo((): boolean => {
    if (!campaignTaskTracking) return true;
    return Object.entries(campaignTaskTracking)
      .filter(([key]) => key !== 'site_link_generation')
      .every(([_, task]) => task.completed + task.failed >= task.total);
  }, [campaignTaskTracking]);

  useEffect(() => {
    if (areAllTasksCompleted && fetchCampaign) {
      fetchCampaign();
    }
  }, [campaignTaskTracking]);

  return (
    <div className='mt-12'>
      <div className='flex justify-between items-center mb-4'>
        {!areAllTasksCompleted ? <TaskTrackingProgress taskTrackingData={campaignTaskTracking} /> : <div />}

        <Button
          onClick={() => {
            setIsCreateAdModalOpen(true);
            posthog?.capture('create_ad_clicked', { campaignId: campaignId });
          }}
          color='indigo'
          disabled={maxAdsReached}
        >
          Create Ad +
        </Button>
      </div>

      <div className='overflow-x-auto sm:-mx-6 lg:-mx-8'>
        <div className='inline-block min-w-full py-2 align-middle'>
          <Table className='table-fixed w-full'>
            <TableHead>
              <TableRow>
                <TableHeader className='w-1/3'>Ad preview</TableHeader>
                <TableHeader className='w-1/2'>Keywords</TableHeader>
                <TableHeader className='w-1/6'>Action</TableHeader>
              </TableRow>
            </TableHead>
            <TableBody>
              {areAllTasksCompleted ? (
                <AdsTableRows ads={ads} campaignslug={campaignslug} />
              ) : (
                [...Array(5)].map((_, index) => (
                  <TableRow key={`skeleton-${index}`}>
                    <TableCell>
                      <Skeleton className='h-24 w-full' />
                    </TableCell>
                    <TableCell>
                      <Skeleton className='h-16 w-full' />
                    </TableCell>
                    <TableCell>
                      <Skeleton className='h-10 w-24' />
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {campaignUrl && (
        <CreateAdModal
          isOpen={isCreateAdModalOpen && !maxAdsReached}
          onClose={() => setIsCreateAdModalOpen(false)}
          campaignId={campaignId}
          campaignUrl={campaignUrl}
          onAdCreated={onAdCreated}
        />
      )}
    </div>
  );
}
interface AdsTableRowsProps {
  ads: Ad[];
  campaignslug: string;
}

const AdsTableRows: React.FC<AdsTableRowsProps> = ({ ads, campaignslug }) => {
  const posthog = usePostHog();
  return (
    <>
      {ads.map((ad) => {
        const adslug = ad.slug; // Extract adslug from ad object

        return (
          <TableRow key={ad.id}>
            <TableCell className='w-1/3'>
              <AdComponent
                url={ad.url}
                headline1={ad.headlines[0]?.text}
                headline2={ad.headlines[1]?.text}
                description={ad.descriptions[0]?.text}
              />
            </TableCell>
            <TableCell className='w-1/2'>
              <Keywords keywords={ad.keywords} />
            </TableCell>
            <TableCell className='w-1/6'>
              <Button
                color={ad.state === 'draft' ? 'yellow' : 'indigo'}
                to={`/campaigns/$campaignslug/ads/$adslug`}
                params={{ campaignslug, adslug }}
                onClick={() =>
                  posthog?.capture('ad_action_clicked', {
                    adId: ad.id,
                    action: ad.state === 'draft' ? 'review' : 'edit',
                  })
                }
              >
                {ad.state === 'draft' ? 'Review' : 'Edit'}
              </Button>
            </TableCell>
          </TableRow>
        );
      })}
    </>
  );
};

function AdsSkeleton() {
  return (
    <div className='mt-12'>
      <div className='flex items-center w-full justify-between mb-4'>
        <h2 className='text-base font-semibold leading-6 text-zinc-900 dark:text-white'>Ads</h2>
        <Button disabled color='indigo'>
          Create Ad +
        </Button>
      </div>
      <div className='overflow-x-auto sm:-mx-6 lg:-mx-8'>
        <div className='inline-block min-w-full py-2 align-middle'>
          <Table>
            <TableHead>
              <TableRow>
                <TableHeader>Ad preview</TableHeader>
                <TableHeader>Keywords</TableHeader>
                <TableHeader>Action</TableHeader>
              </TableRow>
            </TableHead>
            <TableBody>
              {[...Array(5)].map((_, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <div className='space-y-2'>
                      <Skeleton className='h-4 w-3/4' />
                      <Skeleton className='h-4 w-1/2' />
                      <Skeleton className='h-4 w-full' />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className='space-y-2'>
                      <Skeleton className='h-4 w-1/4' />
                      <Skeleton className='h-4 w-1/3' />
                      <Skeleton className='h-4 w-1/4' />
                      <Skeleton className='h-4 w-1/3' />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Skeleton className='h-10 w-24' />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

export { AdComponent, Ads, AdsSkeleton, CreateAdModal, Keywords };
