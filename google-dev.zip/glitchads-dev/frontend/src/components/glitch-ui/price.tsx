import { useState } from 'react';
import { usePostHog } from 'posthog-js/react';

import { Alert, AlertActions, AlertTitle } from '@/components/catalyst/alert';
import { Button } from '@/components/catalyst/button';
import { PlusIcon } from '@heroicons/react/24/solid';
import { Dropdown, DropdownButton, DropdownItem, DropdownMenu } from '@/components/catalyst/dropdown';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/catalyst/table';
import { EllipsisHorizontalIcon } from '@heroicons/react/16/solid';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';
import { PriceType } from '@/lib/types';
import { useUpdatePriceMutationOptions, useDeletePriceMutationOptions } from '@/lib/query-options';

import { PriceForm } from './price-form';

export function Prices({
  prices,
  refetchCampaign,
  campaignId,
}: {
  prices: PriceType[];
  refetchCampaign: () => void;
  campaignId: number;
}) {
  const { toast } = useToast();
  const posthog = usePostHog();
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deletePriceId, setDeletePriceId] = useState<number | null>(null);
  const [newPriceOpen, setNewPriceOpen] = useState(false);
  const priceUpdateMutation = useUpdatePriceMutationOptions();
  const priceDeleteMutation = useDeletePriceMutationOptions();

  const handleSavePrice = async (updatedPrice: PriceType) => {
    try {
      await priceUpdateMutation.mutateAsync({ campaignId, price: updatedPrice });
      refetchCampaign();
      toast({ description: updatedPrice.id ? '🙌 Price updated' : '🎉 Price added' });
      posthog?.capture('price_saved', { priceId: updatedPrice.id, campaignId, ...updatedPrice });
    } catch (error) {
      console.error(error);
      toast({ description: 'Error saving price', variant: 'destructive' });
      posthog?.capture('price_save_error', { priceId: updatedPrice.id, campaignId, error });
    }
  };

  const handleDeletePrice = async () => {
    if (!deletePriceId) return;
    try {
      setDeleteConfirmOpen(false);
      await priceDeleteMutation.mutateAsync({ campaignId, priceId: deletePriceId });
      refetchCampaign();
      toast({ description: '🗑️ Price deleted' });
      posthog?.capture('price_deleted', { priceId: deletePriceId, campaignId });
    } catch (error) {
      console.error(error);
      toast({ description: 'Error deleting price', variant: 'destructive' });
      posthog?.capture('price_delete_error', { priceId: deletePriceId, campaignId, error });
    }
  };

  return (
    <>
      <Toaster />
      <Alert open={deleteConfirmOpen} onClose={setDeleteConfirmOpen}>
        <AlertTitle>Are you sure you want to delete this price?</AlertTitle>
        <AlertActions>
          <Button plain onClick={() => setDeleteConfirmOpen(false)}>
            Cancel
          </Button>
          <Button color='rose' onClick={handleDeletePrice}>
            Delete
          </Button>
        </AlertActions>
      </Alert>
      <div className='p-4'>
        <PriceForm
          isOpen={newPriceOpen}
          setIsOpen={setNewPriceOpen}
          price={{
            type: 'brands',
            currency: '',
            qualifier: 'no qualifier',
            header: '',
            value: 0,
            frequency: 'no units',
            description: '',
            final_url: '',
          }}
          handleSavePrice={handleSavePrice}
        />
        <Table className='[--gutter:theme(spacing.6)] sm:[--gutter:theme(spacing.8)]'>
          <TableHead>
            <TableRow>
              <TableHeader>Type</TableHeader>
              <TableHeader>Header</TableHeader>
              <TableHeader>Value</TableHeader>
              <TableHeader>Frequency</TableHeader>
              <TableHeader className='relative w-0'>
                <span className='sr-only'>Actions</span>
              </TableHeader>
            </TableRow>
          </TableHead>
          <TableBody>
            {prices.map((price) => (
              <Price
                key={price.id}
                price={price}
                handleSavePrice={handleSavePrice}
                setDeleteConfirmOpen={setDeleteConfirmOpen}
                setDeletePriceId={setDeletePriceId}
              />
            ))}
          </TableBody>
        </Table>
        <div>
          <Button
            color='white'
            className='mt-4'
            onClick={() => {
              setNewPriceOpen(true);
              posthog?.capture('add_price_clicked', { campaignId });
            }}
          >
            <PlusIcon className='text-slate-900' />
            Add Price
          </Button>
        </div>
      </div>
    </>
  );
}

function Price({
  price,
  handleSavePrice,
  setDeleteConfirmOpen,
  setDeletePriceId,
}: {
  price: PriceType;
  handleSavePrice: (updatedPrice: PriceType) => void;
  setDeleteConfirmOpen: (open: boolean) => void;
  setDeletePriceId: (id: number) => void;
}) {
  const posthog = usePostHog();
  const [edit, setEdit] = useState(false);

  const handleDelete = () => {
    if (!price.id) return;
    setDeletePriceId(price.id);
    setDeleteConfirmOpen(true);
    posthog?.capture('delete_price_clicked', { priceId: price.id });
  };

  if (edit) {
    return <PriceForm isOpen={edit} setIsOpen={setEdit} price={price} handleSavePrice={handleSavePrice} />;
  }

  return (
    <TableRow>
      <TableCell>{price.type}</TableCell>
      <TableCell>{price.header}</TableCell>
      <TableCell>{`${price.currency} ${price.value}`}</TableCell>
      <TableCell>{price.frequency}</TableCell>
      <TableCell>
        <div className='-mx-3 -my-1.5 sm:-mx-2.5'>
          <Dropdown>
            <DropdownButton plain aria-label='More options'>
              <EllipsisHorizontalIcon />
            </DropdownButton>
            <DropdownMenu anchor='bottom end'>
              <DropdownItem
                onClick={() => {
                  setEdit(true);
                  posthog?.capture('edit_price_clicked', { priceId: price.id });
                }}
              >
                Edit
              </DropdownItem>
              <DropdownItem className='text-rose-500' onClick={handleDelete}>
                Delete
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>
      </TableCell>
    </TableRow>
  );
}
