import { ArrowDownIcon, ArrowUpIcon, MinusIcon } from '@heroicons/react/24/solid';

const getRandomPercentage = (): number => {
  const base = 10;
  const variation = Math.floor(Math.random() * 16);
  const direction = Math.random() < 0.5 ? -1 : 1;
  return base + variation * direction;
};
const Metric = ({ label }: { label: string }) => {
  const percentage = getRandomPercentage();
  const Icon = percentage > 10 ? ArrowUpIcon : percentage < 10 ? ArrowDownIcon : MinusIcon;
  const iconColor = percentage > 10 ? 'text-green-500' : percentage < 10 ? 'text-red-500' : 'text-blue-500';

  return (
    <div className='text-center'>
      <p className='text-gray-500 uppercase tracking-wide'>{label}</p>
      <div className='flex items-center justify-center space-x-1'>
        <span className='text-lg font-bold'>{percentage}%</span>
        <Icon className={`h-4 w-4 ${iconColor}`} />
      </div>
    </div>
  );
};

export const Metrics = () => {
  return (
    <div className='flex space-x-8 p-8'>
      <Metric label='Cost' />
      <Metric label='Impressions' />
      <Metric label='Conversions' />
      <Metric label='Clicks' />
    </div>
  );
};
