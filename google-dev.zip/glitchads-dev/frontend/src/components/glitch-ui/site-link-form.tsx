import { usePostHog } from 'posthog-js/react';
import { useForm } from '@tanstack/react-form';
import clsx from 'clsx';
import { z } from 'zod';
import { zodValidator } from '@tanstack/zod-form-adapter';

import { Button } from '@/components/catalyst/button';
import { Dialog, DialogActions, DialogBody } from '@/components/catalyst/dialog';
import { Field, FieldGroup, Fieldset, Label, ErrorMessage } from '@/components/catalyst/fieldset';
import { Input } from '@/components/catalyst/input';
import { SiteLink as SiteLinkType } from '@/lib/types';

export function SiteLinkForm({
  isOpen,
  setIsOpen,
  siteLink,
  handleSaveSiteLink,
}: {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  siteLink: SiteLinkType;
  handleSaveSiteLink: (siteLink: SiteLinkType) => void;
}) {
  const posthog = usePostHog();
  const { name, description1, description2, url } = siteLink;

  const form = useForm({
    defaultValues: {
      name,
      description1,
      description2,
      url,
    },
    onSubmit: async (form) => {
      let updatedSiteLink = {
        ...siteLink,
        name: form.value.name,
        description1: form.value.description1,
        description2: form.value.description2,
        url: form.value.url,
      };
      handleSaveSiteLink(updatedSiteLink);
      posthog?.capture('site_link_form_submitted', updatedSiteLink);
      setIsOpen(false);
      try {
      } catch (error) {}
    },
    validatorAdapter: zodValidator(),
  });

  const handleFieldChange = (fieldName: string, value: string) => {
    posthog?.capture('site_link_form_field_changed', { fieldName, value });
  };

  if (isOpen) {
    posthog?.capture('site_link_form_opened', { siteLinkId: siteLink.id });
  }

  return (
    <Dialog
      open={isOpen}
      onClose={() => {
        setIsOpen(false);
        posthog?.capture('site_link_form_closed', { siteLinkId: siteLink.id });
      }}
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          e.stopPropagation();
          form.handleSubmit();
        }}
      >
        <DialogBody>
          <Fieldset>
            <FieldGroup>
              <form.Field
                validators={{
                  onChange: z.string().trim().min(1, 'Name is required'),
                }}
                name='name'
                children={(field) => (
                  <Field className='mb-4'>
                    <Label>Name</Label>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                    <Input
                      name={field.name}
                      placeholder='Link name'
                      autoFocus
                      value={field.state.value}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('name', e.target.value);
                      }}
                    />
                  </Field>
                )}
              />

              <form.Field
                validators={{
                  onChange: z.string().trim().min(1, 'Description one is required'),
                }}
                name='description1'
                children={(field) => (
                  <Field className='mb-4'>
                    <Label>Description one</Label>

                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                    <Input
                      name={field.name}
                      placeholder='Link description'
                      autoFocus
                      value={field.state.value}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('description1', e.target.value);
                      }}
                    />
                  </Field>
                )}
              />

              <form.Field
                validators={{
                  onChange: z.string().trim().min(1, 'Description two is required'),
                }}
                name='description2'
                children={(field) => (
                  <Field className='mb-4'>
                    <Label>Description two</Label>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                    <Input
                      name={field.name}
                      placeholder='Link description'
                      autoFocus
                      value={field.state.value}
                      onChange={(e) => {
                        field.handleChange(e.target.value);
                        handleFieldChange('description2', e.target.value);
                      }}
                    />
                  </Field>
                )}
              />

              <form.Field
                validators={{
                  onChange: z.string().trim().min(1, 'URL is required'),
                }}
                name='url'
                children={(field) => (
                  <Field className='mb-4'>
                    <Label>URL</Label>
                    {field.state.meta.touchedErrors && <ErrorMessage>{field.state.meta.touchedErrors}</ErrorMessage>}
                    <div className='flex rounded-lg shadow-sm ring-1 basis-2/3 ring-inset ring-gray-300 focus-within:ring-2 mt-2'>
                      <span className='flex select-none items-center pl-3 text-gray-500 sm:text-sm'>https://</span>
                      <input
                        type='text'
                        name={field.name}
                        className='block w-full flex-1 border-0 bg-transparent py-1.5 pl-1 text-gray-900 placeholder:text-gray-400 focus:ring-0 sm:text-sm sm:leading-6'
                        value={field.state.value}
                        onChange={(e) => {
                          field.handleChange(e.target.value);
                          handleFieldChange('url', e.target.value);
                        }}
                      />
                    </div>
                  </Field>
                )}
              />
            </FieldGroup>
          </Fieldset>
        </DialogBody>
        <DialogActions>
          <Button
            plain
            onClick={() => {
              setIsOpen(false);
              posthog?.capture('site_link_form_cancelled', { siteLinkId: siteLink.id });
            }}
          >
            Cancel
          </Button>
          <form.Subscribe
            selector={(state) => [state.canSubmit, state.isSubmitting]}
            children={([canSubmit, isSubmitting]) => {
              return (
                <Button
                  color='indigo'
                  className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                  type='submit'
                  disabled={!canSubmit}
                >
                  {isSubmitting ? '...' : 'Save'}
                </Button>
              );
            }}
          />
        </DialogActions>
      </form>
    </Dialog>
  );
}
