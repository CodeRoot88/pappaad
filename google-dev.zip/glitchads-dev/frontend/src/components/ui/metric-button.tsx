import * as React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MetricButtonProps {
  label: string;
  value: string;
  icon?: React.ReactNode;
  className?: string;
}

export function MetricButton({
  label,
  value,
  icon = <ArrowUpRight className='h-4 w-4' />,
  className,
}: MetricButtonProps) {
  return (
    <div className={cn('flex items-center gap-4 rounded-lg bg-white p-4 shadow-sm', className)}>
      <div className='flex h-8 w-8 items-center justify-center rounded-lg bg-purple-100'>{icon}</div>
      <span className='text-sm text-gray-600'>{label}</span>
      <div className='flex items-center'>
        <ArrowUpRight className='h-4 w-4' />
        <span className='font-medium'>{value}</span>
      </div>
    </div>
  );
}
