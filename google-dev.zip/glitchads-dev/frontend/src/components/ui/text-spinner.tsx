import { Loader2 } from 'lucide-react';

export function TextSpinner({ message }: { message: string }) {
  return (
    <div className='flex items-center justify-center p-8 rounded-md'>
      <Loader2 className='w-6 h-6 text-blue-500 animate-spin mr-3' />
      <span className='text-blue-700 font-medium'>{message}</span>
    </div>
  );
}
