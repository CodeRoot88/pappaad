import { useGoogleLogin } from '@react-oauth/google';
import { useNavigate } from '@tanstack/react-router';
import { useState } from 'react';
import { usePostHog } from 'posthog-js/react';

import { useToast } from '@/components/ui/use-toast';
import { setCookie } from '@/lib/utils';
import { getUserProfileFromToken } from '@/lib/auth';
import { useUserProfile } from '@/contexts/user.context';
import {
  fetchGoogleAdsAccounts,
  getAccessTokenFromGoogleAccessToken,
  getAccessTokenFromGoogleAccessTokenWithInviteCode,
} from '@/lib/apis';
const onboardingUrl = '/redesign/campaigns/new/onboarding';

const useGoogleSignIn = ({
  redirectUrl,
  fallbackUrl,
  inviteCode,
}: {
  redirectUrl: string;
  fallbackUrl: string;
  inviteCode?: string;
}) => {
  const posthog = usePostHog();

  const [isLoading, setIsLoading] = useState(false);
  const { setUser } = useUserProfile();
  const navigate = useNavigate();
  const { toast } = useToast();

  const signInWithGoogle = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      setIsLoading(true);
      try {
        const response = inviteCode
          ? await getAccessTokenFromGoogleAccessTokenWithInviteCode({
              googleAccessToken: tokenResponse.access_token,
              inviteCode,
            })
          : await getAccessTokenFromGoogleAccessToken({ googleAccessToken: tokenResponse.access_token });

        if (response?.access_token) {
          setCookie('access_token', response.access_token, 1);
          const userProfile = getUserProfileFromToken(response.access_token);
          setUser(userProfile);
          const { name, email } = userProfile;
          posthog?.identify(email, {
            email,
            name,
          });
          const accounts = await fetchGoogleAdsAccounts();
          const isFirstTimeLoginUser = accounts.every((account) => !account.selected);
          navigate({ to: redirectUrl.startsWith('/redesign') && isFirstTimeLoginUser ? onboardingUrl : redirectUrl });
        } else {
          setIsLoading(false);
          toast({
            title: 'Login Failed',
            description: 'Unable to sign in due to an internal error. Please try again.',
          });
          navigate({ to: fallbackUrl });
        }
      } catch (error: any) {
        setIsLoading(false);
        toast({
          title: 'Login Failed',
          description: error.message || 'Unable to sign in due to an internal error. Please try again.',
        });
        navigate({ to: fallbackUrl });
      }
    },
  });

  return { signInWithGoogle, isLoading };
};

export default useGoogleSignIn;
