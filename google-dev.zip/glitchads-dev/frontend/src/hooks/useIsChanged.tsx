import { useEffect, useState } from 'react';

export const useIsChanged = <T,>(original: Array<T>, current: Array<T>): boolean => {
  const [isChanged, setIsChanged] = useState(false);

  useEffect(() => {
    setIsChanged(JSON.stringify(original) !== JSON.stringify(current));
  }, [original, current]);

  return isChanged;
};
