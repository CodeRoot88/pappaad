import { useGoogleLogin } from '@react-oauth/google';
import { useNavigate } from '@tanstack/react-router';
import { useState } from 'react';
import { usePostHog } from 'posthog-js/react';

import { useToast } from '@/components/ui/use-toast';
import { setCookie } from '@/lib/utils';
import { fetchGoogleAdsAccounts, getAuthToken, getAuthTokenWithInviteCode } from '@/lib/apis';
import { getUserProfileFromToken } from '@/lib/auth';
import { useUserProfile } from '@/contexts/user.context';

const onboardingUrl = '/redesign/campaigns/new/onboarding';
const useGoogleSignUp = ({
  redirectUrl,
  fallbackUrl,
  inviteCode,
}: {
  redirectUrl: string;
  fallbackUrl: string;
  inviteCode?: string;
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const { setUser } = useUserProfile();
  const navigate = useNavigate();
  const { toast } = useToast();
  const posthog = usePostHog();

  const signupWithGoogle = useGoogleLogin({
    onSuccess: async (codeResponse) => {
      setIsLoading(true);
      try {
        const token = inviteCode
          ? await getAuthTokenWithInviteCode({ authCode: codeResponse.code, inviteCode })
          : await getAuthToken({ authCode: codeResponse.code });

        if (token) {
          setCookie('access_token', token, 1);
          const userProfile = getUserProfileFromToken(token);
          setUser(userProfile);
          const { name, email } = userProfile;
          posthog?.identify(email, {
            email,
            name,
          });
          const accounts = await fetchGoogleAdsAccounts();
          const isFirstTimeLoginUser = accounts.every((account) => !account.selected);
          navigate({ to: redirectUrl.startsWith('/redesign') && isFirstTimeLoginUser ? onboardingUrl : redirectUrl });
        }
      } catch (error: any) {
        toast({
          title: 'SignUp Failed',
          description: error.message || 'Unable to sign in due to an internal error. Please try again.',
        });
        navigate({ to: fallbackUrl });
      } finally {
        setIsLoading(false);
      }
    },
    scope: 'https://www.googleapis.com/auth/adwords',
    flow: 'auth-code',
    include_granted_scopes: false,
  });

  return { signupWithGoogle, isLoading };
};

export default useGoogleSignUp;
