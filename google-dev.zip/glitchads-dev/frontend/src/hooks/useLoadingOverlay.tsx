import { useEffect } from 'react';
import { Loading } from 'notiflix/build/notiflix-loading-aio';

function useLoadingOverlay(isLoading: boolean) {
  useEffect(() => {
    if (isLoading) {
      Loading.standard();
    } else {
      Loading.remove();
    }

    return () => {
      Loading.remove();
    };
  }, [isLoading]);
}

export default useLoadingOverlay;
