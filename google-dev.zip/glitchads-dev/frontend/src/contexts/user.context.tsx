import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { getCookie, getUserProfileFromToken } from '@/lib/auth';
import { UserProfile } from '@/lib/types';

interface UserContextProps {
  user: UserProfile;
  setUser: (user: UserProfile) => void;
}

const UserContext = createContext<UserContextProps | undefined>(undefined);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const token = getCookie('access_token');
  const [user, setUser] = useState<UserProfile>(getUserProfileFromToken(token));

  useEffect(() => {
    setUser(getUserProfileFromToken(token));
  }, [token]);

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUserProfile = (): UserContextProps => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUserProfile must be used within a UserProvider');
  }
  return context;
}