import { Description, ErrorMessage, Field, Label } from '@/components/catalyst/fieldset';
import { ValidationError } from '@tanstack/react-form';
import { ReactNode } from 'react';

type BaseFieldProps = {
	label: string;
	htmlFor: string;
	description?: string;
	errors?: ValidationError[];
	children: ReactNode;
};

export function BaseField({ label, htmlFor, description, errors, children }: BaseFieldProps) {
	return (
		<Field>
			<Label htmlFor={htmlFor} className='sm:text-xl'>
				{label}
			</Label>
			{description && <Description className='sm:text-base'>{description}</Description>}
			{children}
			{errors && <ErrorMessage>{errors}</ErrorMessage>}
		</Field>
	);
}