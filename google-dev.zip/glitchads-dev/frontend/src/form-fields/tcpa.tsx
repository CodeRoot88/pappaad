import { useAtomValue } from 'jotai';
import { BaseField } from './base-form-field';
import { FieldPropsType } from './field-type';
import { campaignDataAtom } from '@/store';
import getSymbolFromCurrency from "currency-symbol-map";

interface TCPAFieldProps<T extends number> {
  field: FieldPropsType;
  onFieldChange: (value: T) => void;
}

export function TCPAField<T extends number>({ field, onFieldChange }: TCPAFieldProps<T>) {
  const campaign = useAtomValue(campaignDataAtom)
  
  const { name, state, handleChange } = field;
  const label = 'Target CPA';
  const description = 'Set a target cost per action';

  const currency = campaign?.googleads_account.currency ?? "USD";
  const symbol = getSymbolFromCurrency(currency);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const parsedValue = parseFloat(e.target.value) as T;
    handleChange(parsedValue);
    onFieldChange(parsedValue);
  };

  return (
    <BaseField label={label} description={description} htmlFor={name} errors={state.meta.touchedErrors}>
      <div className='relative mt-2 rounded-md shadow-sm max-w-48'>
        <div className='pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3'>
          <span className='text-gray-500 sm:text-sm'>{symbol}</span>
        </div>
        <input
          type='text'
          name='price'
          id='price'
          defaultValue={state.value}
          className='block w-full rounded-md border-0 py-1.5 pl-7 pr-12 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6'
          placeholder='0.00'
          aria-describedby='price-currency'
          onChange={handleInputChange}
        />
        <div className='pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3'>
          <span className='text-gray-500 sm:text-sm' id='price-currency'>
            {currency}
          </span>
        </div>
      </div>
    </BaseField>
  );
}
