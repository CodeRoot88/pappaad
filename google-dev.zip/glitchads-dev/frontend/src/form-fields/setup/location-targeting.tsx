import { Field, Label } from '@/components/catalyst/fieldset';
import { locationsQueryOptions, nearByLocationsQueryOptions } from '@/lib/query-options';
import { Location } from '@/lib/types';
import { MagnifyingGlassIcon, XMarkIcon } from '@heroicons/react/24/solid';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { useDebounce } from 'use-debounce';
import { FieldPropsType } from '../field-type';

const formatNumber = (num: number) => {
  return new Intl.NumberFormat().format(num);
};

interface LocationTargetingSelectFieldProps<T extends Location[]> {
  field: FieldPropsType;
  onFieldChange: (value: T) => void;
}

export function LocationTargetingSelectField<T extends Location[]>({
  field,
  onFieldChange,
}: LocationTargetingSelectFieldProps<T>) {
  const { handleChange, state } = field;
  return (
    <Field>
      <LocationMultiSelect handleChange={handleChange} value={state.value} onFieldChange={onFieldChange} />
    </Field>
  );
}

// Props types for subcomponents
type SelectedLocationsProps = {
  selected: Location[];
  setSelected: React.Dispatch<React.SetStateAction<Location[]>>;
  inputRef: React.RefObject<HTMLInputElement>;
};

type SearchInputProps = {
  query: string;
  setQuery: React.Dispatch<React.SetStateAction<string>>;
  setMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setSelectedNearBySearchItem: React.Dispatch<React.SetStateAction<Location | null>>;
};

type LocationMenuProps = {
  filteredLocations: Location[];
  nearByLocations: Location[];
  setSelected: React.Dispatch<React.SetStateAction<Location[]>>;
  selectedNearBySearchItem: Location | null;
  setSelectedNearBySearchItem: React.Dispatch<React.SetStateAction<Location | null>>;
  setQuery: React.Dispatch<React.SetStateAction<string>>;
  query: string;
  loading: boolean;
  nearByLoading: boolean;
};

// Main LocationMultiSelect Component
interface LocationMultiSelectProps<T extends Location[]> {
  value: Location[];
  handleChange: (selectedLocations: Location[]) => void;
  onFieldChange: (value: T) => void;
}
function LocationMultiSelect<T extends Location[]>({
  value,
  handleChange,
  onFieldChange,
}: LocationMultiSelectProps<T>) {
  const [query, setQuery] = useState<string>('');
  const [selected, setSelected] = useState<Location[]>(value);
  const [menuOpen, setMenuOpen] = useState<boolean>(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const [debouncedQuery] = useDebounce(query, 500);
  const locationQuery = useQuery(locationsQueryOptions(debouncedQuery));
  const locations = locationQuery.data || [];
  const [selectedNearBySearchItem, setSelectedNearBySearchItem] = useState<Location | null>(null);
  const nearByLocationQuery = useQuery(nearByLocationsQueryOptions(selectedNearBySearchItem));
  const nearByLocations = nearByLocationQuery.data || [];

  useEffect(() => {
    handleChange(selected);
    onFieldChange(selected as T);
  }, [selected]);

  const filteredLocations = locations.filter(
    (item) =>
      item.name.toLocaleLowerCase().includes(query.toLocaleLowerCase().trim()) &&
      !selected.some((selectedItem) => selectedItem.criteria_id === item.criteria_id),
  );

  return (
    <div className='relative w-80 max-h-96 text-sm mt-3'>
      {selected.length > 0 && <SelectedLocations selected={selected} setSelected={setSelected} inputRef={inputRef} />}
      <SearchInput
        query={query}
        setQuery={setQuery}
        setMenuOpen={setMenuOpen}
        setSelectedNearBySearchItem={setSelectedNearBySearchItem}
      />
      {menuOpen && (
        <LocationMenu
          filteredLocations={filteredLocations}
          nearByLocations={nearByLocations}
          setSelected={setSelected}
          selectedNearBySearchItem={selectedNearBySearchItem}
          setSelectedNearBySearchItem={setSelectedNearBySearchItem}
          setQuery={setQuery}
          query={query}
          loading={locationQuery.isLoading}
          nearByLoading={nearByLocationQuery.isLoading}
        />
      )}
    </div>
  );
}

function SelectedLocations({ selected, setSelected, inputRef }: SelectedLocationsProps) {
  return (
    <div className='bg-white w-80 relative text-xs flex flex-wrap gap-1 p-2 mb-2'>
      {selected.map((location) => (
        <div
          key={location.criteria_id}
          className='rounded-full w-fit py-1.5 px-3 border border-gray-400 bg-gray-50 text-gray-500 flex items-center gap-2'
        >
          {location.canonical_name}
          <div
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => setSelected(selected.filter((i) => i.criteria_id !== location.criteria_id))}
          >
            <XMarkIcon className='size-4 text-slate-500' />
          </div>
        </div>
      ))}
      <div className='w-full text-right'>
        <span
          className='text-gray-400 cursor-pointer'
          onClick={() => {
            setSelected([]);
            inputRef.current?.focus();
          }}
        >
          Clear all
        </span>
      </div>
    </div>
  );
}

// SearchInput Component
function SearchInput({ query, setQuery, setMenuOpen, setSelectedNearBySearchItem }: SearchInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  return (
    <div className='relative mt-2 rounded-md shadow-sm'>
      <div className='pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3'>
        <MagnifyingGlassIcon className='size-4' />
      </div>
      <input
        ref={inputRef}
        type='text'
        value={query}
        onChange={(e) => {
          setQuery(e.target.value.trimStart());
          setSelectedNearBySearchItem(null);
        }}
        placeholder='Search locations'
        className='block w-full rounded-md border-0 py-1.5 pl-10 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6'
        onFocus={() => {
          setMenuOpen(true);
        }}
        onBlur={() => setMenuOpen(false)}
      />
    </div>
  );
}

// LocationMenu Component
function LocationMenu({
  filteredLocations,
  setSelected,
  setQuery,
  query,
  loading,
  // nearByLocations,
  // selectedNearBySearchItem,
  // setSelectedNearBySearchItem,
  // nearByLoading,
}: LocationMenuProps) {
  // const [selectedNearByLocations, setSelectedNearByLocations] = useState<Location[]>([]);
  // const handleSetNearByLocations = (e: ChangeEvent<HTMLInputElement>, location: Location) =>
  //   e.target.checked
  //     ? setSelectedNearByLocations((prev) => [...prev, location])
  //     : setSelectedNearByLocations(
  //         selectedNearByLocations.filter((selectedLocation) => selectedLocation.criteria_id !== location.criteria_id),
  //       );

  if (!query) return null;
  if (loading)
    return (
      <div className='absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm'>
        <ul className='block w-full '>
          <li className='p-2 text-gray-500'>Loading...</li>
        </ul>
      </div>
    );
  return (
    <div className='absolute z-10 mt-1 max-h-60 min-w-[30rem] overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm'>
      <ul className='block w-full'>
        {filteredLocations.length ? (
          <>
            <li className='px-2'>
              <div className='flex w-full justify-between'>
                <Label className='!text-gray-400 !text-xs'>Matches</Label>
                <Label className='!text-gray-400 !text-xs'>Reach</Label>
              </div>
            </li>
            {filteredLocations.map((location) => (
              <li
                key={location.criteria_id}
                className='cursor-pointerw-full'
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setSelected((prev) => [...prev, location]);
                  setQuery('');
                }}
              >
                <div className='p-2 rounded-md  w-full flex hover:bg-indigo-50 hover:text-indigo-500'>
                  <div className='flex w-full justify-between'>
                    <Label>{location.canonical_name}</Label>
                    <Label>{formatNumber(location.reach)}</Label>
                  </div>
                  {/* <div className='flex w-1/5 justify-center'>
                    <Label
                      className='!text-blue-600 cursor-pointer'
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedNearBySearchItem(location);
                      }}
                    >
                      NearBy
                    </Label>
                  </div> */}
                </div>

                {/* {nearByLoading &&
                selectedNearBySearchItem &&
                selectedNearBySearchItem.criteria_id === location.criteria_id ? (
                  <ul className='block w-full pl-1'>
                    <li className='px-3 w-4/5 pt-2 text-gray-500'>Loading...</li>
                  </ul>
                ) : (
                  <>
                    {nearByLocations.length > 0 &&
                      selectedNearBySearchItem &&
                      selectedNearBySearchItem.criteria_id === location.criteria_id && (
                        <ul className='block w-full pl-1' onClick={(e) => e.stopPropagation()}>
                          <li className='px-3 w-4/5 pt-2'>
                            <Label className='!text-gray-400 !text-xs'>Near By</Label>
                          </li>
                          {nearByLocations.map((location) => (
                            <li
                              key={location.criteria_id}
                              className='px-3 py-1 hover:bg-indigo-50 hover:text-indigo-500 rounded-md w-full flex'
                              onMouseDown={(e) => e.preventDefault()}
                            >
                              <div className='flex w-4/5 justify-between cursor-pointer'>
                                <div className='flex gap-2 items-center'>
                                  <input
                                    type='checkbox'
                                    className='w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2'
                                    value={location.criteria_id}
                                    checked={selectedNearByLocations
                                      .map((location) => location.criteria_id)
                                      .includes(location.criteria_id)}
                                    onChange={(e) => handleSetNearByLocations(e, location)}
                                  />
                                  <Label>{location.canonical_name}</Label>
                                </div>
                                <Label>{location.reach}</Label>
                              </div>
                            </li>
                          ))}
                          {selectedNearByLocations.length > 0 && (
                            <li className='px-3 py-1 w-full flex justify-end'>
                              <div className='flex w-1/5 pl-2 justify-between'>
                                <Label
                                  className='!text-blue-600 cursor-pointer'
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelected((prev) => [...prev, ...selectedNearByLocations]);
                                    setSelectedNearByLocations([]);
                                    setSelectedNearBySearchItem(null);
                                  }}
                                >
                                  Okay
                                </Label>
                                <Label
                                  className='!text-blue-600 cursor-pointer'
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedNearByLocations([]);
                                    setSelectedNearBySearchItem(null);
                                  }}
                                >
                                  Cancel
                                </Label>
                              </div>
                            </li>
                          )}
                        </ul>
                      )}
                  </>
                )} */}
              </li>
            ))}
          </>
        ) : (
          <li className='p-2 text-gray-500'>No options available</li>
        )}
      </ul>
    </div>
  );
}
