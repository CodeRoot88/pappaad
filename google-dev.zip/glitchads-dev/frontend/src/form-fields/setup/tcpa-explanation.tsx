import { BaseField } from '../base-form-field';
import { Textarea } from '@/components/catalyst/textarea';
import { FieldPropsType } from '../field-type';

interface CampaignNameFieldProps {
  field: FieldPropsType;
  onFieldChange: (value: string) => void;
}

export const TCPAExplanationField = ({ field }: CampaignNameFieldProps) => {
  const { name, state, handleChange, handleBlur } = field;
  const label = "How we calculated your Campaign's TCPA";

  return (
    <BaseField label={label} htmlFor={name} errors={state.meta.touchedErrors}>
      <div className='flex items-start space-x-4 mt-2'>
        {/* Avatar image */}

        <Textarea
          name={name}
          className='h-60'
          resizable={false}
          defaultValue={state.value}
          placeholder='TCPA Explanation'
          onChange={(e) => {
            handleChange(e.target.value);
          }}
          onBlur={handleBlur}
        />
      </div>
    </BaseField>
  );
};
