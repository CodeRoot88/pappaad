import { BaseField } from '../base-form-field';
import { Textarea } from '@/components/catalyst/textarea';
import { FieldPropsType } from '../field-type';

interface CampaignNameFieldProps {
  field: FieldPropsType;
  onFieldChange: (value: string) => void;
}

export const BusinessInfoField = ({ field }: CampaignNameFieldProps) => {
  const { name, state, handleChange, handleBlur } = field;
  const label = 'The Goal Of this Campaign';

  return (
    <BaseField label={label} htmlFor={name} errors={state.meta.touchedErrors}>
      <div className='flex items-start space-x-4 mt-2'>
        <Textarea
          name={name}
          className='h-60'
          resizable={false}
          defaultValue={state.value}
          placeholder='Business description'
          onChange={(e) => {
            handleChange(e.target.value);
          }}
          onBlur={handleBlur}
        />
      </div>
    </BaseField>
  );
};
