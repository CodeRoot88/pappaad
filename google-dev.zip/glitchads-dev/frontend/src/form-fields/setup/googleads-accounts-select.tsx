import { Select } from '@/components/catalyst/select';
import { FieldPropsType } from '../field-type';
import { BaseField } from '../base-form-field';

export function GoogleAdsAccountSelectField({ field }: { field: FieldPropsType }) {
  const { name, state, handleChange, handleBlur } = field;
  const label = 'Select Google Ads account';
  return (
    <BaseField label={label} htmlFor={name} errors={state.meta.touchedErrors}>
      <Select name={name} defaultValue={state.value} onChange={(e) => handleChange(e.target.value)} onBlur={handleBlur}>
        <option value='190-326-7786'>190-326-7786</option>
        <option value='535-128-8874'>535-128-8874</option>
      </Select>
    </BaseField>
  );
}
