import { Input } from '@/components/catalyst/input';
import { BaseField } from '../base-form-field';
import { FieldPropsType } from '../field-type';

interface CampaignNameFieldProps {
  field: FieldPropsType;
  onFieldChange: (value: string) => void;
}

export function CampaignNameField({ field, onFieldChange }: CampaignNameFieldProps) {
  const { name, state, handleChange, handleBlur } = field;
  const label = 'Campaign Name';

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    handleChange(value);
    onFieldChange(value);
  };

  return (
    <BaseField label={label} htmlFor={name} errors={state.meta.touchedErrors}>
      <Input
        name={name}
        defaultValue={state.value}
        onChange={handleInputChange}
        onBlur={handleBlur}
        placeholder='New super Campaign'
      />
    </BaseField>
  );
}
