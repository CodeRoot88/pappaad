import { Input } from '@/components/catalyst/input';
import { BaseField } from '../base-form-field';
import { FieldPropsType } from '../field-type';

interface OrganizationNameFieldProps {
  field: FieldPropsType;
  onFieldChange: (value: string) => void;
}

export function OrganizationNameField({ field, onFieldChange }: OrganizationNameFieldProps) {
  const { name, state, handleChange, handleBlur } = field;
  const label = 'Organization Name';

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    handleChange(value);
    onFieldChange(value);
  };

  return (
    <BaseField label={label} htmlFor={name} errors={state.meta.touchedErrors}>
      <Input
        name={name}
        defaultValue={state.value}
        onChange={handleInputChange}
        onBlur={handleBlur}
        placeholder='New Organization'
      />
    </BaseField>
  );
}
