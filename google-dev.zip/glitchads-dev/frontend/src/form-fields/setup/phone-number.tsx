import { PhoneInput } from 'react-international-phone';
import { BaseField } from '../base-form-field';
import { FieldPropsType } from '../field-type';

import 'react-international-phone/style.css';

interface PhoneNumberFieldProps {
  field: FieldPropsType;
  onFieldChange: (value: string) => void;
}

export function PhoneNumberField({ field, onFieldChange }: PhoneNumberFieldProps) {
  const { name, state, handleChange } = field;
  const label = 'Phone Number';
  const description = 'Show a call button in your ad';

  const handlePhoneChange = (phone: string) => {
    handleChange(phone);
    onFieldChange(phone);
  };

  return (
    <BaseField label={label} description={description} htmlFor={name} errors={state.meta.touchedErrors}>
      <PhoneInput defaultCountry='ie' value={state.value} onChange={handlePhoneChange} />
    </BaseField>
  );
}
