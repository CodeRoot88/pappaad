import { Input } from '@/components/catalyst/input';
import { BaseField } from '../base-form-field';
import { FieldPropsType } from '../field-type';

export function WebsiteUrlField({ field }: { field: FieldPropsType }) {
  const { name, state, handleChange, handleBlur } = field;
  const label = 'Choose what landing page you would like the ad to go to';
  const description = 'What website address would you like users to visit?';

  return (
    <BaseField label={label} description={description} htmlFor={name} errors={state.meta.touchedErrors}>
      <div className='flex my-3'>
        <span className='inline-flex items-center rounded-l-md border border-r-0 border-gray-300 px-3 text-gray-500 sm:text-sm bg-gray-100'>
          https://
        </span>
        <Input
          name={name}
          defaultValue={state.value}
          onChange={(e) => handleChange(`https://${e.target.value}`)}
          onBlur={handleBlur}
          placeholder='mysite.com'
        />
      </div>
    </BaseField>
  );
}
