import { FieldApi } from '@tanstack/react-form';

export type FieldPropsType = FieldApi<any, any, any, any>;
