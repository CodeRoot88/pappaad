import { Description, ErrorMessage, Field, Label } from '@/components/catalyst/fieldset';
import { ValidationError } from '@tanstack/react-form';
import { ReactNode } from 'react';

type BaseFieldProps = {
  label: string;
  htmlFor: string;
  description?: string;
  errors?: ValidationError[];
  children: ReactNode;
};

export function BaseField({ label, htmlFor, description, errors, children }: BaseFieldProps) {
  return (
    <Field>
      <Label htmlFor={htmlFor} className='font-semibold leading-7'>
        {label}
      </Label>
      {description && <Description className='sm:text-base'>{description}</Description>}
      {children}
      {errors && errors.length > 0 && (
        <div className='mt-2 text-sm text-red-600'>
          {errors.map((error, index) => (
            <ErrorMessage key={index}>{error}</ErrorMessage>
          ))}
        </div>
      )}
    </Field>
  );
}
