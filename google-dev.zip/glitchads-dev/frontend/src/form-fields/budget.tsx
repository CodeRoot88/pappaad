import { useAtomValue } from 'jotai';
import { BaseField } from './base-form-field';
import { FieldPropsType } from './field-type';
import { campaignDataAtom } from '@/store';
import getSymbolFromCurrency from "currency-symbol-map";

interface BudgetFieldProps {
  field: FieldPropsType;
  onFieldChange: (value: number) => void;
}

const getDaysInCurrentMonth = (): number => {
  const date = new Date();
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
};

export function BudgetField({ field, onFieldChange }: BudgetFieldProps) {

  const campaign = useAtomValue(campaignDataAtom)
  const currency = campaign?.googleads_account.currency ?? "USD";
  const symbol = getSymbolFromCurrency(currency);
  const { name, state, handleChange } = field;
  const label = 'Daily Budget';
  const description = 'Set a daily budget for this campaign';

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value) || 0;
    handleChange(value);
    onFieldChange(value);
  };

  const monthlyEstimate = state.value ? state.value * getDaysInCurrentMonth() : 0;

  return (
    <BaseField label={label} description={description} htmlFor={name} errors={state.meta.touchedErrors}>
      <div className='space-y-2'>
        <div className='relative mt-2 rounded-md shadow-sm max-w-48'>
          <div className='pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3'>
            <span className='text-gray-500 sm:text-sm'>{symbol}</span>
          </div>
          <input
            type='text'
            name={name}
            id='budget'
            defaultValue={state.value}
            className='block w-full rounded-md border-0 py-1.5 pl-7 pr-20 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6'
            placeholder='0.00'
            aria-describedby='price-currency monthly-estimate'
            onChange={handleInputChange}
          />
          <div className='pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3'>
            <span className='text-gray-500 sm:text-sm' id='price-currency'>
              {currency} per day
            </span>
          </div>
        </div>
        {state.value > 0 && (
          <div className='text-sm text-gray-500' id='monthly-estimate'>
            Estimated monthly cost (for {getDaysInCurrentMonth()} days): ${monthlyEstimate.toFixed(2)}
          </div>
        )}
      </div>
    </BaseField>
  );
}
