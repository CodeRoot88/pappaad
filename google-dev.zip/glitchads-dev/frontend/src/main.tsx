import { StrictMode } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RouterProvider, createRouter, ErrorComponent } from '@tanstack/react-router';
import { Provider } from 'jotai';
import posthog from 'posthog-js';
import { PostHogProvider } from 'posthog-js/react';
import * as Sentry from '@sentry/react';

import { Toaster } from '@/components/ui/toaster';

import { routeTree } from './routeTree.gen';
import './index.css';
import { UserProvider } from './contexts/user.context';

const env = import.meta.env;

const NODE_ENV = env.VITE_NODE_ENV;
// Initialize PostHog
if (NODE_ENV === 'production') {
  posthog?.init(env.VITE_POSTHOG_API_KEY!, {
    api_host: env.VITE_POSTHOG_HOST!,
  });
}
if (NODE_ENV === 'production' || NODE_ENV === 'staging') {
  Sentry.init({
    dsn: env.VITE_SENTRY_DSN,
    integrations: [
      Sentry.browserTracingIntegration(),
      Sentry.browserProfilingIntegration(),
      Sentry.replayIntegration(),
    ],
    // Tracing
    tracesSampleRate: 1.0,
    tracePropagationTargets: ['localhost', /^https:\/\/app.glichads\.ai/, /^https:\/\/staging.glichads\.ai/],
    profilesSampleRate: 1.0,
    // Session Replay
    replaysSessionSampleRate: 1.0,
    replaysOnErrorSampleRate: 1.0,
    environment: NODE_ENV,
  });
}
console.log('version', 1.05);
export const queryClient = new QueryClient();
const GOOGLE_ADS_CLIENT_ID = env.VITE_GOOGLE_ADS_CLIENT_ID!;
const router = createRouter({
  routeTree,
  defaultErrorComponent: ({ error }) => <ErrorComponent error={error} />,
  context: {
    queryClient,
  },
  defaultPreload: 'intent',
  defaultPreloadStaleTime: 0,
});

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
  interface HistoryState {
    impersonate?: { action?: string };
  }
}

const rootElement = document.getElementById('app')!;
if (!rootElement.innerHTML) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <StrictMode>
      <PostHogProvider client={posthog}>
        <QueryClientProvider client={queryClient}>
          <Provider>
            <GoogleOAuthProvider clientId={GOOGLE_ADS_CLIENT_ID}>
              <UserProvider>
                <Toaster />
                <RouterProvider router={router} />
              </UserProvider>

            </GoogleOAuthProvider>
          </Provider>
        </QueryClientProvider>
      </PostHogProvider>
    </StrictMode>,
  );
}
