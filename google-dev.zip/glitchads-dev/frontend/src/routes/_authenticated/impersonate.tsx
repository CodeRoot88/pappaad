import { useEffect, useState } from 'react';
import { createFileRoute, useNavigate, useRouterState } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { useImpersonateUserMutationOptions, useUnsetImpersonateUserMutationOptions, usersQueryOptions } from '@/lib/query-options';
import { User } from '@/lib/types';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/catalyst/button';
import ConfirmationModal from '@/components/catalyst/confirmation-modal';
import { setCookie } from '@/lib/utils';
import { getUserProfileFromToken } from '@/lib/auth';
import { useUserProfile } from '@/contexts/user.context';

export const Route = createFileRoute('/_authenticated/impersonate')({
  component: Impersonate,
});


function Impersonate() {
  const { isLoading, data: users = [] } = useSuspenseQuery(usersQueryOptions());
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [impersonateUser, setImpersonateUser] = useState<User | null>(null);
  const state = useRouterState({ select: s => s.location.state });
  const impersonateUserMutation = useImpersonateUserMutationOptions();
  const unsetImpersonateUserMutation = useUnsetImpersonateUserMutationOptions();
  const { user, setUser } = useUserProfile();

  useEffect(() => {
    const handleLogoutAsImpersonator = async () => {
      if (state?.impersonate?.action !== 'logout') return;

      try {
        const { access_token: token } = await unsetImpersonateUserMutation.mutateAsync();
        if (token) {
          setCookie('access_token', token, 1);
          setUser(getUserProfileFromToken(token));
        }
      } catch (error) {
        toast({
          title: 'Impersonating failed Failed',
          description: 'Unable to impersonate due to an internal error. Please try again.',
        });
      }
    };

    handleLogoutAsImpersonator();
  }, [state]);

  const { toast } = useToast();
  const navigate = useNavigate();

  if (isLoading) {
    return <p>Loading...</p>;
  }

  const { impersonating_email } = user
  const filteredUsers = users.filter((item: User) => item.email !== user?.email);

  const handleCheckboxChange = async (selectedUser: User) => {

    try {
      const data = await impersonateUserMutation.mutateAsync(selectedUser.email);
      const token = data?.access_token
      if (token) {
        setCookie('access_token', token, 1);
        setUser(getUserProfileFromToken(token))
        navigate({ to: '/', state: { impersonate: { action: 'login' } } });
      }
    } catch (error) {
      toast({
        title: 'Impersonating Failed',
        description: 'Unable to impersonate due to an internal error. Please try again.',
      });
    }
  };

  return (
    <div className='overflow-x-auto'>
      <table className='min-w-full table-auto'>
        <thead>
          <tr>
            <th className='px-4 py-2'>Name</th>
            <th className='px-4 py-2'>Email</th>
            <th className='px-4 py-2'>Role</th>
            <th className='px-4 py-2'>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.map((user: User) => (
            <tr key={user.email} className='border-b'>
              <td className='px-4 py-2 text-center'>{user.name}</td>
              <td className='px-4 py-2 text-center'>{user.email}</td>
              <td className='px-4 py-2 text-center'>{user.role ?? 'User'}</td>
              <td className='px-4 py-2 text-center'>
                <Button
                  color={impersonating_email === user.email ? "indigo" : "rose"}
                  onClick={() => {
                    setConfirmModalOpen(true)
                    setImpersonateUser(user)
                  }}
                  disabled={impersonating_email === user.email}
                >
                  {impersonating_email === user.email ? "Impersonating..." : "Impersonate"}
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => {
          setConfirmModalOpen(false)
          setImpersonateUser(null)
        }}
        onConfirm={() => handleCheckboxChange(impersonateUser ?? {} as User)}
        title='Impersonate User'
        description='Are you sure you want to impersonate this user?'
      />
    </div>
  );
}
