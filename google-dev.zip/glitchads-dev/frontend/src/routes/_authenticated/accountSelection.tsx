import { createFileRoute } from '@tanstack/react-router';
// import { GoogleAdsAccountSelectMain } from '@/components/glitch-ui/google-ads-account-select-main';
import { Button } from '@/components/catalyst/button';
import { useLocation, useNavigate } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { useSetAtom } from 'jotai';
import { googleAdsCustomerIdAtom } from '@/store';
import { googleAdsAccountsQueryOptions } from '@/lib/query-options';
import { useToast } from '@/components/ui/use-toast';
import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { useUserProfile } from '@/contexts/user.context';
import { useSetGoogleAdsCustomerIdMutationOptions } from '@/lib/query-options';
import { useEffect, useState } from 'react';

export const Route = createFileRoute('/_authenticated/accountSelection')({
  component: () => <AccountSelection />,
});

export function AccountSelection() {
  const currentLocation = useLocation();
  const { toast } = useToast();
  const navigate = useNavigate({ from: '/' });
  const { isLoading, data: accounts = [] } = useSuspenseQuery(googleAdsAccountsQueryOptions());
  const { user } = useUserProfile();
  useLoadingOverlay(isLoading);

  const googleAdsCustomerMutation = useSetGoogleAdsCustomerIdMutationOptions();
  const setGoogleAdsCustomerId = useSetAtom(googleAdsCustomerIdAtom);
  const setSelectedAccount = useState<number | null>(null)[1];
  const linkedAccounts = accounts.filter((account) => account.linked === 'LINKED');
  useEffect(() => {
    if (accounts.length > 0) {
      let selected = accounts.filter((account) => account.selected);
      if (selected.length > 0) {
        setSelectedAccount(selected[0].googleads_account_id);
        setGoogleAdsCustomerId(selected[0].googleads_account_id);
      }
    } else {
      if (user && user.email) {
        toast({
          title: 'No Google Ads Account',
          description: `${user.email} does not have a Google Ads account associated with it.`,
        });
      } else {
        toast({
          title: 'No Google Ads Account',
          description: 'Your account does not have a Google Ads account associated with it.',
        });
      }
    }
  }, [accounts, user, toast]);

  useEffect(() => {
    if (accounts.length > 0) {
      let selected = accounts.filter((account) => account.selected);
      if (selected.length === 0) {
        navigate({ to: '/' });
      } else {
        setSelectedAccount(selected[0].googleads_account_id);
        setGoogleAdsCustomerId(selected[0].googleads_account_id);
        navigate({ to: '/campaigns' });
      }
    } else {
      toast({
        title: 'No accounts',
        description: (
          <>
            Sign Up at{' '}
            <a href='https://ads.google.com' target='_blank' rel='noopener noreferrer' style={{ color: '#0000EE' }}>
              Google
            </a>{' '}
            or Email: team@glitchads.ai
          </>
        ),
      });
    }
  }, [accounts]);

  const handleClick = async () => {
    if (linkedAccounts.length === 0) {
      return;
    }
    let value = linkedAccounts[0].googleads_account_id;
    setSelectedAccount(value);
    setGoogleAdsCustomerId(value);
    let res = await googleAdsCustomerMutation.mutateAsync({ adsCustomerId: value });
    if (res) {
      if (currentLocation.pathname === '/') {
        location.reload();
      } else {
        navigate({ to: '/' });
      }
    }
  };

  if (!accounts) {
    return null;
  }
  return (
    <div className='container bg-white p-12 rounded-md'>
      {/* <div className='w-full px-12'>
        <p className='mb-4 text-sm leading-6 text-gray-500 pl-1'>
          Link the Google Accounts you want to connect to Glitch{' '}
        </p>
      </div> */}
      {/* <div className='w-full px-12'>
        <GoogleAdsAccountSelectMain />
      </div> */}
      <div className='w-full px-12'>
        {accounts.length > 0 && (
          <Button
            className='mt-4'
            color='indigo'
            onClick={() => {
              handleClick();
            }}
          >
            Continue
          </Button>
        )}
      </div>
    </div>
  );
}
