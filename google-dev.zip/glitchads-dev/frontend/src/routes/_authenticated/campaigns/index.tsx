import { Button } from '@/components/catalyst/button';
import {
  ChartContextProvider,
  ChartDateRange,
  ChartForecastToggle,
  ChartMetrics,
  DateRange,
  FORECAST_DAYS,
  LineChart,
} from '@/components/Charts';

import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { campaignData } from '@/lib/dummydata';
import { campaignsQueryOptions } from '@/lib/query-options';
import { useSuspenseQuery } from '@tanstack/react-query';
import { createFileRoute } from '@tanstack/react-router';
import { addDays, startOfDay } from 'date-fns';
import { CampaignCard } from '@/components/glitch-ui/campaign-card';
import { useUserProfile } from '@/contexts/user.context';
import { isAdmin } from '@/lib/utils';

const RENDER_CHART = false;
export const Route = createFileRoute('/_authenticated/campaigns/')({
  component: Campaigns,
});

export function Campaigns() {
  const { isLoading, data: campaigns = [] } = useSuspenseQuery(campaignsQueryOptions());
  const { user } = useUserProfile();

  useLoadingOverlay(isLoading);

  return (
    <div className='container bg-white p-12 rounded-md'>
      <div className='px-4 sm:px-6 lg:px-8'>
        <div className='sm:flex sm:items-center'>
          <div className='sm:flex-auto'>
            <h1 className='text-base font-semibold leading-6 text-gray-900'>Campaigns</h1>
          </div>
          <div className='mt-4 sm:ml-16 sm:mt-0 sm:flex-none'>
            <Button color='indigo' to={`/campaigns/new/landing`}>
              New Campaign
            </Button>
          </div>

          {user?.role && isAdmin(user?.role) && (
            <div className='mt-4 sm:ml-16 sm:mt-0 sm:flex-none'>
              <Button color='indigo' to={`/campaigns/google`}>
                Import Campaign from Google
              </Button>
            </div>
          )}
        </div>
        {RENDER_CHART && <CampaignChart />}
        <div className='mt-8 flow-root'>
          <div className='-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8'>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4 sm:px-6 lg:px-8'>
              {campaigns.map((campaign) => (
                <CampaignCard key={campaign.id} campaign={campaign} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CampaignChart({ forecastEnabled, forecastOnly }: { forecastEnabled?: boolean; forecastOnly?: boolean }) {
  const initialDateRange = forecastOnly
    ? ({
      start: startOfDay(new Date()).getTime(),
      end: startOfDay(addDays(new Date(), FORECAST_DAYS)).getTime(),
    } as DateRange)
    : undefined;
  return (
    <ChartContextProvider
      forecastEnabled={forecastEnabled || forecastOnly}
      dateRange={initialDateRange}
      campaignIds={[campaignData.id.toString()]}
    >
      <div className='flex flex-col w-full gap-4 my-8'>
        <h3 className='text-base font-semibold leading-6 text-gray-900'>
          {forecastOnly ? 'Forecasted ' : ''}Overall Performance
        </h3>
        <div className='flex items-center w-full justify-between'>
          <ChartMetrics variant='subtle' size='md' />
          <div className='flex flex-col items-end gap-5 -mb-3 -mt-4'>
            <ChartDateRange labelPosition='left' />
            {!forecastOnly && <ChartForecastToggle />}
          </div>
        </div>
        <LineChart />
      </div>
    </ChartContextProvider>
  );
}
