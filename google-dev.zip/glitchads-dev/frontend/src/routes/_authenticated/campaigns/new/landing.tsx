import { useEffect, useState } from 'react';
import { usePostHog } from 'posthog-js/react';
import { useForm } from '@tanstack/react-form';
import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useQuery } from '@tanstack/react-query';
import { zodValidator } from '@tanstack/zod-form-adapter';
import clsx from 'clsx';
import { nanoid } from 'nanoid';
import { z } from 'zod';

import { Button } from '@/components/catalyst/button';
import { FieldGroup, Fieldset } from '@/components/catalyst/fieldset';
import { LocationTargetingSelectField } from '@/form-fields/setup/location-targeting';
import { useCreateCampaignMutation, campaignDescriptionQueryOptions } from '@/lib/query-options';

import { BreadCrumb, BusinessInfoField, WebsiteUrlField, GoalType, goals } from '@/components/campaign/New';
import { CampaignGoal } from '@/components/glitch-ui/campaign-goal';
import { Processing } from '@/components/glitch-ui/processing';
import { TextSpinner } from '@/components/ui/text-spinner';
import { debounce, isValidUrl } from '@/lib/utils';

export const Route = createFileRoute('/_authenticated/campaigns/new/landing')({
  component: Landing,
});

function Landing() {
  const posthog = usePostHog();
  const navigate = useNavigate({ from: '/campaigns/new/landing' });

  const [selected, setSelected] = useState<GoalType>(goals[0]);

  const [debouncedWebsiteUrl, setDebouncedWebsiteUrl] = useState('');
  const [campaignGoalText, setCampaignGoalText] = useState('');
  const createCampaignMutation = useCreateCampaignMutation();

  const form = useForm({
    defaultValues: {
      websiteUrl: '',
      description: '',
      goal: '',
      targetingLocations: [],
    },

    onSubmit: async ({ value }) => {
      let newCampaign = await createCampaignMutation.mutateAsync({
        slug: nanoid(10),
        website_url: value.websiteUrl,
        business_desc: value.description,
        goal: selected.value,
        target_locations: value.targetingLocations,
        campaign_goal_text: selected.value === 'specific' ? campaignGoalText : undefined,
      });

      if (newCampaign.slug) {
        posthog?.capture('campaign_created', { campaignSlug: newCampaign.slug, campaignGoalText: campaignGoalText });
        navigate({
          to: '/campaigns/$campaignslug/ads',
          params: { campaignslug: newCampaign.slug },
        });
      }
    },
    validatorAdapter: zodValidator(),
  });

  // Debounced handler for the website URL
  const debouncedHandleChange = debounce((value) => {
    setDebouncedWebsiteUrl(value);
  }, 1000); // Debounce for 1000ms

  const { setFieldValue } = form;
  const {
    isLoading: loading,
    data: campaignDescription,
    error: campaignDescriptionError,
  } = useQuery(campaignDescriptionQueryOptions(debouncedWebsiteUrl, isValidUrl(debouncedWebsiteUrl)));

  const handleFieldChange = <T,>(fieldName: string, value: T) => {
    posthog?.capture('field_changed', { fieldName, value });
    if (fieldName === 'websiteUrl') {
      debouncedHandleChange(value);
    }
  };

  useEffect(() => {
    setFieldValue('description', campaignDescription?.description ?? '');
  }, [campaignDescription?.description]);

  const [validationError, setValidationError] = useState<string>();

  useEffect(() => {
    setValidationError(undefined);
    if (campaignDescriptionError) {
      setValidationError(campaignDescriptionError.message || 'Unknown error');
    }
  }, [campaignDescriptionError]);

  return (
    <div className='bg-white py-12 rounded-lg'>
      <BreadCrumb />
      <div className='flex justify-center'>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            e.stopPropagation();
            form.handleSubmit();
          }}
        >
          <Fieldset>
            <FieldGroup>
              <form.Field
                validators={{
                  onChange: ({ value }) => {
                    if (typeof value !== 'string' || !isValidUrl(`https://${value}`)) {
                      setValidationError(undefined);
                      return 'Invalid URL';
                    }
                  },
                }}
                name='websiteUrl'
              >
                {(field) => (
                  <div className='flex justify-center'>
                    <WebsiteUrlField
                      field={field}
                      error={validationError}
                      disabled={loading}
                      onChange={(value) => handleFieldChange('websiteUrl', value)}
                    />
                  </div>
                )}
              </form.Field>

              <form.Field
                validators={{
                  onChange: z.string(),
                }}
                name='description'
              >
                {(field) =>
                  campaignDescription ? (
                    <BusinessInfoField field={field} />
                  ) : loading ? (
                    <TextSpinner message='Generating business description...' />
                  ) : (
                    <></>
                  )
                }
              </form.Field>
              <CampaignGoal
                selected={selected}
                setSelected={(goal) => {
                  setSelected(goal);
                  posthog?.capture('goal_selected', { goal });
                }}
                onCampaignGoalTextChange={setCampaignGoalText}
              />
              <div className='mb-4'>
                <label className='text-xl'>What Locations are you looking to target?</label>
              </div>
              <form.Field
                validators={{
                  onChange: z
                    .array(
                      z.object({
                        canonical_name: z.string(),
                        country_code: z.string().optional(),
                        criteria_id: z.number(),
                        name: z.string(),
                        status: z.string(),
                        target_type: z.string(),
                      }),
                    )
                    .nonempty('Location Targeting is required'),
                }}
                name='targetingLocations'
              >
                {(field) => (
                  <LocationTargetingSelectField
                    field={field}
                    onFieldChange={(value) => handleFieldChange('targetingLocations', value)}
                  />
                )}
              </form.Field>
            </FieldGroup>
          </Fieldset>

          <div className='mt-16'>
            <p className='text-sm leading-6 text-gray-500'>
              Glitch AI will generate Ads for you based on your campaign information.
            </p>
            <p className='mb-4 text-sm leading-6 text-gray-500'>
              Don't worry, you will get to review them before we send them to Google.
            </p>
            <div className='flex flex-row justify-between mt-6'>
              <form.Subscribe
                selector={(state) => [state.canSubmit, state.isSubmitting]}
                children={([canSubmit, isSubmitting]) => (
                  <Button
                    color='indigo'
                    className={clsx('sm:text-base', isSubmitting ? 'cursor-progress' : 'cursor-pointer')}
                    type='submit'
                    disabled={!canSubmit}
                    onClick={() => posthog?.capture('create_campaign_clicked')}
                  >
                    {isSubmitting ? <Processing /> : 'Create Campaign'}
                  </Button>
                )}
              />
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
