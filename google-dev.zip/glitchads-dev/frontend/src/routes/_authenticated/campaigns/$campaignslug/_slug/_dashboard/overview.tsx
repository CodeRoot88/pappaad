import CampaignRecommendations from '@/components/campaign/Recommendation';
import { campaignDataAtom } from '@/store';
import { createFileRoute } from '@tanstack/react-router';
import { useAtomValue } from 'jotai';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard/overview')({
  component: CampaignOverview,
});

function CampaignOverview() {
  const campaign = useAtomValue(campaignDataAtom);
  return campaign ? <CampaignRecommendations campaign={campaign} /> : null;
}
