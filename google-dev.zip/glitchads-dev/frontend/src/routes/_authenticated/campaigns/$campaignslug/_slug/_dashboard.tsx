import { Outlet, createFileRoute } from '@tanstack/react-router';
import { CampaignErrors } from '@/components/glitch-ui/campaign-errors';
import { Header, Tabs } from '@/components/campaign/Layout';
import { useAtomValue } from 'jotai';
import { campaignDataAtom, campaignTaskTrackingAtom, fetchCampaignAtom } from '@/store';
import { useUserProfile } from '@/contexts/user.context';
import { UserRole } from '@/lib/types';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard')({
  component: CampaignDashboardLayout,
});

function CampaignDashboardLayout() {
  const campaign = useAtomValue(campaignDataAtom);
  const fetchCampaign = useAtomValue(fetchCampaignAtom);
  const campaignTaskTracking = useAtomValue(campaignTaskTrackingAtom);
  const { user } = useUserProfile();
  if (!campaign) return null;
  const adsState = campaignTaskTracking?.ad_generation.in_progress
    ? 'draft'
    : campaign.ads.every((ad) => ad.state === 'approved')
      ? 'approved'
      : 'draft';

  const tabs = [
    {
      name: 'Ads',
      href: `/campaigns/${campaign.slug}/ads`,
      state: adsState,
    },
    { name: 'Settings', href: `/campaigns/${campaign.slug}/settings`, state: campaign.settings_state },
    { name: 'Assets', href: `/campaigns/${campaign.slug}/assets`, state: campaign.assets_state },
    ...(adsState === 'approved' && campaign.settings_state === 'approved' && campaign.assets_state === 'approved'
      ? [{ name: 'Budget', href: `/campaigns/${campaign.slug}/budget`, state: campaign.budget_state }]
      : []),
  ];

  if (user.role === UserRole.ADMIN) {
    tabs.push({ name: 'Action Logs', href: `/campaigns/${campaign.slug}/action-logs`, state: '' });
  }
  return (
    <div className='container bg-white p-12 rounded-md'>
      {campaign && (
        <>
          <Header campaign={campaign} refetchCampaign={fetchCampaign} />
          <Tabs tabs={tabs} />
          {campaign.errors.length > 0 && <CampaignErrors campaign={campaign} refetchCampaign={fetchCampaign} />}
          <Outlet />
        </>
      )}
    </div>
  );
}
