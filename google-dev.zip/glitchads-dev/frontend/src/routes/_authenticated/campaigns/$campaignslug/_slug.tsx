import { useSetAtom } from 'jotai';
import { useQuery, useSuspenseQuery } from '@tanstack/react-query';
import { Outlet, createFileRoute } from '@tanstack/react-router';
import { campaignQueryOptions, campaignTaskTrackingQueryOptions } from '@/lib/query-options';
import {
  campaignDataAtom,
  campaignTaskTrackingAtom,
  fetchCampaignAtom,
  isLoadingCampaignAtom,
  fetchCampaignTaskTrackingAtom,
} from '@/store';
import { useToast } from '@/components/ui/use-toast';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug')({
  component: CampaignLayout,
});

function CampaignLayout() {
  const setCampaignData = useSetAtom(campaignDataAtom);
  const setFetchCampaign = useSetAtom(fetchCampaignAtom);
  const setLoadingCampaign = useSetAtom(isLoadingCampaignAtom);
  const setCampaignTaskTracking = useSetAtom(campaignTaskTrackingAtom);
  const setFetchCampaignTaskTracking = useSetAtom(fetchCampaignTaskTrackingAtom);

  const { toast } = useToast();
  const { campaignslug } = Route.useParams();
  const { isLoading, data: campaign, refetch } = useSuspenseQuery(campaignQueryOptions(campaignslug));
  const { data: campaignTaskTracking, refetch: refetchTracking } = useQuery(
    campaignTaskTrackingQueryOptions(campaign.id),
  );

  const handleRefetch = async () => {
    try {
      const { data } = await refetch();
      setCampaignData(data || null);
    } catch (error) {
      console.error(error);
      toast({ description: 'Failed to fetch campaign', variant: 'destructive' });
    }
  };
  const handleRefetchTracking = async () => {
    try {
      const { data } = await refetchTracking();
      setCampaignTaskTracking(data);
    } catch (error) {
      console.error(error);
    }
  };

  setCampaignData(campaign);
  setFetchCampaign(() => handleRefetch);
  setLoadingCampaign(isLoading);
  setCampaignTaskTracking(campaignTaskTracking);
  setFetchCampaignTaskTracking(() => handleRefetchTracking);

  return <Outlet />;
}
