import { useToast } from '@/components/ui/use-toast';
import { useState } from 'react';
import { createFileRoute } from '@tanstack/react-router';
import { campaignActionLogsQueryOptions, useCampaignZeroImpressionOptimisationMutation } from '@/lib/query-options';
import { useQuery } from '@tanstack/react-query';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard/action-logs')({
  component: ActionLogs,
});
import { format } from 'date-fns';
import { ActionLog } from '@/lib/types';

function ActionLogs() {
  const { campaignslug } = Route.useParams();
  const { data } = useQuery(campaignActionLogsQueryOptions(campaignslug));

  const zeroImpressionOptimisationMutation = useCampaignZeroImpressionOptimisationMutation(campaignslug);
  const { toast } = useToast();
  const triggerZeoImpressionKeywordsOptimisation = async () => {
    try {
      await zeroImpressionOptimisationMutation.mutateAsync();
      toast({
        description: '🙌 Zeo impression keywords optimisation has run succesfully',
      });
    } catch (error) {
      toast({ description: `${error}`, variant: 'destructive' });
    }
  };
  return (
    <>
      <div className='my-4'>
        <Button
          className='cursor-pointer'
          onClick={triggerZeoImpressionKeywordsOptimisation}
          disabled={zeroImpressionOptimisationMutation.isPending}
        >
          Trigger zeo impression keywords optimisation
        </Button>
      </div>
      <KeywordReplacementLog data={data} />
    </>
  );
}
interface KeywordReplacementLogProps {
  data?: ActionLog[];
}
function KeywordReplacementLog({ data }: KeywordReplacementLogProps) {
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set());

  const toggleRowExpansion = (id: number) => {
    setExpandedRows((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'MMM d, yyyy HH:mm:ss');
  };

  const truncateLog = (log: string, maxLength: number = 100) => {
    return log.length > maxLength ? `${log.substring(0, maxLength)}...` : log;
  };

  if (!data || data.length === 0) {
    return (
      <div className='container mx-auto py-10'>
        <h1 className='text-2xl font-bold mb-4'>Keyword Replacement Log</h1>
        <p>No data available.</p>
      </div>
    );
  }

  return (
    <div className='container mx-auto py-10'>
      <h1 className='text-2xl font-bold mb-4'>Keyword Replacement Log</h1>
      <div className='rounded-md border'>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className='w-[100px]'>ID</TableHead>
              <TableHead>Campaign ID</TableHead>
              <TableHead>Created At</TableHead>
              <TableHead className='max-w-[500px]'>Log</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((entry) => (
              <TableRow key={entry.id}>
                <TableCell className='font-medium'>{entry.id}</TableCell>
                <TableCell>{entry.campaign_id}</TableCell>
                <TableCell>{formatDate(entry.created_at)}</TableCell>
                <TableCell>
                  {expandedRows.has(entry.id) ? (
                    <>
                      <p>{entry.log}</p>
                      <Button variant='link' onClick={() => toggleRowExpansion(entry.id)} className='mt-2'>
                        Show Less
                      </Button>
                    </>
                  ) : (
                    <>
                      <p>{truncateLog(entry.log)}</p>
                      {entry.log.length > 100 && (
                        <Button variant='link' onClick={() => toggleRowExpansion(entry.id)} className='mt-2'>
                          Show More
                        </Button>
                      )}
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
