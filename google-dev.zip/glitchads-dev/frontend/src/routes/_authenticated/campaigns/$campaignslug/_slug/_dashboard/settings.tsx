import { CampaignSettings } from '@/components/campaign/Settings';
import { campaignDataAtom, fetchCampaignAtom } from '@/store';
import { createFileRoute } from '@tanstack/react-router';
import { useAtomValue } from 'jotai';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard/settings')({
  component: Settings,
});

function Settings() {
  const campaign = useAtomValue(campaignDataAtom);
  const fetchCampaign = useAtomValue(fetchCampaignAtom);
  return campaign ? <CampaignSettings campaign={campaign} refetchCampaign={fetchCampaign!} /> : null;
}
