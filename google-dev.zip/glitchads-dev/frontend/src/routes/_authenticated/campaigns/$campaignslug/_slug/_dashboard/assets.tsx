import { CampaignAssets } from '@/components/campaign/Assets';
import { campaignDataAtom, fetchCampaignAtom } from '@/store';
import { createFileRoute } from '@tanstack/react-router'
import { useAtomValue } from 'jotai';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard/assets')({
  component: Assets
})

function Assets() {
  const campaign = useAtomValue(campaignDataAtom);
  const fetchCampaign = useAtomValue(fetchCampaignAtom);
  return campaign ? <CampaignAssets campaign={campaign} refetchCampaign={fetchCampaign!} /> : null;
}