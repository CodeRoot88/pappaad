import { CampaignBudget } from '@/components/campaign/Budget';
import { campaignDataAtom, fetchCampaignAtom } from '@/store';
import { createFileRoute } from '@tanstack/react-router';
import { useAtomValue } from 'jotai';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard/budget')({
  component: Budget,
});

function Budget() {
  const campaign = useAtomValue(campaignDataAtom);
  const fetchCampaign = useAtomValue(fetchCampaignAtom);

  return campaign ? <CampaignBudget campaign={campaign} refetchCampaign={fetchCampaign!} /> : null;
}
