import { Ads, AdsSkeleton } from '@/components/glitch-ui/ads';
import { createFileRoute } from '@tanstack/react-router';
import { useAtomValue } from 'jotai';
import { campaignDataAtom, campaignTaskTrackingAtom, fetchCampaignAtom } from '@/store';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/_dashboard/ads')({
  component: AdsScreen,
});

function AdsScreen() {
  const { campaignslug } = Route.useParams();
  const campaign = useAtomValue(campaignDataAtom);
  const fetchCampaign = useAtomValue(fetchCampaignAtom);
  if (!campaign) return null;
  const campaignTaskTracking = useAtomValue(campaignTaskTrackingAtom);

  return (
    <div className='container bg-white pr-12 pl-12 rounded-md'>
      {campaign ? (
        <Ads
          ads={campaign.ads}
          campaignId={campaign.id}
          campaignslug={campaignslug}
          campaignUrl={campaign.website_url}
          onAdCreated={fetchCampaign!}
          campaignTaskTracking={campaignTaskTracking}
        />
      ) : (
        <AdsSkeleton />
      )}
    </div>
  );
}
