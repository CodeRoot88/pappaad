import { useEffect, useState, useMemo } from 'react';
import { usePostHog } from 'posthog-js/react';
import { useNavigate, useBlocker, Link } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { createFileRoute } from '@tanstack/react-router';

import { useToast } from '@/components/ui/use-toast';
import { useUpdateAdMutationOptions, useAdStateMutationOptions, useAdDeleteMutationOptions } from '@/lib/query-options';
import { Ad, Headline, Description, Keyword, AlternativeKeyword } from '@/lib/types';
import {
  Header,
  HeadlinesSection,
  DescriptionsSection,
  KeywordsSection,
  AdPreviewOnPhone,
} from '@/components/campaign/AdManager';
import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { ChevronLeftIcon } from '@heroicons/react/24/outline';
import { useAtomValue } from 'jotai';
import { campaignDataAtom, fetchCampaignAtom, isLoadingCampaignAtom } from '@/store';
import { useIsChanged } from '@/hooks/useIsChanged';
import ConfirmationModal from '@/components/catalyst/confirmation-modal';
import { VOID } from '@/lib/utils';

export const Route = createFileRoute('/_authenticated/campaigns/$campaignslug/_slug/ads/$adslug/')({
  component: () => <AdManager />,
});

function Breadcrumb({ campaignslug, adslug }: { campaignslug: string; adslug: string }) {
  return (
    <nav className='flex items-center text-sm font-medium mb-4' aria-label='Breadcrumb'>
      <Link to={`/campaigns/${campaignslug}/`} className='text-gray-500 hover:text-gray-700'>
        Campaign
      </Link>
      <ChevronLeftIcon className='h-4 w-4 mx-2 text-gray-400' aria-hidden='true' />
      <Link to={`/campaigns/${campaignslug}/ads/`} className='text-gray-500 hover:text-gray-700'>
        Ads
      </Link>
      <ChevronLeftIcon className='h-4 w-4 mx-2 text-gray-400' aria-hidden='true' />
      <span className='text-gray-900' aria-current='page'>
        {adslug}
      </span>
    </nav>
  );
}

function AdManager() {
  const posthog = usePostHog();
  const { adslug, campaignslug } = Route.useParams();
  const campaignData = useAtomValue(campaignDataAtom);
  const isLoading = useAtomValue(isLoadingCampaignAtom);
  const refetchCampaign = useAtomValue(fetchCampaignAtom);

  useLoadingOverlay(isLoading);
  const { toast } = useToast();

  const updateAdMutation = useUpdateAdMutationOptions();
  const adData = useMemo(() => campaignData?.ads.find((ad) => ad.slug === adslug), [campaignData, adslug]);

  const [headlines, setHeadlines] = useState<Headline[]>([]);
  const [descriptions, setDescriptions] = useState<Description[]>([]);
  const [keywords, setKeywords] = useState<Keyword[]>([]);
  const [alternativeKeywords, setAlternativeKeywords] = useState<AlternativeKeyword[]>([]);
  const [customKeyword, setCustomKeyword] = useState('');

  if (!adData) return <div>No Ads</div>;
  useEffect(() => {
    if (adData) {
      setHeadlines(adData.headlines);
      setDescriptions(adData.descriptions);
      setKeywords(adData.keywords);
      setAlternativeKeywords(adData.alternative_keywords);
    }
  }, [adData]);

  const isHeadlineChanged = useIsChanged(headlines, adData.headlines);
  const isDescriptionChanged = useIsChanged(descriptions, adData.descriptions);
  const isKeywordsChanged = useIsChanged(keywords, adData.keywords);

  const isAdDirty = isHeadlineChanged || isDescriptionChanged || isKeywordsChanged;

  const { proceed, reset, status } = useBlocker({
    condition: isAdDirty,
  });

  const handleSaveSettings = async (): Promise<boolean> => {
    if (!campaignData || !adslug || !adData) return false;

    const updatedAd: Ad = { ...adData, headlines, descriptions, keywords };

    try {
      await updateAdMutation.mutateAsync({ campaignId: campaignData.id, ad: updatedAd });
      if (refetchCampaign) await refetchCampaign();
      toast({ description: '🎉 Ad updated successfully' });
      posthog?.capture('ad_updated', { adslug });
      return true;
    } catch (error) {
      console.error('Failed to update ad:', error);
      toast({ description: 'Failed to update ad', variant: 'destructive' });
      posthog?.capture('ad_update_failed', { adslug, error });
      return false;
    }
  };

  const adStateMutation = useAdStateMutationOptions(campaignData?.id ?? -1, adData.id, 'approved');
  const adDeleteMutation = useAdDeleteMutationOptions(campaignData?.id ?? -1, adData.id);

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const handleApproveSettings = async () => {
    try {
      const res = await adStateMutation.mutateAsync();
      if (res) {
        queryClient.invalidateQueries({ queryKey: ['campaign', campaignData?.slug || ''] });
        if (refetchCampaign) await refetchCampaign();
        navigate({ to: `/campaigns/$campaignslug/ads`, params: { campaignslug: campaignData?.slug || '' } });
        posthog?.capture('ad_marked_as_reviewed', { adId: adData.id });
      }
    } catch (error) {
      console.error('Failed to approve ad:', error);
      toast({ description: 'Failed to approve ad', variant: 'destructive' });
      posthog?.capture('ad_approve_failed', { adslug, error });
    }
  };

  const handleDeleteAd = async () => {
    try {
      await adDeleteMutation.mutateAsync();

      queryClient.invalidateQueries({ queryKey: ['campaign', campaignData?.slug || ''] });
      if (refetchCampaign) await refetchCampaign();
      navigate({ to: `/campaigns/$campaignslug/ads`, params: { campaignslug: campaignData?.slug || '' } });
      posthog?.capture('ad_deleted', { adId: adData.id });
    } catch (error) {
      console.error('Failed to delete ad:', error);
      toast({ description: 'Failed to delete ad', variant: 'destructive' });
      posthog?.capture('ad_delete_failed', { adslug, error });
    }
  };
  return (
    <div className='container bg-white p-12 rounded-md'>
      <ConfirmationModal
        isOpen={status === 'blocked'}
        onClose={reset ?? VOID}
        onConfirm={proceed ?? VOID}
        title='Unsaved changes'
        description='You have unsaved changes on this ad, are you sure you want to leave?'
        confirmText='Leave page'
      />
      <Breadcrumb campaignslug={campaignslug} adslug={adslug} />
      <Header
        isAdDirty={isAdDirty}
        url={adData.url}
        state={adData.state}
        isSavePending={updateAdMutation.isPending}
        handleSaveSettings={handleSaveSettings}
        handleApproveSettings={handleApproveSettings}
        handleDeleteAd={handleDeleteAd}
      />
      {campaignData && (
        <div className='flex flex-row'>
          <div className='flex-1'>
            <KeywordsSection
              keywords={keywords}
              setKeywords={setKeywords}
              alternativeKeywords={alternativeKeywords}
              setAlternativeKeywords={setAlternativeKeywords}
              customKeyword={customKeyword}
              setCustomKeyword={setCustomKeyword}
              adslug={adslug}
            />
            <HeadlinesSection
              headlines={headlines}
              setHeadlines={setHeadlines}
              adslug={adslug}
              campaignId={campaignData.id}
              adId={adData.id}
            />
            <DescriptionsSection
              descriptions={descriptions}
              setDescriptions={setDescriptions}
              adslug={adslug}
              campaignId={campaignData.id}
              adId={adData.id}
            />
          </div>
          <div className='flex-1'>
            <AdPreviewOnPhone adData={adData} />
          </div>
        </div>
      )}
    </div>
  );
}

export default AdManager;
