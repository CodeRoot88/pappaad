import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { googleCampaignsQueryOptions, useImportGoogleAdsCampaignMutation } from '@/lib/query-options';
import { GoogleCampaign } from '@/lib/types';
import { useQuery } from '@tanstack/react-query';
import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { Button } from '@/components/catalyst/button';
import ConfirmationModal from '@/components/catalyst/confirmation-modal';
import { useState } from 'react';
import { useToast } from '@/components/ui/use-toast';

export const Route = createFileRoute('/_authenticated/campaigns/google/')({
  component: GoogleCampaigns,
});

export function GoogleCampaigns() {
  const { isLoading, data: googleCampaigns = [] } = useQuery(googleCampaignsQueryOptions());
  const importGoogleAdsCampaignMutation = useImportGoogleAdsCampaignMutation();

  const { toast } = useToast();

  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [selectedGoogleCampaign, setSelectedGoogleCampaign] = useState<GoogleCampaign>();
  useLoadingOverlay(isLoading || importGoogleAdsCampaignMutation.isPending);

  const navigate = useNavigate();

  const importCampaignFromGoogle = async (campaign?: GoogleCampaign) => {
    if (!campaign) return;
    try {
      const res = await importGoogleAdsCampaignMutation.mutateAsync({ gaCampaignId: campaign.id });
      navigate({ to: `/campaigns/${res.slug}/ads` });
    } catch (error) {
      const err = error as unknown as Error;
      toast({ description: err?.message ?? 'Failed to import google campaign', variant: 'destructive' });
      setConfirmModalOpen(false);
    }
  };
  return (
    <div className='overflow-x-auto'>
      <table className='min-w-full table-auto'>
        <thead>
          <tr>
            <th className='px-4 py-2'>Id</th>
            <th className='px-4 py-2'>Slug</th>
            <th className='px-4 py-2'>Action</th>
          </tr>
        </thead>
        <tbody>
          {googleCampaigns.map((campaign: GoogleCampaign) => (
            <tr key={campaign.id} className='border-b'>
              <td className='px-4 py-2 text-center'>{campaign.id}</td>
              <td className='px-4 py-2 text-center'>{campaign.name}</td>
              <td className='px-4 py-2 text-center'>
                <Button
                  color='indigo'
                  onClick={() => {
                    setConfirmModalOpen(true);
                    setSelectedGoogleCampaign(campaign);
                  }}
                  disabled={isLoading}
                >
                  Import
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => {
          setConfirmModalOpen(false);
        }}
        onConfirm={() => importCampaignFromGoogle(selectedGoogleCampaign)}
        title='Import Campaign From Google'
        description='Are you sure you want to import campaign from google'
      />
    </div>
  );
}
