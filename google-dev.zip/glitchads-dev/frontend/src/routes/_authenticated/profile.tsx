import { useEffect } from 'react';
import { usePostHog } from 'posthog-js/react';
import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useUserProfile } from '@/contexts/user.context';

export const Route = createFileRoute('/_authenticated/profile')({
  component: () => <Profile />,
});

function Profile() {
  const posthog = usePostHog();
  const { user: { email, picture, name, impersonating_email } } = useUserProfile();

  console.log("impersonating_email+++", impersonating_email)
  const navigate = useNavigate({ from: '/' });
  if (!email) {
    navigate({ to: '/login' });
  }

  useEffect(() => {
    posthog?.capture('view_profile', { email, name });
  }, [email, name]);

  const handleUpdateClick = (field: string) => {
    posthog?.capture('update_profile_click', { email, field });
  };

  return (
    <main className='px-4 py-16 sm:px-6 lg:flex-auto lg:px-0 lg:py-20'>
      <img src={picture} alt='profile picture' className='h-24 w-24 flex-none rounded-lg bg-gray-800 object-cover' />
      <div className='mx-auto max-w-2xl space-y-16 sm:space-y-20 lg:mx-0 lg:max-w-none mt-6'>
        <div>
          <h2 className='text-base font-semibold leading-7 text-gray-900'>Profile</h2>
          <p className='mt-1 text-sm leading-6 text-gray-500'>
            This information will be displayed publicly so be careful what you share.
          </p>

          <dl className='mt-6 space-y-6 divide-y divide-gray-100 border-t border-gray-200 text-sm leading-6'>
            <div className='pt-6 sm:flex'>
              <dt className='font-medium text-gray-900 sm:w-64 sm:flex-none sm:pr-6'>Full name</dt>
              <dd className='mt-1 flex justify-between gap-x-6 sm:mt-0 sm:flex-auto'>
                <div className='text-gray-900'>{name}</div>
                <button
                  type='button'
                  className='font-semibold text-indigo-600 hover:text-indigo-500'
                  onClick={() => handleUpdateClick('name')}
                >
                  Update
                </button>
              </dd>
            </div>
            <div className='pt-6 sm:flex'>
              <dt className='font-medium text-gray-900 sm:w-64 sm:flex-none sm:pr-6'>Email address</dt>
              <dd className='mt-1 flex justify-between gap-x-6 sm:mt-0 sm:flex-auto'>
                <div className='text-gray-900'>{email}</div>
                <button
                  type='button'
                  className='font-semibold text-indigo-600 hover:text-indigo-500'
                  onClick={() => handleUpdateClick('email')}
                >
                  Update
                </button>
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </main>
  );
}

export default Profile;
