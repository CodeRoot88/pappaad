import AddNewCard from '@/components/organization/NewCard';
import OrganizationCard from '@/components/organization/OrganizationCard';
import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { organizationsQueryOptions } from '@/lib/query-options';
import { useSuspenseQuery } from '@tanstack/react-query';
import { createFileRoute } from '@tanstack/react-router';

export const Route = createFileRoute('/_authenticated/organizations/')({
  component: () => <OrganizationDashboard />,
});

export function OrganizationDashboard() {
  const { isLoading, data: organizations = [] } = useSuspenseQuery(organizationsQueryOptions());
  useLoadingOverlay(isLoading);

  return (
    <div className='grid grid-cols-4 gap-4 p-4'>
      <AddNewCard />
      {organizations.map((org) => (
        <OrganizationCard key={org.id} organization={org} />
      ))}
    </div>
  );
}
