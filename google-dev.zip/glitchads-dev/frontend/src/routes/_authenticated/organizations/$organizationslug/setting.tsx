import { useSetAtom } from 'jotai'
import { useSuspenseQuery } from '@tanstack/react-query'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { organizationQueryOptions } from '@/lib/query-options'
import { fetchOrganizationDataAtom, organizationDataAtom } from '@/store'
import { useToast } from '@/components/ui/use-toast'
import Tabs from '@/components/organization/Settings/Tabs'

export const Route = createFileRoute(
  '/_authenticated/organizations/$organizationslug/setting',
)({
  component: OrganizationSetting,
})


function OrganizationSetting() {
  const setOrganizationData = useSetAtom(organizationDataAtom)
  const setFetchOrganization = useSetAtom(fetchOrganizationDataAtom)

  const { toast } = useToast()
  const navigate = useNavigate()
  const { organizationslug } = Route.useParams()

  const { data: organization, refetch } = useSuspenseQuery(
    organizationQueryOptions(organizationslug),
  )

  const handleRefetch = async () => {
    try {
      const { data } = await refetch()
      setOrganizationData(data || null)
    } catch (error) {
      console.error(error)
      toast({ description: 'Failed to fetch organization', variant: 'destructive' })
    }
  }

  setOrganizationData(organization)
  setFetchOrganization(() => handleRefetch)

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="mb-4">
        <a
          onClick={() => navigate({ to: '/organizations' })}
          className="text-sm text-indigo-500 cursor-pointer hover:underline"
        >
          &larr; Back to Home
        </a>
      </div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Organizations</h1>
      <Tabs organization={organization} />
    </div>
  )
}
