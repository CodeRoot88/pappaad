import { nanoid } from 'nanoid';
import { createFileRoute } from '@tanstack/react-router';
import { useNavigate } from '@tanstack/react-router';
import { usePostHog } from 'posthog-js/react';
import { zodValidator } from '@tanstack/zod-form-adapter';
import { useForm } from '@tanstack/react-form';

import { FieldGroup, Fieldset } from '@/components/catalyst/fieldset';
import { useToast } from '@/components/ui/use-toast';
import { useCreateOrganizationMutation } from '@/lib/query-options';
import { OrganizationNameField } from '@/form-fields/setup/organization-name';

export const Route = createFileRoute('/_authenticated/organizations/new/')({
  component: New,
});

export function New() {
  const posthog = usePostHog();
  const { toast } = useToast();
  const navigate = useNavigate({ from: '/organizations' });
  const createOrganizationMutation = useCreateOrganizationMutation();

  const form = useForm({
    defaultValues: {
      name: '',
    },

    onSubmit: async (form) => {
      if (!form.value.name.trim()) {
        toast({
          description: 'Organization Name is required.',
          variant: 'destructive',
        });
        return;
      }
      try {
        const newOrganization = await createOrganizationMutation.mutateAsync({
          slug: nanoid(10),
          name: form.value.name,
        });
        if (newOrganization.slug) {
          posthog?.capture('organization_created', {
            organizationSlug: newOrganization.slug,
            organizationName: newOrganization.name,
          });
          toast({ description: 'New Organization is successfully created.' });
          navigate({
            to: '/organizations',
            params: { organizationslug: newOrganization.slug },
          });
        }
      } catch (err) {
        toast({
          description: 'Failed to create organization. Please try again.',
          variant: 'destructive',
        });
      }
    },
    validatorAdapter: zodValidator(),
  });

  const handleFieldChange = <T,>(fieldName: string, value: T) => {
    posthog?.capture('field_changed', { fieldName, value });
  };

  return (
    <div className=''>
      <div className='max-w-lg bg-white rounded-lg shadow-lg p-6'>
        <h1 className='text-2xl font-semibold text-gray-900 mb-6'>Create Organization</h1>
        <form
          className='space-y-6'
          onSubmit={(e) => {
            e.preventDefault();
            form.handleSubmit();
          }}
        >
          <Fieldset>
            <FieldGroup>
              <div className='-space-y-px rounded-md shadow-sm'>
                <form.Field name='name'>
                  {(field) => (
                    <OrganizationNameField field={field} onFieldChange={(value) => handleFieldChange('name', value)} />
                  )}
                </form.Field>
              </div>

              <div className='flex justify-end space-x-4 mt-6'>
                <button
                  type='button'
                  onClick={() => navigate({ to: '/organizations' })}
                  className='px-4 py-2 border border-gray-400 text-gray-500 rounded-md hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'
                >
                  Cancel
                </button>
                <button
                  type='submit'
                  className='px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'
                >
                  Create Organization
                </button>
              </div>
            </FieldGroup>
          </Fieldset>
        </form>
      </div>
    </div>
  );
}
