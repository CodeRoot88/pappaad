import { createFileRoute } from '@tanstack/react-router';

import { GoogleAdsAccountSelectMain } from '@/components/glitch-ui/google-ads-account-select-main';
export const Route = createFileRoute('/_authenticated/providers')({
  component: () => <Providers />,
});

export function Providers() {
  return (
    <div className='container bg-white p-12 rounded-md'>
      <div className='w-full px-12'>
        <GoogleAdsAccountSelectMain />
      </div>
    </div>
  );
}
