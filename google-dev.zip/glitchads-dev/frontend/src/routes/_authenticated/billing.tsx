import { createFileRoute } from '@tanstack/react-router';
// import { apiEndpoint } from '@/lib/consts';
// import { loadStripe } from '@stripe/stripe-js';
// import { EmbeddedCheckoutProvider, EmbeddedCheckout } from '@stripe/react-stripe-js';
export const Route = createFileRoute('/_authenticated/billing')({
  component: () => <App />,
});

// // Make sure to call `loadStripe` outside of a component’s render to avoid
// // recreating the `Stripe` object on every render.
// const stripePromise = loadStripe('pk_test_LU84JAlPwALUKzQH3v44rahD', {});

// export async function fetchClientSecret() {
//   try {
//     const response = await fetch(`${apiEndpoint}/create-checkout-session`, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//     });
//     if (!response.ok) {
//       throw new Error('Network response was not ok');
//     }

//     return response.json();
//   } catch (error) {
//     console.error('Error fetching items:', error);
//     return [];
//   }
// }
const App = () => {
  //   const options = { fetchClientSecret }

  return (
    <>
      <div>billing</div>
      {/* <EmbeddedCheckoutProvider stripe={stripePromise} options={options}>
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider> */}
    </>
  );
};
