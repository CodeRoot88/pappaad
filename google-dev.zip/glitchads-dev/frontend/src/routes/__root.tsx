import { Outlet, createRootRouteWithContext } from '@tanstack/react-router';
import { QueryClient } from '@tanstack/react-query';
import { NotFoundPage } from '@/components/notfound/NotFoundPage';

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  component: () => (
    <>
      <Outlet />
    </>
  ),
  notFoundComponent: () => <NotFoundPage />
});
