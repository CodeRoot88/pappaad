import { useToast } from '@/components/ui/use-toast';
import useGoogleSignIn from '@/hooks/useGoogleSignIn';
import useGoogleSignUp from '@/hooks/useGoogleSignUp';
import useLoadingOverlay from '@/hooks/useLoadingOverlay';
import { verifyInviteCodeQueryOptions } from '@/lib/query-options';
import { useSuspenseQuery } from '@tanstack/react-query';
import { createFileRoute } from '@tanstack/react-router';
import { useEffect } from 'react';

export const Route = createFileRoute('/invite-signup/$code/')({
  component: RegisterInvitedUser,
});

function RegisterInvitedUser() {
  const { code: inviteCode } = Route.useParams();
  const { signupWithGoogle, isLoading: isSignUpLoading } = useGoogleSignUp({
    redirectUrl: '/',
    fallbackUrl: '/signup',
    inviteCode,
  });
  const { signInWithGoogle, isLoading: isSignInLoading } = useGoogleSignIn({
    redirectUrl: '/',
    fallbackUrl: '/redesign/signup',
    inviteCode,
  });
  const {
    data: { is_valid_refresh_token },
    isLoading,
  } = useSuspenseQuery(verifyInviteCodeQueryOptions(inviteCode));
  useLoadingOverlay(isSignUpLoading || isSignInLoading || isLoading);

  const { toast } = useToast();
  useEffect(() => {
    if (!is_valid_refresh_token) {
      toast({
        description: 'You should sign up to accept the invitation.',
      });
    }
  }, [is_valid_refresh_token]);
  return (
    <div className='flex min-h-screen'>
      <div className='flex flex-col items-center justify-center w-full sm:w-1/2 bg-white p-4 sm:p-8'>
        <h2 className='text-2xl font-semibold'>Create Account</h2>
        <p className='text-gray-600 text-center mt-4 w-96 mb-4'>
          Glitch is your AI Growth Engine. Onboard in minutes, and our AI will help you get more leads for less.
        </p>
        <button
          className='w-64 mt-4 focus:outline-none focus:ring focus:border-blue-500'
          onClick={() => {
            if (is_valid_refresh_token) signInWithGoogle();
            else signupWithGoogle();
          }}
        >
          <div className='flex items-center justify-center p-4 border border-gray-300 rounded-lg shadow-md hover:shadow-lg transition duration-200 ease-in-out'>
            <img
              src='https://img.icons8.com/?size=100&id=17949&format=png&color=000000'
              alt='Google Sign'
              className='w-8 h-8 mr-4'
            />
            <span className='text-lg font-semibold text-gray-800'>Accept via Google</span>
          </div>
        </button>
      </div>
      <div className='hidden sm:flex flex-col items-center justify-center w-1/2 bg-gray-100 p-8'>
        <img
          src='https://cdn.midjourney.com/ede65276-604e-4b57-9af5-ea762707f26d/0_3.png'
          alt='Testimonial'
          className='w-3/4 rounded-md'
        />
        <p className='text-gray-600 text-center mt-4 max-w-96'>
          Conversions appear to be up, with the cost-per-con version coming down. I feel as though I'm in safe hands.
          Very happy to recommend!
        </p>
      </div>
    </div>
  );
}
