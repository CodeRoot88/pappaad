import { Outlet, createFileRoute, redirect } from '@tanstack/react-router';
import { isAuthenticated } from '@/lib/auth';
import MainHeader from '@/components/main-header';

export const Route = createFileRoute('/_authenticated')({
  beforeLoad: async ({ location }) => {
    if (!isAuthenticated()) {
      throw redirect({
        to: '/login',
        search: {
          redirect: location.href,
        },
      });
    }
  },

  component: () => <AppShell />,
});

function AppShell() {
  return (
    <div className='min-h-full'>
      <MainHeader />
      <div className='py-10'>
        <main>
          <div className='mx-auto max-w-screen-2xl sm:px-6 lg:px-8'>
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
