export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER',
}

//member role of an organization
export enum MembershipRole {
  OWNER = 'owner',
  ADMIN = 'admin',
  MEMBER = 'member',
}

//Status of a member in an organization
export enum MembershipStatus {
  ACTIVE = 'active', //active status is for when a user has accepted an invitation to an organization
  PENDING = 'pending', //pending status is for when a user has been invited to an organization but has not accepted the invitation
  DISABLED = 'disabled', //disabled status is for when a user has been removed from an organization
}

export type OrganizationCreate = {
  slug: string;
  name: string;
};

export interface OrganizationData {
  id: number;
  slug: string;
  name: string;
}

export interface Membership {
  status: MembershipStatus; // e.g., ACTIVE, PENDING, REJECTED
  role: MembershipRole; // e.g., ADMIN, MEMBER
}

export interface OrganizationDataWithMembership extends OrganizationData {
  membership: Membership;
}

export interface UserAccountWithMembership extends User {
  membership: Membership;
}
export interface OrganizationDataWithUsersMembership extends OrganizationDataWithMembership {
  users?: UserAccountWithMembership[];
}

export type CampaignCreate = {
  slug: string;
  website_url: string;
  business_desc?: string;
  goal: string;
  target_locations: Location[];
  campaign_goal_text?: string;
  budget?: number;
};

export type Location = {
  canonical_name: string;
  country_code: string;
  criteria_id: number;
  name: string;
  parent_id: number;
  reach: number;
  status: 'Active' | 'Removal Planned';
  target_type: string;
};

export enum ACTION_STATE {
  APPROVED = 'approved',
  UPDATED = 'updated',
}

export enum APPROVAL_STATE {
  APPROVED = 'approved',
  DRAFT = 'draft',
}

export enum CAMPAIGN_STATE {
  LIVE = 'live',
  DRAFT = 'draft',
  ERROR = 'error',
  PAUSED = 'paused',
}
export type GoogleAdsAccount = {
  id: string;
  currency: string;
  googleads_account_id: string;
  manager_account_id: string | null;
  name: string;
};
export type CampaignData = {
  business_description: string;
  slug: string;
  name: string;
  state: CAMPAIGN_STATE;
  website_url: string;
  business_desc: string;
  target_cpa_explanation: string;
  id: number;
  target_locations: Location[];
  target_cpa: number;
  budget: number;
  phone_numbers: { value: string }[];
  ads: Ad[];
  site_links: SiteLink[];
  callouts: CalloutType[];
  structured_snippets: StructuredSnippetType[];
  prices: PriceType[];
  settings_state: APPROVAL_STATE;
  assets_state: APPROVAL_STATE;
  budget_state: APPROVAL_STATE;
  errors: CampaignError[];
  user_account_id: number;
  googleads_account_id: number;
  googleads_campaign: GoogleCampaignLink;
  googleads_account: GoogleAdsAccount;
};

export type GoogleCampaign = {
  id: string;
  name: string;
};
export type GoogleCampaignLink = {
  campaign_id: number;
  googleads_campaign_id: number;
};
export type CampaignError = { error_type: string; error_data?: AdBase };

export type CampaignUpdate = {
  slug: string;
  name: string;
  state: CAMPAIGN_STATE;
  website_url: string;
  business_desc: string;
  id: number;
  target_locations: Location[];
  target_cpa: number;
  target_cpa_explanation: string;
  settings_state: APPROVAL_STATE;
  assets_state: APPROVAL_STATE;
  budget_state: APPROVAL_STATE;
  phone_numbers: string[];
  budget: number;
};

export enum AD_STATE {
  APPROVED = 'approved',
  DRAFT = 'draft',
  ERROR = 'error',
}
export type AdBase = {
  url: string;
  slug: string;
  state: AD_STATE;
};

export type Ad = {
  url: string;
  slug: string;
  id: number;
  state: AD_STATE;
  headlines: Headline[];
  descriptions: Description[];
  keywords: Keyword[];
  alternative_keywords: AlternativeKeyword[];
};

export type Headline = {
  id?: number;
  text: string;
  // length: number; // Added the length property
};

export type Description = {
  id?: number;
  text: string;
  // length: number; // Added the length property
};

export type SiteLink = {
  url: string;
  id?: number;
  name: string;
  description1: string;
  description2: string;
};

export type SiteLinkCreateOrUpdate = {
  url: string;
  id?: number;
  name: string;
  description1: string;
  description2: string;
};

export type CalloutType = {
  id?: number;
  text: string;
};

export type StructuredSnippetType = {
  id?: number;
  header_type: string;
  values: { value: string }[];
};

export type PriceType = {
  id?: number;
  type: string;
  currency: string;
  qualifier: string;
  header: string;
  value: number;
  frequency: string;
  description: string;
  final_url: string;
  mobile_url?: string;
};

export type GoogleAdsAccounts = {
  user_account_id: number;
  googleads_account_id: number;
  name: string;
  selected: boolean;
  linked: string;
};

export type UserProfile = {
  email?: string;
  picture?: string;
  name?: string;
  role?: UserRole;
  impersonating_email?: string;
};

export enum RECOMMENDATION_SEVERITY {
  SUGGESTION = 'suggestion',
  URGENT = 'urgent',
  FIX = 'fix',
}

export enum RECOMMENDATION_STATE {
  PENDING = 'pending',
  INSTANT_FIX_APPLIED = 'instant fix applied',
  MARKED_RESOLVED = 'marked resolved',
  MARKED_FAILED = 'marked failed',
  MARKED_NOT_APPLICABLE = 'marked not applicable',
  FAILED = 'failed',
}

export type Keyword = {
  id?: number;
  text: string;
  is_deleted?: boolean;
};

export type AlternativeKeyword = Omit<Keyword, 'is_deleted'>;

export type AdRecommendation = {
  id: number;
  ad_id: number;
  campaign_recommendation_id: number;
  title: string;
  severity: RECOMMENDATION_SEVERITY;
  description: string;
  state: RECOMMENDATION_STATE;
  created_at: string;
  ad: Ad;
  keyword_recommendations: KeywordRecommendation[];
  recommendation_type: 'underperforming_keyword' | 'new_keyword';
};

export type KeywordRecommendation = {
  id: number;
  title: string;
  severity: RECOMMENDATION_SEVERITY;
  description: string;
  state: RECOMMENDATION_STATE;
  created_at: string;
  keyword: Keyword;
};

export type CampaignRecommendations = {
  recommendations: CampaignRecommendation[];
};

export type CampaignRecommendation = {
  id: number;
  campaign_id: number;
  title: string;
  description: string;
  severity: RECOMMENDATION_SEVERITY;
  state: RECOMMENDATION_STATE;
  created_at: string;
  ad_recommendations: AdRecommendation[];
  recommendation_type: 'underperforming_keyword' | 'new_keyword';
};

export type TaskTrackingSummary = {
  total: number;
  in_progress: number;
  completed: number;
  failed: number;
};

export type TaskTrackingResponse = {
  ad_generation: TaskTrackingSummary;
  site_link_generation: TaskTrackingSummary;
  tcpa_generation: TaskTrackingSummary;
  keywords_generation: TaskTrackingSummary;
  headline_generation: TaskTrackingSummary;
  descriptions_generation: TaskTrackingSummary;
};

export type User = {
  email: string;
  name: string;
  role: UserRole;
};

export type ActionLog = {
  id: number;
  campaign_id: number;
  log: string;
  created_at: string;
};

// New Types for Redesign

export type ButtonVariant = 'link' | 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost';

export interface StatusSectionProps {
  title: string;
  description: string;
  metrics: Array<{
    label: string;
    value: string;
    icon?: React.ReactNode;
  }>;
  className?: string;
}

export interface StatusCardProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description: string;
  values: (string | number)[];
  icon?: React.ReactNode;
}

export interface SummaryCardProps {
  title?: string;
  content: string[];
  statusCardProps?: StatusCardProps[];
  statusSectionProps?: StatusSectionProps[];
}

export interface NumberBadgeProps {
  number: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export interface StringBadgeProps {
  string: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export type BadgeProps = NumberBadgeProps | StringBadgeProps;

export interface ButtonProps {
  label: string;
  onClick: () => void;
  className?: string;
  variant?: ButtonVariant;
}

export interface SectionHeaderProps {
  title: string;
  badgeProps?: BadgeProps;
  buttonProps?: ButtonProps[];
}

export type Button = {
  label: string;
  onClick: () => void;
  style?: string;
};

export type TaskCardProps = {
  icon?: string;
  title: string;
  content: string;
  buttons?: Button[];
};

export interface TaskSectionProps {
  title: string;
  badge?: NumberBadgeProps | StringBadgeProps;
  tasks?: TaskCardProps[];
  isLast?: boolean;
}

export type CampaignGoal = {
  id: string;
  title: string;
  icon: React.ReactNode;
  className: string;
};

export interface Country {
  id: string;
  name: string;
  reach: string;
}

export type Position = 'UP' | 'DOWN';

export interface TargetItem {
  id: string;
  name: string;
}

export interface MultiSelectItemProps {
  selectedItems: TargetItem[];
  onItemAdd: (item: TargetItem) => void;
  onItemRemove: (item_id: string) => void;
}

export interface BudgetInputProps {
  value: number;
  setValue: (value: number) => void;
  currency?: string;
  placeholder?: string;
}

export interface Action {
  label: string;
  onClick: () => void;
  variant?: ButtonVariant;
}

export interface MetricCardProps {
  label: string;
  value: string | number;
}

export type CampaignTabValue = 'overview' | 'ads' | 'assets' | 'settings';
export type SettingsTabValue = 'company' | 'team' | 'billing' | 'notification' | 'privacy';

export interface Tab {
  id: CampaignTabValue | SettingsTabValue;
  name: string;
  href: string;
}

export interface TabsProps {
  tabs: Tab[];
  currentTab?: string;
  setCurrentTab?: (value: CampaignTabValue | SettingsTabValue) => void;
  className?: string;
}

export interface AdCardProps {
  title: string;
  description: string;
  keywords: Keyword[];
  needReview: boolean;
}

export interface UserListProps {
  users: User[];
  selectedUser?: User;
  onUserSelect?: (user: User) => void;
}

export interface UserListItemProps {
  user: GoogleAdsAccounts;
  selected?: boolean;
  onSelect?: (user: GoogleAdsAccounts) => void;
}

export interface Url {
  id: string;
  url: string;
}

export interface KeywordManagerProps {
  keywords: Keyword[];
  setKeywords: React.Dispatch<React.SetStateAction<Keyword[]>>;
  alternativeKeywords: Keyword[];
  setAlternativeKeywords: React.Dispatch<React.SetStateAction<Keyword[]>>;
  customKeyword: string;
  setCustomKeyword: React.Dispatch<React.SetStateAction<string>>;
  maxKeywords: number;
  handleSave: () => void;
  handleApprove: () => void;
  isAdDirty: boolean;
  isKeywordDirty: boolean;
}

export interface HeadlineManagerProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description: string;
  headlines: Headline[];
  maxHeadlines: number;
  setHeadlines: (headlines: Headline[]) => void;
  handleSave: () => void;
  handleApprove: () => void;
  isAdDirty: boolean;
  isHeadlineDirty: boolean;
}

export interface DescriptionManagerProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description: string;
  descriptions: Description[];
  maxDescriptions: number;
  setDescriptions: (descriptions: Description[]) => void;
  handleSave: () => void;
  handleApprove: () => void;
  isAdDirty: boolean;
  isDescriptionDirty: boolean;
}

export interface AssetsAdCardProps {
  id?: number;
  url: string;
  title: string;
  description: string;
  image: string;
  locations?: string[];
}
