import { apiEndpoint } from './consts';
import {
  Location as LocationType,
  CampaignCreate,
  CampaignData,
  CampaignUpdate,
  SiteLink,
  CalloutType,
  StructuredSnippetType,
  PriceType,
  Ad,
  GoogleAdsAccounts,
  TaskTrackingResponse,
  User,
  CampaignRecommendations,
  GoogleCampaign,
  CAMPAIGN_STATE,
  OrganizationDataWithMembership,
  OrganizationCreate,
  OrganizationDataWithUsersMembership,
  OrganizationData,
  ActionLog,
} from './types';
import { getCookie } from './auth';

const fetchWithAuth = async (url: string, options = {}) => {
  const token = getCookie('access_token');

  let headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };

  const config = {
    ...options,
    headers,
  };

  const response = await fetch(url, config);

  return response;
};

export default fetchWithAuth;

export async function registerUserAccount(name: string, email: string, password: string): Promise<any> {
  const url = `${apiEndpoint}/auth/signup`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ name, email, password });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: body,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  } catch (error) {
    console.error('Error user account register:', error);
    throw error;
  }
}

export async function loginUserAccount(email: string, password: string): Promise<any> {
  const url = `${apiEndpoint}/auth/signin`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ email, password });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: body,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  } catch (error) {
    console.error('Error fetching auth token:', error);
    throw error;
  }
}

export async function createCampaign(campaign: CampaignCreate) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns`, {
    method: 'POST',
    body: JSON.stringify(campaign),
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchLocations(query: string): Promise<LocationType[] | undefined> {
  if (query.trim().length < 3) return [];

  try {
    const response = await fetchWithAuth(`${apiEndpoint}/locations?name=${query}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data: LocationType[] = await response.json();
    return data || [];
  } catch (error) {
    console.error('Error fetching items:', error);
    return [];
  }
}

export async function fetchNearByLocations(location: LocationType | null): Promise<LocationType[] | undefined> {
  if (!location) return [];

  try {
    const response = await fetchWithAuth(`${apiEndpoint}/locations/nearby`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data: LocationType[] = await response.json();
    return data || [];
  } catch (error) {
    console.error('Error fetching items:', error);
    return [];
  }
}

export async function fetchCampaigns(): Promise<CampaignData[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchGoogleCampaigns(): Promise<GoogleCampaign[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/google/campaigns`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchCampaign(slug: string): Promise<CampaignData> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${slug}`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  const data = await response.json();
  return data;
}

export async function fetchCampaignRecommendations(campaignId: number): Promise<CampaignRecommendations | null> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/recommendations`, {
    method: 'GET',
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function updateCampaignRecommendationFix(campaignId: number, campaignRecommendationId: number) {
  let response = await fetchWithAuth(
    `${apiEndpoint}/campaigns/${campaignId}/recommendations/${campaignRecommendationId}/apply-instant-fix`,
    {
      method: 'POST',
    },
  );
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function updateAdRecommendationFix(campaignId: number, adRecommendationId: number) {
  let response = await fetchWithAuth(
    `${apiEndpoint}/campaigns/${campaignId}/ad-recommendation/${adRecommendationId}/apply-instant-fix`,
    {
      method: 'POST',
    },
  );
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function updateKeywordRecommendationFix(campaignId: number, keywordRecommendationId: number) {
  let response = await fetchWithAuth(
    `${apiEndpoint}/campaigns/${campaignId}/keyword-recommendation/${keywordRecommendationId}/apply-instant-fix`,
    {
      method: 'POST',
    },
  );
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function updateAdState(campaignId: number, adId: number, state: 'approved' | 'draft' | 'error') {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/ads/${adId}/state`, {
    method: 'PUT',
    body: JSON.stringify({ state }),
    headers: {
      'Content-Type': 'application/json',
    },
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function updateCampaignState(campaignId: number, state: CAMPAIGN_STATE) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/state`, {
    method: 'PUT',
    body: JSON.stringify({ state }),
    headers: {
      'Content-Type': 'application/json',
    },
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function importGoogleAdsCampaign(gaCampaignId: string) {
  let response = await fetchWithAuth(`${apiEndpoint}/google/campaigns/${gaCampaignId}`, {
    method: 'POST',
  });
  if (!response.ok) {
    const errorRes = await response.json();
    throw new Error(errorRes.detail);
  }
  return response.json();
}

export async function deleteCampaign(campaignId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}`, {
    method: 'Delete',
  });
  if (!response.ok) {
    throw new Error('Failed to delete campaign');
  }
  if (response.status !== 204) {
    return await response.json();
  }

  return null;
}

export async function deleteCampaignErrors(campaignId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/errors`, {
    method: 'Delete',
  });
  if (!response.ok) {
    throw new Error('Failed to delete campaign');
  }
  if (response.status !== 204) {
    return await response.json();
  }

  return null;
}

export async function updateCampaign(campaign: CampaignUpdate) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaign.id}`, {
    method: 'PUT',
    body: JSON.stringify(campaign),
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function getAccessTokenFromGoogleAccessToken({ googleAccessToken }: { googleAccessToken: string }) {
  const url = `${apiEndpoint}/auth/google/token`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ google_access_token: googleAccessToken });

  const response = await fetch(url, {
    method: 'POST',
    headers: headers,
    body: body,
  });

  if (!response.ok) {
    const errorRes = await response.json();
    throw new Error(errorRes?.detail || 'An unexpected error occurred');
  }

  const data = await response.json();
  return data;
}

export async function getAccessTokenFromGoogleAccessTokenWithInviteCode({
  googleAccessToken,
  inviteCode,
}: {
  googleAccessToken: string;
  inviteCode: string;
}) {
  const url = `${apiEndpoint}/auth/google/token/invite/${inviteCode}`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ google_access_token: googleAccessToken });

  const response = await fetch(url, {
    method: 'POST',
    headers: headers,
    body: body,
  });

  if (!response.ok) {
    const errorRes = await response.json();
    throw new Error(errorRes?.detail || 'Network response was not ok');
  }

  const data = await response.json();
  return data;
}

export async function getAuthToken({ authCode }: { authCode: string }) {
  const url = `${apiEndpoint}/google/auth`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ code: authCode });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: body,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data.access_token;
  } catch (error) {
    console.error('Error fetching auth token:', error);
    throw error;
  }
}

export async function getAuthTokenWithInviteCode({ authCode, inviteCode }: { authCode: string; inviteCode: string }) {
  const url = `${apiEndpoint}/google/auth/invite/${inviteCode}`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ code: authCode });

  const response = await fetch(url, {
    method: 'POST',
    headers: headers,
    body: body,
  });

  if (!response.ok) {
    const errorRes = await response.json();
    throw new Error(errorRes.detail);
  }
  const data = await response.json();
  return data.access_token;
}

export async function addOrUpdateSiteLink(campaignId: number, siteLink: SiteLink) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/site-links`, {
    method: 'POST',
    body: JSON.stringify(siteLink),
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function deleteSiteLink(campaignId: number, siteLinkId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/site-links/${siteLinkId}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function addOrUpdateCallout(campaignId: number, callout: CalloutType) {
  const url = `${apiEndpoint}/campaigns/${campaignId}/callouts`;
  const method = 'POST';

  let response = await fetchWithAuth(url, {
    method,
    body: JSON.stringify(callout),
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function deleteCallout(campaignId: number, calloutId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/callouts/${calloutId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function addOrUpdateStructuredSnippet(campaignId: number, structuredSnippet: StructuredSnippetType) {
  const url = `${apiEndpoint}/campaigns/${campaignId}/structured-snippets`;
  const method = structuredSnippet.id ? 'PUT' : 'POST';

  let response = await fetchWithAuth(`${url}${structuredSnippet.id ? `/${structuredSnippet.id}` : ''}`, {
    method,
    body: JSON.stringify(structuredSnippet),
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function deleteStructuredSnippet(campaignId: number, structuredSnippetId: number) {
  let response = await fetchWithAuth(
    `${apiEndpoint}/campaigns/${campaignId}/structured-snippets/${structuredSnippetId}`,
    {
      method: 'DELETE',
    },
  );

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function addOrUpdatePrice(campaignId: number, price: PriceType) {
  const url = `${apiEndpoint}/campaigns/${campaignId}/prices`;
  const method = price.id ? 'PUT' : 'POST';

  let response = await fetchWithAuth(`${url}${price.id ? `/${price.id}` : ''}`, {
    method,
    body: JSON.stringify(price),
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function deletePrice(campaignId: number, priceId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/prices/${priceId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export const updateAd = async (campaignId: number, ad: Ad): Promise<Ad> => {
  const response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/ads/${ad.id}`, {
    method: 'PUT',

    body: JSON.stringify(ad),
  });

  if (!response.ok) {
    throw new Error('Failed to update ad');
  }

  return response.json();
};

export const deleteAd = async (campaignId: number, adId: number): Promise<void> => {
  const response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/ads/${adId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    throw new Error('Failed to delete ad');
  }

  return response.json();
};

export async function fetchGoogleAdsAccounts(): Promise<GoogleAdsAccounts[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/google/accounts`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchLinkedGoogleAdsAccounts(): Promise<GoogleAdsAccounts[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/google/accounts/linked`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function setSelectedGoogleAdsAccount(adsCustomerId: number): Promise<string> {
  let response = await fetchWithAuth(`${apiEndpoint}/google/accounts/set-selected`, {
    method: 'PUT',
    body: JSON.stringify({ googleads_account_id: adsCustomerId }),
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
}

export async function fetchCampaignDescription(url: string): Promise<{ description: string }> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/description?url=${url}`, {
    method: 'GET',
  });
  if (!response.ok) {
    const errorRes = await response.json();
    throw new Error(errorRes.detail);
  }
  return response.json();
}

export async function updateGoogleCampaign(campaignId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/google/campaigns/${campaignId}`, {
    method: 'PUT',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function createAd(campaignId: number, url: string): Promise<Ad> {
  const response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/ads/`, {
    method: 'POST',
    body: JSON.stringify({ url: url }),
  });
  if (!response.ok) {
    const errorRes = await response.json();
    const errorMessage = errorRes.detail || 'An unknown error occurred';
    throw new Error(errorMessage);
  }
  return response.json();
}

export async function fetchCampaignTaskTracking(campaignId: number): Promise<TaskTrackingResponse> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/task-tracking`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchUsers(): Promise<User[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/users`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function impersonateUser(email: string) {
  let response = await fetchWithAuth(`${apiEndpoint}/user/${email}/impersonate`, {
    method: 'POST',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function unsetImpersonateUser() {
  let response = await fetchWithAuth(`${apiEndpoint}/user/unset_impersonate`, {
    method: 'POST',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function copyCampaign(campaignId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/copy`, {
    method: 'POST',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function linkGoogleAdsCustomer(googleAdsCustomerId: number, name: string) {
  let response = await fetchWithAuth(`${apiEndpoint}/google/link-accounts`, {
    method: 'POST',
    body: JSON.stringify({
      account_id: googleAdsCustomerId,
      name: name,
    }),
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export const regenerateCampaignTcpa = async (campaignId: number): Promise<any> => {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${campaignId}/tcpa/`, {
    method: 'POST',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
};

export async function fetchOrganizations(): Promise<OrganizationDataWithMembership[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/organizations`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function createOrganization(organization: OrganizationCreate) {
  let response = await fetchWithAuth(`${apiEndpoint}/organizations`, {
    method: 'POST',
    body: JSON.stringify(organization),
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchOrganization(slug: string): Promise<OrganizationDataWithUsersMembership> {
  let response = await fetchWithAuth(`${apiEndpoint}/organizations/${slug}`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  const data = await response.json();
  return data;
}

export async function deleteOrganization(organizationId: number) {
  let response = await fetchWithAuth(`${apiEndpoint}/organizations/${organizationId}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    const errorData = await response.json();
    return { msg: errorData.detail || 'An unexpected error occurred' };
  }
  if (response.status !== 204) {
    return await response.json();
  }

  return null;
}

export async function updateOrganization(organization: OrganizationData) {
  let response = await fetchWithAuth(`${apiEndpoint}/organizations/${organization.id}`, {
    method: 'PUT',
    body: JSON.stringify(organization),
  });
  if (!response.ok) {
    const errorData = await response.json();
    return { msg: errorData.detail || 'An unexpected error occurred' };
  }
  return response.json();
}

export async function sendInvitationToUser(
  name: string,
  email: string,
  role: string,
  organizationId: number,
): Promise<any> {
  const url = `${apiEndpoint}/organizations/${organizationId}/invite`;

  const headers = {
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({ name, email, role });

  try {
    const response = await fetchWithAuth(url, {
      method: 'POST',
      headers: headers,
      body: body,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  } catch (error) {
    console.error('Error user account register:', error);
    throw error;
  }
}

export async function verifyInviteCode(code: string): Promise<{ email: string; is_valid_refresh_token: boolean }> {
  let response = await fetchWithAuth(`${apiEndpoint}/auth/verify-invite-code/${code}`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}

export async function fetchCampaignActionLogs(slug: string): Promise<ActionLog[]> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${slug}/action-logs/`, {
    method: 'GET',
  });
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  const data = await response.json();
  return data;
}

export async function triggerZeroImpressionOptimisation(slug: string): Promise<string> {
  let response = await fetchWithAuth(`${apiEndpoint}/campaigns/${slug}/optimisations/zeroimpression/`, {
    method: 'POST',
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.detail || 'An unknown error occurred');
  }

  const data = await response.json();
  return data;
}
