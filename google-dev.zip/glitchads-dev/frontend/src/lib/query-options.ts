import * as Sentry from '@sentry/browser';

import { Query, QueryKey, queryOptions, useMutation } from '@tanstack/react-query';
import {
  registerUserAccount,
  loginUserAccount,
  addOrUpdateCallout,
  addOrUpdatePrice,
  addOrUpdateSiteLink,
  addOrUpdateStructuredSnippet,
  updateCampaignRecommendationFix,
  createCampaign,
  deleteCallout,
  deletePrice,
  deleteSiteLink,
  deleteStructuredSnippet,
  fetchCampaign,
  fetchCampaignRecommendations,
  fetchCampaigns,
  fetchGoogleAdsAccounts,
  fetchCampaignDescription,
  fetchLocations,
  setSelectedGoogleAdsAccount,
  updateAd,
  updateAdState,
  updateCampaign,
  updateCampaignState,
  updateGoogleCampaign,
  updateAdRecommendationFix,
  updateKeywordRecommendationFix,
  deleteAd,
  deleteCampaign,
  fetchCampaignTaskTracking,
  createAd,
  fetchNearByLocations,
  deleteCampaignErrors,
  fetchUsers,
  impersonateUser,
  unsetImpersonateUser,
  copyCampaign,
  fetchGoogleCampaigns,
  importGoogleAdsCampaign,
  linkGoogleAdsCustomer,
  fetchLinkedGoogleAdsAccounts,
  fetchOrganizations,
  createOrganization,
  fetchOrganization,
  deleteOrganization,
  updateOrganization,
  sendInvitationToUser,
  verifyInviteCode,
  fetchCampaignActionLogs,
  triggerZeroImpressionOptimisation,
} from './apis';
import {
  Ad,
  CalloutType,
  CAMPAIGN_STATE,
  CampaignRecommendations,
  CampaignUpdate,
  GoogleAdsAccounts,
  Location,
  OrganizationData,
  PriceType,
  SiteLink,
  StructuredSnippetType,
  TaskTrackingResponse,
} from './types';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { usePostHog } from 'posthog-js/react';
import { regenerateCampaignTcpa } from './apis';

export const useUserAccountRegisterMutation = (name: string, email: string, password: string) => {
  return useMutation({
    mutationKey: ['users', 'register'],
    mutationFn: () => registerUserAccount(name, email, password),

    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUserAccountLoginMutation = (email: string, password: string) => {
  return useMutation({
    mutationKey: ['users', 'register'],
    mutationFn: () => loginUserAccount(email, password),

    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useCreateCampaignMutation = () => {
  return useMutation({
    mutationKey: ['campaigns', 'create'],
    mutationFn: createCampaign,

    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useCampaignCopyMutation = (campaignId: number) => {
  return useMutation({
    mutationKey: ['campaigns', 'copy'],
    mutationFn: () => copyCampaign(campaignId),
  });
};

export const useImportGoogleAdsCampaignMutation = () => {
  return useMutation<
    {
      slug: string;
      campaign_id: string;
    },
    Error,
    { gaCampaignId: string }
  >({
    mutationFn: ({ gaCampaignId }) => importGoogleAdsCampaign(gaCampaignId),
  });
};

export const campaignDescriptionQueryOptions = (url: string, enabled: boolean) => {
  return queryOptions({
    queryKey: ['campaign_description', url],
    queryFn: () => {
      if (url === '') return null;
      return fetchCampaignDescription(url);
    },
    enabled,
    retry: false,
  });
};

export const locationsQueryOptions = (name: string) => {
  return queryOptions({
    queryKey: ['locations', name],
    queryFn: () => fetchLocations(name),
  });
};

export const nearByLocationsQueryOptions = (location: Location | null) => {
  return queryOptions({
    queryKey: ['nearbyLocations', location],
    queryFn: () => fetchNearByLocations(location),
  });
};

export const campaignsQueryOptions = () => {
  return queryOptions({
    queryKey: ['campaigns'],
    queryFn: () => fetchCampaigns(),
  });
};

export const googleCampaignsQueryOptions = () => {
  return queryOptions({
    queryKey: ['googlecampaigns'],
    queryFn: () => fetchGoogleCampaigns(),
  });
};

export const campaignQueryOptions = (slug: string) => {
  return queryOptions({
    queryKey: ['campaigns', slug],
    queryFn: () => fetchCampaign(slug),
    refetchInterval: (query) => {
      let ads = query.state.data?.ads;
      if (!ads) return 5000;
      return false;
    },
  });
};

export const campaignRecommendationsQueryOptions = (campaignId: number) => {
  return queryOptions({
    queryKey: ['campaignRecommendations', campaignId],
    queryFn: () => fetchCampaignRecommendations(campaignId) as Promise<CampaignRecommendations | null>,
  });
};

export const useCampaignRecommendationsFixMutationOptions = (campaignId: number, recommendationId: number) => {
  return useMutation({
    mutationKey: ['campaignRecommendationFix', 'apply'],
    mutationFn: () => updateCampaignRecommendationFix(campaignId, recommendationId),
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useAdRecommendationsFixMutationOptions = (campaignId: number, adRecommendationId: number) => {
  return useMutation({
    mutationKey: ['adRecommendationFix', 'apply'],
    mutationFn: () => updateAdRecommendationFix(campaignId, adRecommendationId),
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useKeywordRecommendationsFixMutationOptions = (campaignId: number, keywordRecommendationId: number) => {
  return useMutation({
    mutationKey: ['keywordRecommendationFix', 'apply'],
    mutationFn: () => updateKeywordRecommendationFix(campaignId, keywordRecommendationId),
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useAdStateMutationOptions = (campaignId: number, adId: number, state: 'approved' | 'draft' | 'error') => {
  return useMutation({
    mutationKey: ['ads', 'state', adId],
    mutationFn: () => updateAdState(campaignId, adId, state),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useAdDeleteMutationOptions = (campaignId: number, adId: number) => {
  return useMutation({
    mutationKey: ['ads', 'delete', campaignId, adId],
    mutationFn: () => deleteAd(campaignId, adId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUpdateAdMutationOptions = () => {
  return useMutation<Ad, Error, { campaignId: number; ad: Ad }>({
    mutationFn: ({ campaignId, ad }) => updateAd(campaignId, ad),
  });
};

export const useCampaignStateMutationOptions = (campaignId: number) => {
  return useMutation({
    mutationKey: ['campaigns', 'state', campaignId],
    mutationFn: (newState: CAMPAIGN_STATE) => updateCampaignState(campaignId, newState),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};
export const useCampaignDeleteMutationOptions = (campaignId: number) => {
  return useMutation({
    mutationKey: ['campaigns', 'delete', campaignId],
    mutationFn: () => deleteCampaign(campaignId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useCampaignMutationOptions = () => {
  return useMutation({
    mutationKey: ['campaigns', 'update'],
    mutationFn: (campaign: CampaignUpdate) => updateCampaign(campaign),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUpdateGoogleCampaignMutationOptions = (campaignId: number) => {
  return useMutation({
    mutationKey: ['googleCampaign', 'update'],
    mutationFn: () => updateGoogleCampaign(campaignId),
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUpdateSiteLinkMutationOptions = () => {
  return useMutation({
    mutationKey: ['siteLinks', 'update'],
    mutationFn: ({ campaignId, siteLink }: { campaignId: number; siteLink: SiteLink }) =>
      addOrUpdateSiteLink(campaignId, siteLink),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useDeleteSiteLinkMutationOptions = () => {
  return useMutation({
    mutationKey: ['siteLinks', 'delete'],
    mutationFn: ({ campaignId, siteLinkId }: { campaignId: number; siteLinkId: number }) =>
      deleteSiteLink(campaignId, siteLinkId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useCampaignErrorsDeleteMutationOptions = (campaignId: number) => {
  return useMutation({
    mutationKey: ['campaignsErrors', 'delete', campaignId],
    mutationFn: () => deleteCampaignErrors(campaignId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useCreateAdMutationOptions = () => {
  return useMutation({
    mutationKey: ['ads', 'create'],
    mutationFn: ({ campaignId, url }: { campaignId: number; url: string }) => createAd(campaignId, url),
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};
export const useUpdateCalloutMutationOptions = () => {
  return useMutation({
    mutationKey: ['callouts', 'update'],
    mutationFn: ({ campaignId, callout }: { campaignId: number; callout: CalloutType }) =>
      addOrUpdateCallout(campaignId, callout),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useDeleteCalloutMutationOptions = () => {
  return useMutation({
    mutationKey: ['callouts', 'delete'],
    mutationFn: ({ campaignId, calloutId }: { campaignId: number; calloutId: number }) =>
      deleteCallout(campaignId, calloutId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUpdateStructuredSnippetMutationOptions = () => {
  return useMutation({
    mutationKey: ['structuredSnippets', 'update'],
    mutationFn: ({ campaignId, structuredSnippet }: { campaignId: number; structuredSnippet: StructuredSnippetType }) =>
      addOrUpdateStructuredSnippet(campaignId, structuredSnippet),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useDeleteStructuredSnippetMutationOptions = () => {
  return useMutation({
    mutationKey: ['structuredSnippets', 'delete'],
    mutationFn: ({ campaignId, structuredSnippetId }: { campaignId: number; structuredSnippetId: number }) =>
      deleteStructuredSnippet(campaignId, structuredSnippetId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUpdatePriceMutationOptions = () => {
  return useMutation({
    mutationKey: ['prices', 'update'],
    mutationFn: ({ campaignId, price }: { campaignId: number; price: PriceType }) =>
      addOrUpdatePrice(campaignId, price),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useDeletePriceMutationOptions = () => {
  return useMutation({
    mutationKey: ['prices', 'delete'],
    mutationFn: ({ campaignId, priceId }: { campaignId: number; priceId: number }) => deletePrice(campaignId, priceId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const googleAdsAccountsQueryOptions = () => {
  return queryOptions({
    queryKey: ['goolgeadsAccounts'],
    queryFn: () => fetchGoogleAdsAccounts(),
    refetchInterval: (query: Query<GoogleAdsAccounts[], Error, GoogleAdsAccounts[], QueryKey>) => {
      let data = query.state.data;
      if (data && data.length > 0) {
        return false;
      }

      return 2000;
    },
    retry: 5,
  });
};

export const googleAdsLinkedAccountsQueryOptions = () => {
  return queryOptions({
    queryKey: ['goolgeadsLinkedAccounts'],
    queryFn: () => fetchLinkedGoogleAdsAccounts(),
    refetchInterval: (query: Query<GoogleAdsAccounts[], Error, GoogleAdsAccounts[], QueryKey>) => {
      let data = query.state.data;
      if (data && data.length > 0) {
        return false;
      }

      return 2000;
    },
    retry: 5,
  });
};

export const linkGoogleAdsCustomertMutationOptions = () => {
  return useMutation({
    mutationKey: ['googleAdsCustomer', 'link'],
    mutationFn: ({ googleAdsCustomerId, name }: { googleAdsCustomerId: number; name: string }) =>
      linkGoogleAdsCustomer(googleAdsCustomerId, name),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useSetGoogleAdsCustomerIdMutationOptions = () => {
  return useMutation({
    mutationKey: ['googleAdsCustomerId'],
    mutationFn: ({ adsCustomerId }: { adsCustomerId: number }) => setSelectedGoogleAdsAccount(adsCustomerId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const campaignTaskTrackingQueryOptions = (campaignId: number) => {
  return queryOptions<TaskTrackingResponse, Error>({
    queryKey: ['campaignTaskTracking', campaignId],
    queryFn: () => fetchCampaignTaskTracking(campaignId),
    refetchInterval: (query) => {
      let trackings = query.state.data;
      if (!trackings) return 1000;
      const allCompleted = Object.values(trackings).every((task) => {
        if (task.total === 0) return false;
        return task.completed + task.failed >= task.total;
      });
      if (allCompleted) {
        return false;
      }
      return 3000;
    },
  });
};

export const usersQueryOptions = () => {
  return queryOptions({
    queryKey: ['users'],
    queryFn: () => fetchUsers(),
  });
};

export const useImpersonateUserMutationOptions = () => {
  return useMutation({
    mutationKey: ['impersonate'],
    mutationFn: (email: string) => impersonateUser(email),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useUnsetImpersonateUserMutationOptions = () => {
  return useMutation({
    mutationKey: ['unset_impersonate'],
    mutationFn: () => unsetImpersonateUser(),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useTcpaRegenerateMutation = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const posthog = usePostHog();

  return useMutation({
    mutationKey: ['tcpa', 'regenerate'],
    mutationFn: (campaignId: number) => regenerateCampaignTcpa(campaignId),
    onSuccess: (_, campaignId) => {
      toast({ description: 'TCPA regeneration started' });
      posthog?.capture('tcpa_regenerate_clicked', { campaignId });
      queryClient.invalidateQueries({ queryKey: ['campaignTaskTracking', campaignId] });
    },
    onError: () => {
      toast({ description: 'Failed to regenerate TCPA', variant: 'destructive' });
    },
  });
};

export const organizationsQueryOptions = () => {
  return queryOptions({
    queryKey: ['organizations'],
    queryFn: () => fetchOrganizations(),
  });
};

export const useCreateOrganizationMutation = () => {
  return useMutation({
    mutationKey: ['organizations', 'create'],
    mutationFn: createOrganization,

    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const organizationQueryOptions = (slug: string) => {
  return queryOptions({
    queryKey: ['organizations', slug],
    queryFn: () => fetchOrganization(slug),
    refetchInterval: () => {
      return false;
    },
  });
};

export const useOrganizationDeleteMutationOptions = (organizationId: number) => {
  return useMutation({
    mutationKey: ['organizations', 'delete', organizationId],
    mutationFn: () => deleteOrganization(organizationId),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useOrganizationMutationOptions = () => {
  return useMutation({
    mutationKey: ['organizations', 'update'],
    mutationFn: (organization: OrganizationData) => updateOrganization(organization),
    onSuccess: (data) => {
      return data;
    },
    onError: (error, variables, context) => {
      console.error('error', error, variables, context);
    },
  });
};

export const useSendInvitationToUserMutation = () => {
  return useMutation<
    null,
    Error,
    {
      name: string;
      email: string;
      role: string;
      organizationId: number;
    }
  >({
    mutationKey: ['users', 'invite'],
    mutationFn: ({ name, email, role, organizationId }) => sendInvitationToUser(name, email, role, organizationId),
  });
};

export const verifyInviteCodeQueryOptions = (code: string) => {
  return queryOptions({
    queryKey: ['verify-invite-code', code],
    queryFn: () => verifyInviteCode(code),
  });
};

export const campaignActionLogsQueryOptions = (slug: string) => {
  return queryOptions({
    queryKey: ['action-logs', slug],
    queryFn: () => fetchCampaignActionLogs(slug),
  });
};

export const useCampaignZeroImpressionOptimisationMutation = (slug: string) => {
  return useMutation({
    mutationKey: ['zero-impression-optimisation', slug],
    mutationFn: () => triggerZeroImpressionOptimisation(slug),
    onSuccess: (data) => {
      return data;
    },
    onError: (error) => {
      Sentry.captureException(error);
    },
  });
};
