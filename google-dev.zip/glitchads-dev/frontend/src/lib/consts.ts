const env = import.meta.env;

const NODE_ENV = env.VITE_NODE_ENV;
console.log(NODE_ENV);
export let apiEndpoint = '';

if (NODE_ENV === 'production') {
  apiEndpoint = 'https://glitchads-prod-108905211504.europe-west4.run.app';
} else if (NODE_ENV === 'staging') {
  apiEndpoint = 'https://glitchads-staging-108905211504.europe-west4.run.app';
} else {
  apiEndpoint = 'http://localhost:8000';
}
