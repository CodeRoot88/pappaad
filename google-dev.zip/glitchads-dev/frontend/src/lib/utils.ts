import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { CampaignData, CampaignTabValue, SettingsTabValue } from './types';
import { RECOMMENDATION_STATE, UserRole } from './types';

// https://stackoverflow.com/questions/10992921/how-to-remove-emoji-code-using-javascript
const emojiRegex = /\p{Emoji}/u;

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function isResolvedState(state: RECOMMENDATION_STATE) {
  return state === RECOMMENDATION_STATE.INSTANT_FIX_APPLIED || state === RECOMMENDATION_STATE.MARKED_RESOLVED;
}

export const getGoogleAdsCampaignLink = (campaign: CampaignData) => {
  if (
    campaign.googleads_campaign &&
    campaign.googleads_account.googleads_account_id &&
    campaign.googleads_campaign.googleads_campaign_id
  ) {
    let x = `https://ads.google.com/aw/campaigns?campaignId=${campaign.googleads_campaign.googleads_campaign_id}&customerId=${campaign.googleads_account_id}`;
    return x;
  }
  return null;
};

export function setCookie(name: string, value: string, days: number) {
  let expires = '';
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = '; expires=' + date.toUTCString();
  }
  document.cookie = name + '=' + (value || '') + expires + '; path=/';
}

export function debounce<Params extends any[]>(
  func: (...args: Params) => any,
  timeout: number,
): (...args: Params) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Params) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      func(...args);
    }, timeout);
  };
}

export function isValidUrl(url: string) {
  var res = url.match(
    /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g,
  );
  if (res == null) return false;
  else return true;
}

export function isValidSegment(segment: string): boolean {
  return /^[a-zA-Z0-9-_]+$/.test(segment);
}

export function isValidInput(input: string): boolean {
  return /^[a-zA-Z0-9-_\s]+$/.test(input);
}

export function isAdmin(role: UserRole) {
  return role === UserRole.ADMIN;
}

export function removeEmojis(input: string): string {
  // Use a regular expression to match and remove emojis
  return input.replace(emojiRegex, '');
}

export function containsEmoji(input: string): boolean {
  // Check if any emoji is present in the string
  return emojiRegex.test(input);
}

export function isCampaignTabValue(value: string): value is CampaignTabValue {
  return ['overview', 'ads', 'assets', 'settings'].includes(value);
}

export function isSettingsTabValue(value: string): value is SettingsTabValue {
  return ['company', 'team', 'billing', 'notification', 'privacy'].includes(value);
}

export function getInitialUserName(name: string) {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()[0];
}

export const formatPhoneNumber = (value: string): string => {
  let cleaned = value.replace(/[^\d+]/g, '');

  cleaned = cleaned.startsWith('+') ? cleaned : `+${cleaned}`;

  const formatted = cleaned.replace(
    /^(\+\d{0,1})(\d{0,3})(\d{0,2})(\d{0,3}).*/,
    (_, p1 = '+', p2 = '', p3 = '', p4 = '') => {
      let parts = [p1];
      if (p2) parts.push(p2);
      if (p3) parts.push(p3);
      if (p4) parts.push(p4);
      return parts.join(' ').trim();
    },
  );

  return formatted;
};

export const validatePhone = (input: string): boolean => {
  return /^\+(?=.*\d)[+\d\s]*$/.test(input);
};

export const VOID = () => {
  /** */
};
