export const campaignData = {
  slug: 'bX7T57-YH4',
  name: 'Campaign bX7T57-YH4',
  status: 'draft',
  website_url: 'https://ndrc.ie',
  id: 24,
  ads: [
    {
      slug: 'No_8v-XkrU',
      id: 101,
      headlines: [
        {
          id: 1122,
          text: 'Support for Entrepreneurs',
        },
        {
          id: 1123,
          text: 'Join the Startup Journey',
        },
        {
          id: 1124,
          text: 'Get Early Feedback Now',
        },
        {
          id: 1125,
          text: 'Investment Opportunities Await',
        },
        {
          id: 1126,
          text: 'Mentor-Led Programmes Start',
        },
        {
          id: 1127,
          text: 'Find Your Co-Founder',
        },
        {
          id: 1128,
          text: 'Join the Pre-Accelerator',
        },
        {
          id: 1129,
          text: 'Pitch to Accelerators Now',
        },
        {
          id: 1130,
          text: 'For Ecosystem Builders',
        },
        {
          id: 1131,
          text: 'Innovative Tech Startups',
        },
      ],
      descriptions: [
        {
          id: 337,
          text: 'Supporting you every step.',
        },
        {
          id: 338,
          text: 'Navigate the ecosystem easily.',
        },
        {
          id: 339,
          text: 'Receive investment and coaching.',
        },
        {
          id: 340,
          text: 'Connect and scale your startup.',
        },
      ],
      keywords: [
        {
          ad_id: 101,
          text: 'entrepreneurs',
          id: 782,
        },
        {
          ad_id: 101,
          text: 'startup journey',
          id: 783,
        },
        {
          ad_id: 101,
          text: 'early feedback',
          id: 784,
        },
        {
          ad_id: 101,
          text: 'investment',
          id: 785,
        },
        {
          ad_id: 101,
          text: 'mentor-led programmes',
          id: 786,
        },
        {
          ad_id: 101,
          text: 'co-founder',
          id: 787,
        },
        {
          ad_id: 101,
          text: 'pre-accelerator',
          id: 788,
        },
        {
          ad_id: 101,
          text: 'pitch to accelerators',
          id: 789,
        },
        {
          ad_id: 101,
          text: 'ecosystem builders',
          id: 790,
        },
        {
          ad_id: 101,
          text: 'innovative tech startup',
          id: 791,
        },
      ],
    },
    {
      slug: 'qooI_C_ff0',
      id: 102,
      headlines: [
        {
          id: 1132,
          text: 'Start Your Entrepreneurial Journey',
        },
        {
          id: 1133,
          text: 'Raise Investment with Ease',
        },
        {
          id: 1134,
          text: 'Explore Your Idea Early',
        },
        {
          id: 1135,
          text: 'Join Mentor-led Programmes',
        },
        {
          id: 1136,
          text: 'Join Our Startup Community',
        },
        {
          id: 1137,
          text: 'Achieve Startup Success Fast',
        },
        {
          id: 1138,
          text: 'Book Office Hours Now',
        },
        {
          id: 1139,
          text: 'Experience Founder Weekend',
        },
        {
          id: 1140,
          text: 'Join the Pre-Accelerator',
        },
        {
          id: 1141,
          text: 'Upskill with Ecosystem Masterclasses',
        },
        {
          id: 1142,
          text: 'Journey to Startup Success',
        },
        {
          id: 1143,
          text: 'Your Idea, Our Programme',
        },
        {
          id: 1144,
          text: 'Scale with Mentor-led Guidance',
        },
        {
          id: 1145,
          text: 'Funding for Entrepreneurs',
        },
        {
          id: 1146,
          text: 'Master Entrepreneurship',
        },
      ],
      descriptions: [
        {
          id: 341,
          text: 'Supporting you at every startup stage.',
        },
        {
          id: 342,
          text: 'Mentor-led programmes to scale fast.',
        },
        {
          id: 343,
          text: 'Join our community and succeed.',
        },
        {
          id: 344,
          text: 'Get feedback and funding support.',
        },
      ],
      keywords: [
        {
          ad_id: 102,
          text: 'entrepreneurial journey',
          id: 792,
        },
        {
          ad_id: 102,
          text: 'raise investment',
          id: 793,
        },
        {
          ad_id: 102,
          text: 'explore idea',
          id: 794,
        },
        {
          ad_id: 102,
          text: 'mentor-led programmes',
          id: 795,
        },
        {
          ad_id: 102,
          text: 'join community',
          id: 796,
        },
        {
          ad_id: 102,
          text: 'startup success',
          id: 797,
        },
        {
          ad_id: 102,
          text: 'office hours',
          id: 798,
        },
        {
          ad_id: 102,
          text: 'founder weekend',
          id: 799,
        },
        {
          ad_id: 102,
          text: 'pre-accelerator',
          id: 800,
        },
        {
          ad_id: 102,
          text: 'ecosystem masterclasses',
          id: 801,
        },
      ],
    },
    {
      slug: '-6iNfJNjcY',
      id: 103,
      headlines: [
        {
          id: 1147,
          text: 'Support for Entrepreneurs',
        },
        {
          id: 1148,
          text: 'Begin your Startup Journey',
        },
        {
          id: 1149,
          text: 'Join Mentor-Led Programmes',
        },
        {
          id: 1150,
          text: 'Raise Investment Easily',
        },
        {
          id: 1151,
          text: 'Guidance from Global VC',
        },
        {
          id: 1152,
          text: 'Explore Funding Pathways',
        },
        {
          id: 1153,
          text: 'Join our Pre-Accelerator',
        },
        {
          id: 1154,
          text: 'Post-Accelerator Support',
        },
        {
          id: 1155,
          text: 'Attend Masterclass Sessions',
        },
        {
          id: 1156,
          text: 'Experience Founder Weekend',
        },
        {
          id: 1157,
          text: 'NDRC Entrepreneur Support',
        },
        {
          id: 1158,
          text: 'Your Startup Journey Starts',
        },
        {
          id: 1159,
          text: 'Mentor-led Growth Programmes',
        },
        {
          id: 1160,
          text: 'Simplify Raising Investment',
        },
        {
          id: 1161,
          text: 'Connect with Global VC',
        },
      ],
      descriptions: [
        {
          id: 345,
          text: "Get support at every stage from idea to Series A with NDRC's tailored programs.",
        },
        {
          id: 346,
          text: 'Join NDRC and navigate the startup ecosystem with expert mentorship and programmes.',
        },
        {
          id: 347,
          text: 'From pre-accelerator to post-accelerator, get the guidance and support to succeed.',
        },
        {
          id: 348,
          text: "Explore our funding pathways and masterclasses to boost your startup's potential.",
        },
      ],
      keywords: [
        {
          ad_id: 103,
          text: 'entrepreneur support',
          id: 802,
        },
        {
          ad_id: 103,
          text: 'startup journey',
          id: 803,
        },
        {
          ad_id: 103,
          text: 'mentor-led programmes',
          id: 804,
        },
        {
          ad_id: 103,
          text: 'raise investment',
          id: 805,
        },
        {
          ad_id: 103,
          text: 'global VC',
          id: 806,
        },
        {
          ad_id: 103,
          text: 'funding pathways',
          id: 807,
        },
        {
          ad_id: 103,
          text: 'pre-accelerator',
          id: 808,
        },
        {
          ad_id: 103,
          text: 'post-accelerator',
          id: 809,
        },
        {
          ad_id: 103,
          text: 'ecosystem masterclass',
          id: 810,
        },
        {
          ad_id: 103,
          text: 'founder weekend',
          id: 811,
        },
      ],
    },
    {
      slug: 'gFKpxi1pqI',
      id: 104,
      headlines: [
        {
          id: 1162,
          text: 'Join Your Startup Journey',
        },
        {
          id: 1163,
          text: 'Get Entrepreneurial Support',
        },
        {
          id: 1164,
          text: 'Series A Funding Awaits You',
        },
        {
          id: 1165,
          text: 'Mentor-Led Programmes for You',
        },
        {
          id: 1166,
          text: 'Book Office Hours Now',
        },
        {
          id: 1167,
          text: 'Discover Founder Weekend',
        },
        {
          id: 1168,
          text: 'Join Pre-Accelerator Today',
        },
        {
          id: 1169,
          text: 'Accelerator for Innovators',
        },
        {
          id: 1170,
          text: 'Post-Accelerator Support Here',
        },
        {
          id: 1171,
          text: 'Ecosystem Masterclasses Now',
        },
        {
          id: 1172,
          text: 'Master Startup Journey',
        },
        {
          id: 1173,
          text: 'Support for Entrepreneurs',
        },
        {
          id: 1174,
          text: 'Fund Your Series A',
        },
        {
          id: 1175,
          text: 'Guided Mentor Programmes',
        },
        {
          id: 1176,
          text: 'Early Office Hours Advice',
        },
      ],
      descriptions: [
        {
          id: 349,
          text: 'Join a community of innovators and receive support on your startup journey.',
        },
        {
          id: 350,
          text: 'Get expert feedback and mentorship at every stage of your entrepreneurial journey.',
        },
        {
          id: 351,
          text: 'Access mentor-led programmes to develop and scale your startup idea.',
        },
        {
          id: 352,
          text: 'Sign up for office hours to receive early feedback and funding advice.',
        },
      ],
      keywords: [
        {
          ad_id: 104,
          text: 'startup journey',
          id: 812,
        },
        {
          ad_id: 104,
          text: 'entrepreneurial support',
          id: 813,
        },
        {
          ad_id: 104,
          text: 'Series A funding',
          id: 814,
        },
        {
          ad_id: 104,
          text: 'mentor-led programmes',
          id: 815,
        },
        {
          ad_id: 104,
          text: 'office hours',
          id: 816,
        },
        {
          ad_id: 104,
          text: 'founder weekend',
          id: 817,
        },
        {
          ad_id: 104,
          text: 'pre-accelerator',
          id: 818,
        },
        {
          ad_id: 104,
          text: 'accelerator',
          id: 819,
        },
        {
          ad_id: 104,
          text: 'post-accelerator support',
          id: 820,
        },
        {
          ad_id: 104,
          text: 'ecosystem masterclasses',
          id: 821,
        },
      ],
    },
    {
      slug: 'B-Fo72D-PR',
      id: 105,
      headlines: [
        {
          id: 1177,
          text: 'Entrepreneur Support Here',
        },
        {
          id: 1178,
          text: 'Join Our Startup Journey',
        },
        {
          id: 1179,
          text: 'Raise Investment Now',
        },
        {
          id: 1180,
          text: 'Find Your Co-Founder',
        },
        {
          id: 1181,
          text: 'Validate Your Ideas Fast',
        },
        {
          id: 1182,
          text: 'Join Accelerator Program',
        },
        {
          id: 1183,
          text: 'Mentor-Led Programmes Await',
        },
        {
          id: 1184,
          text: 'Post-Accelerator Support',
        },
        {
          id: 1185,
          text: 'Build Your Ecosystem',
        },
        {
          id: 1186,
          text: 'Get Early Feedback Now',
        },
        {
          id: 1187,
          text: 'Support for Entrepreneurs',
        },
        {
          id: 1188,
          text: 'Startup Journey Starts Here',
        },
        {
          id: 1189,
          text: 'Raise Investment Today',
        },
        {
          id: 1190,
          text: 'Find Your Co-Founder',
        },
        {
          id: 1191,
          text: 'Validate Ideas Quickly',
        },
      ],
      descriptions: [
        {
          id: 353,
          text: 'Get support at every stage of your entrepreneurial journey. Start today!',
        },
        {
          id: 354,
          text: 'Join our mentor-led programs to raise investment and scale your idea.',
        },
        {
          id: 355,
          text: 'Sign up for early feedback, idea validation, and funding guidance.',
        },
        {
          id: 356,
          text: 'Find co-founders, get support, and accelerate your startup journey.',
        },
      ],
      keywords: [
        {
          ad_id: 105,
          text: 'entrepreneur support',
          id: 822,
        },
        {
          ad_id: 105,
          text: 'startup journey',
          id: 823,
        },
        {
          ad_id: 105,
          text: 'raise investment',
          id: 824,
        },
        {
          ad_id: 105,
          text: 'find co-founder',
          id: 825,
        },
        {
          ad_id: 105,
          text: 'idea validation',
          id: 826,
        },
        {
          ad_id: 105,
          text: 'accelerator program',
          id: 827,
        },
        {
          ad_id: 105,
          text: 'mentor-led programs',
          id: 828,
        },
        {
          ad_id: 105,
          text: 'post-accelerator support',
          id: 829,
        },
        {
          ad_id: 105,
          text: 'ecosystem building',
          id: 830,
        },
        {
          ad_id: 105,
          text: 'early feedback',
          id: 831,
        },
      ],
    },
  ],
  site_links: [
    {
      id: 783,
      url: 'https://www.ndrc.ie/masterclasses/startup-ecosystems',
    },
    {
      id: 784,
      url: 'https://www.ndrc.ie/masterclasses/world-class-mentoring',
    },
    {
      id: 785,
      url: 'https://www.ndrc.ie/masterclasses/angel-investing-best-practice',
    },
    {
      id: 786,
      url: 'https://www.ndrc.ie/masterclasses/startup-metrics-that-matter',
    },
    {
      id: 787,
      url: 'https://www.ndrc.ie/accelerator-cohort-2021',
    },
    {
      id: 788,
      url: 'https://www.ndrc.ie/masterclasses/corporate-innovation',
    },
    {
      id: 789,
      url: 'https://www.ndrc.ie/masterclasses/startup-legals',
    },
    {
      id: 790,
      url: 'https://www.ndrc.ie/safe',
    },
    {
      id: 791,
      url: 'https://www.ndrc.ie/masterclasses/growing-your-startup-hub',
    },
    {
      id: 792,
      url: 'https://www.ndrc.ie/accelerator-cohort-2022-h1',
    },
    {
      id: 793,
      url: 'https://www.ndrc.ie/masterclasses/startup-accounting',
    },
    {
      id: 794,
      url: 'https://www.ndrc.ie/pre-accelerator-cohort-2024-rdi',
    },
    {
      id: 795,
      url: 'https://www.ndrc.ie/masterclasses/raising-a-round',
    },
    {
      id: 796,
      url: 'https://www.ndrc.ie/accelerator-cohort-2022-h2',
    },
    {
      id: 797,
      url: 'https://www.ndrc.ie/masterclasses/building-a-compelling-pitch',
    },
    {
      id: 798,
      url: 'https://www.ndrc.ie/masterclasses/introduction-to-ndrc',
    },
    {
      id: 799,
      url: 'https://www.ndrc.ie/accelerator-cohort-2023-h1',
    },
    {
      id: 800,
      url: 'https://www.ndrc.ie/masterclasses/innovating-in-regulated-industries',
    },
    {
      id: 801,
      url: 'https://www.ndrc.ie/masterclasses/forming-a-startup-founding-team',
    },
    {
      id: 802,
      url: 'https://www.ndrc.ie/accelerator-cohort-2023-h2',
    },
    {
      id: 803,
      url: 'https://www.ndrc.ie/masterclasses/scaling-deeptech',
    },
    {
      id: 804,
      url: 'https://www.ndrc.ie/masterclasses/harnessing-generative-ai',
    },
    {
      id: 805,
      url: 'https://www.ndrc.ie/2050-sustainability-hackathon-with-greentech-hq',
    },
    {
      id: 806,
      url: 'https://www.ndrc.ie/masterclasses/shaping-future-ireland',
    },
    {
      id: 808,
      url: 'https://www.ndrc.ie/office-hours',
    },
    {
      id: 809,
      url: 'https://www.ndrc.ie/founder-weekend',
    },
    {
      id: 810,
      url: 'https://www.ndrc.ie/pre-accelerator',
    },
    {
      id: 812,
      url: 'https://www.ndrc.ie/accelerator-cohort-2024-h1',
    },
    {
      id: 813,
      url: 'https://www.ndrc.ie/startup-sprint',
    },
    {
      id: 814,
      url: 'https://www.ndrc.ie/masterclasses/elements-of-a-compelling-pitch',
    },
    {
      id: 816,
      url: 'https://www.ndrc.ie/impact-report-2024',
    },
    {
      id: 817,
      url: 'https://www.ndrc.ie/fierce',
    },
    {
      id: 818,
      url: 'https://ndrc.ie',
    },
    {
      id: 815,
      url: 'https://www.ndrc.ie/home',
    },
    {
      id: 782,
      url: 'https://www.ndrc.ie/apply',
    },
    {
      id: 807,
      url: 'https://www.ndrc.ie/accelerator',
    },
    {
      id: 811,
      url: 'https://www.ndrc.ie/masterclasses',
    },
    {
      id: 781,
      url: 'https://www.ndrc.ie/programmes',
    },
  ],
};
