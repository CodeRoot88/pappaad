import * as z from 'zod';

export const urlSchema = z.object({
  businessUrl: z
    .string()
    .min(1, 'Business URL is required')
    .url('Please enter a valid URL')
    .refine((url) => {
      try {
        new URL(url);
        return true;
      } catch {
        return false;
      }
    }, 'Please enter a valid URL'),
});

export type UrlFormData = z.infer<typeof urlSchema>;
