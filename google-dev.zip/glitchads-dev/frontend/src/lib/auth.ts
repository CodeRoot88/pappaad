import { jwtDecode } from 'jwt-decode';

import { UserProfile } from './types';

export const defaultProfile: UserProfile = {
  email: undefined,
  picture: undefined,
  name: undefined,
  role: undefined,
  impersonating_email: undefined
};

export const getCookie = (name: string) => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) {
    const cookieValue = parts.pop()?.split(';').shift();
    return cookieValue ? cookieValue : undefined;
  }
  return undefined;
};

export const isAuthenticated = () => {
  const token = getCookie('access_token');
  if (!token) return false;

  try {
    const decodedToken = jwtDecode(token);
    if (!decodedToken) {
      return false; // Token is invalid
    }
    const currentTime = Date.now() / 1000; // Current time in seconds
    if (decodedToken.exp && decodedToken.exp < currentTime) {
      return false; // Token has expired
    }
    return true; // Token is valid
  } catch (error) {
    return false; // Error decoding token
  }
};

export const deleteAccessTokenCookie = () => {
  document.cookie = 'access_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
};

export function getUserProfileFromToken(token?: string): UserProfile {
  if (!token)
    return defaultProfile;

  const decodedToken: UserProfile = jwtDecode(token);
  if (!decodedToken) {
    return defaultProfile;
  }

  const {
    email = undefined,
    picture = undefined,
    name = undefined,
    role = undefined,
    impersonating_email = undefined
  } = decodedToken;

  return { email, picture, name, role, impersonating_email };
}
