#!/bin/bash

set -eu

# Prompt the user for the migration description
read -p "Enter the migration description: " MIGRATION_DESC

# Ensure the description is not empty
if [[ -z "$MIGRATION_DESC" ]]; then
    echo "Migration description cannot be empty!"
    exit 1
fi

uv run alembic revision --autogenerate -m "$MIGRATION_DESC"


LATEST_HASH=$(uv run alembic heads | head -n 1 | awk '{print $1}')

echo "Latest migration hash: $LATEST_HASH"
