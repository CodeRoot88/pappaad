#!/bin/bash

# Exit the script if any command fails
set -e

# Step 1: Build the Docker image without cache
echo "Building the staging Docker image..."
docker buildx build --platform linux/amd64 --no-cache -t glitchads-staging .

# Step 2: Tag the Docker image
echo "Tagging the staging Docker image..."
docker tag glitchads-staging:latest europe-west4-docker.pkg.dev/gltichv2/glitch/glitchads-staging:latest

# Step 3: Push the Docker image to the registry
echo "Pushing the staging Docker image..."
docker push europe-west4-docker.pkg.dev/gltichv2/glitch/glitchads-staging:latest

echo "Staging Docker image deployed successfully!"
