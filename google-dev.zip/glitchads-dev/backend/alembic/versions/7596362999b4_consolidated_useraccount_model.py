"""Consolidated UserAccount Model

Revision ID: 7596362999b4
Revises: 3acecf3e5dc5
Create Date: 2024-11-22 08:57:10.934903

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = '7596362999b4'
down_revision: Union[str, None] = '3acecf3e5dc5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    # Change `google_refresh_token` to be nullable
    op.alter_column(
        'useraccount',
        'google_refresh_token',
        existing_type=sa.String(),
        nullable=True
    )


def downgrade():
    # Revert `google_refresh_token` to be non-nullable
    op.alter_column(
        'useraccount',
        'google_refresh_token',
        existing_type=sa.String(),
        nullable=False
    )
