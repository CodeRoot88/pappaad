"""Merge dev and feature branch migrations

Revision ID: d6dba67494fe
Revises: 7596362999b4, faf5adea0aa1
Create Date: 2024-11-22 20:46:59.062359

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = 'd6dba67494fe'
down_revision: Union[str, None] = ('7596362999b4', 'faf5adea0aa1')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
