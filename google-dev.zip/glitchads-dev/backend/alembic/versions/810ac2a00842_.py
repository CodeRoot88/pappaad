"""empty message
Revision ID: 810ac2a00842
Revises: 277e4ae3f2b3
Create Date: 2024-09-12 17:58:40.250922
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = '810ac2a00842'
down_revision: Union[str, None] = '277e4ae3f2b3'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass