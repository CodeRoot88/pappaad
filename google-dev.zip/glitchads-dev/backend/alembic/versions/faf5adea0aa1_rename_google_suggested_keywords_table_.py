"""rename google suggested keywords table to alternative keywords

Revision ID: faf5adea0aa1
Revises: 888b9afe5f2e
Create Date: 2024-11-22 14:35:04.670338

"""
from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = 'faf5adea0aa1'
down_revision: Union[str, None] = '888b9afe5f2e'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.rename_table('googlesuggestedkeyword', 'alternativekeyword')



def downgrade() -> None:
    op.rename_table('alternativekeyword', 'googlesuggestedkeyword')
