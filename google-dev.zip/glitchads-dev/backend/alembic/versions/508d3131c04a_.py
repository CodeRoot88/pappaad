"""empty message

Revision ID: 508d3131c04a
Revises: bb10685fd672, bfdcc7b6556d
Create Date: 2024-09-19 10:19:25.555076

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = '508d3131c04a'
down_revision: Union[str, None] = ('bb10685fd672', 'bfdcc7b6556d')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
