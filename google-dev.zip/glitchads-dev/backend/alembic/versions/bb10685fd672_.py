"""empty message

Revision ID: bb10685fd672
Revises: 3d318afa3c10, 63f3baff2879
Create Date: 2024-09-16 10:30:11.699055

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = 'bb10685fd672'
down_revision: Union[str, None] = ('3d318afa3c10', '63f3baff2879')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
