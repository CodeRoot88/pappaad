"""add more types to task tracking type

Revision ID: 298ef7431efc
Revises: 7f40a637904b
Create Date: 2024-11-25 09:32:31.928708

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = '298ef7431efc'
down_revision: Union[str, None] = '7f40a637904b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TYPE tasktrackingtype ADD VALUE 'KEYWORDS_GENERATION'")
    op.execute("ALTER TYPE tasktrackingtype ADD VALUE 'HEADLINE_GENERATION'")
    op.execute("ALTER TYPE tasktrackingtype ADD VALUE 'DESCRIPTIONS_GENERATION'")


def downgrade() -> None:
    op.execute("ALTER TYPE tasktrackingtype RENAME TO tasktrackingtype_old")
    op.execute("""
        CREATE TYPE tasktrackingtype AS ENUM (
            'AD_GENERATION',
            'SITE_LINK_GENERATION',
            'TCPA_GENERATION'
        )
    """)
    op.execute("""
        ALTER TABLE tasktracking
        ALTER COLUMN task_type TYPE tasktrackingtype
        USING task_type::text::tasktrackingtype
    """)

    op.execute("DROP TYPE tasktrackingtype_old")
