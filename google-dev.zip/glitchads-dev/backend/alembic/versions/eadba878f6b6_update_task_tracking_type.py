"""Update task tracking type

Revision ID: eadba878f6b6
Revises: c9d48505e91c
Create Date: 2024-10-29 15:38:58.965756

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel.sql.sqltypes


# revision identifiers, used by Alembic.
revision: str = 'eadba878f6b6'
down_revision: Union[str, None] = 'c9d48505e91c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add the new enum value
    op.execute("ALTER TYPE tasktrackingtype ADD VALUE 'TCPA_GENERATION'")

def downgrade() -> None:
    # Remove the enum value by recreating the enum type without it
    # Step 1: Rename the existing enum type
    op.execute("ALTER TYPE tasktrackingtype RENAME TO tasktrackingtype_old")
    
    # Step 2: Create a new enum type without 'TCPA_GENERATION'
    op.execute("CREATE TYPE tasktrackingtype AS ENUM('AD_GENERATION', 'SITE_LINK_GENERATION')")
    
    # Step 3: Alter the column to use the new enum type
    op.execute("""
        ALTER TABLE tasktracking
        ALTER COLUMN task_type TYPE tasktrackingtype
        USING task_type::text::tasktrackingtype
    """)
    
    # Step 4: Drop the old enum type
    op.execute("DROP TYPE tasktrackingtype_old")
