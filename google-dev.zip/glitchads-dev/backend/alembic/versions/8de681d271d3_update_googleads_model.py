"""Update googleads model

Revision ID: 8de681d271d3
Revises: eadba878f6b6
Create Date: 2024-11-07 22:44:18.364566

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '8de681d271d3'
down_revision = 'eadba878f6b6'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Rename table 'googleadscustomer' to 'googleadsaccount'
    op.rename_table('googleadscustomer', 'googleadsaccount')

    # Change data types and rename columns in 'googleadsaccount' table
    # First, rename 'ads_customer_id' to 'googleads_account_id' and change its type from BigInteger to String
    op.alter_column(
        'googleadsaccount',
        'ads_customer_id',
        new_column_name='googleads_account_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="ads_customer_id::varchar"
    )

    # Rename 'mcc_id' to 'manager_account_id' and change its type from BigInteger to String
    op.alter_column(
        'googleadsaccount',
        'mcc_id',
        new_column_name='manager_account_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="mcc_id::varchar"
    )

    # Update foreign key constraints in 'campaign' table
    # Drop the existing foreign key constraint
    op.drop_constraint('campaign_ads_customer_id_fkey', 'campaign', type_='foreignkey')

    # Rename the column in 'campaign' table
    op.alter_column(
        'campaign',
        'ads_customer_id',
        new_column_name='googleadsaccount_id',
        existing_type=sa.Integer()
    )

    # Recreate the foreign key constraint referencing the renamed table and column
    op.create_foreign_key(
        'campaign_googleadsaccount_id_fkey',  # Constraint name
        'campaign',  # Source table
        'googleadsaccount',  # Referent table
        ['googleadsaccount_id'],  # Local columns
        ['id']  # Remote columns
    )

    # Adjust columns and unique constraints in other tables
    # For 'googleadscallasset' table
    op.drop_constraint('uix_phone_number_asset', 'googleadscallasset', type_='unique')
    op.alter_column(
        'googleadscallasset',
        'google_ads_asset_id',
        new_column_name='googleads_asset_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="google_ads_asset_id::varchar"
    )
    op.create_unique_constraint('uix_phone_number_asset', 'googleadscallasset', ['phone_number_id', 'googleads_asset_id'])

    # For 'googleadscalloutasset' table
    op.drop_constraint('uix_callout_asset', 'googleadscalloutasset', type_='unique')
    op.alter_column(
        'googleadscalloutasset',
        'google_ads_asset_id',
        new_column_name='googleads_asset_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="google_ads_asset_id::varchar"
    )
    op.create_unique_constraint('uix_callout_asset', 'googleadscalloutasset', ['callout_id', 'googleads_asset_id'])

    # For 'googleadspriceasset' table
    op.drop_constraint('uix_price_asset', 'googleadspriceasset', type_='unique')
    op.alter_column(
        'googleadspriceasset',
        'google_ads_asset_id',
        new_column_name='googleads_asset_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="google_ads_asset_id::varchar"
    )
    op.create_unique_constraint('uix_price_asset', 'googleadspriceasset', ['price_id', 'googleads_asset_id'])

    # For 'googleadssitelinkasset' table
    op.drop_constraint('uix_site_link_asset', 'googleadssitelinkasset', type_='unique')
    op.alter_column(
        'googleadssitelinkasset',
        'google_ads_asset_id',
        new_column_name='googleads_asset_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="google_ads_asset_id::varchar"
    )
    op.create_unique_constraint('uix_site_link_asset', 'googleadssitelinkasset', ['site_link_id', 'googleads_asset_id'])

    # For 'googleadsstructuredsnippetasset' table
    op.drop_constraint('uix_site_structured_snippet_asset', 'googleadsstructuredsnippetasset', type_='unique')
    op.alter_column(
        'googleadsstructuredsnippetasset',
        'google_ads_asset_id',
        new_column_name='googleads_asset_id',
        type_=sa.String(),
        existing_type=sa.BigInteger(),
        postgresql_using="google_ads_asset_id::varchar"
    )
    op.create_unique_constraint('uix_site_structured_snippet_asset', 'googleadsstructuredsnippetasset', ['structured_snippet_id', 'googleads_asset_id'])


def downgrade() -> None:
    # Revert changes in 'googleadsstructuredsnippetasset' table
    op.drop_constraint('uix_site_structured_snippet_asset', 'googleadsstructuredsnippetasset', type_='unique')
    op.alter_column(
        'googleadsstructuredsnippetasset',
        'googleads_asset_id',
        new_column_name='google_ads_asset_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="googleads_asset_id::bigint"
    )
    op.create_unique_constraint('uix_site_structured_snippet_asset', 'googleadsstructuredsnippetasset', ['structured_snippet_id', 'google_ads_asset_id'])

    # Revert changes in 'googleadssitelinkasset' table
    op.drop_constraint('uix_site_link_asset', 'googleadssitelinkasset', type_='unique')
    op.alter_column(
        'googleadssitelinkasset',
        'googleads_asset_id',
        new_column_name='google_ads_asset_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="googleads_asset_id::bigint"
    )
    op.create_unique_constraint('uix_site_link_asset', 'googleadssitelinkasset', ['site_link_id', 'google_ads_asset_id'])

    # Revert changes in 'googleadspriceasset' table
    op.drop_constraint('uix_price_asset', 'googleadspriceasset', type_='unique')
    op.alter_column(
        'googleadspriceasset',
        'googleads_asset_id',
        new_column_name='google_ads_asset_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="googleads_asset_id::bigint"
    )
    op.create_unique_constraint('uix_price_asset', 'googleadspriceasset', ['price_id', 'google_ads_asset_id'])

    # Revert changes in 'googleadscalloutasset' table
    op.drop_constraint('uix_callout_asset', 'googleadscalloutasset', type_='unique')
    op.alter_column(
        'googleadscalloutasset',
        'googleads_asset_id',
        new_column_name='google_ads_asset_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="googleads_asset_id::bigint"
    )
    op.create_unique_constraint('uix_callout_asset', 'googleadscalloutasset', ['callout_id', 'google_ads_asset_id'])

    # Revert changes in 'googleadscallasset' table
    op.drop_constraint('uix_phone_number_asset', 'googleadscallasset', type_='unique')
    op.alter_column(
        'googleadscallasset',
        'googleads_asset_id',
        new_column_name='google_ads_asset_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="googleads_asset_id::bigint"
    )
    op.create_unique_constraint('uix_phone_number_asset', 'googleadscallasset', ['phone_number_id', 'google_ads_asset_id'])

    # Revert foreign key constraint in 'campaign' table
    op.drop_constraint('campaign_googleadsaccount_id_fkey', 'campaign', type_='foreignkey')
    op.alter_column(
        'campaign',
        'googleadsaccount_id',
        new_column_name='ads_customer_id',
        existing_type=sa.Integer()
    )
    op.create_foreign_key(
        'campaign_ads_customer_id_fkey',
        'campaign',
        'googleadscustomer',
        ['ads_customer_id'],
        ['id']
    )

    # Revert column renames and data types in 'googleadsaccount' table
    op.alter_column(
        'googleadsaccount',
        'googleads_account_id',
        new_column_name='ads_customer_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="googleads_account_id::bigint"
    )

    op.alter_column(
        'googleadsaccount',
        'manager_account_id',
        new_column_name='mcc_id',
        type_=sa.BigInteger(),
        existing_type=sa.String(),
        postgresql_using="manager_account_id::bigint"
    )

    # Rename table back to 'googleadscustomer'
    op.rename_table('googleadsaccount', 'googleadscustomer')
