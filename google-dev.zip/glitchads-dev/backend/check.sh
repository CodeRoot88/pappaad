#!/bin/bash

# Exit on error
set -xeu

# Step 1: Sync dependencies using uv
echo "Syncing dependencies..."
uv sync

# Step 2: Run Ruff linter to check the app folder
echo "Running Ruff linter..."
uv run ruff check app

# Step 3: Run Mypy for type checking on the app folder
#echo "Running Mypy type checker..."
#uv run mypy app

# Step 4: Run Pytest to execute tests in the tests folder
echo "Running Pytest..."
uv run pytest app

echo "All checks completed successfully."
