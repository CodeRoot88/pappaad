from sqlmodel import Session

from app.campaign.db_ops import update_campaign
from app.web_miner.scraper import get_url_content
from app.llm_services import gen_tcpa
from app.task_tracking.schemas import TaskTrackingType
from app.task_tracking.task_tracking_service_base import TaskTrackingService
from app.google_ads.db_ops import get_googleads_account_by_id
from app.google_ads.exception.exceptions import GoogleAdsAccountNotFoundErrorException
from app.campaign.db_ops import get_campaign_by_id


class TcpaCreateService(TaskTrackingService):
    def __init__(self, campaign_id: int, db: Session):
        super().__init__(db, campaign_id)
        campaign = get_campaign_by_id(campaign_id, db)
        self.campaign = campaign

    def create_tcpa(self) -> None:
        self.execute_task_with_tracking(task_type=TaskTrackingType.TCPA_GENERATION)

    def run_task(self) -> None:
        self.generate_tcpa()

    def generate_tcpa(self) -> None:
        site_data = get_url_content(self.campaign.website_url, self.db)
        if not self.campaign.googleadsaccount_id:
            raise GoogleAdsAccountNotFoundErrorException("Google Ads Account Not Found")
        google_ads_account = get_googleads_account_by_id(self.campaign.googleadsaccount_id, self.db)
        if not google_ads_account:
            raise GoogleAdsAccountNotFoundErrorException("Google Ads Account Not Found")
        if site_data.content:
            tcpa_data = gen_tcpa(
                site_data.content, google_ads_account.currency if google_ads_account.currency else "USD"
            )
            update_campaign(
                updated_data={"target_cpa": tcpa_data.tcpa, "target_cpa_explanation": tcpa_data.summary},
                campaign_id=self.campaign.id,
                db=self.db,
            )
