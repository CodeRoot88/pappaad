import logging

from sqlmodel import Session

from app.campaign.asset_models import CalloutBase, SiteLinkNewOrUpdate
from app.campaign.db_ops import add_callout, add_site_link
from app.campaign.models import CampaignReadWithoutAssociations
from app.llm_services import gen_sitelink_name_descriptions_and_callout
from app.task_tracking.schemas import TaskTrackingType
from app.task_tracking.task_tracking_service_base import TaskTrackingService
from app.web_miner.scraper import get_url_content, is_url_reachable

logger = logging.getLogger(__name__)


class AssetsCreateService(TaskTrackingService):
    def __init__(self, campaign: CampaignReadWithoutAssociations, db: Session, url: str):
        super().__init__(db, campaign.id)
        self.url = url

    def create_assets(self):
        return self.execute_task_with_tracking(task_type=TaskTrackingType.SITE_LINK_GENERATION)

    def run_task(self):
        return self.generate_assets()

    def generate_assets(self):
        url = self.url
        if not is_url_reachable(url):
            return

        db = self.db
        campaign_id = self.campaign_id
        site_data = get_url_content(url, db)
        try:
            sitelink_name_descriptions = gen_sitelink_name_descriptions_and_callout(url=url, content=site_data.content)
        except Exception as e:
            logger.error(f"Failed to generate site link for url: {url}, error: {e}")
            return
        callout = CalloutBase(text=sitelink_name_descriptions.callout)
        add_callout(campaign_id=campaign_id, db=db, new_callout=callout)
        site_link = SiteLinkNewOrUpdate(
            url=url,
            name=sitelink_name_descriptions.name,
            content="",
            markdown_content=site_data.content,
            description1=sitelink_name_descriptions.description1,
            description2=sitelink_name_descriptions.description2,
        )
        add_site_link(campaign_id=campaign_id, db=db, new_site_link=site_link)
