from fastapi import BackgroundTasks
from sqlmodel import Session

from app.ad.services.ad_create import AdCreateService, FocusedAdCreateService
from app.campaign.db_ops import add_campaign, update_campaign, get_campaign_by_name_and_account
from app.campaign.models import CampaignCreate, CampaignReadWithoutAssociations, CampaignWithGoogleAdsAccount, Campaign
from app.campaign.services.assets_create import AssetsCreateService
from app.campaign.services.tcpa import TcpaCreateService

from app.google_ads.db_ops import get_current_user_selected_google_ads_customer
from app.google_ads.models import GoogleAdsAccountData
from app.llm_services import get_recommended_urls_for_ads, generate_campaign_name_from_content
from app.user.models import UserAccountData
from app.web_miner.scraper import get_url_content


class CampaignCreateService:
    def __init__(self, user: UserAccountData, db: Session, bgts: BackgroundTasks):
        self.db = db
        self.bgts = bgts
        self.user = user

    async def create_campaign(self, campaign: CampaignCreate) -> CampaignWithGoogleAdsAccount:
        new_campaign = add_campaign(campaign, self.db)

        self.campaign = CampaignReadWithoutAssociations.model_validate(new_campaign)
        self.bgts.add_task(
            update_campaign,
            self.campaign.id,
            {"name": self.generate_campaign_name(new_campaign)},
            self.db,
        )
        # fetch the urls while creating the campaign
        # so it makes it faster to load up the tasks when we need to create ads
        site_links = get_url_content(self.campaign.website_url, self.db).links
        if not site_links:
            # need to handle this front end as well.
            raise Exception("No site links found")

        self.bgts.add_task(self.post_campaign_creation_actions, site_links)
        return CampaignWithGoogleAdsAccount.model_validate(new_campaign)

    def post_campaign_creation_actions(self, site_links: list[str]):
        self.bgts.add_task(self.create_ads, site_links)
        self.bgts.add_task(self.create_assets, site_links)
        self.bgts.add_task(TcpaCreateService(self.campaign.id, self.db).create_tcpa)

    def create_ads(self, site_links: list[str]):
        refresh_token = self.user.google_refresh_token
        if refresh_token is None:
            raise Exception("User has no Google refresh token")
        googleads_account = get_current_user_selected_google_ads_customer(self.user.id, self.db)
        if googleads_account is None:
            raise Exception("Google Ads account not found for ad generation")

        if self.campaign.goal == "focused":
            self.create_ads_for_focused_campaign(self.campaign.website_url, googleads_account, refresh_token)
        else:
            self.create_ads_for_prospecting_campaign(site_links, googleads_account, refresh_token)

    def create_ads_for_prospecting_campaign(
        self, site_links: list[str], googleads_account: GoogleAdsAccountData, refresh_token: str
    ):
        urls = get_recommended_urls_for_ads(site_links).urls
        for url in urls:
            self.bgts.add_task(
                AdCreateService(
                    campaign=self.campaign,
                    db=self.db,
                    url=url,
                    googleads_account_id=googleads_account.googleads_account_id,
                    google_manager_account_id=googleads_account.manager_account_id,
                    google_refresh_token=refresh_token,
                    bgts=self.bgts,
                ).create_ad
            )

    def create_ads_for_focused_campaign(
        self, website_url: str, googleads_account: GoogleAdsAccountData, refresh_token: str
    ):
        for i in range(5):
            self.bgts.add_task(
                FocusedAdCreateService(
                    campaign=self.campaign,
                    db=self.db,
                    url=website_url,
                    googleads_account_id=googleads_account.googleads_account_id,
                    google_manager_account_id=googleads_account.manager_account_id,
                    google_refresh_token=refresh_token,
                    bgts=self.bgts,
                    number=i,
                ).create_ad
            )

    def create_assets(self, site_links: list[str]):
        urls = get_recommended_urls_for_ads(site_links, num=10).urls
        for url in urls:
            self.bgts.add_task(AssetsCreateService(self.campaign, self.db, url).create_assets)

    def generate_campaign_name(self, campaign):
        name = generate_campaign_name_from_content(
            campaign.business_desc, campaign.target_locations[0].name, campaign.goal
        )
        return name.name

    def add_campaign_name_to_campaign(self, campaign: Campaign):
        campaign.name = self.generate_campaign_name(campaign)
        campaign.name = self.get_unique_name(campaign.name, campaign.googleadsaccount_id)
        update_campaign(campaign.id, {"name": campaign.name}, self.db)

    def get_unique_name(self, base_name: str, googleadsaccount_id: int) -> str:
        # If name already exists in this account, try incrementing any number at the end
        if get_campaign_by_name_and_account(base_name, googleadsaccount_id, self.db):
            # Split the name into base and number if it ends with a number
            parts = base_name.rsplit(" ", 1)
            if len(parts) > 1 and parts[1].isdigit():
                new_name = f"{parts[0]} {int(parts[1]) + 1}"
            else:
                new_name = f"{base_name} 1"
            return self.get_unique_name(new_name, googleadsaccount_id)
        return base_name
