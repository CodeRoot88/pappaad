from typing import Optional

from fastapi import BackgroundTasks, HTTPException, status
from google.ads.googleads.client import GoogleAdsClient
from nanoid import generate
from sqlmodel import Session

from app.ad.db_ops import (
    add_ad,
    get_ad_by_id,
)
from app.auth.exception.exceptions import GoogleRefreshTokenEmptyException
from app.ad.models import Ad

from app.campaign.asset_models import (
    CalloutBase,
    PriceBase,
    PriceFrequency,
    PriceQualifier,
    PriceType,
    SiteLinkNewOrUpdate,
    StructuredSnippetCreate,
    StructuredSnippetValueBase,
)
from app.task_tracking.db_ops import create_task_tracking, update_task_tracking
from app.campaign.db_ops import (
    add_callout,
    add_campaign,
    add_price,
    add_site_link,
    add_structured_snippet,
    copy_campaign,
    get_campaign_by_id,
    get_campaign_errors,
    get_campaign_recommendations_by_type,
    get_location_by_criteria_id,
    remove_campaign,
    remove_campaign_errors_by_campaign_id,
)
from app.campaign.models import (
    Campaign,
    CampaignCreate,
    CampaignData,
    CampaignRecommendation,
    CampaignRecommendationData,
    ErrorData,
)
from app.campaign.schemas import CampaignRecommendations
from app.task_tracking.schemas import TaskTrackingState, TaskTrackingType
from app.common_state_enums import RecommendationState, RecommendationType
from app.google_ads.db_ops import (
    add_googleads_ad,
    add_googleads_ad_group,
    add_googleads_campaign,
    add_googleads_keyword,
    get_googleads_campaign_by_campaign_id,
)
from app.google_ads.services import (
    GoogleAdsService,
)
from app.google_ads_integration.ad import GoogleAdsAdIntegration
from app.google_ads_integration.asset import GoogleAdsAssetIntegration
from app.google_ads_integration.campaign.base import GoogleAdsCampaignIntegration
from app.google_ads_integration.keywords import GoogleAdsKeywordIntegration
from app.google_ads_integration.location import GoogleAdsLocationIntegration
from app.headline.db_ops import add_description, add_headline
from app.keyword.db_ops import add_keyword
from app.user.db_ops import get_user_account_by_id
from app.user.models import UserAccountData


class CampaignService:
    def __init__(self, user: UserAccountData, db: Session, bgts: BackgroundTasks):
        self.db = db
        self.bgts = bgts
        self.user_id = user.id
        self.user = user
        self.campaign: Campaign | None = None

    def create_campaign_from_googleads(
        self, client: GoogleAdsClient, googleads_account_id: str, googleads_campaign_id: str, googleadsaccount_id: int
    ) -> CampaignData:
        googleads_locations = GoogleAdsLocationIntegration(
            client=client, googleads_account_id=googleads_account_id, googleads_campaign_id=googleads_campaign_id
        ).get_locations_for_googleads_campaign()

        db_locations = []
        for googleads_location in googleads_locations:
            criteria_id = googleads_location.location.geo_target_constant.split("/")[1]
            db_location = get_location_by_criteria_id(int(criteria_id), db=self.db)
            db_locations.append(db_location)

        googleads_campaign_service = GoogleAdsCampaignIntegration(
            googleads_account_id=googleads_account_id,
            client=client,
            googleads_campaign_id=googleads_campaign_id,
            campaign=None,
        )
        googleads_campaign = googleads_campaign_service.get_googleads_campaign_by_id()

        googleads_website_url = googleads_campaign_service.get_website_url_for_campaign()
        campaign_data = CampaignCreate(
            slug=generate(size=10),
            name=googleads_campaign["name"],
            website_url=googleads_website_url,
            goal="MOCK_GOAL",  # Todo
            business_desc=None,
            user_account_id=self.user.id,
            googleadsaccount_id=googleadsaccount_id,
            target_locations=db_locations,
            budget=int(googleads_campaign["amount_micros"] / 1000000)
            if googleads_campaign["total_amount_micros"] is not None
            else 0,
            target_cpa=int(googleads_campaign["target_cpa"] / 1000000)
            if googleads_campaign["target_cpa"] is not None
            else 0,
        )
        created_campaign = add_campaign(campaign_data, self.db)

        self.campaign = created_campaign
        googleads_campaign_service.campaign = created_campaign

        add_googleads_campaign(created_campaign.id, googleads_campaign_id, self.db)
        return created_campaign

    def googleads_create_campaign(
        self, googleads_account_id: str, campaign: CampaignData, refresh_token=None, manager_account_id=None
    ):
        if not refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

        GoogleAdsService(
            googleads_account_id=googleads_account_id,
            db=self.db,
            refresh_token=refresh_token,
            googleads_manager_account_id=manager_account_id,
        ).create_campaign_in_googleads(campaign)

    def googleads_update_campaign(self, googleads_account_id, campaign, refresh_token=None, manager_account_id=None):
        if not refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

        GoogleAdsService(
            db=self.db,
            refresh_token=refresh_token,
            googleads_account_id=googleads_account_id,
            googleads_manager_account_id=manager_account_id,
        ).update_campaign_in_googleads(campaign)

    def set_budget_by_recommendation(
        self, campaign_id: int, googleads_account_id: str, manager_account_id: Optional[str] = None
    ):
        campaign = get_campaign_by_id(campaign_id, self.db)
        if campaign and campaign.id:
            campaign.budget = self.get_budget_recommendation(campaign.id, googleads_account_id, manager_account_id)
            self.db.add(campaign)
            self.db.commit()

    def get_budget_recommendation(
        self, campaign_id: int, googleads_account_id: str, manager_account_id: Optional[str] = None
    ):
        return self.get_googleads_budget_recommendation(campaign_id, googleads_account_id, manager_account_id)

    def get_googleads_budget_recommendation(
        self, campaign_id: int, googleads_account_id: str, manager_account_id: str | None = None
    ):
        user = get_user_account_by_id(self.user_id, self.db)
        if not self.campaign:
            self.campaign = get_campaign_by_id(campaign_id, self.db)
        if not user:
            return 0
        if not self.campaign or not self.campaign.id or not self.campaign.website_url:
            return 0

        if not user.google_refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

        return GoogleAdsService(
            db=self.db,
            refresh_token=user.google_refresh_token,
            googleads_account_id=googleads_account_id,
            googleads_manager_account_id=manager_account_id,
        ).get_budget_recommendation(url=self.campaign.website_url, glitch_campaign_id=self.campaign.id)

    def forecast_campaign(self, googleads_account_id: str, campaign: Campaign):
        user = get_user_account_by_id(self.user_id, self.db)
        if not user:
            raise Exception("User not found for campaign forecast")

        if not user.google_refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

        return GoogleAdsService(
            db=self.db, refresh_token=user.google_refresh_token, googleads_account_id=googleads_account_id
        ).forecast_campaign(campaign)

    def delete_campaign(
        self, googleads_account_id: str, campaign: CampaignData, refresh_token=None, manager_account_id=None
    ):
        if not refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")
        googleads_campaign = get_googleads_campaign_by_campaign_id(campaign.id, self.db)
        if googleads_campaign:
            try:
                googleads_service = GoogleAdsService(
                    db=self.db,
                    refresh_token=refresh_token,
                    googleads_account_id=googleads_account_id,
                    googleads_manager_account_id=manager_account_id,
                )
                googleads_campaign_budget_id = GoogleAdsCampaignIntegration(
                    googleads_account_id=googleads_account_id,
                    client=googleads_service.client,
                    campaign=campaign,
                    googleads_campaign_id=googleads_campaign.googleads_campaign_id,
                ).get_googleads_campaign_budget()
                googleads_service.delete_campaign(
                    googleads_campaign_id=googleads_campaign.googleads_campaign_id,
                    googleads_budget_id=googleads_campaign_budget_id,
                )
            except Exception as e:
                print(e)
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Failed to delete campaign in Google Ads",
                )

        remove_campaign(campaign.id, self.db)

    def delete_campaign_errors(self, campaignId: int):
        try:
            remove_campaign_errors_by_campaign_id(campaign_id=campaignId, db=self.db)

        except Exception as e:
            print(e)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to delete campaign errors",
            )

    def fetch_googleads_campaigns(self, googleads_account_id: str, refresh_token=None, manager_account_id=None):
        if not refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")
        googleads_service = GoogleAdsService(
            db=self.db,
            refresh_token=refresh_token,
            googleads_account_id=googleads_account_id,
            googleads_manager_account_id=manager_account_id,
        )

        return GoogleAdsCampaignIntegration(
            googleads_account_id=googleads_account_id,
            client=googleads_service.client,
            campaign=None,
            googleads_campaign_id=None,
        ).get_all_googleads_campaigns()

    def import_googleads_campaign(
        self,
        googleads_account_id: str,
        googleadsaccount_id: int,
        googleads_campaign_id: str,
        refresh_token=None,
        manager_account_id=None,
    ):
        if not refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

        client = GoogleAdsService(
            db=self.db,
            refresh_token=refresh_token,
            googleads_account_id=googleads_account_id,
            googleads_manager_account_id=manager_account_id,
        ).client

        created_campaign = self.create_campaign_from_googleads(
            client=client,
            googleads_account_id=googleads_account_id,
            googleads_campaign_id=googleads_campaign_id,
            googleadsaccount_id=googleadsaccount_id,
        )
        self.campaign = created_campaign

        self.post_googleads_campaign_creation_actions(
            client=client,
            googleads_account_id=googleads_account_id,
            googleads_campaign_id=googleads_campaign_id,
            campaign=created_campaign,
        )

        return created_campaign

    def post_googleads_campaign_creation_actions(self, client, googleads_account_id, googleads_campaign_id, campaign):
        self.bgts.add_task(
            self.add_googleads_assets_to_glitchads, googleads_account_id, client, campaign.id, googleads_campaign_id
        )

        self.bgts.add_task(
            self.add_googleads_keyword_headlines_description_to_glitchads,
            client,
            googleads_account_id,
            campaign,
            googleads_campaign_id,
        )

    def add_googleads_assets_to_glitchads(
        self, googleads_account_id, client, glitch_campaign_id, googleads_campaign_id
    ):
        googleads_assets_service = GoogleAdsAssetIntegration(
            client=client,
            googleads_account_id=googleads_account_id,
            campaign_id=glitch_campaign_id,
            googleads_campaign_id=googleads_campaign_id,
        )
        try:
            task_tracking = create_task_tracking(
                campaign_id=glitch_campaign_id, db=self.db, task_type=TaskTrackingType.SITE_LINK_GENERATION
            )
            # Add ga assets site links to glitchads
            googleads_assets_site_links = googleads_assets_service.get_googleads_sitelinks_for_campaign()
            for googleads_site_link in googleads_assets_site_links:
                new_site_link = SiteLinkNewOrUpdate(
                    name=googleads_site_link.sitelink_asset.link_text,
                    url=googleads_site_link.final_urls[0],
                    description1=googleads_site_link.sitelink_asset.description1,
                    description2=googleads_site_link.sitelink_asset.description2,
                )
                add_site_link(glitch_campaign_id, self.db, new_site_link)

            # Add ga assets callout to glitchads
            googleads_assets_callouts = googleads_assets_service.get_googleads_callouts_for_campaign()
            for googleads_callout in googleads_assets_callouts:
                callout_text = googleads_callout.callout_asset.callout_text
                callout = CalloutBase(text=callout_text)
                add_callout(glitch_campaign_id, self.db, callout)

            googleads_assets_prices = googleads_assets_service.get_googleads_prices_for_campaign()
            for googleads_price in googleads_assets_prices:
                type = googleads_price.price_asset.type_.name
                qualifier = googleads_price.price_asset.price_qualifier
                frequency = None  # Todo
                price_offerings = googleads_price.price_asset.price_offerings

                for offering in price_offerings:
                    header = offering.header
                    description = offering.description
                    price_amount = offering.price.amount_micros
                    currency_code = offering.price.currency_code
                    final_url = offering.final_url

                    actual_price = int(price_amount) / 1000000 if price_amount is not None else 0

                    price_base = PriceBase(
                        type=getattr(PriceType, type, PriceType.UNKNOWN),
                        currency=currency_code,
                        qualifier=qualifier if qualifier is not None else PriceQualifier.NO_QUALIFIER,
                        header=header,
                        value=actual_price,
                        frequency=frequency if frequency is not None else PriceFrequency.NO_UNITS,
                        description=description,
                        final_url=final_url,
                        mobile_url=None,
                    )
                    add_price(glitch_campaign_id, self.db, price_base)

            googleads_assets_structured_snippets = (
                googleads_assets_service.get_googleads_structured_snippets_for_campaign()
            )
            snippet_values = []
            for googleads_structured_snippet in googleads_assets_structured_snippets:
                value = googleads_structured_snippet.structured_snippet_asset.value
                snippet_values.append(StructuredSnippetValueBase(value))
                add_structured_snippet(glitch_campaign_id, self.db, StructuredSnippetCreate(values=snippet_values))

            update_task_tracking(db=self.db, task_id=task_tracking.id, state=TaskTrackingState.COMPLETED)

        except Exception as e:
            update_task_tracking(
                db=self.db,
                task_id=task_tracking.id,
                state=TaskTrackingState.FAILED,
                error_message=str(e),
            )

    def add_googleads_keyword_headlines_description_to_glitchads(
        self, client, googleads_account_id: str, googleads_campaign_id: str, campaign: CampaignData
    ):
        googleads_ads = GoogleAdsAdIntegration(
            client=client, googleads_account_id=googleads_account_id, googleads_campaign_id=googleads_campaign_id
        ).get_googleads_ads()

        if googleads_ads:
            for googleads_ad in googleads_ads:
                task_tracking = create_task_tracking(
                    campaign_id=campaign.id, db=self.db, task_type=TaskTrackingType.AD_GENERATION
                )
                try:
                    ad_data = Ad(
                        campaign_id=campaign.id,
                        slug=generate(size=10),
                        url=googleads_ad["ad_group_ad_url"][0],
                    )
                    created_ad = add_ad(
                        ad_data,
                        db=self.db,
                    )

                    add_googleads_ad_group(
                        googleads_campaign_id=campaign,
                        googleads_ad_group_id=googleads_ad["ad_group_id"],
                        ad_id=created_ad.id,
                        db=self.db,
                    )

                    add_googleads_ad(
                        googleads_ad_group_id=googleads_ad["ad_group_id"],
                        googleads_ad_id=googleads_ad["ad_group_ad_id"],
                        ad_id=created_ad.id,
                        db=self.db,
                    )

                    # add keyword
                    # TODO: Get keywords based on ad group instead of individual ads,
                    # as there's no way to determine which ad a keyword is related to.

                    googleads_ad_group_id = googleads_ad["ad_group_id"]
                    keywords = GoogleAdsKeywordIntegration().get_keywords_text_for_ad_group(
                        client=client, googleads_account_id=googleads_account_id, ad_group_id=googleads_ad_group_id
                    )
                    for keyword in keywords:
                        created_keyword = add_keyword(ad_id=created_ad.id, text=keyword, db=self.db)
                        add_googleads_keyword(created_keyword.id, ad_id=created_ad.id, db=self.db)
                    for headline in googleads_ad["ad_group_ad_headlines"]:
                        add_headline(ad_id=created_ad.id, text=headline, keyword_id=None, db=self.db)

                    for description in googleads_ad["ad_group_ad_descriptions"]:
                        add_description(ad_id=created_ad.id, text=description, db=self.db)

                    update_task_tracking(db=self.db, task_id=task_tracking.id, state=TaskTrackingState.COMPLETED)
                except Exception as e:
                    update_task_tracking(
                        db=self.db,
                        task_id=task_tracking.id,
                        state=TaskTrackingState.FAILED,
                        error_message=str(e),
                    )


def get_and_parse_campaign_errors(campaign_id: int, db: Session) -> list[ErrorData]:
    errors = []
    campaign_errors = get_campaign_errors(campaign_id, db)
    for error in campaign_errors:
        if error.class_name == "Ad":
            ad = get_ad_by_id(error.class_id, db)
            if ad:
                errors.append(ErrorData(error_type="Ad", error_data=ad))
        else:
            errors.append(ErrorData(error_type=error.class_name, error_data=None))
    return errors


def check_campaign_all_instant_fix_applied(campaign_recommendation: CampaignRecommendation) -> bool:
    """
    Check if all AdRecommendations associated with a CampaignRecommendation
    have the state INSTANT_FIX_APPLIED.
    """
    return all(
        ad_rec.state == RecommendationState.INSTANT_FIX_APPLIED for ad_rec in campaign_recommendation.ad_recommendations
    )


def get_latest_recommendation(
    campaign_id: int, db: Session, recommendation_type: RecommendationType
) -> CampaignRecommendationData | None:
    recommendations = get_campaign_recommendations_by_type(campaign_id, db, recommendation_type)
    if recommendations:
        recommendation = recommendations[0]
        if recommendation.state == RecommendationState.PENDING:
            return recommendation
    return None


def get_latest_campaign_recommendations(campaign_id: int, db: Session) -> CampaignRecommendations:
    recommendations = []
    new_recommendation = get_latest_recommendation(campaign_id, db, RecommendationType.NEW_KEYWORD)
    if new_recommendation:
        recommendations.append(new_recommendation)

    underperforming_recommendation = get_latest_recommendation(
        campaign_id, db, RecommendationType.UNDERPERFORMING_KEYWORD
    )
    if underperforming_recommendation:
        recommendations.append(underperforming_recommendation)

    return CampaignRecommendations(recommendations=recommendations)


def copy_campaign_and_associations(campagin: CampaignData, db: Session) -> CampaignData:
    return copy_campaign(campagin, db)


class CampaignStateManager:
    def __init__(self, db: Session, bgts: BackgroundTasks, campaign: CampaignData):
        self.db = db
        self.bgts = bgts
        self.campaign = campaign
        self.campaign_id = campaign.id
        self.state = campaign.state
        self.ad_states = [ad.state.value for ad in self.campaign.ads]
        self.ad_state = "pending"
        if all(state == "approved" for state in self.ad_states):
            self.ad_state = "approved"
        self.budget_state = self.campaign.budget_state.value
        self.assets_state = self.campaign.assets_state.value
        self.settings_state = self.campaign.settings_state.value

    def is_campaign_approved(self) -> bool:
        return self.state == "approved"

    def are_asset_ads_settings_approved(self) -> bool:
        return self.assets_state == "approved" and self.ad_state == "approved" and self.settings_state == "approved"
