class CampaignNotFoundError(Exception):
    def __init__(self, detail: str = "Campaign Not Found."):
        self.detail = detail


class CampaignCreationError(Exception):
    def __init__(self, detail: str = "Failed to create Campaign."):
        self.detail = detail
