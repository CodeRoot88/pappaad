from enum import Enum
from typing import TYPE_CHECKING, Optional

from sqlmodel import (
    Field,
    Relationship,
    SQLModel,
)

from sqlalchemy import Column, Integer, ForeignKey

from pydantic import field_validator

from helper.check_emoji import validate_no_emojis

if TYPE_CHECKING:
    from .models import Campaign


class SiteLinkBase(SQLModel):
    name: str
    url: str
    description1: str
    description2: str
    content: Optional[str] = None
    markdown_content: Optional[str] = None


class SiteLinkNewOrUpdate(SiteLinkBase):
    id: Optional[int] = None


class SiteLink(SiteLinkBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )
    campaign: Optional["Campaign"] = Relationship(back_populates="site_links")


class SiteLinkData(SiteLinkBase):
    id: int


class CalloutBase(SQLModel):
    text: str

    @field_validator("text")
    def validate_text_no_emojis(cls, value: str) -> str:
        return validate_no_emojis(value)


class CalloutCreateOrUpdate(CalloutBase):
    id: int | None = None


class Callout(CalloutBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )
    campaign: "Campaign" = Relationship(back_populates="callouts")


class PhoneNumber(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    value: Optional[str] = None
    country_code: Optional[str] = None
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )
    campaign: Optional["Campaign"] = Relationship(back_populates="phone_numbers")


class HeaderType(str, Enum):
    AMENITIES = "amenities"
    BRANDS = "brands"
    COURSES = "courses"
    DEGREE_PROGRAMS = "degree programs"
    DESTINATIONS = "destinations"
    FEATURED_HOTELS = "featured hotels"
    INSURANCE_COVERAGE = "insurance coverage"
    MODELS = "models"
    NEIGHBORHOODS = "neighborhoods"
    SERVICE_CATALOG = "services (service catalog)"
    SHOWS = "shows"
    STYLES = "styles"
    TYPES = "types"
    VENUES = "venues"


class StructuredSnippetBase(SQLModel):
    header_type: HeaderType


class StructuredSnippetCreate(StructuredSnippetBase):
    values: list["StructuredSnippetValueBase"]


class StructuredSnippetUpdate(StructuredSnippetCreate):
    id: int


class StructuredSnippetData(StructuredSnippetBase):
    id: int
    values: list["StructuredSnippetValueBase"]


class StructuredSnippet(StructuredSnippetBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )
    campaign: "Campaign" = Relationship(back_populates="structured_snippets")
    values: list["StructuredSnippetValue"] = Relationship(
        back_populates="structured_snippet", sa_relationship_kwargs={"cascade": "all, delete"}
    )


class StructuredSnippetValueBase(SQLModel):
    value: str


class StructuredSnippetValueCreate(StructuredSnippetBase):
    structured_snippet_id: int


class StructuredSnippetValueUpdate(StructuredSnippetValueCreate):
    id: int


class StructuredSnippetValue(StructuredSnippetValueBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    structured_snippet_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("structuredsnippet.id", ondelete="CASCADE"))
    )
    structured_snippet: StructuredSnippet = Relationship(back_populates="values")


class PriceType(str, Enum):
    UNSPECIFIED = "unspecified"
    UNKNOWN = "unknown"
    BRANDS = "brands"
    EVENTS = "events"
    LOCATIONS = "locations"
    NEIGHBORHOODS = "neighborhoods"
    PRODUCT_CATEGORIES = "product categories"
    PRODUCT_TIERS = "product tiers"
    SERVICES = "services"
    SERVICE_TIERS = "service tiers"
    SERVICE_CATEGORIES = "service_categories"


class PriceFrequency(str, Enum):
    NO_UNITS = "no units"
    PER_HOUR = "per hour"
    PER_DAY = "per day"
    PER_WEEK = "per week"
    PER_MONTH = "per month"
    PER_YEAR = "per year"
    PER_NIGHT = "per night"


class PriceQualifier(str, Enum):
    NO_QUALIFIER = "no qualifier"
    FROM = "from"
    UP_TO = "up to"
    AVERAGE = "average"


class PriceBase(SQLModel):
    type: PriceType
    currency: str
    qualifier: PriceQualifier
    header: str
    value: float
    frequency: PriceFrequency
    description: str
    final_url: str
    mobile_url: Optional[str] = None


class Price(PriceBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )

    campaign: "Campaign" = Relationship(back_populates="prices")


class PriceCreate(PriceBase):
    pass


class PriceUpdate(PriceBase):
    id: int


class PriceRead(PriceBase):
    id: int
