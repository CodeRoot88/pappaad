from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from pydantic import BaseModel
from sqlmodel import Session

from app.ad.db_ops import (
    get_ad_recommendations,
    get_keyword_recommendations,
    remove_keyword_and_update_state,
    update_ad_recommendation_state,
)
from app.auth.exception.exceptions import GoogleRefreshTokenEmptyException
from app.campaign.asset_models import (
    CalloutCreateOrUpdate,
    PriceCreate,
    PriceRead,
    PriceUpdate,
    SiteLinkNewOrUpdate,
    StructuredSnippetCreate,
    StructuredSnippetData,
    StructuredSnippetUpdate,
)
from app.campaign.db_ops import (
    add_callout,
    add_price,
    add_site_link,
    add_structured_snippet,
    delete_all_campaign_errors,
    delete_price,
    delete_structured_snippet,
    get_callout_by_id,
    get_campaign_level_recommendation,
    get_price_by_id,
    get_site_link_by_id,
    get_structured_snippet_by_id,
    get_user_ads_customer_campaigns,
    update_callout,
    update_campaign_recommendation_state,
    update_campaign_state,
    update_db_campaign,
    update_price,
    update_site_link,
    update_structured_snippet,
)
from app.campaign.models import (
    CampaignCreate,
    CampaignData,
    CampaignDataWithErrors,
    CampaignState,
    CampaignUpdate,
    CampaignWithGoogleAdsAccount,
    GoogleAdsLocation,
    NewCampaignParams,
)
from app.campaign.schemas import CampaignRecommendations
from app.campaign.services import (
    CampaignService,
    CampaignStateManager,
    copy_campaign_and_associations,
    get_and_parse_campaign_errors,
    get_latest_campaign_recommendations,
)
from app.campaign.services.campaign_create import CampaignCreateService
from app.campaign.services.tcpa import TcpaCreateService
from app.database import get_db_session
from app.endpoint_dependencies import (
    get_current_googleads_account,
    get_current_user,
    get_user_campaign,
)
from app.google_ads.db_ops import get_googleads_campaign_by_campaign_id, get_googleads_campaign_by_googleads_campaign_id
from app.google_ads.models import GoogleAdsAccountData
from app.google_ads.services import GoogleAdsService
from app.recommendations.services import get_campaign_action_logs, run_zero_impression_optimisation
from app.user.models import UserAccountData
from app.web_miner.scraper import get_url_content, is_url_reachable

router = APIRouter()


@router.post("/campaigns", response_model=CampaignWithGoogleAdsAccount)
async def create_campaign(
    campaign: NewCampaignParams,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db_session),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    new_campaign = CampaignCreate(
        user_account_id=current_user.id,
        googleadsaccount_id=googleads_account.id,
        **campaign.model_dump(),
    )
    new_campaign = await CampaignCreateService(user=current_user, db=db, bgts=background_tasks).create_campaign(
        new_campaign
    )
    return new_campaign


@router.get("/campaigns/description")
async def gen_campaign_description(
    url: str,
    db: Session = Depends(get_db_session),
):
    is_valid_url = is_url_reachable(url)
    if not is_valid_url:
        raise HTTPException(status_code=400, detail="This Url can not be reachable")
    try:
        scraped_data = get_url_content(url, db)
    except Exception:
        raise HTTPException(status_code=400, detail="Failed read the site content")

    return {"description": scraped_data.description}


@router.get("/locations", response_model=list[GoogleAdsLocation])
def search_locations(
    name: str,
    db: Session = Depends(get_db_session),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    if current_user.google_refresh_token is None:
        raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")
    suggestions = GoogleAdsService(
        db=db,
        refresh_token=current_user.google_refresh_token,
        googleads_account_id=googleads_account.googleads_account_id,
        googleads_manager_account_id=googleads_account.manager_account_id,
    ).get_geo_target_suggestions_by_search_string(name)
    return suggestions


@router.get("/locations/nearby", response_model=list[GoogleAdsLocation])
def get_nearby_locations(
    db: Session = Depends(get_db_session),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    if current_user.google_refresh_token is None:
        raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

    suggestions = GoogleAdsService(
        db=db,
        refresh_token=current_user.google_refresh_token,
        googleads_account_id=googleads_account.googleads_account_id,
        googleads_manager_account_id=googleads_account.manager_account_id,
    ).get_geo_nearby_suggestions_by_get_targets("location")
    return suggestions


class CampaignStateUpdate(BaseModel):
    state: str


@router.put("/campaigns/{campaign_id}/state")
def launch_campaign(
    state_update: CampaignStateUpdate,
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    current_user: UserAccountData = Depends(get_current_user),
    campaign: CampaignData = Depends(get_user_campaign),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    state = state_update.state
    if state == "live":
        update_campaign_state(campaign.id, CampaignState.LIVE, db)
    elif state == "paused":
        update_campaign_state(campaign.id, CampaignState.PAUSED, db)
    elif state == "draft":
        update_campaign_state(campaign.id, CampaignState.DRAFT, db)
    elif state == "error":
        update_campaign_state(campaign.id, CampaignState.ERROR, db)
    else:
        return {"message": "Invalid state"}

    # Check if the Google Ads campaign exists
    googleads_campaign = get_googleads_campaign_by_campaign_id(campaign.id, db)
    if not googleads_campaign:
        # Create a new Google Ads campaign if it doesn't exist
        CampaignService(user=current_user, db=db, bgts=background_tasks).googleads_create_campaign(
            googleads_account_id=googleads_account.googleads_account_id,
            campaign=campaign,
            refresh_token=current_user.google_refresh_token,
            manager_account_id=googleads_account.manager_account_id,
        )
    else:
        # Update the existing Google Ads campaign
        GoogleAdsService(
            db=db,
            refresh_token=current_user.google_refresh_token,
            googleads_account_id=googleads_account.googleads_account_id,
            googleads_manager_account_id=googleads_account.manager_account_id,
        ).update_campaign_in_googleads(campaign)

    return {"message": "Campaign state updated"}


@router.put("/google/campaigns/{campaign_id}")
def update_googleads_campaign(
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    # Todo: This should go to service layer after @tianyi finishing campaign refactoring
    if not current_user.google_refresh_token:
        raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

    delete_all_campaign_errors(campaign.id, db)
    GoogleAdsService(
        db=db,
        refresh_token=current_user.google_refresh_token,
        googleads_account_id=googleads_account.googleads_account_id,
        googleads_manager_account_id=googleads_account.manager_account_id,
    ).update_campaign_in_googleads(campaign)

    return {"update": True}


@router.get("/campaigns", response_model=list[CampaignData])
def get_campaigns(
    db: Session = Depends(get_db_session),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    campaign_list = []

    campaigns = get_user_ads_customer_campaigns(current_user.id, googleads_account.id, db)
    for campaign in campaigns:
        campaign_data = CampaignData(
            **campaign.model_dump(),
            target_locations=campaign.target_locations,
            phone_numbers=campaign.phone_numbers,
            callouts=campaign.callouts,
            site_links=campaign.site_links,
            structured_snippets=campaign.structured_snippets,
            prices=campaign.prices,
            ads=campaign.ads,
        )

        campaign_errors = []
        campaign_errors = get_and_parse_campaign_errors(campaign_id=campaign_data.id, db=db)
        if campaign_errors:
            campaign_data.state = CampaignState.ERROR
        campaign_list.append(
            CampaignDataWithErrors(
                **campaign_data.model_dump(),
                errors=campaign_errors,
            )
        )
    return campaign_list


@router.get("/campaigns/{campaign_slug}", response_model=CampaignDataWithErrors)
def get_campaign(
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    campaign_errors = []
    campaign_errors = get_and_parse_campaign_errors(campaign_id=campaign.id, db=db)
    return CampaignDataWithErrors(
        **campaign.model_dump(),
        errors=campaign_errors,
    )


@router.put("/campaigns/{campaign_id}")
def update_campaign(
    campaign: CampaignUpdate,
    user_campaign: CampaignData = Depends(get_user_campaign),
    user: UserAccountData = Depends(get_current_user),
    db: Session = Depends(get_db_session),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
    bgts: BackgroundTasks = BackgroundTasks(),
):
    update_db_campaign(user_campaign.id, campaign, db)
    csm = CampaignStateManager(db=db, bgts=bgts, campaign=user_campaign)
    if csm.are_asset_ads_settings_approved() and campaign.budget == 0:
        CampaignService(db=db, bgts=bgts, user=user).set_budget_by_recommendation(
            campaign_id=user_campaign.id,
            googleads_account_id=googleads_account.googleads_account_id,
            manager_account_id=googleads_account.manager_account_id,
        )
    return "ok"


@router.post("/campaigns/{campaign_id}/site-links")
def add_or_update_campaign_site_links(
    site_link: SiteLinkNewOrUpdate,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    if site_link.id:
        existing_site_link = get_site_link_by_id(site_link.id, db)
        if not existing_site_link or existing_site_link.campaign_id != campaign.id:
            raise HTTPException(
                status_code=404,
                detail="Site link not found or does not belong to the campaign",
            )
        update_site_link(campaign.id, db, site_link)
    else:
        add_site_link(campaign.id, db, site_link)


@router.delete("/campaigns/{campaign_id}/site-links/{site_link_id}")
def delete_campaign_site_link(
    site_link_id: int,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    site_link = get_site_link_by_id(site_link_id, db)
    if not site_link or site_link.campaign_id != campaign.id:
        raise HTTPException(
            status_code=404,
            detail="Site link not found or does not belong to the campaign",
        )

    db.delete(site_link)
    db.commit()


@router.post("/campaigns/{campaign_id}/callouts")
def add_or_update_campaign_callout(
    callout: CalloutCreateOrUpdate,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    if callout.id:
        existing_callout = get_callout_by_id(callout.id, db)
        if not existing_callout or existing_callout.campaign_id != campaign.id:
            raise HTTPException(
                status_code=404,
                detail="Callout not found or does not belong to the campaign",
            )
        update_callout(campaign.id, db, callout, callout.id)
    else:
        add_callout(campaign.id, db, callout)
    return {"message": "Callout added or updated successfully"}


@router.delete("/campaigns/{campaign_id}/callouts/{callout_id}")
def delete_campaign_callout(
    callout_id: int,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    callout = get_callout_by_id(callout_id, db)
    if not callout or callout.campaign_id != campaign.id:
        raise HTTPException(
            status_code=404,
            detail="Callout not found or does not belong to the campaign",
        )

    db.delete(callout)
    db.commit()
    return {"message": "Callout deleted successfully"}


@router.post("/campaigns/{campaign_id}/structured-snippets", response_model=StructuredSnippetData)
def add_or_update_campaign_structured_snippet(
    structured_snippet: StructuredSnippetCreate,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    new_structured_snippet = add_structured_snippet(campaign.id, db, structured_snippet)
    return new_structured_snippet


@router.put(
    "/campaigns/{campaign_id}/structured-snippets/{structured_snippet_id}",
    response_model=StructuredSnippetData,
)
def update_campaign_structured_snippet(
    structured_snippet_id: int,
    structured_snippet: StructuredSnippetUpdate,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    existing_structured_snippet = get_structured_snippet_by_id(structured_snippet_id, db)
    if not existing_structured_snippet or existing_structured_snippet.campaign_id != campaign.id:
        raise HTTPException(
            status_code=404,
            detail="Structured snippet not found or does not belong to the campaign",
        )
    updated_structured_snippet = update_structured_snippet(campaign.id, db, structured_snippet, structured_snippet_id)
    return updated_structured_snippet


@router.delete("/campaigns/{campaign_id}/structured-snippets/{structured_snippet_id}")
def delete_campaign_structured_snippet(
    structured_snippet_id: int,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    structured_snippet = get_structured_snippet_by_id(structured_snippet_id, db)
    if not structured_snippet or structured_snippet.campaign_id != campaign.id:
        raise HTTPException(
            status_code=404,
            detail="Structured snippet not found or does not belong to the campaign",
        )

    delete_structured_snippet(structured_snippet, db)
    return {"message": "Structured snippet deleted successfully"}


@router.post("/campaigns/{campaign_id}/prices", response_model=PriceRead)
def add_or_update_campaign_price(
    price: PriceCreate,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    new_price = add_price(campaign.id, db, price)
    return new_price


@router.put("/campaigns/{campaign_id}/prices/{price_id}", response_model=PriceRead)
def update_campaign_price(
    price_id: int,
    price: PriceUpdate,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    existing_price = get_price_by_id(price_id, db)
    if not existing_price or existing_price.campaign_id != campaign.id:
        raise HTTPException(
            status_code=404,
            detail="Price not found or does not belong to the campaign",
        )
    updated_price = update_price(campaign.id, db, price, price_id)
    return updated_price


@router.delete("/campaigns/{campaign_id}/prices/{price_id}")
def delete_campaign_price(
    price_id: int,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    price = get_price_by_id(price_id, db)
    if not price or price.campaign_id != campaign.id:
        raise HTTPException(
            status_code=404,
            detail="Price not found or does not belong to the campaign",
        )

    delete_price(db, price)
    return {"message": "Price deleted successfully"}


@router.get("/campaigns/{campaign_id}/recommendations", response_model=CampaignRecommendations)
def get_campaign_recommendations(
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    return get_latest_campaign_recommendations(campaign.id, db)


@router.post("/campaigns/{campaign_id}/recommendations/{recommendation_id}/apply-instant-fix")
def apply_instant_fix(
    recommendation_id: int, campaign: CampaignData = Depends(get_user_campaign), db: Session = Depends(get_db_session)
):
    campaign_recommendation = get_campaign_level_recommendation(campaign.id, recommendation_id, db)

    if campaign_recommendation and campaign_recommendation.id:
        ad_recommendations = get_ad_recommendations(campaign_recommendation.id, db)

        for ad_rec in ad_recommendations:
            if ad_rec and ad_rec.id:
                keyword_recommendations = get_keyword_recommendations(ad_rec.id, db)

                for keyword_rec in keyword_recommendations:
                    # Perform the instant fix: remove the keyword and update the recommendation state
                    remove_keyword_and_update_state(keyword_rec, db)

                # Update the Ad Recommendation state if all keyword fixes are applied
                update_ad_recommendation_state(ad_rec, db)

        # Update the Campaign Recommendation state if all ad fixes are applied
        update_campaign_recommendation_state(campaign_recommendation, db)

    db.commit()

    return {"detail": "Instant fixes applied successfully"}


@router.delete("/campaigns/{campaign_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_campaign(
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    campaign: CampaignData = Depends(get_user_campaign),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    return CampaignService(user=current_user, db=db, bgts=background_tasks).delete_campaign(
        googleads_account_id=googleads_account.googleads_account_id,
        manager_account_id=googleads_account.manager_account_id,
        campaign=campaign,
        refresh_token=current_user.google_refresh_token,
    )


@router.delete("/campaigns/{campaign_id}/errors", status_code=status.HTTP_204_NO_CONTENT)
def delete_campaign_errors(
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
    current_user: UserAccountData = Depends(get_current_user),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    return CampaignService(user=current_user, db=db, bgts=background_tasks).delete_campaign_errors(
        campaignId=campaign.id,
    )


@router.post("/campaigns/{campaign_id}/copy", response_model=CampaignData)
async def copy_campaign(
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    return copy_campaign_and_associations(campaign, db)


@router.get("/google/campaigns")
async def get_all_googleads_campaigns(
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    return CampaignService(user=current_user, db=db, bgts=background_tasks).fetch_googleads_campaigns(
        googleads_account_id=googleads_account.googleads_account_id,
        refresh_token=current_user.google_refresh_token,
        manager_account_id=googleads_account.manager_account_id,
    )


@router.patch("/campaigns/{campaign_id}/budget_recommendation")
async def update_campaign_with_budget_recommendation(
    campaign_id: int,
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    return CampaignService(user=current_user, db=db, bgts=background_tasks).set_budget_by_recommendation(
        campaign_id=campaign_id,
        googleads_account_id=googleads_account.googleads_account_id,
        manager_account_id=googleads_account.manager_account_id,
    )


@router.post("/google/campaigns/{googleads_campaign_id}", response_model=CampaignData)
async def get_googleads_campaign_by_id(
    googleads_campaign_id: str,
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    googleads_campaign = get_googleads_campaign_by_googleads_campaign_id(
        googleads_campaign_id == int(googleads_campaign_id), db=db
    )
    if googleads_campaign:
        raise HTTPException(status_code=400, detail="Google campaign already imported")

    return CampaignService(user=current_user, db=db, bgts=background_tasks).import_googleads_campaign(
        googleads_account_id=googleads_account.googleads_account_id,
        googleadsaccount_id=googleads_account.id,
        refresh_token=current_user.google_refresh_token,
        googleads_campaign_id=googleads_campaign_id,
        manager_account_id=googleads_account.manager_account_id,
    )


@router.post("/campaigns/{campaign_id}/tcpa/")
def regenerate_tcpa(
    campaign_id: int,
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Regenerate TCPA for a campaign by creating a new task tracking entry"""

    TcpaCreateService(campaign_id=campaign_id, db=db).create_tcpa()

    return {"message": "TCPA regeneration started"}


@router.post("/campaigns/{campaign_slug}/optimisations/zeroimpression/")
def trigger_zero_impression_keywords_optimisation(
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    try:
        return run_zero_impression_optimisation(campaign, db)
    except Exception as e:
        error_message = str(e)
        print(error_message)
        raise HTTPException(status_code=400, detail=error_message)


@router.get("/campaigns/{campaign_slug}/action-logs/")
def campaign_action_logs(
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    return get_campaign_action_logs(campaign, db)
