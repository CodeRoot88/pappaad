from pydantic import BaseModel

from app.campaign.models import CampaignRecommendationData


class CampaignRecommendations(BaseModel):
    recommendations: list[CampaignRecommendationData]
