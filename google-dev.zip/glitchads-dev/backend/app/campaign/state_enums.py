from enum import Enum


class CampaignState(Enum):
    LIVE = "live"
    ERROR = "error"
    DRAFT = "draft"
    PAUSED = "paused"


class SettingsState(str, Enum):
    APPROVED = "approved"
    DRAFT = "draft"


class AssetsState(str, Enum):
    APPROVED = "approved"
    DRAFT = "draft"


class BudgetState(str, Enum):
    APPROVED = "approved"
    DRAFT = "draft"
