from datetime import datetime
from typing import Optional

from fastapi import HTTPException, status
from nanoid import generate
from sqlmodel import Session, col, delete, desc, select

from app.ad.models import Ad
from app.campaign.models import (
    Campaign,
    CampaignCreate,
    CampaignData,
    CampaignError,
    CampaignRecommendation,
    CampaignRecommendationData,
    CampaignUpdate,
    Location,
)
from app.campaign.exceptions import CampaignCreationError
from app.campaign.state_enums import CampaignState
from app.common_state_enums import RecommendationState, RecommendationType

from app.headline.models import Description, Headline
from app.keyword.models import AlternativeKeyword, Keyword
from app.user.models import UserAccount

from app.campaign.asset_models import (
    Callout,
    CalloutBase,
    CalloutCreateOrUpdate,
    PhoneNumber,
    Price,
    PriceCreate,
    PriceUpdate,
    SiteLink,
    SiteLinkNewOrUpdate,
    StructuredSnippet,
    StructuredSnippetCreate,
    StructuredSnippetUpdate,
    StructuredSnippetValue,
)


def filter_locations_by_name(name: str, db: Session) -> list[Location]:
    statement = select(Location).where(col(Location.name).icontains(name))
    results = db.exec(statement).all()
    return list(results)


def add_campaign(campaign: CampaignCreate, db: Session) -> Campaign:
    locations = campaign.target_locations
    campaign.target_locations = []
    new_campaign = Campaign.model_validate(campaign)
    new_campaign.name = new_campaign.name or f"Campaign {new_campaign.slug}"
    db.add(new_campaign)
    db.commit()
    db.refresh(new_campaign)

    for location in locations:
        db_location = get_location_by_criteria_id(location.criteria_id, db)
        if db_location:
            new_campaign.target_locations.append(db_location)
    db.add(new_campaign)
    db.commit()
    db.refresh(new_campaign)
    return new_campaign


def update_campaign(campaign_id: int, updated_data: dict[str, int | str], db: Session):
    campaign = db.exec(select(Campaign).where(Campaign.id == campaign_id)).first()
    for key, value in updated_data.items():
        setattr(campaign, key, value)
    db.add(campaign)
    db.commit()


def update_db_campaign(campaign_id: int, campaign_update: CampaignUpdate, db: Session):
    campaign = db.exec(select(Campaign).where(Campaign.id == campaign_id)).first()
    if not campaign:
        return
    updated_locations = campaign_update.target_locations
    campaign.sqlmodel_update(campaign_update.model_dump(exclude_unset=True))

    current_locations = []
    for location in campaign.target_locations:
        current_locations.append(get_location_by_criteria_id(location.criteria_id, db))

    for location in current_locations:
        campaign.target_locations.remove(location)

    db.add(campaign)
    db.commit()
    db.refresh(campaign)

    for location in updated_locations:
        db_location = get_location_by_criteria_id(location.criteria_id, db)
        if db_location:
            campaign.target_locations.append(db_location)

    if campaign_update.phone_numbers:
        phone_number = db.exec(select(PhoneNumber).where(PhoneNumber.campaign_id == campaign.id)).first()
        if phone_number:
            phone_number.value = campaign_update.phone_numbers[0]
        else:
            phone_number = PhoneNumber(campaign_id=campaign.id, value=campaign_update.phone_numbers[0])
        db.add(phone_number)
    db.add(campaign)
    db.commit()
    db.refresh(campaign)
    return campaign


def get_campaign_by_id(id: int, db: Session) -> Campaign | None:
    statement = select(Campaign).where(Campaign.id == id)
    campaign = db.exec(statement).first()
    return campaign


def get_user_campaign_by_slug(slug: str, user_id: int, db: Session) -> CampaignData | None:
    statement = select(Campaign).where(Campaign.slug == slug, UserAccount.id == user_id)
    campaign = db.exec(statement).first()
    if campaign:
        return CampaignData.model_validate(campaign)
    return None


def get_user_campaign_by_id(id: int, user_id: int, db: Session) -> CampaignData | None:
    statement = select(Campaign).where(Campaign.id == id, UserAccount.id == user_id)
    campaign = db.exec(statement).first()
    if campaign:
        return CampaignData.model_validate(campaign)
    return None


def get_location_by_criteria_id(id: int, db: Session):
    statement = select(Location).where(Location.criteria_id == id)
    location = db.exec(statement).first()
    return location


def add_site_links(campaign_id: int, links: list[str], db: Session) -> None:
    for link in links:
        site_link = SiteLink(
            campaign_id=campaign_id,
            url=link,
            name="",
            content="",
            markdown_content="",
            description1="",
            description2="",
        )
        db.add(site_link)
    db.commit()


def add_site_link(campaign_id: int, db: Session, new_site_link: SiteLinkNewOrUpdate) -> None:
    new_site_link_dict = new_site_link.model_dump()
    new_site_link_dict["campaign_id"] = campaign_id
    site_link = SiteLink(**new_site_link_dict)
    db.add(site_link)
    db.commit()


def update_site_link(
    campaign_id: int,
    db: Session,
    site_link_params: SiteLinkNewOrUpdate,
    content: str | None = None,
    markdown_content: str | None = None,
) -> None:
    if site_link_params.id:
        statement = select(SiteLink).where(SiteLink.campaign_id == campaign_id, SiteLink.id == site_link_params.id)
    else:
        statement = select(SiteLink).where(SiteLink.campaign_id == campaign_id, SiteLink.url == site_link_params.url)

    site_link = db.exec(statement).first()
    if site_link:
        site_link.sqlmodel_update(site_link_params.model_dump(exclude_unset=True))
        if content:
            site_link.content = content
        if markdown_content:
            site_link.markdown_content = markdown_content

        db.add(site_link)
        db.commit()


def get_site_link_by_id(id: int, db: Session) -> SiteLink | None:
    statement = select(SiteLink).where(SiteLink.id == id)
    return db.exec(statement).first()


def add_location_to_campaign(campaign_id: int, location_id: int, db: Session):
    # TODO. What is this function doing? why pass in campaign id but not using it.
    location = Location(
        name="", canonical_name="", parent_id=None, country_code="", target_type="", status="", criteria_id=location_id
    )
    db.add(location)
    db.commit()
    db.refresh(location)
    return location


def add_structured_snippet(
    campaign_id: int, db: Session, new_structured_snippet: StructuredSnippetCreate
) -> StructuredSnippet:
    new_structured_snippet_dict = new_structured_snippet.model_dump()
    new_structured_snippet_dict["campaign_id"] = campaign_id
    structured_snippet_values = []
    for value in new_structured_snippet.values:
        structured_snippet_values.append(StructuredSnippetValue(value=value.value))
    new_structured_snippet_dict["values"] = structured_snippet_values
    structured_snippet = StructuredSnippet(**new_structured_snippet_dict)
    db.add(structured_snippet)
    db.commit()
    db.refresh(structured_snippet)
    return structured_snippet


def update_structured_snippet(
    campaign_id: int,
    db: Session,
    structured_snippet_params: StructuredSnippetUpdate,
    structured_snippet_id: int,
) -> StructuredSnippet | None:
    statement = select(StructuredSnippet).where(
        StructuredSnippet.campaign_id == campaign_id,
        StructuredSnippet.id == structured_snippet_id,
    )
    structured_snippet = db.exec(statement).first()

    if structured_snippet:
        # Update header_type
        structured_snippet.header_type = structured_snippet_params.header_type

        # Fetch and delete existing values
        existing_values_statement = select(StructuredSnippetValue).where(
            StructuredSnippetValue.structured_snippet_id == structured_snippet_id
        )
        existing_values = db.exec(existing_values_statement).all()
        for value in existing_values:
            db.delete(value)

        # Add new values
        new_values = [
            StructuredSnippetValue(structured_snippet_id=structured_snippet_id, value=value.value)
            for value in structured_snippet_params.values
        ]
        db.add_all(new_values)

        # Commit changes
        db.add(structured_snippet)
        db.commit()
        db.refresh(structured_snippet)

    return structured_snippet


def get_structured_snippet_by_id(id: int, db: Session) -> StructuredSnippet | None:
    statement = select(StructuredSnippet).where(StructuredSnippet.id == id)
    return db.exec(statement).first()


def delete_structured_snippet(structured_snippet: StructuredSnippet, db: Session) -> None:
    db.delete(structured_snippet)
    db.commit()


def add_price(campaign_id: int, db: Session, price: PriceCreate) -> Price:
    db_price = Price(campaign_id=campaign_id, **price.model_dump())
    db.add(db_price)
    db.commit()
    db.refresh(db_price)
    return db_price


def get_price_by_id(id: int, db: Session) -> Price | None:
    return db.get(Price, id)


def update_price(
    campaign_id: int,
    db: Session,
    price_params: PriceUpdate,
    price_id: int,
) -> Price | None:
    db_price = get_price_by_id(price_id, db)
    if db_price and db_price.campaign_id == campaign_id:
        update_data = price_params.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_price, key, value)
        db.add(db_price)
        db.commit()
        db.refresh(db_price)
    return db_price


def delete_price(db: Session, price: Price) -> None:
    db.delete(price)
    db.commit()


def add_campaign_error(
    campaign_id: str,
    error_request_id: str,
    error_code: str,
    error_message: str,
    fields: list[str],
    class_name: str,
    class_id: int,
    db: Session,
):
    error = CampaignError(
        campaign_id=campaign_id,
        error_request_id=error_request_id,
        error_code=error_code,
        error_message=error_message,
        fields=fields,
        class_name=class_name,
        class_id=class_id,
        timestamp=str(datetime.now()),
    )
    db.add(error)
    db.commit()
    db.refresh(error)
    return error


def get_campaign_errors(campaign_id: int, db: Session):
    statement = select(CampaignError).where(CampaignError.campaign_id == campaign_id)
    return db.exec(statement).all()


def add_callout(campaign_id: int, db: Session, new_callout: CalloutBase) -> None:
    new_callout_dict = new_callout.model_dump()
    new_callout_dict["campaign_id"] = campaign_id
    callout = Callout(**new_callout_dict)
    db.add(callout)
    db.commit()


def update_callout(
    campaign_id: int,
    db: Session,
    callout_params: CalloutCreateOrUpdate,
    callout_id: int,
) -> None:
    statement = select(Callout).where(Callout.campaign_id == campaign_id, Callout.id == callout_id)
    callout = db.exec(statement).first()
    if callout:
        callout.sqlmodel_update(callout_params.model_dump(exclude_unset=True))
        db.add(callout)
        db.commit()


def get_callout_by_id(id: int, db: Session) -> Callout | None:
    statement = select(Callout).where(Callout.id == id)
    return db.exec(statement).first()


def get_user_ads_customer_campaigns(user_id: int, googleadsaccount_id: int, db: Session):
    statement = (
        select(Campaign)
        .where(
            Campaign.user_account_id == user_id,
            Campaign.googleadsaccount_id == googleadsaccount_id,
        )
        .order_by(desc(Campaign.id))
        .distinct()
    )

    campaigns = db.exec(statement).unique().all()
    return campaigns


def get_campaign_level_recommendation(
    campaign_id: int, recommendation_id: int, db: Session
) -> Optional[CampaignRecommendation]:
    """
    Fetches all campaign-level recommendations for a given campaign ID.

    Args:
        campaign_id (int): The ID of the campaign.
        db (Session): The database session.

    Returns:
        List[CampaignRecommendation]: A list of campaign recommendations, or an empty list if none are found.
    """
    recommendations = (
        db.query(CampaignRecommendation)
        .filter(CampaignRecommendation.campaign_id == campaign_id, CampaignRecommendation.id == recommendation_id)
        .first()
    )

    return recommendations


def get_campaign_recommendations_by_type(
    campaign_id: int, db: Session, recommendation_type: RecommendationType, limit: int = 1
) -> list[CampaignRecommendationData]:
    statement = (
        select(CampaignRecommendation)
        .where(
            CampaignRecommendation.campaign_id == campaign_id,
            CampaignRecommendation.recommendation_type == recommendation_type,
        )
        .order_by(desc(CampaignRecommendation.created_at))
        .limit(limit)
    )
    results = db.exec(statement).all()
    return [CampaignRecommendationData.model_validate(result) for result in results]


def update_campaign_recommendation_state(campaign_rec: CampaignRecommendation, db: Session):
    campaign_rec.state = RecommendationState.INSTANT_FIX_APPLIED
    db.add(campaign_rec)


def delete_all_campaign_errors(campaign_id: int, db: Session):
    db.query(CampaignError).filter(CampaignError.campaign_id == campaign_id).delete()
    db.commit()
    return True


def get_campaign_by_slug(db: Session, campaign_slug: str) -> Optional[Campaign]:
    statement = select(Campaign).where(Campaign.slug == campaign_slug)
    result = db.exec(statement).first()
    return result


def remove_campaign(campaign_id: int, db: Session):
    statement = select(Campaign).where(Campaign.id == campaign_id)
    campaign = db.exec(statement).first()
    if campaign is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Campaign not found")
    db.delete(campaign)
    db.commit()
    return {"campaign_id": campaign.id, "detail": "Campaign deleted successfully"}


def remove_campaign_errors_by_campaign_id(campaign_id: int, db: Session):
    statement = delete(CampaignError).where(CampaignError.campaign_id == campaign_id)
    db.exec(statement)
    db.commit()


def get_campaign_keywords(campaign_id: int, db: Session):
    statement = select(Keyword.text).where(Keyword.ad_id == Ad.id, Ad.campaign_id == campaign_id)
    return db.exec(statement).all()


def update_campaign_state(campaign_id: int, state: CampaignState, db: Session):
    campaign = db.exec(select(Campaign).where(Campaign.id == campaign_id)).first()
    if campaign:
        campaign.state = state
        db.add(campaign)
        db.commit()


def copy_campaign(origin_campaign: CampaignData, db: Session) -> CampaignData:
    campaign_data_dict = origin_campaign.model_dump()
    new_campaign = CampaignCreate(**campaign_data_dict)
    new_campaign.slug = generate(size=10)
    new_campaign.name = f"Campaign {new_campaign.slug} (Copy of {origin_campaign.name})"
    new_campaign.state = CampaignState.DRAFT
    new_campaign = add_campaign(new_campaign, db)

    for ad in origin_campaign.ads:
        new_ad = Ad(campaign_id=new_campaign.id, url=ad.url, slug=generate(size=10))
        db.add(new_ad)
        db.commit()
        db.refresh(new_ad)
        if not new_ad.id:
            raise CampaignCreationError("Ad could not be copied.")
        for keyword in ad.keywords:
            keyword_dict = keyword.model_dump()
            keyword_dict["ad_id"] = new_ad.id
            keyword_dict["id"] = None
            new_keyword = Keyword(**keyword_dict)
            db.add(new_keyword)

        for headline in ad.headlines:
            headline_dict = headline.model_dump()
            headline_dict["ad_id"] = new_ad.id
            headline_dict["id"] = None
            new_headline = Headline(**headline_dict)
            db.add(new_headline)

        for description in ad.descriptions:
            description_dict = description.model_dump()
            description_dict["ad_id"] = new_ad.id
            description_dict["id"] = None
            new_description = Description(**description_dict)
            db.add(new_description)

        for google_suggested_keyword in ad.alternative_keywords:
            new_google_suggested_keyword = AlternativeKeyword(ad_id=new_ad.id, text=google_suggested_keyword.text)
            db.add(new_google_suggested_keyword)

    for callout in origin_campaign.callouts:
        new_callout = Callout(campaign_id=new_campaign.id, text=callout.text)
        db.add(new_callout)

    for site_link in origin_campaign.site_links:
        new_site_link = SiteLink(
            campaign_id=new_campaign.id,
            name=site_link.name,
            url=site_link.url,
            content=site_link.content,
            markdown_content=site_link.markdown_content,
            description1=site_link.description1,
            description2=site_link.description2,
        )
        db.add(new_site_link)
    for structured_snippet in origin_campaign.structured_snippets:
        structured_snippet_dict = structured_snippet.model_dump()
        structured_snippet_dict["campaign_id"] = new_campaign.id
        structured_snippet_dict["id"] = None
        new_structured_snippet = StructuredSnippet(**structured_snippet_dict)
        db.add(new_structured_snippet)

    for price in origin_campaign.prices:
        price_dict = price.model_dump()
        price_dict["campaign_id"] = new_campaign.id
        price_dict["id"] = None
        new_price = Price(**price_dict)
        db.add(new_price)
    for phone_number in origin_campaign.phone_numbers:
        phone_number_dict = phone_number.model_dump()
        phone_number_dict["campaign_id"] = new_campaign.id
        phone_number_dict["id"] = None
        new_phone_number = PhoneNumber(**phone_number_dict)
        db.add(new_phone_number)
    db.commit()

    return new_campaign


def get_campaign_by_name(name: str, db: Session) -> Campaign | None:
    statement = select(Campaign).where(Campaign.name == name)
    return db.exec(statement).first()


def get_campaign_by_name_and_account(name: str, googleadsaccount_id: int, db: Session) -> Campaign | None:
    statement = select(Campaign).where(Campaign.name == name, Campaign.googleadsaccount_id == googleadsaccount_id)
    return db.exec(statement).first()
