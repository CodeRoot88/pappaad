from datetime import datetime, timezone
from typing import TYPE_CHECKING, Optional

from sqlalchemy import Column as SA_Column
from sqlalchemy import ForeignKey, Integer
from sqlalchemy.dialects.postgresql import ARRAY
from sqlmodel import (
    BigInteger,
    Column,
    Field,
    Relationship,
    SQLModel,
    String,
)

from app.ad.models import Ad, AdBase, AdData, AdRecommendation, AdRecommendationData
from app.campaign.asset_models import (
    Callout,
    PhoneNumber,
    Price,
    PriceRead,
    SiteLink,
    SiteLinkData,
    StructuredSnippet,
    StructuredSnippetData,
)
from app.campaign.state_enums import AssetsState, BudgetState, CampaignState, SettingsState
from app.common_state_enums import RecommendationSeverity, RecommendationState, RecommendationType
from app.google_ads.models import GoogleAdsAccount, GoogleAdsCampaign
from app.task_tracking.models import TaskTracking


if TYPE_CHECKING:
    from app.user.models import UserAccount
    from app.recommendations.models import ActionLog


class CampaignLocationLink(SQLModel, table=True):
    campaign_id: Optional[int] = Field(
        default=None, sa_column=SA_Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"), primary_key=True)
    )

    location_criteria_id: Optional[int] = Field(
        default=None,
        sa_column=SA_Column(Integer, ForeignKey("location.criteria_id"), primary_key=True),
    )


class BaseLocation(SQLModel):
    criteria_id: int = Field(primary_key=True)
    name: str
    canonical_name: str
    parent_id: Optional[int] = Field(default=None, index=True)
    country_code: str = Field(index=True)
    target_type: str
    status: str = Field(index=True)


class Location(BaseLocation, table=True):
    campaign: list["Campaign"] = Relationship(back_populates="target_locations", link_model=CampaignLocationLink)


class GoogleAdsLocation(BaseLocation):
    reach: int


class CampaignBase(SQLModel):
    slug: str
    name: str | None = None
    state: Optional[CampaignState] = Field(default=CampaignState.DRAFT)
    settings_state: Optional[SettingsState] = Field(default=SettingsState.DRAFT)
    assets_state: Optional[AssetsState] = Field(default=AssetsState.DRAFT)
    budget_state: Optional[BudgetState] = Field(default=BudgetState.DRAFT)
    website_url: str
    goal: str | None = None
    target_cpa: Optional[int] = 0
    target_cpa_explanation: str | None = None
    budget: Optional[int] = Field(default=0, sa_column=Column(BigInteger()))
    business_desc: str | None = None


class Campaign(CampaignBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_account_id: int = Field(foreign_key="useraccount.id")

    googleadsaccount_id: Optional[int] = Field(foreign_key="googleadsaccount.id")

    is_deleted: Optional[bool] = Field(default=False)
    campaign_goal_text: Optional[str] = Field(None, max_length=280)

    ads: list["Ad"] = Relationship(back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"})
    site_links: Optional[list["SiteLink"]] = Relationship(
        back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    target_locations: list["Location"] = Relationship(back_populates="campaign", link_model=CampaignLocationLink)
    callouts: list["Callout"] = Relationship(
        back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    structured_snippets: list["StructuredSnippet"] = Relationship(
        back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    phone_numbers: list["PhoneNumber"] = Relationship(
        back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    prices: list["Price"] = Relationship(back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"})
    user_account: Optional["UserAccount"] = Relationship(back_populates="campaigns")
    googleads_account: Optional["GoogleAdsAccount"] = Relationship(back_populates="campaigns")
    campaign_recommendations: list["CampaignRecommendation"] = Relationship(
        back_populates="campaign", cascade_delete=True
    )
    action_logs: list["ActionLog"] = Relationship(back_populates="campaign", cascade_delete=True)
    ga_campaign: Optional["GoogleAdsCampaign"] = Relationship(
        back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    campaign_errors: list["CampaignError"] = Relationship(
        back_populates="campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )

    task_trackings: list["TaskTracking"] = Relationship(
        sa_relationship_kwargs={"lazy": "joined"}, back_populates="campaign"
    )
    googleads_campaign: Optional["GoogleAdsCampaign"] = Relationship(back_populates="campaign", cascade_delete=True)


class CampaignReadWithoutAssociations(CampaignBase):
    id: int
    user_account_id: int
    googleadsaccount_id: Optional[int]


class CampaignUpdate(CampaignBase):
    target_locations: list["Location"]
    phone_numbers: list[str]


class CampaignData(CampaignBase):
    id: int
    ads: list["AdData"]
    site_links: list["SiteLinkData"]
    target_locations: list["Location"]
    callouts: list["Callout"]
    structured_snippets: list["StructuredSnippetData"]
    prices: list["PriceRead"]
    phone_numbers: list["PhoneNumber"]
    campaign_goal_text: Optional[str] = None
    user_account_id: int
    googleadsaccount_id: int
    googleads_campaign: Optional["GoogleAdsCampaign"] = None
    googleads_account: Optional[GoogleAdsAccount] = None


class CampaignWithGoogleAdsAccount(CampaignBase):
    id: int
    googleads_account: Optional["GoogleAdsAccount"]


class CampaignDataWithGoogleAdsAccount(CampaignData):
    googleads_account: Optional["GoogleAdsAccount"]


class NewCampaignParams(CampaignBase):
    target_locations: list["Location"]
    campaign_goal_text: Optional[str] = Field(None, max_length=280)


class CampaignCreate(NewCampaignParams):
    user_account_id: int
    googleadsaccount_id: int


class CampaignError(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: int | None = Field(
        default=None, sa_column=SA_Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )
    error_request_id: str
    error_code: str
    error_message: str
    fields: list[str] = Field(sa_column=Column(ARRAY(String)))
    class_name: str
    class_id: int
    timestamp: str
    campaign: "Campaign" = Relationship(back_populates="campaign_errors")


class ErrorData(SQLModel):
    error_type: str
    error_data: Optional["AdBase"]


class CampaignDataWithErrors(CampaignData):
    errors: list[ErrorData]


class CampaignRecommendationBase(SQLModel):
    campaign_id: int = Field(foreign_key="campaign.id", ondelete="CASCADE")
    title: str
    severity: RecommendationSeverity
    description: str
    state: RecommendationState
    recommendation_type: RecommendationType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class CampaignRecommendation(CampaignRecommendationBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign: "Campaign" = Relationship(back_populates="campaign_recommendations")
    ad_recommendations: list["AdRecommendation"] = Relationship(back_populates="campaign_recommendation")


class CampaignRecommendationData(CampaignRecommendationBase):
    id: int
    ad_recommendations: list["AdRecommendationData"]
