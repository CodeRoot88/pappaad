from app.google_ads.services import GoogleAdsService
from app.user.models import UserAccount
from app.campaign.models import Campaign
from app.campaign.services import CampaignService
from app.database import get_db_session
from app.endpoint_dependencies import (
    get_user_campaign,
    get_current_user,
    get_current_googleads_account,
)
from .models import GoogleAdsAccount
from .db_ops import (
    update_user_selected_googleads_account,
    get_googleads_accounts_by_user_id,
    update_googleads_account_linked_status,
    get_googleads_account_by_user_id_and_googleads_account_id,
    select_first_linked_googleads_account,
    get_googleads_linked_accounts_by_user_id,
)

from ..keyword.db_ops import get_google_alt_keywords_by_ad_id

from fastapi import APIRouter, Body, Depends, BackgroundTasks
from sqlmodel import Session
from typing import Annotated
import os

router = APIRouter()


@router.get("/google/accounts")
def get_ads_accounts(
    current_user: UserAccount = Depends(get_current_user),
    db: Session = Depends(get_db_session),
) -> list[GoogleAdsAccount] | None:
    if current_user.id:
        return get_googleads_accounts_by_user_id(current_user.id, db)
    return None


@router.get("/google/accounts/linked")
def get_linked_ads_accounts(
    current_user: UserAccount = Depends(get_current_user),
    db: Session = Depends(get_db_session),
) -> list[GoogleAdsAccount] | None:
    if current_user.id:
        return get_googleads_linked_accounts_by_user_id(current_user.id, db)
    return None


@router.put("/google/accounts/set-selected")
def set_user_selected_ads_account(
    googleads_account_id: Annotated[int, Body(embed=True)],
    current_user: UserAccount = Depends(get_current_user),
    db: Session = Depends(get_db_session),
):
    if current_user.id:
        update_user_selected_googleads_account(
            user_id=current_user.id, googleads_account_id=googleads_account_id, db=db
        )
        return {"message": "Selected account updated successfully"}


@router.put("/google/accounts/first-linked")
def set_first_linked_ads_account(
    current_user: UserAccount = Depends(get_current_user),
    db: Session = Depends(get_db_session),
):
    if current_user.id:
        select_first_linked_googleads_account(user_id=current_user.id, db=db)
        return {"message": "Selected account updated successfully"}


@router.get("/google/forecast/{campaign_slug}")
def forecast_campaign(
    db: Session = Depends(get_db_session),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    current_user: UserAccount = Depends(get_current_user),
    campaign: Campaign = Depends(get_user_campaign),
    googleads_account: GoogleAdsAccount = Depends(get_current_googleads_account),
):
    forecast = CampaignService(user=current_user, db=db, bgts=background_tasks).forecast_campaign(
        googleads_account_id=googleads_account.googleads_account_id, campaign=campaign
    )
    return {
        "impressions": forecast.impressions,
        "click_through_rate": forecast.click_through_rate,
        "average_cpc_micros": forecast.average_cpc_micros,
        "clicks": forecast.clicks,
        "cost_micros": forecast.cost_micros,
        "conversions": forecast.conversions,
        "conversion_rate": forecast.conversion_rate,
        "average_cpm_micros": forecast.average_cpa_micros,
    }


@router.get("/ads/{ad_id}/alt-keywords")
def get_google_recommended_keywords(
    ad_id: int,
    db: Session = Depends(get_db_session),
):
    keywords = get_google_alt_keywords_by_ad_id(ad_id=ad_id, db=db)
    return [keyword.text for keyword in keywords]


@router.post("/google/link-accounts")
def link_googleads_account(
    account_id: Annotated[str, Body(embed=True)],
    db: Session = Depends(get_db_session),
    current_user: UserAccount = Depends(get_current_user),
):
    if not current_user.id:
        return {"message": "User not found"}
    account = get_googleads_account_by_user_id_and_googleads_account_id(current_user.id, account_id, db)
    if account and account.linked == "LINKED":
        return {"message": "Account already linked"}
    glitch_mcc_id = os.getenv("GOOGLE_ADS_LOGIN_CUSTOMER_ID")
    if not glitch_mcc_id:
        return
    linked = GoogleAdsService(
        db=db,
        refresh_token=current_user.google_refresh_token,
        googleads_account_id=account_id,
        googleads_manager_account_id=glitch_mcc_id,
    ).link_client_account_to_manager_account()

    if linked:
        update_googleads_account_linked_status(
            user_id=current_user.id, googleads_account_id=account_id, linked="PENDING", db=db
        )
        return {"message": "Google Ads account linked successfully"}
    else:
        return {"message": "Failed to link Google Ads account"}
