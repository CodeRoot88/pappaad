from .models import (
    GoogleAdsAd,
    GoogleAdsAdGroup,
    GoogleAdsCallAsset,
    GoogleAdsCalloutAsset,
    GoogleAdsCampaign,
    GoogleAdsAccount,
    GoogleAdsAccountData,
    GoogleAdsKeyword,
    GoogleAdsPriceAsset,
    GoogleAdsSiteLinkAsset,
    GoogleAdsStructuredSnippetAsset,
)

from app.google_ads.models import LinkedStatus
from sqlalchemy.dialects.postgresql import insert
from sqlmodel import Session, select
from sqlalchemy import asc
import os


def upsert(session, model, values, conflict_columns):
    """
    Perform an upsert (insert or update) operation.

    :param session: SQLAlchemy session
    :param model: SQLAlchemy model/table
    :param values: Dictionary of values to insert or update
    :param conflict_columns: List of columns to check for conflicts
    """
    stmt = insert(model).values(values)

    update_dict = {
        c.name: getattr(stmt.excluded, c.name) for c in model.__table__.columns if c.name not in conflict_columns
    }

    stmt = stmt.on_conflict_do_update(index_elements=conflict_columns, set_=update_dict)

    session.execute(stmt)
    session.commit()


def update_googleads_accounts(googleads_accounts: list[dict], user_account_id: int, db: Session):
    glitch_mcc = None
    if os.environ.get("GOOGLE_ADS_LOGIN_CUSTOMER_ID"):
        glitch_mcc = int(os.environ.get("GOOGLE_ADS_LOGIN_CUSTOMER_ID"))

    current_accounts = db.exec(
        select(GoogleAdsAccount).where(GoogleAdsAccount.user_account_id == user_account_id)
    ).all()

    current_accounts_dict = {account.googleads_account_id: account for account in current_accounts}
    for _, googleads_account in enumerate(googleads_accounts):
        linked = "NOT_LINKED"
        if glitch_mcc and glitch_mcc in googleads_account["mcc_id"]:
            linked = "LINKED"
        mcc = googleads_account.get("mcc_id")
        if mcc:
            mcc = mcc[0]
        if googleads_account["account_id"] in current_accounts_dict:
            to_be_updated = current_accounts_dict[googleads_account["account_id"]]
            to_be_updated.name = googleads_account["name"]
            to_be_updated.linked = LinkedStatus(linked)
            to_be_updated.currency = googleads_account["currency"]
            to_be_updated.manager_account_id = mcc
            db.add(to_be_updated)
            db.commit()
            continue
        add_googleads_account(
            user_account_id=user_account_id,
            googleads_account_id=googleads_account["account_id"],
            name=googleads_account["name"],
            manager_account_id=mcc,
            db=db,
            selected=False,
            linked=LinkedStatus(linked),
        )


def add_googleads_account(
    user_account_id: int,
    googleads_account_id: str,
    name: str,
    db: Session,
    manager_account_id: str | None = None,
    selected: bool | None = False,
    linked: LinkedStatus | None = None,
):
    account = get_googleads_account_by_user_id_and_googleads_account_id(user_account_id, googleads_account_id, db)
    if account:
        return
    googleads_customer = GoogleAdsAccount(
        user_account_id=user_account_id,
        name=name,
        googleads_account_id=googleads_account_id,
        manager_account_id=manager_account_id,
        selected=selected,
        linked=LinkedStatus(linked),
    )

    db.add(googleads_customer)
    db.commit()


def get_googleads_accounts_by_user_id(user_id: int, db: Session) -> list[GoogleAdsAccount]:
    statement = (
        select(GoogleAdsAccount).where(GoogleAdsAccount.user_account_id == user_id).order_by(asc(GoogleAdsAccount.name))
    )
    googleads_customer = db.exec(statement).all()

    return list(googleads_customer)


def get_googleads_linked_accounts_by_user_id(user_id: int, db: Session) -> list[GoogleAdsAccount]:
    statement = (
        select(GoogleAdsAccount)
        .where(GoogleAdsAccount.user_account_id == user_id, GoogleAdsAccount.linked == "LINKED")
        .order_by(asc(GoogleAdsAccount.name))
    )
    googleads_customer = db.exec(statement).all()

    return list(googleads_customer)


def get_googleads_account_by_user_id_and_googleads_account_id(
    user_id: int, googleads_account_id: str, db: Session
) -> GoogleAdsAccount | None:
    statement = select(GoogleAdsAccount).where(
        GoogleAdsAccount.user_account_id == user_id,
        GoogleAdsAccount.googleads_account_id == googleads_account_id,
    )
    googleads_customer = db.exec(statement).first()
    return googleads_customer


def update_googleads_account_linked_status(user_id: int, googleads_account_id: str, linked: str, db: Session):
    googleads_account = get_googleads_account_by_user_id_and_googleads_account_id(user_id, googleads_account_id, db)
    if googleads_account:
        googleads_account.linked = LinkedStatus(linked)
        db.add(googleads_account)
        db.commit()
        return googleads_account
    return None


def get_googleads_account_by_id(id: int, db: Session) -> GoogleAdsAccountData | None:
    statement = select(GoogleAdsAccount).where(
        GoogleAdsAccount.id == id,
    )

    googleads_account = db.exec(statement).first()
    if googleads_account:
        return GoogleAdsAccountData.model_validate(googleads_account)
    return None


def get_current_user_selected_google_ads_customer(user_id: int, db: Session) -> GoogleAdsAccountData | None:
    statement = select(GoogleAdsAccount).where(
        GoogleAdsAccount.user_account_id == user_id,
        GoogleAdsAccount.selected == True,  # noqa
    )

    googleads_account = db.exec(statement).first()
    if googleads_account:
        return GoogleAdsAccountData.model_validate(googleads_account)
    return None


def update_user_selected_googleads_account(user_id: int, googleads_account_id: int, db: Session):
    current_customers = db.exec(select(GoogleAdsAccount).where(GoogleAdsAccount.user_account_id == user_id)).all()
    for current in current_customers:
        current.selected = current.googleads_account_id == str(googleads_account_id)
        db.add(current)
    db.commit()
    # ignor


def select_first_linked_googleads_account(user_id: int, db: Session):
    first_customer = db.exec(
        select(GoogleAdsAccount).where(GoogleAdsAccount.user_account_id == user_id, GoogleAdsAccount.linked == "LINKED")
    ).first()
    if first_customer:
        first_customer.selected = True
        db.commit()


def add_googleads_campaign(campaign_id: int, googleads_campaign_id: str, db: Session):
    googleads_campaign = GoogleAdsCampaign(campaign_id=campaign_id, googleads_campaign_id=googleads_campaign_id)
    db.add(googleads_campaign)
    db.commit()
    db.refresh(googleads_campaign)
    return googleads_campaign


def add_googleads_ad_group(googleads_campaign_id: str, googleads_ad_group_id: str, ad_id: int, db: Session):
    googleads_ad_group = GoogleAdsAdGroup(
        googleads_campaign_id=googleads_campaign_id,
        googleads_ad_group_id=googleads_ad_group_id,
        ad_id=ad_id,
    )

    db.add(googleads_ad_group)
    db.commit()
    db.refresh(googleads_ad_group)
    return googleads_ad_group


def get_googleads_campaign_by_campaign_id(campaign_id: int, db: Session) -> GoogleAdsCampaign:
    statement = select(GoogleAdsCampaign).where(GoogleAdsCampaign.campaign_id == campaign_id)
    googleads_campaign = db.exec(statement).first()
    return googleads_campaign


def add_googleads_ad(googleads_ad_group_id: str, googleads_ad_id: str, ad_id: int, db: Session):
    googleads_ad = GoogleAdsAd(
        ad_id=ad_id, googleads_ad_id=googleads_ad_id, googleads_ad_group_id=googleads_ad_group_id
    )
    db.add(googleads_ad)
    db.commit()
    db.refresh(googleads_ad)
    return googleads_ad


def add_google_ads_group_to_campaign(
    campaign_id: int,
    googleads_ad_group_id: str,
    googleads_campaign_id: str,
    db: Session,
):
    googleads_ad_group = GoogleAdsAdGroup(
        campaign_id=campaign_id,
        googleads_ad_group_id=googleads_ad_group_id,
        googleads_campaign_id=googleads_campaign_id,
    )
    db.add(googleads_ad_group)
    db.commit()
    db.refresh(googleads_ad_group)
    return googleads_ad_group


def get_googleads_ad_group_by_ad_id(ad_id: int, db: Session) -> GoogleAdsAdGroup | None:
    statement = select(GoogleAdsAdGroup).where(GoogleAdsAdGroup.ad_id == ad_id)
    googleads_ad_group = db.exec(statement).first()
    return googleads_ad_group


def get_googleads_ad_by_ad_id(ad_id: int, db: Session) -> GoogleAdsAd | None:
    statement = select(GoogleAdsAd).where(GoogleAdsAd.ad_id == ad_id)
    googleads_ad = db.exec(statement).first()
    return googleads_ad


def get_google_ads_asset_by_asset_id(asset_id: int, asset_type: str, db: Session):
    if asset_type == "site_link":
        statement = select(GoogleAdsSiteLinkAsset).where(GoogleAdsSiteLinkAsset.site_link_id == asset_id)
    elif asset_type == "callout":
        statement = select(GoogleAdsCalloutAsset).where(GoogleAdsCalloutAsset.callout_id == asset_id)
    elif asset_type == "structured_snippet":
        statement = select(GoogleAdsStructuredSnippetAsset).where(
            GoogleAdsStructuredSnippetAsset.structured_snippet_id == asset_id
        )
    elif asset_type == "price":
        statement = select(GoogleAdsPriceAsset).where(GoogleAdsPriceAsset.price_id == asset_id)
    elif asset_type == "call":
        statement = select(GoogleAdsCallAsset).where(GoogleAdsCallAsset.phone_number_id == asset_id)
    else:
        return None
    googleads_asset = db.exec(statement).first()
    return googleads_asset


def add_googleads_site_link(site_link_id: int, googleads_asset_id: str, db: Session):
    googleads_site_link = GoogleAdsSiteLinkAsset(site_link_id=site_link_id, googleads_asset_id=googleads_asset_id)

    data_dict = googleads_site_link.model_dump()
    if data_dict["id"] is None:
        del data_dict["id"]
    upsert(db, GoogleAdsSiteLinkAsset, data_dict, ["site_link_id", "googleads_asset_id"])
    db.commit()
    return googleads_site_link


def add_googleads_callout(callout_id: int, google_ads_asset_id: str, db: Session):
    googleads_callout = GoogleAdsCalloutAsset(callout_id=callout_id, google_ads_asset_id=google_ads_asset_id)
    upsert(
        db,
        GoogleAdsCalloutAsset,
        googleads_callout.model_dump(),
        ["callout_id", "google_ads_asset_id"],
    )
    db.commit()
    return googleads_callout


def add_googleads_structured_snippet(structured_snippet_id: int, google_ads_asset_id: str, db: Session):
    googleads_structured_snippet = GoogleAdsStructuredSnippetAsset(
        structured_snippet_id=structured_snippet_id,
        google_ads_asset_id=google_ads_asset_id,
    )
    upsert(
        db,
        GoogleAdsStructuredSnippetAsset,
        googleads_structured_snippet.model_dump(),
        ["structured_snippet_id", "google_ads_asset_id"],
    )
    db.commit()
    return googleads_structured_snippet


def add_googleads_price(price_id: int, google_ads_asset_id: str, db: Session):
    googleads_price = GoogleAdsPriceAsset(price_id=price_id, google_ads_asset_id=google_ads_asset_id)
    upsert(
        db,
        GoogleAdsPriceAsset,
        googleads_price.model_dump(),
        ["price_id", "google_ads_asset_id"],
    )
    db.commit()
    return googleads_price


def add_google_ads_call(phone_number_id: int, google_ads_asset_id: str, db: Session):
    googleads_call = GoogleAdsCallAsset(phone_number_id=phone_number_id, google_ads_asset_id=google_ads_asset_id)
    upsert(
        db,
        GoogleAdsCallAsset,
        googleads_call.model_dump(),
        ["phone_number_id", "google_ads_asset_id"],
    )
    db.commit()
    return googleads_call


def get_googleads_campaign_by_googleads_campaign_id(googleads_campaign_id: int, db: Session):
    statement = select(GoogleAdsCampaign).where(GoogleAdsCampaign.googleads_campaign_id == googleads_campaign_id)
    googleads_campaign = db.exec(statement).first()
    return googleads_campaign


def add_google_ad_group_to_google_ads_campaign(ad_group_id: int, campaign_id: int, db: Session):
    googleads_ad_group = GoogleAdsAdGroup(campaign_id=campaign_id, ad_group_id=ad_group_id)
    db.add(googleads_ad_group)
    db.commit()
    db.refresh(googleads_ad_group)
    return googleads_ad_group


def add_googleads_keyword(keyword_id: int, ad_id: int, db: Session):
    googleads_keyword = GoogleAdsKeyword(keyword_id=keyword_id, ad_id=ad_id)
    db.add(googleads_keyword)
    db.commit()
    db.refresh(googleads_keyword)
    return googleads_keyword
