from typing import Optional, TYPE_CHECKING
from enum import Enum

from sqlmodel import (
    Field,
    Relationship,
    SQLModel,
    UniqueConstraint,
)

from sqlalchemy import Column as SA_Column, Integer, ForeignKey, String

from ..user.models import UserAccount

if TYPE_CHECKING:
    from ..ad.models import Ad
    from ..campaign.models import Campaign


class LinkedStatus(Enum):
    LINKED = "LINKED"
    PENDING = "PENDING"
    NOT_LINKED = "NOT_LINKED"


class GoogleAdsCampaign(SQLModel, table=True):
    id: Optional[int] = Field(primary_key=True)
    campaign_id: int = Field(default=None, sa_column=SA_Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE")))
    googleads_campaign_id: str = Field(unique=True)

    campaign: Optional["Campaign"] = Relationship(back_populates="googleads_campaign")
    googleads_ad_groups: list["GoogleAdsAdGroup"] = Relationship(
        back_populates="googleads_campaign", sa_relationship_kwargs={"cascade": "all, delete"}
    )


class GoogleAdsAd(SQLModel, table=True):
    id: Optional[int] = Field(primary_key=True)
    ad: "Ad" = Relationship(back_populates="googleads_ad")
    ad_id: int = Field(default=None, sa_column=SA_Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))
    googleads_ad_id: str = Field(unique=True)
    googleads_ad_group_id: str = Field(foreign_key="googleadsadgroup.googleads_ad_group_id")


class GoogleAdsAdGroup(SQLModel, table=True):
    id: Optional[int] = Field(primary_key=True)
    googleads_ad_group_id: str = Field(unique=True)
    ad: "Ad" = Relationship(back_populates="googleads_ad_group")
    ad_id: int = Field(default=None, sa_column=SA_Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))
    googleads_campaign_id: str = Field(
        default=None,
        sa_column=SA_Column(String, ForeignKey("googleadscampaign.googleads_campaign_id", ondelete="CASCADE")),
    )
    googleads_campaign: Optional["GoogleAdsCampaign"] = Relationship(back_populates="googleads_ad_groups")


class GoogleAdsAsset(SQLModel):
    id: Optional[int] = Field(default=None, primary_key=True)
    googleads_asset_id: Optional[str] = None


class GoogleAdsSiteLinkAsset(GoogleAdsAsset, table=True):
    site_link_id: int = Field(sa_column=SA_Column(Integer, ForeignKey("sitelink.id", ondelete="CASCADE")))
    __table_args__ = (UniqueConstraint("site_link_id", "googleads_asset_id", name="uix_site_link_asset"),)


class GoogleAdsCalloutAsset(GoogleAdsAsset, table=True):
    callout_id: int = Field(foreign_key="callout.id")
    __table_args__ = (UniqueConstraint("callout_id", "googleads_asset_id", name="uix_callout_asset"),)


class GoogleAdsStructuredSnippetAsset(GoogleAdsAsset, table=True):
    structured_snippet_id: int = Field(
        sa_column=SA_Column(Integer, ForeignKey("structuredsnippet.id", ondelete="CASCADE"))
    )
    __table_args__ = (
        UniqueConstraint(
            "structured_snippet_id",
            "googleads_asset_id",
            name="uix_site_structured_snippet_asset",
        ),
    )


class GoogleAdsPriceAsset(GoogleAdsAsset, table=True):
    price_id: int = Field(sa_column=SA_Column(Integer, ForeignKey("price.id", ondelete="CASCADE")))
    __table_args__ = (UniqueConstraint("price_id", "googleads_asset_id", name="uix_price_asset"),)


class GoogleAdsCallAsset(GoogleAdsAsset, table=True):
    phone_number_id: int = Field(foreign_key="phonenumber.id", unique=True)
    __table_args__ = (UniqueConstraint("phone_number_id", "googleads_asset_id", name="uix_phone_number_asset"),)


class GoogleAdsKeyword(SQLModel, table=True):
    id: Optional[int] = Field(primary_key=True)
    keyword_id: str
    ad_id: int = Field(default=None, sa_column=SA_Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))
    ad: "Ad" = Relationship(back_populates="googleads_keywords")


class GoogleAdsAccountBase(SQLModel):
    googleads_account_id: str
    manager_account_id: Optional[str]
    name: Optional[str]
    currency: Optional[str]
    user_account_id: int = Field(foreign_key="useraccount.id")
    selected: Optional[bool] = False
    linked: Optional[LinkedStatus] = Field(default="NOT_LINKED")


class GoogleAdsAccount(GoogleAdsAccountBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_account: Optional["UserAccount"] = Relationship(back_populates="googleads_accounts")
    campaigns: list["Campaign"] = Relationship(back_populates="googleads_account")


class GoogleAdsAccountData(GoogleAdsAccountBase):
    id: int
