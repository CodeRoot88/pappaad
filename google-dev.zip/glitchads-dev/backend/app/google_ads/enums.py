from enum import Enum


class KeywordAction(Enum):
    ADD = "Add"
    UPDATE = "Update"
