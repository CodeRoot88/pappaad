from fastapi import HTTPException, status


class GoogleAdsAccountNotFoundErrorException(HTTPException):
    def __init__(self, detail: str):
        self.status_code = status.HTTP_404_NOT_FOUND
        self.detail = detail


class GoogleAdsAdNotFoundErrorException(HTTPException):
    def __init__(self, detail: str):
        self.status_code = status.HTTP_404_NOT_FOUND
        self.detail = detail


class GoogleAdsAdDeleteErrorException(HTTPException):
    def __init__(self, detail: str):
        self.status_code = status.HTTP_400_BAD_REQUEST
        self.detail = detail
