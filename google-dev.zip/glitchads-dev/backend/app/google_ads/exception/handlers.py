from fastapi import Request
from fastapi.responses import JSONResponse

from .exceptions import (
    GoogleAdsAccountNotFoundErrorException,
    GoogleAdsAdNotFoundErrorException,
    GoogleAdsAdDeleteErrorException,
)


def register_google_ads_exception_handlers(app):
    @app.exception_handler(GoogleAdsAccountNotFoundErrorException)
    async def googleads_ad_account_error_exception_handler(
        request: Request, exc: GoogleAdsAccountNotFoundErrorException
    ):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )

    @app.exception_handler(GoogleAdsAdNotFoundErrorException)
    async def googleads_ad_not_found_error_exception_handler(request: Request, exc: GoogleAdsAdNotFoundErrorException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )

    @app.exception_handler(GoogleAdsAdDeleteErrorException)
    async def googleads_ad_delete_error_exception_handler(request: Request, exc: GoogleAdsAdDeleteErrorException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )
