from google.ads.googleads.errors import GoogleAdsException
from sqlmodel import Session


from app.ad.models import Ad
from app.ad.db_ops import get_ad_by_id, get_negative_keywords_by_ad_id, get_keywords_by_ad_id, remove_keyword_by_id

from app.campaign.models import Campaign, CampaignData
from app.campaign.db_ops import (
    get_campaign_by_id,
    add_campaign_error,
)
from app.google_ads.enums import KeywordAction
from app.keyword.models import KeywordData
from app.google_client_setup import initialize_googleads_client

from app.google_ads_integration.ad import GoogleAdsAdIntegration
from app.google_ads_integration.asset import GoogleAdsAssetIntegration
from app.google_ads_integration.campaign.base import GoogleAdsCampaignIntegration
from app.google_ads_integration.forecast import forecast_campaign
from app.google_ads_integration.keywords import (
    GoogleAdsKeywordIntegration,
)
from app.google_ads_integration.account_link import GoogleAdsAccountLinkIntegration
from app.google_ads_integration.keywords import (
    generate_keyword_ideas as keyword_ideas,
)
from app.google_ads_integration.report import GoogleAdsReportIntegration

from app.google_ads_integration.location import (
    get_geo_target_suggestions_by_search_string,
    get_geo_nearby_suggestions_by_get_targets,
)
from .db_ops import (
    add_googleads_keyword,
    add_googleads_ad,
    add_googleads_ad_group,
    add_googleads_callout,
    add_googleads_campaign,
    add_googleads_price,
    add_googleads_site_link,
    add_googleads_structured_snippet,
    get_googleads_campaign_by_campaign_id,
    get_googleads_ad_by_ad_id,
    get_googleads_ad_group_by_ad_id,
    update_googleads_accounts,
)

from typing import Any


class GoogleAdsService:
    def __init__(
        self,
        db: Session,
        refresh_token: str,
        googleads_account_id: str,
        googleads_manager_account_id: str | None = None,
    ):
        self.db = db
        self.client = initialize_googleads_client(refresh_token, googleads_manager_account_id)
        self.googleads_account_id = googleads_account_id
        self.googleads_manager_account_id = googleads_manager_account_id
        self.current_errors: list[Any] = []
        self.refresh_token = refresh_token

    def add_update_googleads_accounts(self, user_account_id: int):
        googleads_accounts = self.get_googleads_accounts()
        if googleads_accounts:
            update_googleads_accounts(
                googleads_accounts=googleads_accounts, user_account_id=user_account_id, db=self.db
            )

    def generate_keyword_ideas(self, url: str):
        return keyword_ideas(
            client=self.client,
            googleads_account_id=self.googleads_account_id,
            page_url=url,
            keyword_texts=None,
            language_id=None,
        )

    # def get_budget_recommendation(self, campaign_id):
    #     campaign = Campaign.get_campaign_by_id(campaign_id, self.db)
    #     ga_campaign_id = get_googleads_campaign_by_campaign_id(campaign_id, self.db).googleads_campaign_id
    #     return GoogleAdsCampaignIntegration(campaign, self.googleads_account_id, self.client, ga_campaign_id=ga_campaign_id).get_budget_recommendation()

    def get_budget_recommendation(self, url: str, glitch_campaign_id: int):
        # Example Request

        #         {
        #   "recommendationTypes": [
        #     "CAMPAIGN_BUDGET"

        #   ],
        #   "advertisingChannelType": "SEARCH",
        #   "countryCodes": [
        #     "US"

        #   ],
        #   "seedInfo": {
        #     "urlSeed": "https://ronspotflexwork.com/"

        #   },
        #   "biddingInfo": {
        #     "biddingStrategyType": "MAXIMIZE_CONVERSIONS"

        #   },
        #   "languageCodes": [
        #     "10"

        #   ],
        #   "positiveLocationsIds": [
        #     1022469

        #   ],
        #   "adGroupInfo": [
        #     {
        #       "adGroupType": "SEARCH_STANDARD",
        #       "keywords": [
        #         {
        #           "matchType": "BROAD",
        #           "text": "ronspot"
        #         },

        #       ]
        #     }

        #   ]

        # }
        client = self.client

        googleads_account_id = self.googleads_account_id
        glitch_campaign = get_campaign_by_id(glitch_campaign_id, self.db)

        recommendation_service = client.get_service("RecommendationService")
        if not glitch_campaign:
            return 0
        country_codes = {target_location.country_code for target_location in glitch_campaign.target_locations}
        location_ids = {target_location.criteria_id for target_location in glitch_campaign.target_locations}
        ad_group_info_list = []
        for ad in glitch_campaign.ads:
            if ad.id:
                keywords = get_keywords_by_ad_id(ad.id, self.db)
                ad_group_type = "SEARCH_STANDARD"
                ad_group_info = {
                    "ad_group_type": ad_group_type,
                    "keywords": [{"match_type": "BROAD", "text": keyword.text} for keyword in keywords],
                }
                ad_group_info_list.append(ad_group_info)
        # Create the request for recommendations

        request = {
            "customer_id": googleads_account_id,
            "recommendation_types": ["CAMPAIGN_BUDGET"],
            "advertising_channel_type": "SEARCH",
            "seed_info": {"url_seed": url},
            "country_codes": list(country_codes),  # Ensure this is a list, not a set
            "bidding_info": {"bidding_strategy_type": "MAXIMIZE_CONVERSIONS"},
            "language_codes": ["1000"],  # Use string values in a list
            "positive_locations_ids": list(location_ids),  # Ensure this is a list, not a set
            "ad_group_info": ad_group_info_list,  # Assuming ad_group_info_list is already a list
        }

        response = recommendation_service.generate_recommendations(request=request)

        # Process and print budget recommendations

        return response.recommendations[0].campaign_budget_recommendation.recommended_budget_amount_micros / 1000000

        # Example usage

    def get_campaign_link(self, campaign_id: int):
        googleads_campaign_id = get_googleads_campaign_by_campaign_id(campaign_id, self.db)
        return f"https://ads.google.com/aw/campaigns?campaignId={googleads_campaign_id.googleads_campaign_id}"

    def get_ad_link(self, campaign_id: int):
        googleads_campaign_id = get_googleads_campaign_by_campaign_id(campaign_id, self.db)
        return f"https://ads.google.com/aw/ads?campaignId={googleads_campaign_id.googleads_campaign_id}"

    def get_asset_link(self, campaign_id: int):
        googleads_campaign_id = get_googleads_campaign_by_campaign_id(campaign_id, self.db)
        return f"https://ads.google.com/aw/assetreport/associations/allupgraded?campaignId={googleads_campaign_id.googleads_campaign_id}"

    def create_campaign_in_googleads(self, campaign: CampaignData):
        if not campaign or not campaign.id:
            return

        existing_googleads_campaign = get_googleads_campaign_by_campaign_id(campaign.id, self.db)
        if not existing_googleads_campaign:
            googleads_campaign_id = self.add_campaign_to_googleads(campaign)
            if googleads_campaign_id:
                print("Adding campaign to Google Ads")
                add_googleads_campaign(campaign_id=campaign.id, googleads_campaign_id=googleads_campaign_id, db=self.db)

        else:
            googleads_campaign_id = existing_googleads_campaign.googleads_campaign_id
        if googleads_campaign_id:
            print("Adding ads to Google Ads")
            self.add_ads_to_googleads(campaign, googleads_campaign_id)
            print("Adding assets to Google Ads")
            self.add_assets_to_googleads(campaign, googleads_campaign_id)

    def update_campaign_in_googleads(self, campaign: CampaignData):
        import logging

        logger = logging.getLogger("uvicorn.error")
        self.update_googleads_campaign(campaign, self.googleads_account_id)
        logger.info("Campaign Updated")
        self.update_ads_in_googleads(campaign)
        logger.info("Ads Updated")
        self.update_assets_in_googleads(campaign, self.googleads_account_id)
        logger.info("Assets Updated")

    def add_campaign_to_googleads(self, campaign: CampaignData):
        googleads_campaign = GoogleAdsCampaignIntegration(
            googleads_account_id=self.googleads_account_id,
            client=self.client,
            campaign=campaign,
            googleads_campaign_id=None,
        )
        googleads_campaign.create_googleads_campaign()
        if googleads_campaign.errors:
            for error in googleads_campaign.errors:
                self.log_error(error)
        return googleads_campaign.googleads_campaign_id

    def add_ads_to_googleads(self, campaign: Campaign, googleads_campaign_id: str):
        for ad in campaign.ads:
            self.add_ad_to_googleads(ad, googleads_campaign_id)
        self.db.commit()

    def add_assets_to_googleads(self, campaign, googleads_campaign_id: str):
        campaign_id = campaign.id
        googleads_assets_service = GoogleAdsAssetIntegration(
            client=self.client,
            googleads_account_id=self.googleads_account_id,
            campaign_id=campaign_id,
            googleads_campaign_id=googleads_campaign_id,
        )
        if campaign.site_links:
            googleads_ids = googleads_assets_service.create_googleads_site_links_assets(site_links=campaign.site_links)
            if googleads_assets_service.errors:
                for error in googleads_assets_service.errors:
                    self.log_error(error)
            if googleads_ids:
                for googleads_id, site_link in zip(googleads_ids, campaign.site_links):
                    if site_link.id:
                        add_googleads_site_link(site_link.id, googleads_id.resource_name, self.db)
        if campaign.callouts:
            googleads_ids = googleads_assets_service.create_googleads_callouts_assets(callouts=campaign.callouts)
            if googleads_assets_service.errors:
                for error in googleads_assets_service.errors:
                    self.log_error(error)
            if googleads_ids:
                for googleads_id, callout in zip(googleads_ids, campaign.callouts):
                    if callout.id:
                        add_googleads_callout(callout.id, googleads_id, self.db)
        if campaign.structured_snippets:
            googleads_ids = googleads_assets_service.create_googleads_structured_snippet(
                structured_snippets=campaign.structured_snippets
            )
            if googleads_assets_service.errors:
                for error in googleads_assets_service.errors:
                    self.log_error(error)
            if googleads_ids:
                for googleads_id, snippet in zip(googleads_ids, campaign.structure_snippets):
                    add_googleads_structured_snippet(snippet.id, googleads_id, self.db)
        if campaign.prices:
            googleads_ids = googleads_assets_service.create_googleads_price_assets(prices=campaign.price)
            if googleads_assets_service.errors:
                for error in googleads_assets_service.errors:
                    self.log_error(error)
            if googleads_ids:
                for googleads_id, price in zip(googleads_ids, campaign.prices):
                    if price.id:
                        add_googleads_price(price.id, googleads_id, self.db)
        # if campaign.phone_numbers:
        #     ga_asset = GoogleAdsAssetIntegration(
        # campaign.phone_numbers,
        #         client=self.client,
        #         googleads_account_id=self.googleads_account_id,
        #         campaign_id=campaign_id,
        #         google_ads_campaign_id=google_ads_campaign_id,
        #     )
        #     ga_ids = ga_asset.create_google_ads_call_asset(campaign.phone_numbers)
        #     if ga_asset.errors:
        #         for error in ga_asset.errors:
        #             self.log_error(error)
        #     if ga_ids:
        #         for ga_id, phone_number in zip(ga_ids, campaign.phone_numbers):
        #             add_google_ads_call(phone_number.id, ga_id, self.db)

    def add_ad_to_googleads(self, ad: Ad, googleads_campaign_id: str):
        if not ad.id:
            return

        googleads_ad_service = GoogleAdsAdIntegration(
            client=self.client,
            googleads_account_id=self.googleads_account_id,
            googleads_campaign_id=googleads_campaign_id,
        )

        existing_googleads_ad_group = get_googleads_ad_group_by_ad_id(ad.id, self.db)

        if existing_googleads_ad_group:
            googleads_ad_group_id = existing_googleads_ad_group.googleads_ad_group_id
        else:
            googleads_ad_group_id = googleads_ad_service.create_googleads_ad_group(ad)
            add_googleads_ad_group(
                googleads_campaign_id=googleads_campaign_id,
                googleads_ad_group_id=googleads_ad_group_id,
                db=self.db,
                ad_id=ad.id,
            )

        existing_googleads_ad = get_googleads_ad_by_ad_id(ad.id, self.db)
        current_keywords = get_keywords_by_ad_id(ad.id, self.db)

        if not existing_googleads_ad:
            googlead_id = googleads_ad_service.create_responsive_search_ad(googleads_ad_group_id, ad)

            if googlead_id and ad.campaign_id:
                googleads_ad_id = googlead_id.split("~")[1]
                add_googleads_ad(googleads_ad_group_id, googleads_ad_id, ad.id, self.db)
                self.add_or_update_keywords_to_googleads(
                    googleads_ad_group_id=googleads_ad_group_id,
                    campaign_id=ad.campaign_id,
                    ad_id=ad.id,
                    keywords=current_keywords,
                    googleads_ad_service=googleads_ad_service,
                    action=KeywordAction.ADD,
                )
            else:
                print({"error": "Failed to create ad in Google Ads"})
                return
        # TODO Guard against adding existing keywords
        if existing_googleads_ad and ad.campaign_id:
            self.add_or_update_keywords_to_googleads(
                googleads_ad_group_id=googleads_ad_group_id,
                campaign_id=ad.campaign_id,
                ad_id=ad.id,
                keywords=current_keywords,
                googleads_ad_service=googleads_ad_service,
                action=KeywordAction.UPDATE,
            )

        negative_keywords = get_negative_keywords_by_ad_id(ad.id, self.db)
        self.add_negative_keywords_to_googleads(ad.id, googleads_ad_group_id, ad.campaign_id, negative_keywords)
        if googleads_ad_service.errors:
            for error in googleads_ad_service.errors:
                self.log_error(error)

    def add_or_update_keywords_to_googleads(
        self,
        googleads_ad_group_id: str,
        campaign_id: int,
        ad_id: int,
        keywords: list[KeywordData],
        googleads_ad_service: GoogleAdsAdIntegration,
        action=KeywordAction.ADD,
    ):
        attempt = 0
        max_attempts = 2  # We will try at most twice

        keyword_service = GoogleAdsKeywordIntegration(
            client=self.client,
            googleads_account_id=self.googleads_account_id,
            googleads_ad_group_id=googleads_ad_group_id,
            glitch_campaign_id=campaign_id,
            keywords=keywords,
        )

        if action == KeywordAction.UPDATE:
            keyword_service.remove_keywords_from_googleads()

        while attempt < max_attempts:
            attempt += 1

            googleads_exception, googleads_keyword_pairs = keyword_service.add_keywords_to_googleads()

            if googleads_exception is None:
                for pair in googleads_keyword_pairs:
                    keyword_id, googleads_keyword_id = pair
                    add_googleads_keyword(keyword_id, ad_id, self.db)

                for error in keyword_service.errors:
                    self.log_error(error)
                self.db.commit()
                return
            else:
                policy_violation_texts = []
                for error in googleads_exception.failure.errors:
                    if error.details and error.details.policy_violation_details:
                        policy_violation_details = error.details.policy_violation_details

                        if policy_violation_details.is_exemptible and policy_violation_details.key:
                            violating_text = policy_violation_details.key.violating_text
                            policy_violation_texts.append(violating_text)

                            # keyword_service.add_error(error)
                        else:
                            print(
                                "No exemption request is sent because your keyword "
                                "contained some non-exemptible policy violations."
                            )
                            raise googleads_exception
                    else:
                        print("No exemption request is sent because there are non-policy " "related errors thrown.")
                        raise googleads_exception

                keyword_service.add_error(googleads_exception)
                # Remove violating keywords from the list
                filtered_keywords = [kw for kw in keywords if kw.text not in policy_violation_texts]
                keyword_service.keywords = filtered_keywords

                # Remove and log violate text and its related headline from glitch
                voilated_keywords = [kw for kw in keywords if kw.text in policy_violation_texts]
                for v_keyword in voilated_keywords:
                    remove_keyword_by_id(v_keyword.id, db=self.db)

                ad = get_ad_by_id(ad_id, self.db)
                if ad and ad.googleads_ad and ad.googleads_ad.googleads_ad_id:
                    googleads_ad_service.update_responsive_search_ad(ad.googleads_ad.googleads_ad_id, ad)
                if not keywords:
                    print("No keywords left after removing policy-violating keywords.")
                    return  # Or handle accordingly

        print("Failed to add keywords after removing policy-violating keywords.")

    def add_negative_keywords_to_googleads(self, ad_id, google_ads_ad_group_id, glitch_campaign_id, keywords):
        # First, check if there are any existing negative keywords in Google Ads
        googleads_service = self.client.get_service("GoogleAdsService")

        # Format the ad group resource name correctly
        ad_group_resource_name = f"customers/{self.googleads_account_id}/adGroups/{google_ads_ad_group_id}"

        query = """
            SELECT
                ad_group_criterion.criterion_id,
                ad_group_criterion.keyword.text
            FROM ad_group_criterion
            WHERE ad_group_criterion.type = KEYWORD
            AND ad_group_criterion.status != 'REMOVED'
            AND ad_group_criterion.negative = true
            AND ad_group_criterion.ad_group = '{}' """.format(ad_group_resource_name)

        try:
            response = googleads_service.search(customer_id=self.googleads_account_id, query=query)

            # Check if there are any existing negative keywords
            existing_negative_keywords = [row.ad_group_criterion.keyword.text for row in response]

            if existing_negative_keywords:
                print(
                    f"Skipping negative keyword upload - existing negative keywords found: {existing_negative_keywords}"
                )
                return

            # If no existing negative keywords, proceed with adding new ones
            keyword_service = GoogleAdsKeywordIntegration(
                client=self.client,
                googleads_account_id=self.googleads_account_id,
                googleads_ad_group_id=google_ads_ad_group_id,
                glitch_campaign_id=glitch_campaign_id,
                keywords=keywords,
            )
            keyword_service.add_negative_keywords_to_googleads()
            for error in keyword_service.errors:
                self.log_error(error)
            self.db.commit()

        except GoogleAdsException as ex:
            print(f"Failed to check existing negative keywords: {ex}")
            self.log_error(
                {
                    "error_code": ex.error.code().name,
                    "error_message": ex.failure.errors[0].message,
                    "error_request_id": ex.request_id,
                }
            )

    def update_googleads_campaign(self, campaign: CampaignData, googleads_account_id: str):
        db_googleads_campaign = get_googleads_campaign_by_campaign_id(campaign.id, self.db)
        if db_googleads_campaign is None:
            return
        googleads_campaign_id = db_googleads_campaign.googleads_campaign_id
        googleads_campaign = GoogleAdsCampaignIntegration(
            googleads_account_id=googleads_account_id,
            client=self.client,
            campaign=campaign,
            googleads_campaign_id=googleads_campaign_id,
        )
        googleads_campaign.update_googleads_campaign()
        if googleads_campaign.errors:
            for error in googleads_campaign.errors:
                self.log_error(error)

    def update_ads_in_googleads(self, campaign: CampaignData):
        for ad in campaign.ads:
            self.update_ad_in_googleads(ad_id=ad.id)

    def update_ad_in_googleads(self, ad_id: int):
        ad = get_ad_by_id(id=ad_id, db=self.db)
        keywords = get_keywords_by_ad_id(ad_id, self.db)

        if not ad or not ad.campaign_id:
            return

        if ad.googleads_ad and ad.googleads_ad.googleads_ad_id:
            googleads_ad_service = GoogleAdsAdIntegration(
                client=self.client, googleads_account_id=self.googleads_account_id
            )
            googleads_ad_service.update_responsive_search_ad(googleads_ad_id=ad.googleads_ad.googleads_ad_id, ad=ad)

            googleads_ad_group = get_googleads_ad_group_by_ad_id(ad_id, self.db)
            if googleads_ad_group is None:
                return
            googleads_ad_group_id = googleads_ad_group.googleads_ad_group_id
            self.add_or_update_keywords_to_googleads(
                googleads_ad_group_id=googleads_ad_group_id,
                campaign_id=ad.campaign_id,
                ad_id=ad_id,
                keywords=keywords,
                googleads_ad_service=googleads_ad_service,
                action=KeywordAction.UPDATE,
            )
        else:
            googleads_campaign_id = get_googleads_campaign_by_campaign_id(
                campaign_id=ad.campaign_id, db=self.db
            ).googleads_campaign_id
            self.add_ad_to_googleads(ad=ad, googleads_campaign_id=googleads_campaign_id)

    def update_assets_in_googleads(self, campaign: CampaignData, googleads_account_id: str):
        db_googleads_campaign = get_googleads_campaign_by_campaign_id(campaign.id, self.db)
        if db_googleads_campaign is None:
            return
        googleads_campaign_id = db_googleads_campaign.googleads_campaign_id
        googleadsassets_service = GoogleAdsAssetIntegration(
            client=self.client,
            googleads_account_id=googleads_account_id,
            campaign_id=campaign.id,
            googleads_campaign_id=googleads_campaign_id,
        )
        if campaign.site_links:
            googleadsassets_service.update_googleads_site_link_assets(site_links=campaign.site_links)
            for error in googleadsassets_service.errors:
                self.log_error(error)
        if campaign.callouts:
            googleadsassets_service.update_googleads_callout_assets(callouts=campaign.callouts)
            for error in googleadsassets_service.errors:
                self.log_error(error)
        if campaign.structured_snippets:
            googleadsassets_service.update_googleads_structured_snippet(
                structured_snippets=campaign.structured_snippets
            )
            for error in googleadsassets_service.errors:
                self.log_error(error)
        if campaign.prices:
            googleadsassets_service.update_googleads_price_assets(prices=campaign.prices)
            for error in googleadsassets_service.errors:
                self.log_error(error)
        # if campaign.phone_numbers:
        # phone_numbers = GoogleAdsAssetIntegration(
        #     campaign.phone_numbers,
        # client=self.client,
        # googleads_account_id=googleads_account_id,
        # campaign_id=campaign.id,
        # googleads_campaign_id=googleads_campaign_id,
        # )
        # # phone_numbers.update_googleads_call_asset()
        # for error in phone_numbers.errors:
        #     self.log_error(error)

    def log_error(self, error):
        self.current_errors.append(error)
        add_campaign_error(
            campaign_id=error.get("id"),
            error_code=error.get("error_code"),
            error_message=error.get("error_message"),
            fields=error.get("fields"),
            error_request_id=error.get("error_request_id"),
            class_name=error.get("class_name"),
            class_id=error.get("class_id"),
            db=self.db,
        )

    def get_googleads_accounts(self):
        """
        Lists customer IDs accessible by the given client.
        """
        try:
            # client = self.client
            # customer_service = client.get_service("CustomerService")
            # accessible_customers = customer_service.list_accessible_customers()
            customer_hierarchy, names, managers, currencies = self.get_customer_hierarchy()

            return_values = []
            # if len(accessible_customers.resource_names) == 1:
            #     customer_id = accessible_customers.resource_names[0].split("/")[-1]

            #     return [
            #         {
            #             "account_id": customer_id,
            #             "name": names.get(customer_id),
            #             "mcc_id": None,
            #         }
            #     ]
            for customer_id, mcc in customer_hierarchy.items():
                if customer_id in managers:
                    print("Manager_Id")
                    print(customer_id)
                else:
                    name = names.get(int(customer_id))
                    currency = currencies.get(int(customer_id))
                    return_values.append(
                        {"account_id": str(customer_id), "name": name, "currency": currency, "mcc_id": mcc}
                    )
            return return_values

        except GoogleAdsException as ex:
            print(
                f"Request with ID '{ex.request_id}' failed with status '{ex.error.code().name}' and includes the following errors:"
            )
            for error in ex.failure.errors:
                print(f"\tError with message '{error.message}'.")
                if error.location:
                    for field_path_element in error.location.field_path_elements:
                        print(f"\t\tOn field: {field_path_element.field_name}")

    def get_customer_hierarchy(self):
        """Gets the account hierarchy of the given MCC and login customer ID.

        Args:
        client: The Google Ads client.
        login_customer_id: Optional manager account ID. If none provided, this
        method will instead list the accounts accessible from the
        authenticated Google Ads account.
        """

        # Gets instances of the GoogleAdsService and CustomerService clients.

        client = initialize_googleads_client(self.refresh_token, self.googleads_manager_account_id)
        googleads_service = client.get_service("GoogleAdsService")
        customer_service = client.get_service("CustomerService")

        # A collection of customer IDs to handle.
        seed_customer_ids = []
        managers = []
        # Creates a query that retrieves all child accounts of the manager
        # specified in search calls below.
        query = """
            SELECT
            customer_client.client_customer,
            customer_client.level,
            customer_client.manager,
            customer_client.descriptive_name,
            customer_client.currency_code,
            customer_client.time_zone,
            customer_client.id
            FROM customer_client
            WHERE customer_client.level <= 1
            """

        # If a Manager ID was provided in the customerId parameter, it will be
        # the only ID in the list. Otherwise, we will issue a request for all
        # customers accessible by this authenticated Google account.
        # if login_customer_id is not None:
        #     seed_customer_ids = [login_customer_id]
        # else:
        customer_resource_names = customer_service.list_accessible_customers().resource_names

        for customer_resource_name in customer_resource_names:
            customer_id = googleads_service.parse_customer_path(customer_resource_name)["customer_id"]
            seed_customer_ids.append(customer_id)
        all_accounts = []
        names = {}
        currencies = {}
        for seed_customer_id in seed_customer_ids:
            # Performs a breadth-first search to build a Dictionary that maps
            # managers to their child accounts (customerIdsToChildAccounts).
            unprocessed_customer_ids = [seed_customer_id]
            customer_ids_to_child_accounts = dict()
            root_customer_client = None
            while unprocessed_customer_ids:
                print("start of loop")
                customer_id = int(unprocessed_customer_ids.pop(0))
                print(customer_id)
                try:
                    print("here")
                    response = googleads_service.search(customer_id=str(customer_id), query=query)

                except GoogleAdsException:
                    print(customer_id)
                else:
                    if len([row for row in response]) > 1:
                        managers.append(customer_id)
                    # Iterates over all rows in all pages to get all customer
                    # clients under the specified customer's hierarchy.
                    for googleads_row in response:
                        customer_client = googleads_row.customer_client
                        names[customer_client.id] = customer_client.descriptive_name
                        currencies[customer_client.id] = customer_client.currency_code
                        # The customer client that with level 0 is the specified
                        # customer.

                        if customer_client.level == 0:
                            if root_customer_client is None:
                                root_customer_client = customer_client
                                if customer_client.id not in customer_ids_to_child_accounts.keys():
                                    customer_ids_to_child_accounts[customer_client.id] = []

                            continue

                        # For all level-1 (direct child) accounts that are a
                        # manager account, the above query will be run against them
                        # to create a Dictionary of managers mapped to their child
                        # accounts for printing the hierarchy afterwards.
                        if customer_id not in customer_ids_to_child_accounts:
                            customer_ids_to_child_accounts[customer_id] = []

                        customer_ids_to_child_accounts[customer_id].append(customer_client)

                        if customer_client.manager:
                            print("manager")
                            print(customer_client.id)
                            # A customer can be managed by multiple managers, so to
                            # prevent visiting the same customer many times, we
                            # need to check if it's already in the Dictionary.
                            if customer_client.id not in customer_ids_to_child_accounts and customer_client.level == 1:
                                unprocessed_customer_ids.append(customer_client.id)
                                names[customer_client.id] = customer_client.descriptive_name
                                currencies[customer_client.id] = customer_client.currency_code

            all_accounts.append(customer_ids_to_child_accounts)
        return (self.process_account_structure(all_accounts), names, managers, currencies)

    def process_account_structure(self, account_structure):
        result = {}
        for accounts_hash in account_structure:
            for key, values in accounts_hash.items():
                if result.get(key) is None:
                    result[key] = []
                for v in values:
                    id = v.id
                    if id in result:
                        result[id].append(key)
                    else:
                        result[id] = [key]
        return result

    def update_site_links_in_googleads(self, site_link):
        googleads_asset_service = GoogleAdsAssetIntegration(
            client=self.client, googleads_account_id=self.googleads_account_id, campaign_id=site_link.campaign_id
        )
        googleads_asset_service.update_googleads_site_link_assets()

    def update_callouts_in_googleads(self, callout):
        googleads_asset_service = GoogleAdsAssetIntegration(
            client=self.client, googleads_account_id=self.googleads_account_id, campaign_id=callout.campaign_id
        )
        googleads_asset_service.update_googleads_callout_assets()

    # def update_structured_snippets_in_googleads(self, structured_snippet, campaign_id, glitch_campaign_id):
    #     ga_asset = GoogleAdsAssetIntegration(structured_snippet, self.client, campaign_id, glitch_campaign_id)
    #     # ga_asset.update_google_ads_structured_snippets()

    def update_prices_in_googleads(self, price):
        googleads_asset_service = GoogleAdsAssetIntegration(
            client=self.client, googleads_account_id=self.googleads_account_id, campaign_id=price.campaign_id
        )
        googleads_asset_service.update_googleads_price_assets()

    def delete_campaign(self, googleads_campaign_id, googleads_budget_id):
        client = self.client
        googleads_account_id = self.googleads_account_id
        campaign_service = client.get_service("CampaignService")
        campaign_operation = client.get_type("CampaignOperation")
        campaign_operation.remove = client.get_service("CampaignService").campaign_path(
            googleads_account_id, googleads_campaign_id
        )

        try:
            campaign_service.mutate_campaigns(customer_id=googleads_account_id, operations=[campaign_operation])
        except GoogleAdsException as ex:
            raise Exception(ex)
            self.add_error(ex)

        campaign_budget_service = client.get_service("CampaignBudgetService")
        campaign_budget_operation = client.get_type("CampaignBudgetOperation")
        campaign_budget_operation.remove = client.get_service("CampaignBudgetService").campaign_budget_path(
            googleads_account_id, googleads_budget_id
        )

        try:
            campaign_budget_service.mutate_campaign_budgets(
                customer_id=googleads_account_id, operations=[campaign_budget_operation]
            )
        except GoogleAdsException as ex:
            raise Exception(ex)

            # self.add_error(ex)

    def delete_ad(self, ad_id, ad_group_id):
        googleads_account_id = self.googleads_account_id
        client = self.client

        ad_group_service = client.get_service("AdGroupService")

        # Create a remove operation
        ad_group_operation = client.get_type("AdGroupOperation")
        ad_group_operation.remove = client.get_service("AdGroupService").ad_group_path(
            googleads_account_id, ad_group_id
        )

        try:
            # Send the remove request
            ad_group_response = ad_group_service.mutate_ad_groups(
                customer_id=googleads_account_id, operations=[ad_group_operation]
            )
            print(f"Removed ad group with resource name: {ad_group_response.results[0].resource_name}")
        except GoogleAdsException as ex:
            raise Exception(ex)
            self.add_error(ex)

    def delete_asset(self, asset_id):
        client = self.client
        googleads_account_id = self.googleads_account_id
        asset_service = client.get_service("AssetService")

        # Create a remove operation
        asset_operation = client.get_type("AssetOperation")
        asset_operation.remove = client.get_service("AssetService").asset_path(googleads_account_id, asset_id)

        try:
            # Send the remove request
            asset_response = asset_service.mutate_assets(customer_id=googleads_account_id, operations=[asset_operation])
            print(f"Removed asset with resource name: {asset_response.results[0].resource_name}")
        except GoogleAdsException as ex:
            self.add_error(ex)

    def forecast_campaign(self, campaign: Campaign):
        country_code = campaign.target_locations[0].country_code
        location_query = campaign.target_locations[0].name
        return forecast_campaign(
            client=self.client,
            googleads_account_id=self.googleads_account_id,
            country_code=country_code,
            location_query=location_query,
            ad_groups=campaign.ads,
            locations=None,
        )

    def keyword_performance_report(self):
        return GoogleAdsReportIntegration(
            client=self.client, googleads_account_id=self.googleads_account_id, campaign_id=None
        ).keyword_performance_report()

    def get_geo_target_suggestions_by_search_string(self, search_string):
        return get_geo_target_suggestions_by_search_string(self.client, search_string)

    def get_geo_nearby_suggestions_by_get_targets(self, search_string):
        return get_geo_nearby_suggestions_by_get_targets(self.client, search_string)

    def add_error(self, ex):
        return self

    def link_client_account_to_manager_account(self):
        manager_account_id = self.googleads_manager_account_id
        return GoogleAdsAccountLinkIntegration(
            client=self.client,
            googleads_account_id=self.googleads_account_id,
            manager_account_id=manager_account_id,
        ).link_account_to_manager()
