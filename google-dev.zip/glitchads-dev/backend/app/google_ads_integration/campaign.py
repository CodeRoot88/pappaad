from .campaign.base import GoogleAdsCampaignIntegration

# Re-export the main class
__all__ = ["GoogleAdsCampaignIntegration"]
