from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.client import GoogleAdsClient
import datetime
import pytz
import re
from typing import Optional, Any
from dataclasses import dataclass

from app.campaign.models import CampaignData
from .budget import GoogleAdsBudgetOperations
from .location import GoogleAdsLocationOperations
from .error import GoogleAdsErrorHandler
from .query import GoogleAdsQueryUtils
from .updates import GoogleAdsCampaignUpdates
from ..dsa import create_dynamic_search_ad

_DATE_FORMAT = "%Y%m%d"


@dataclass
class CampaignParams:
    name: Optional[str] = None
    start_date: Optional[str] = None
    advertising_channel_type: Optional[Any] = None
    status: Optional[Any] = None
    enhanced_cpc_enabled: Optional[bool] = None
    positive_geo_target_type: Optional[Any] = None
    bidding_strategy_type: Optional[Any] = None
    target_google_search: Optional[bool] = None
    target_search_network: Optional[bool] = None
    target_partner_search_network: Optional[bool] = None
    target_content_network: Optional[bool] = None
    target_cpa_micros: Optional[int] = None
    dsa_domain_name: Optional[str] = None
    dsa_language_code: Optional[str] = None


class GoogleAdsCampaignIntegration:
    def __init__(
        self,
        googleads_account_id: str,
        client: GoogleAdsClient,
        campaign: CampaignData | None = None,
        googleads_campaign_id: str | None = None,
    ):
        self.client = client
        self.googleads_account_id = googleads_account_id
        self.campaign = campaign
        self.googleads_campaign_id = googleads_campaign_id
        self.googleads_budget_id = 0
        self.errors: list[Any] = []

        # Initialize sub-components
        self.budget_ops = GoogleAdsBudgetOperations(self)
        self.location_ops = GoogleAdsLocationOperations(self)
        self.error_handler = GoogleAdsErrorHandler(self)
        self.query_utils = GoogleAdsQueryUtils(self)
        self.campaign_updates = GoogleAdsCampaignUpdates(self)

    def _configure_campaign_params(self, campaign: Any, params: CampaignParams) -> Any:
        """Configure campaign parameters with provided values."""
        updates = {
            "name": params.name,
            "status": params.status,
            "start_date": params.start_date,
            "advertising_channel_type": params.advertising_channel_type,
            "manual_cpc.enhanced_cpc_enabled": params.enhanced_cpc_enabled,
            "geo_target_type_setting.positive_geo_target_type": params.positive_geo_target_type,
            "bidding_strategy_type": params.bidding_strategy_type,
            "network_settings.target_google_search": params.target_google_search,
            "network_settings.target_search_network": params.target_search_network,
            "network_settings.target_partner_search_network": params.target_partner_search_network,
            "network_settings.target_content_network": params.target_content_network,
            "maximize_conversions.target_cpa_micros": params.target_cpa_micros,
            "dynamic_search_ads_setting.domain_name": params.dsa_domain_name,
            "dynamic_search_ads_setting.language_code": params.dsa_language_code,
        }

        for attr_path, value in updates.items():
            if value is not None:
                parts = attr_path.split(".")
                obj = campaign
                for part in parts[:-1]:
                    obj = getattr(obj, part)
                setattr(obj, parts[-1], value)

        return campaign

    def create_googleads_campaign(self, start_time=None, end_time=None):
        if not self.campaign:
            raise ValueError("Campaign does not exist.")

        if not start_time:
            account_time_zone = self.query_utils.get_account_timezone()
            timezone_obj = pytz.timezone(account_time_zone)
            current_time = datetime.datetime.now(timezone_obj)
            start_time = current_time.date()

        client = self.client
        campaign_operation = client.get_type("CampaignOperation")
        campaign = campaign_operation.create

        # Prepare DSA domain
        domain_name = (
            self.campaign.website_url.replace("http://", "").replace("https://", "").replace("www.", "").split("/")[0]
        )

        # Configure campaign parameters
        params = CampaignParams(
            name=self.campaign.name,
            start_date=datetime.date.strftime(start_time, _DATE_FORMAT),
            advertising_channel_type=client.enums.AdvertisingChannelTypeEnum.SEARCH,
            status=client.enums.CampaignStatusEnum.PAUSED,
            enhanced_cpc_enabled=True,
            positive_geo_target_type=client.enums.PositiveGeoTargetTypeEnum.PRESENCE,
            bidding_strategy_type=client.enums.BiddingStrategyTypeEnum.MAXIMIZE_CONVERSIONS,
            target_google_search=True,
            target_search_network=False,
            target_partner_search_network=False,
            target_content_network=False,
            target_cpa_micros=self.campaign.target_cpa * 1000000 if self.campaign.target_cpa else None,
            dsa_domain_name=domain_name,
            dsa_language_code="en",
        )

        campaign = self._configure_campaign_params(campaign, params)

        # TODO: Campaign budgets can be shared but do we need to do that?
        campaign_budget_service = client.get_service("CampaignBudgetService")
        campaign_service = client.get_service("CampaignService")
        # Create a budget, which can be shared by multiple campaigns.
        campaign_budget_operation = self.budget_ops.create_campaign_budget()
        try:
            campaign_budget_response = campaign_budget_service.mutate_campaign_budgets(
                customer_id=self.googleads_account_id, operations=[campaign_budget_operation]
            )
            campaign_budget_id = campaign_budget_response.results[0].resource_name
            campaign.campaign_budget = campaign_budget_id
        except GoogleAdsException as ex:
            self.error_handler.add_error(ex)

        try:
            campaign_response = campaign_service.mutate_campaigns(
                customer_id=self.googleads_account_id, operations=[campaign_operation]
            )

            campaign_id = re.findall(r"campaigns\/(\d+)", campaign_response.results[0].resource_name)[0]
            campaign_budget_id = 0
            self.googleads_campaign_id = campaign_id
            self.location_ops.add_locations()
            self.location_ops.add_language_to_campaign()
            if self.campaign.ads:
                if self.campaign.ads[0].descriptions:
                    description_for_dsa = self.campaign.ads[0].descriptions[0].text
                    create_dynamic_search_ad(
                        googleads_client=client,
                        googleads_account_id=self.googleads_account_id,
                        googleads_campaign_id=self.googleads_campaign_id,
                        description=description_for_dsa,
                        campaign_name=self.campaign.name,
                    )
            return campaign_id
        except GoogleAdsException as ex:
            self.error_handler.add_error(ex)

    def update_googleads_campaign(self):
        """Update an existing Google Ads campaign with new settings."""
        if not self.campaign or not self.googleads_campaign_id:
            raise ValueError("Campaign or Google Ads Campaign ID does not exist.")

        update_fields = {}
        client = self.client

        # Convert campaign state to Google Ads enum
        if self.campaign.state:
            status_enum = client.enums.CampaignStatusEnum
            status_mapping = {
                "ENABLED": status_enum.ENABLED,
                "PAUSED": status_enum.PAUSED,
                "REMOVED": status_enum.REMOVED,
            }
            status = status_mapping.get(self.campaign.state)
            if status is not None:  # Only add if we have a valid mapping
                update_fields["status"] = status

        if self.campaign.target_cpa:
            update_fields["maximize_conversions.target_cpa_micros"] = self.campaign.target_cpa * 1000000

        if not update_fields:  # Don't proceed if there's nothing to update
            return False

        try:
            # Use the updates module to perform the update
            success = self.campaign_updates.update_googleads_campaign_by_fields(update_fields)

            # Update locations if needed and if the update was successful
            if success:
                self.budget_ops.update_campaign_budget()
            if success and self.campaign.target_locations:
                self.location_ops.add_locations()

            return success
        except Exception as e:
            self.error_handler.add_error(e)
            return False
