from google.ads.googleads.errors import GoogleAdsException
from typing import Optional


class GoogleAdsBudgetOperations:
    def __init__(self, campaign_integration):
        self.integration = campaign_integration

    def get_budget_recommendation(self) -> Optional[float]:
        """Get budget recommendation for the campaign."""
        if not self.integration.campaign:
            return None

        client = self.integration.client
        recommendation_service = client.get_service("RecommendationService")

        query = """
            SELECT 
                recommendation.campaign_budget_recommendation.recommended_budget_amount_micros
            FROM recommendation
            WHERE recommendation.type = 'CAMPAIGN_BUDGET'
            AND recommendation.campaign = '%s'
        """

        try:
            response = recommendation_service.search(
                customer_id=self.integration.googleads_account_id, query=query % self.integration.googleads_campaign_id
            )

            for recommendation in response:
                return self.from_micros(recommendation.campaign_budget_recommendation.recommended_budget_amount_micros)

        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
            return None

    def create_campaign_budget(self):
        """Create a new campaign budget."""
        if not self.integration.campaign:
            raise ValueError("Campaign does not exist.")

        client = self.integration.client
        campaign_budget_operation = client.get_type("CampaignBudgetOperation")
        campaign_budget = campaign_budget_operation.create

        campaign_budget.name = f"Budget #{self.integration.campaign.name}"
        campaign_budget.delivery_method = client.enums.BudgetDeliveryMethodEnum.STANDARD
        campaign_budget.amount_micros = self.to_micros(self.integration.campaign.budget)

        # Set to explicitly shared
        campaign_budget.explicitly_shared = False

        return campaign_budget_operation

    def _update_campaign_budget(self, budget_resource_name: str) -> bool:
        """Update an existing campaign budget."""
        if not self.integration.campaign:
            return False

        client = self.integration.client
        campaign_budget_service = client.get_service("CampaignBudgetService")
        campaign_budget_operation = client.get_type("CampaignBudgetOperation")

        # Set up the budget update
        campaign_budget = campaign_budget_operation.update
        campaign_budget.resource_name = budget_resource_name
        campaign_budget.amount_micros = self.to_micros(self.integration.campaign.budget)

        # Create field mask for budget update
        campaign_budget_operation.update_mask.paths.append("amount_micros")

        try:
            campaign_budget_service.mutate_campaign_budgets(
                customer_id=self.integration.googleads_account_id, operations=[campaign_budget_operation]
            )
            return True
        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
            return False

    @staticmethod
    def to_micros(amount: float) -> int:
        """Convert a regular amount to micros (millionths)."""
        return int(amount * 1_000_000)

    @staticmethod
    def from_micros(micros: int) -> float:
        """Convert micros (millionths) to a regular amount."""
        return micros / 1_000_000

    def get_campaign_budget_resource_name(self) -> Optional[str]:
        """Get the budget resource name for the campaign."""
        if not self.integration.googleads_campaign_id:
            return None

        client = self.integration.client
        ga_service = client.get_service("GoogleAdsService")

        query = """
            SELECT 
                campaign.campaign_budget
            FROM campaign
            WHERE campaign.id = '%s'
        """

        try:
            response = ga_service.search(
                customer_id=self.integration.googleads_account_id, query=query % self.integration.googleads_campaign_id
            )

            for row in response:
                return row.campaign.campaign_budget

        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
            return None

    def update_campaign_budget(self) -> bool:
        """Get and update the campaign budget."""
        if not self.integration.campaign:
            return False

        budget_resource_name = self.get_campaign_budget_resource_name()
        if not budget_resource_name:
            return False

        return self._update_campaign_budget(budget_resource_name)
