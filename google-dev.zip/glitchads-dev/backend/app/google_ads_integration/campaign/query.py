from google.ads.googleads.errors import GoogleAdsException
from typing import List, Dict, Any, Optional


class GoogleAdsQueryUtils:
    def __init__(self, campaign_integration):
        self.integration = campaign_integration

    def get_googleads_campaign_fields(self, fields: List[str]) -> Dict[str, Any]:
        """Get specific fields from a Google Ads campaign."""
        if not self.integration.googleads_campaign_id:
            return {}

        client = self.integration.client
        ga_service = client.get_service("GoogleAdsService")

        query = f"""
            SELECT 
                {", ".join(fields)}
            FROM campaign
            WHERE campaign.id = {self.integration.googleads_campaign_id}
        """

        try:
            response = ga_service.search(customer_id=self.integration.googleads_account_id, query=query)

            for row in response:
                return {field: getattr(row.campaign, field) for field in fields}

        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
            return {}

    def get_account_timezone(self) -> str:
        """Get the timezone of the Google Ads account."""
        client = self.integration.client
        ga_service = client.get_service("GoogleAdsService")

        query = """
            SELECT 
                customer.time_zone
            FROM customer
            LIMIT 1
        """

        try:
            response = ga_service.search(customer_id=self.integration.googleads_account_id, query=query)

            for row in response:
                return row.customer.time_zone

        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
            return "America/Los_Angeles"  # Default fallback timezone

    def get_website_url_for_campaign(self) -> Optional[str]:
        """Get the website URL associated with a campaign."""
        fields = ["dynamic_search_ads_setting.domain_name"]
        result = self.get_googleads_campaign_fields(fields)
        return result.get("dynamic_search_ads_setting.domain_name")
