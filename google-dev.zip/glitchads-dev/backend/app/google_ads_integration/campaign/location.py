from google.ads.googleads.errors import GoogleAdsException


class GoogleAdsLocationOperations:
    def __init__(self, campaign_integration):
        self.integration = campaign_integration

    def add_locations(self):
        """Add location targeting to the campaign."""
        if not self.integration.campaign or not self.integration.campaign.target_locations:
            return

        client = self.integration.client
        campaign_criterion_service = client.get_service("CampaignCriterionService")

        operations = []
        for location in self.integration.campaign.target_locations:
            campaign_criterion_operation = client.get_type("CampaignCriterionOperation")
            campaign_criterion = campaign_criterion_operation.create
            campaign_criterion.campaign = (
                f"customers/{self.integration.googleads_account_id}/campaigns/{self.integration.googleads_campaign_id}"
            )
            campaign_criterion.location.geo_target_constant = f"geoTargetConstants/{location.criteria_id}"
            operations.append(campaign_criterion_operation)

        try:
            campaign_criterion_service.mutate_campaign_criteria(
                customer_id=self.integration.googleads_account_id,
                operations=operations,
            )
        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)

    def add_language_to_campaign(self, language_code: str = "1000"):
        """Add language targeting to the campaign."""
        client = self.integration.client
        campaign_criterion_service = client.get_service("CampaignCriterionService")

        campaign_criterion_operation = client.get_type("CampaignCriterionOperation")
        campaign_criterion = campaign_criterion_operation.create
        campaign_criterion.campaign = (
            f"customers/{self.integration.googleads_account_id}/campaigns/{self.integration.googleads_campaign_id}"
        )
        campaign_criterion.language.language_constant = f"languageConstants/{language_code}"

        try:
            campaign_criterion_service.mutate_campaign_criteria(
                customer_id=self.integration.googleads_account_id,
                operations=[campaign_criterion_operation],
            )
        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
