from google.ads.googleads.errors import GoogleAdsException
from ..errors import GoogleAdsErrorHandler as BaseErrorHandler


class GoogleAdsErrorHandler:
    def __init__(self, campaign_integration):
        self.integration = campaign_integration

    def add_error(self, ex: GoogleAdsException) -> None:
        """Process and store Google Ads API errors."""
        error = BaseErrorHandler.create_error(
            ex=ex, class_name=self.integration.__class__.__name__, id=str(self.integration.googleads_campaign_id or "")
        )

        self.integration.errors.append(error.__dict__)
