from google.ads.googleads.errors import GoogleAdsException
from google.protobuf import field_mask_pb2
from typing import Dict, Any


class GoogleAdsCampaignUpdates:
    def __init__(self, campaign_integration):
        self.integration = campaign_integration

    def update_googleads_campaign_by_fields(self, fields: Dict[str, Any]) -> bool:
        """Update specific fields of a Google Ads campaign."""
        if not self.integration.googleads_campaign_id:
            return False

        client = self.integration.client
        campaign_service = client.get_service("CampaignService")
        campaign_operation = client.get_type("CampaignOperation")

        # Construct the resource name
        campaign = campaign_operation.update
        campaign.resource_name = (
            f"customers/{self.integration.googleads_account_id}/campaigns/{self.integration.googleads_campaign_id}"
        )

        # Update fields
        field_mask = field_mask_pb2.FieldMask()
        update_fields = []

        for field_path, value in fields.items():
            # Handle nested fields
            field_parts = field_path.split(".")
            current = campaign

            # Navigate to the nested field
            for part in field_parts[:-1]:
                if not hasattr(current, part):
                    current = getattr(current, part, None)
                    if current is None:
                        setattr(current, part, client.get_type(part.capitalize()))
                current = getattr(current, part)

            # Set the final value
            setattr(current, field_parts[-1], value)
            update_fields.append(field_path)

        # Set the field mask
        field_mask.paths.extend(update_fields)
        campaign_operation.update_mask.CopyFrom(field_mask)

        try:
            campaign_service.mutate_campaigns(
                customer_id=self.integration.googleads_account_id,
                operations=[campaign_operation],
            )
            return True
        except GoogleAdsException as ex:
            self.integration.error_handler.add_error(ex)
            return False
