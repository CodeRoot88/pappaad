from typing import Any, List, Optional

from app.campaign.asset_models import StructuredSnippetData
from app.google_ads_integration.assets.base import GoogleAdsAssetIntegrationBase
from google.ads.googleads.errors import GoogleAdsException
from google.api_core import protobuf_helpers


class GoogleAdsStructuredSnippetIntegration(GoogleAdsAssetIntegrationBase):
    """Handles creation and management of Google Ads structured snippet assets."""

    def __init__(
        self,
        client,
        googleads_account_id: str,
        campaign_id: int,
        googleads_campaign_id: Optional[str] = None,
    ):
        super().__init__(
            client=client,
            googleads_account_id=googleads_account_id,
            campaign_id=campaign_id,
            googleads_campaign_id=googleads_campaign_id,
            asset_field_type="STRUCTURED_SNIPPET",
        )

    def _create_asset_operation(self, structured_snippet: StructuredSnippetData) -> Any:
        """Create an asset operation for a single structured snippet."""
        operation = self.client.get_type("AssetOperation")
        asset = operation.create
        asset.structured_snippet_asset.header = structured_snippet.header_type
        asset.structured_snippet_asset.values.extend([value.value for value in structured_snippet.values])
        return operation

    def _get_existing_assets(self) -> List[Any]:
        """Fetch existing structured snippet assets for the campaign."""
        query = """
            SELECT 
                campaign_asset.asset,
                asset.structured_snippet_asset.header,
                asset.structured_snippet_asset.values
            FROM campaign_asset
            WHERE 
                campaign_asset.campaign = '{campaign_id}'
                AND campaign_asset.field_type = STRUCTURED_SNIPPET
        """.format(campaign_id=self.googleads_campaign_id)

        ga_service = self.client.get_service("GoogleAdsService")
        response = ga_service.search(customer_id=self.googleads_account_id, query=query)
        return [row.campaign_asset for row in response]

    def _create_update_operation(
        self, structured_snippet: StructuredSnippetData, existing_snippet: Any
    ) -> Optional[Any]:
        """
        Create an update operation for a single structured snippet asset.

        Args:
            structured_snippet: New structured snippet data
            existing_snippet: Existing Google Ads structured snippet asset

        Returns:
            AssetOperation if changes are needed, None otherwise
        """
        operation = self.client.get_type("AssetOperation")
        asset = operation.update
        asset.resource_name = existing_snippet.asset

        # Create field mask for tracking changes
        field_mask = protobuf_helpers.field_mask(None, operation.update)
        has_changes = False

        # Check and update header
        if structured_snippet.header_type != existing_snippet.asset.structured_snippet_asset.header:
            asset.structured_snippet_asset.header = structured_snippet.header_type
            field_mask.paths.append("structured_snippet_asset.header")
            has_changes = True

        # Check and update values
        new_values = [value.value for value in structured_snippet.values]
        if new_values != list(existing_snippet.asset.structured_snippet_asset.values):
            asset.structured_snippet_asset.values.extend(new_values)
            field_mask.paths.append("structured_snippet_asset.values")
            has_changes = True

        if not has_changes:
            return None

        operation.update_mask.CopyFrom(field_mask)
        return operation

    def get_googleads_structured_snippets_for_campaign(self):
        """Fetch all structured snippet assets associated with the campaign."""
        if not self.googleads_campaign_id:
            return []

        googleads_service = self.client.get_service("GoogleAdsService")
        query = f"""
        SELECT
            campaign.id,
            asset.structured_snippet_asset.header,
            asset.structured_snippet_asset.values
        FROM
            campaign_asset
        WHERE
            campaign.id = {self.googleads_campaign_id}
            AND
            campaign_asset.field_type = 'STRUCTURED_SNIPPET'
        """

        try:
            response = googleads_service.search(customer_id=self.googleads_account_id, query=query)
            return [row.asset for row in response]
        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, "StructuredSnippet", self.campaign_id)
            self.errors.append(error)
            return []

    # These methods are now inherited from the base class and don't need to be implemented:
    # - create_googleads_structured_snippet (use create_googleads_assets instead)
    # - update_googleads_structured_snippet (use update_googleads_assets instead)
    # - handle_googleads_exception
    # - _create_campaign_asset_operation
    # - attach_structured_snippets_to_campaign (use base class campaign asset creation)
