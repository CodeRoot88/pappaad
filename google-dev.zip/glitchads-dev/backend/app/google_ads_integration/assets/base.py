from dataclasses import dataclass
from typing import Any, List, Optional
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.client import GoogleAdsClient


@dataclass
class GoogleAdsError:
    error_request_id: str
    error_code: str
    error_message: str
    fields: List[str]
    class_name: str
    id: int
    class_id: int


class GoogleAdsErrorHandlerMixin:
    def handle_googleads_exception(self, ex: GoogleAdsException, class_name: str, entity_id: int) -> GoogleAdsError:
        error_message = self._extract_error_message(ex)
        fields = self._extract_error_fields(ex)

        return GoogleAdsError(
            error_request_id=ex.request_id,
            error_code=ex.error.code().name,
            error_message=error_message,
            fields=fields,
            class_name=class_name,
            id=entity_id,
            class_id=entity_id,
        )

    def _extract_error_message(self, ex: GoogleAdsException) -> str:
        if hasattr(ex.error, "policy_violation_details"):
            return getattr(ex.error.policy_violation_details, "external_policy_name", "")
        return getattr(ex.error, "message", "") or getattr(ex.error, "details", "")

    def _extract_error_fields(self, ex: GoogleAdsException) -> List[str]:
        fields = []
        for error in ex.failure.errors:
            if error.location:
                fields.extend(element.field_name for element in error.location.field_path_elements)
        return fields


class GoogleAdsAssetIntegrationBase(GoogleAdsErrorHandlerMixin):
    """Base class for Google Ads asset integrations."""

    def __init__(
        self,
        client: GoogleAdsClient,
        googleads_account_id: str,
        campaign_id: int,
        googleads_campaign_id: Optional[str] = None,
        asset_field_type: str = None,
    ):
        self.client = client
        self.googleads_account_id = googleads_account_id
        self.googleads_campaign_id = googleads_campaign_id
        self.campaign_id = campaign_id
        self.asset_field_type = asset_field_type
        self.errors: List[GoogleAdsError] = []

    def _create_campaign_asset_operation(self, asset_id: str) -> Any:
        """Create a campaign asset operation for linking an asset to a campaign."""
        operation = self.client.get_type("CampaignAssetOperation")
        campaign_asset = operation.create
        campaign_asset.asset = asset_id
        campaign_asset.field_type = getattr(self.client.enums.AssetFieldTypeEnum, self.asset_field_type)
        campaign_asset.campaign = self.client.get_service("CampaignService").campaign_path(
            customer_id=self.googleads_account_id, campaign_id=self.googleads_campaign_id
        )
        return operation

    def create_googleads_assets(self, assets: List[Any]):
        """Base method for creating assets."""
        if not self.googleads_campaign_id:
            return None

        try:
            # Create assets
            asset_operations = [self._create_asset_operation(asset) for asset in assets]

            asset_service = self.client.get_service("AssetService")
            asset_response = asset_service.mutate_assets(
                customer_id=self.googleads_account_id, operations=asset_operations
            )

            # Link assets to campaign
            campaign_asset_operations = [
                self._create_campaign_asset_operation(result.resource_name) for result in asset_response.results
            ]

            campaign_asset_service = self.client.get_service("CampaignAssetService")
            response = campaign_asset_service.mutate_campaign_assets(
                customer_id=self.googleads_account_id, operations=campaign_asset_operations
            )
            return response.results

        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, self.__class__.__name__, self.campaign_id)
            self.errors.append(error)
            return None

    def _create_asset_operation(self, asset: Any) -> Any:
        """To be implemented by child classes."""
        raise NotImplementedError

    def _get_existing_assets(self) -> List[Any]:
        """To be implemented by child classes."""
        raise NotImplementedError

    def _create_update_operation(self, new_asset: Any, existing_asset: Any) -> Optional[Any]:
        """To be implemented by child classes."""
        raise NotImplementedError

    def update_googleads_assets(self, assets: List[Any]):
        """Base method for updating assets."""
        if not self.googleads_campaign_id:
            return None

        try:
            existing_assets = self._get_existing_assets()
            if not existing_assets:
                return None

            asset_operations = []
            for asset, existing_asset in zip(assets, existing_assets):
                operation = self._create_update_operation(asset, existing_asset)
                if operation:
                    asset_operations.append(operation)

            if not asset_operations:
                return None

            asset_service = self.client.get_service("AssetService")
            response = asset_service.mutate_assets(customer_id=self.googleads_account_id, operations=asset_operations)
            return response.results

        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, self.__class__.__name__, self.campaign_id)
            self.errors.append(error)
            return None
