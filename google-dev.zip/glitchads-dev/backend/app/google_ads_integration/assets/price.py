from typing import Any, List, Optional
from uuid import uuid4

from app.campaign.asset_models import PriceRead
from app.google_ads_integration.assets.base import GoogleAdsAssetIntegrationBase

from google.api_core import protobuf_helpers


class GoogleAdsPriceIntegration(GoogleAdsAssetIntegrationBase):
    """Handles creation and management of Google Ads price assets."""

    def __init__(
        self,
        client,
        googleads_account_id: str,
        campaign_id: int,
        googleads_campaign_id: Optional[str] = None,
    ):
        super().__init__(
            client=client,
            googleads_account_id=googleads_account_id,
            campaign_id=campaign_id,
            googleads_campaign_id=googleads_campaign_id,
            asset_field_type="PRICE",
        )

    def _create_asset_operation(self, price: PriceRead) -> Any:
        """Create an asset operation for a single price."""
        operation = self.client.get_type("AssetOperation")
        asset = operation.create
        asset.name = f"Price Asset #{uuid4()}"

        price_asset = asset.price_asset
        price_asset.type_ = self.client.enums.PriceExtensionTypeEnum.SERVICES
        price_asset.price_qualifier = self.client.enums.PriceExtensionPriceQualifierEnum.FROM
        price_asset.language_code = "en"

        price_offering = self._create_price_offering(
            header=price.header,
            description=price.description,
            final_url=price.final_url,
            final_mobile_url=price.mobile_url,
            price_in_micros=price.value,
            currency_code=price.currency,
            unit=self._get_frequency(price.frequency),
        )
        price_asset.price_offerings.append(price_offering)

        return operation

    def _create_price_offering(
        self,
        header: str,
        description: str,
        final_url: str,
        final_mobile_url: Optional[str],
        price_in_micros: int,
        currency_code: str,
        unit: Any,
    ) -> Any:
        """Create a price offering object."""
        price_offering = self.client.get_type("PriceOffering")
        price_offering.header = header
        price_offering.description = description
        price_offering.final_url = final_url
        if final_mobile_url:
            price_offering.final_mobile_url = final_mobile_url
        price_offering.price.amount_micros = price_in_micros
        price_offering.price.currency_code = currency_code
        price_offering.unit = unit
        return price_offering

    def _get_frequency(self, frequency: str) -> Any:
        """Convert frequency string to Google Ads enum value."""
        frequency_map = {
            "per hour": self.client.enums.PriceExtensionPriceUnitEnum.PER_HOUR,
            "per day": self.client.enums.PriceExtensionPriceUnitEnum.PER_DAY,
            "per week": self.client.enums.PriceExtensionPriceUnitEnum.PER_WEEK,
            "per month": self.client.enums.PriceExtensionPriceUnitEnum.PER_MONTH,
            "per year": self.client.enums.PriceExtensionPriceUnitEnum.PER_YEAR,
            "per night": self.client.enums.PriceExtensionPriceUnitEnum.PER_NIGHT,
        }
        return frequency_map.get(frequency)

    def _get_existing_assets(self) -> List[Any]:
        """Fetch existing price assets for the campaign."""
        campaign_resource_name = self.client.get_service("CampaignService").campaign_path(
            customer_id=self.googleads_account_id, campaign_id=self.googleads_campaign_id
        )

        query = """
            SELECT 
                campaign_asset.asset,
                asset.price_asset.price_offerings,
                asset.price_asset.type,
                asset.price_asset.price_qualifier,
                asset.price_asset.language_code
            FROM campaign_asset
            WHERE 
                campaign_asset.campaign = '{campaign_resource_name}'
                AND campaign_asset.field_type = PRICE
        """.format(campaign_resource_name=campaign_resource_name)

        ga_service = self.client.get_service("GoogleAdsService")
        response = ga_service.search(customer_id=self.googleads_account_id, query=query)
        return [row for row in response]

    def _create_update_operation(self, price: PriceRead, existing_price: Any) -> Optional[Any]:
        """
        Create an update operation for a single price asset.

        Args:
            price: New price data
            existing_price: Existing Google Ads price asset

        Returns:
            AssetOperation if changes are needed, None otherwise
        """
        operation = self.client.get_type("AssetOperation")
        asset = operation.update
        asset.resource_name = existing_price.asset.resource_name

        # Create field mask for tracking changes
        field_mask = protobuf_helpers.field_mask(asset._pb, asset)
        has_changes = False

        # Check and update price offering fields
        existing_offering = existing_price.asset.price_asset.price_offerings[0]
        if (
            price.header != existing_offering.header
            or price.description != existing_offering.description
            or price.final_url != existing_offering.final_url
            or price.value != existing_offering.price.amount_micros
            or price.currency != existing_offering.price.currency_code
            or self._get_frequency(price.frequency) != existing_offering.unit
        ):
            price_offering = self._create_price_offering(
                header=price.header,
                description=price.description,
                final_url=price.final_url,
                final_mobile_url=price.mobile_url,
                price_in_micros=price.value,
                currency_code=price.currency,
                unit=self._get_frequency(price.frequency),
            )
            asset.price_asset.price_offerings.append(price_offering)
            field_mask.paths.append("price_asset.price_offerings")
            has_changes = True

        if not has_changes:
            return None

        operation.update_mask.CopyFrom(field_mask)
        return operation

    # These methods are now inherited from the base class and don't need to be implemented:
    # - create_googleads_price_assets (use create_googleads_assets instead)
    # - update_googleads_price_assets (use update_googleads_assets instead)
    # - handle_googleads_exception
    # - _create_campaign_asset_operation
