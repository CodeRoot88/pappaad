from typing import Any, List, Optional

from app.campaign.asset_models import PhoneNumber
from app.google_ads_integration.assets.base import GoogleAdsAssetIntegrationBase

from google.ads.googleads.errors import GoogleAdsException
from google.api_core import protobuf_helpers


class GoogleAdsCallIntegration(GoogleAdsAssetIntegrationBase):
    """Handles creation and management of Google Ads call assets."""

    def __init__(
        self,
        client,
        googleads_account_id: str,
        campaign_id: int,
        googleads_campaign_id: Optional[str] = None,
    ):
        super().__init__(
            client=client,
            googleads_account_id=googleads_account_id,
            campaign_id=campaign_id,
            googleads_campaign_id=googleads_campaign_id,
            asset_field_type="CALL",
        )

    def _create_asset_operation(self, phone_number: PhoneNumber, conversion_action_id: Optional[str] = None) -> Any:
        """Create an asset operation for a single call asset."""
        operation = self.client.get_type("AssetOperation")
        asset = operation.create.call_asset
        asset.country_code = phone_number.country_code
        asset.phone_number = phone_number.value

        # Add default schedule (Monday 9-5)
        ad_schedule = self._create_ad_schedule()
        asset.ad_schedule_targets.append(ad_schedule)

        if conversion_action_id:
            self._add_conversion_tracking(asset, conversion_action_id)

        return operation

    def _create_ad_schedule(self) -> Any:
        """Create a default ad schedule (Monday 9-5)."""
        ad_schedule = self.client.get_type("AdScheduleInfo")
        ad_schedule.day_of_week = self.client.enums.DayOfWeekEnum.MONDAY
        ad_schedule.start_hour = 9
        ad_schedule.end_hour = 17
        ad_schedule.start_minute = self.client.enums.MinuteOfHourEnum.ZERO
        ad_schedule.end_minute = self.client.enums.MinuteOfHourEnum.ZERO
        return ad_schedule

    def _add_conversion_tracking(self, asset: Any, conversion_action_id: str):
        """Add conversion tracking to a call asset."""
        googleads_service = self.client.get_service("GoogleAdsService")
        asset.call_conversion_action = googleads_service.conversion_action_path(
            customer_id=self.googleads_account_id, conversion_action_id=conversion_action_id
        )
        asset.call_conversion_reporting_state = (
            self.client.enums.CallConversionReportingStateEnum.USE_RESOURCE_LEVEL_CALL_CONVERSION_ACTION
        )

    def _get_existing_assets(self) -> List[Any]:
        """Fetch existing call assets for the campaign."""
        campaign_resource_name = self.client.get_service("CampaignService").campaign_path(
            customer_id=self.googleads_account_id, campaign_id=self.googleads_campaign_id
        )

        query = """
            SELECT 
                campaign_asset.asset,
                asset.call_asset.country_code,
                asset.call_asset.phone_number,
                asset.call_asset.call_conversion_action,
                asset.call_asset.call_conversion_reporting_state
            FROM campaign_asset
            WHERE 
                campaign_asset.campaign = '{campaign_resource_name}'
                AND campaign_asset.field_type = CALL
        """.format(campaign_resource_name=campaign_resource_name)

        ga_service = self.client.get_service("GoogleAdsService")
        response = ga_service.search(customer_id=self.googleads_account_id, query=query)
        return [row for row in response]

    def _create_update_operation(self, phone_number: PhoneNumber, existing_call: Any) -> Optional[Any]:
        """
        Create an update operation for a single call asset.

        Args:
            phone_number: New phone number data
            existing_call: Existing Google Ads call asset

        Returns:
            AssetOperation if changes are needed, None otherwise
        """
        operation = self.client.get_type("AssetOperation")
        asset = operation.update
        asset.resource_name = existing_call.asset.resource_name

        # Create field mask for tracking changes
        field_mask = protobuf_helpers.field_mask(None)
        has_changes = False

        # Check and update phone number fields
        if phone_number.country_code != existing_call.asset.call_asset.country_code:
            asset.call_asset.country_code = phone_number.country_code
            field_mask.paths.append("call_asset.country_code")
            has_changes = True

        if phone_number.value != existing_call.asset.call_asset.phone_number:
            asset.call_asset.phone_number = phone_number.value
            field_mask.paths.append("call_asset.phone_number")
            has_changes = True

        if not has_changes:
            return None

        operation.update_mask.CopyFrom(field_mask)
        return operation

    def get_googleads_calls_for_campaign(self):
        """Fetch all call assets associated with the campaign."""
        if not self.googleads_campaign_id:
            return []

        googleads_service = self.client.get_service("GoogleAdsService")
        query = f"""
        SELECT
            campaign.id,
            asset.call_asset.country_code,
            asset.call_asset.phone_number,
            asset.call_asset.call_conversion_action,
            asset.call_asset.call_conversion_reporting_state
        FROM
            campaign_asset
        WHERE
            campaign.id = {self.googleads_campaign_id}
            AND
            campaign_asset.field_type = 'CALL'
        """

        try:
            response = googleads_service.search(customer_id=self.googleads_account_id, query=query)
            return [row.asset for row in response]
        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, "Call", self.campaign_id)
            self.errors.append(error)
            return []

    def create_google_ads_call_asset(self, phone_number: PhoneNumber, conversion_action_id: Optional[str] = None):
        """Create a single call asset and attach it to the campaign."""
        operation = self._create_asset_operation(phone_number, conversion_action_id)

        try:
            # Create the asset
            asset_service = self.client.get_service("AssetService")
            response = asset_service.mutate_assets(customer_id=self.googleads_account_id, operations=[operation])
            resource_name = response.results[0].resource_name

            # Attach to campaign
            if self.googleads_campaign_id:
                campaign_asset_operation = self._create_campaign_asset_operation(resource_name)
                campaign_asset_service = self.client.get_service("CampaignAssetService")
                campaign_asset_service.mutate_campaign_assets(
                    customer_id=self.googleads_account_id, operations=[campaign_asset_operation]
                )

            return resource_name
        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, "Call", self.campaign_id)
            self.errors.append(error)
            return None

    # These methods are now inherited from the base class and don't need to be implemented:
    # - handle_googleads_exception
    # - _create_campaign_asset_operation
