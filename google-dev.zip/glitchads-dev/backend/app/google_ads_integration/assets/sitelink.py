from typing import Any, List, Optional
from google.api_core import protobuf_helpers

from app.campaign.asset_models import SiteLinkData
from app.google_ads_integration.assets.base import GoogleAdsAssetIntegrationBase
from google.ads.googleads.errors import GoogleAdsException


class GoogleAdsSiteLinkIntegration(GoogleAdsAssetIntegrationBase):
    """Handles creation and management of Google Ads sitelink assets."""

    def __init__(
        self,
        client,
        googleads_account_id: str,
        campaign_id: int,
        googleads_campaign_id: Optional[str] = None,
    ):
        super().__init__(
            client=client,
            googleads_account_id=googleads_account_id,
            campaign_id=campaign_id,
            googleads_campaign_id=googleads_campaign_id,
            asset_field_type="SITELINK",
        )

    def _create_asset_operation(self, site_link: SiteLinkData) -> Any:
        """Create an asset operation for a single sitelink."""
        operation = self.client.get_type("AssetOperation")
        asset = operation.create
        asset.final_urls.append(site_link.url)
        asset.sitelink_asset.description1 = site_link.description1
        asset.sitelink_asset.description2 = site_link.description2
        asset.sitelink_asset.link_text = site_link.name
        return operation

    def _get_existing_assets(self) -> List[Any]:
        """Fetch existing sitelink assets for the campaign."""
        campaign_resource_name = self.client.get_service("CampaignService").campaign_path(
            customer_id=self.googleads_account_id, campaign_id=self.googleads_campaign_id
        )

        query = """
            SELECT 
                campaign_asset.asset,
                asset.sitelink_asset.link_text,
                asset.sitelink_asset.description1,
                asset.sitelink_asset.description2,
                asset.final_urls,
                asset.resource_name
            FROM campaign_asset
            WHERE 
                campaign_asset.campaign = '{campaign_resource_name}'
                AND campaign_asset.field_type = SITELINK
        """.format(campaign_resource_name=campaign_resource_name)

        ga_service = self.client.get_service("GoogleAdsService")
        response = ga_service.search(customer_id=self.googleads_account_id, query=query)
        return [row for row in response]

    def _create_update_operation(self, site_link: SiteLinkData, existing_link: Any) -> Optional[Any]:
        """
        Create an update operation for a single sitelink asset.

        Args:
            site_link: New sitelink data
            existing_link: Existing Google Ads sitelink asset row

        Returns:
            AssetOperation if changes are needed, None otherwise
        """
        operation = self.client.get_type("AssetOperation")
        asset = operation.update
        asset.resource_name = existing_link.asset.resource_name

        # Create field mask for tracking changes
        field_mask = protobuf_helpers.field_mask(None, asset._pb)
        has_changes = False

        # Check and update each field
        if site_link.url != existing_link.asset.final_urls[0]:
            asset.final_urls.clear()  # Clear existing URLs first
            asset.final_urls.append(site_link.url)
            field_mask.paths.append("final_urls")
            has_changes = True

        if site_link.description1 != existing_link.asset.sitelink_asset.description1:
            asset.sitelink_asset.description1 = site_link.description1
            field_mask.paths.append("sitelink_asset.description1")
            has_changes = True

        if site_link.description2 != existing_link.asset.sitelink_asset.description2:
            asset.sitelink_asset.description2 = site_link.description2
            field_mask.paths.append("sitelink_asset.description2")
            has_changes = True

        if site_link.name != existing_link.asset.sitelink_asset.link_text:
            asset.sitelink_asset.link_text = site_link.name
            field_mask.paths.append("sitelink_asset.link_text")
            has_changes = True

        if not has_changes:
            return None

        operation.update_mask.CopyFrom(field_mask)
        return operation

    def get_googleads_sitelinks_for_campaign(self):
        """Fetch all sitelink assets associated with the campaign."""
        if not self.googleads_campaign_id:
            return []

        googleads_service = self.client.get_service("GoogleAdsService")
        query = f"""
        SELECT
            campaign.id,
            asset.sitelink_asset.link_text,
            asset.sitelink_asset.description1,
            asset.sitelink_asset.description2,
            asset.final_urls
        FROM
            campaign_asset
        WHERE
            campaign.id = {self.googleads_campaign_id}
            AND
            campaign_asset.field_type = 'SITELINK'
        """

        try:
            response = googleads_service.search(customer_id=self.googleads_account_id, query=query)
            return [row.asset for row in response]
        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, "SiteLink", self.campaign_id)
            self.errors.append(error)
            return []

    # These methods are now inherited from the base class and don't need to be implemented:
    # - create_googleads_site_links_assets (use create_googleads_assets instead)
    # - update_googleads_site_links_assets (use update_googleads_assets instead)
    # - handle_googleads_exception
    # - _create_campaign_asset_operation
