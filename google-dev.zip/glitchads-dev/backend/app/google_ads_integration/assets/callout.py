from typing import Any, List, Optional
from google.api_core import protobuf_helpers

from app.campaign.asset_models import Callout
from app.google_ads_integration.assets.base import GoogleAdsAssetIntegrationBase
from google.ads.googleads.errors import GoogleAdsException


class GoogleAdsCalloutIntegration(GoogleAdsAssetIntegrationBase):
    """Handles creation and management of Google Ads callout assets."""

    def __init__(
        self,
        client,
        googleads_account_id: str,
        campaign_id: int,
        googleads_campaign_id: Optional[str] = None,
    ):
        super().__init__(
            client=client,
            googleads_account_id=googleads_account_id,
            campaign_id=campaign_id,
            googleads_campaign_id=googleads_campaign_id,
            asset_field_type="CALLOUT",
        )

    def _create_asset_operation(self, callout: Callout) -> Any:
        """Create an asset operation for a single callout."""
        operation = self.client.get_type("AssetOperation")
        asset = operation.create
        asset.callout_asset.callout_text = callout.text
        return operation

    def _get_existing_assets(self) -> List[Any]:
        """Fetch existing callout assets for the campaign."""
        campaign_resource_name = self.client.get_service("CampaignService").campaign_path(
            customer_id=self.googleads_account_id, campaign_id=self.googleads_campaign_id
        )

        query = """
            SELECT 
                campaign_asset.asset,
                asset.callout_asset.callout_text
            FROM campaign_asset
            WHERE 
                campaign_asset.campaign = '{campaign_resource_name}'
                AND campaign_asset.field_type = CALLOUT
        """.format(campaign_resource_name=campaign_resource_name)

        ga_service = self.client.get_service("GoogleAdsService")
        response = ga_service.search(customer_id=self.googleads_account_id, query=query)
        return [row for row in response]

    def _create_update_operation(self, callout: Callout, existing_callout: Any) -> Optional[Any]:
        """
        Create an update operation for a single callout asset.

        Args:
            callout: New callout data
            existing_callout: Existing Google Ads callout asset

        Returns:
            AssetOperation if changes are needed, None otherwise
        """
        operation = self.client.get_type("AssetOperation")
        asset = operation.update
        asset.resource_name = existing_callout.asset.resource_name

        # Create field mask for tracking changes
        field_mask = protobuf_helpers.field_mask(None, asset._pb)
        has_changes = False

        # Check and update text field
        if callout.text != existing_callout.asset.callout_asset.callout_text:
            asset.callout_asset.callout_text = callout.text
            field_mask.paths.append("callout_asset.callout_text")
            has_changes = True

        if not has_changes:
            return None

        operation.update_mask.CopyFrom(field_mask)
        return operation

    def get_googleads_callouts_for_campaign(self):
        """Fetch all callout assets associated with the campaign."""
        if not self.googleads_campaign_id:
            return []

        googleads_service = self.client.get_service("GoogleAdsService")
        query = f"""
        SELECT
            campaign.id,
            asset.callout_asset.callout_text
        FROM
            campaign_asset
        WHERE
            campaign.id = {self.googleads_campaign_id}
            AND
            campaign_asset.field_type = 'CALLOUT'
        """

        try:
            response = googleads_service.search(customer_id=self.googleads_account_id, query=query)
            return [row.asset for row in response]
        except GoogleAdsException as ex:
            error = self.handle_googleads_exception(ex, "Callout", self.campaign_id)
            self.errors.append(error)
            return []

    # These methods are now inherited from the base class and don't need to be implemented:
    # - create_googleads_callouts_assets (use create_googleads_assets instead)
    # - update_googleads_callout_assets (use update_googleads_assets instead)
    # - handle_googleads_exception
    # - _create_campaign_asset_operation
