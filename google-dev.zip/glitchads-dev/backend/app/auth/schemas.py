from pydantic import BaseModel
from typing import Optional

from app.user.schemas import UserRole
from app.membership.schemas import MembershipRole


class AccessTokenData(BaseModel):
    email: str
    picture: Optional[str] = None
    name: str
    role: UserRole
    impersonating_email: str | None = None

    class Config:
        use_enum_values = True


class AccessToken(BaseModel):
    access_token: str


class GoogleAccessToken(BaseModel):
    google_access_token: str


class GoogleAuthTokens(BaseModel):
    access_token: str
    refresh_token: str


class UserSignin(BaseModel):
    email: str
    password: str


class UserSignup(UserSignin):
    name: str


class UserAuthResponse(BaseModel):
    message: str
    token: str


class InviteUserRequest(BaseModel):
    email: str
    name: str
    role: MembershipRole


class VerifyInviteCodeResponse(BaseModel):
    email: str
    is_valid_refresh_token: bool


class AuthCodeRequest(BaseModel):
    code: str
