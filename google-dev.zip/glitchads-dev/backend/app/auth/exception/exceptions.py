class GoogleAuthenticationErrorException(Exception):
    def __init__(self, detail: str = "Google Authentication failed."):
        self.detail = detail


class DuplicateUserEmailException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class GoogleRefreshTokenEmptyException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class UserNotFoundException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class UserEmailNotFoundException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class UserPasswordIncorrectException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class InvalidRefreshTokenException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class InvalidInviteCodeException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class EmailMismatchException(Exception):
    def __init__(self, detail: str):
        self.detail = detail
