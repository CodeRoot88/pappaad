from fastapi import Request, status
from fastapi.responses import JSONResponse

from app.auth.exception.exceptions import (
    GoogleAuthenticationErrorException,
    DuplicateUserEmailException,
    UserNotFoundException,
    UserEmailNotFoundException,
    UserPasswordIncorrectException,
    GoogleRefreshTokenEmptyException,
    InvalidRefreshTokenException,
    InvalidInviteCodeException,
    EmailMismatchException,
)


def authentication_exception_handlers(app):  # type: ignore
    @app.exception_handler(GoogleAuthenticationErrorException)  # type: ignore
    async def google_authentication_error_exception_handler(
        request: Request, exc: GoogleAuthenticationErrorException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(DuplicateUserEmailException)  # type: ignore
    async def duplicate_email_error_exception_handler(
        request: Request, exc: DuplicateUserEmailException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(UserNotFoundException)  # type: ignore
    async def user_not_found_error_exception_handler(request: Request, exc: UserNotFoundException) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": exc.detail},
        )

    @app.exception_handler(UserEmailNotFoundException)  # type: ignore
    async def email_not_found_error_exception_handler(
        request: Request, exc: UserEmailNotFoundException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": exc.detail},
        )

    @app.exception_handler(UserPasswordIncorrectException)  # type: ignore
    async def password_incorrect_exception_handler(
        request: Request, exc: UserPasswordIncorrectException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(GoogleRefreshTokenEmptyException)  # type: ignore
    async def google_refresh_token_empty_exception_handler(
        request: Request, exc: GoogleRefreshTokenEmptyException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(InvalidRefreshTokenException)  # type: ignore
    async def google_refresh_token_invalid_exception_handler(
        request: Request, exc: InvalidRefreshTokenException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(InvalidInviteCodeException)  # type: ignore
    async def invite_verify_code_invalid_exception_handler(
        request: Request, exc: InvalidInviteCodeException
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(EmailMismatchException)  # type: ignore
    async def invite_email_mismatch_exception_handler(request: Request, exc: EmailMismatchException) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )
