from typing import Annotated

from fastapi import APIRouter, Body, Depends
from sqlmodel import Session

from app.auth.schemas import (
    AccessToken,
    GoogleAccessToken,
    UserSignin,
    UserSignup,
    UserAuthResponse,
    VerifyInviteCodeResponse,
)
from app.auth.services.signup import sign_up
from app.auth.services.signin import (
    create_or_signin_account,
    get_access_token,
    sign_in,
    get_access_token_with_invite_code,
    create_or_signin_account_with_invite_code,
)
from app.database import get_db_session
from app.auth.services.invite import validate_and_process_invite_code

router = APIRouter()


@router.post("/auth/signup", response_model=UserAuthResponse)
def user_signup(
    signUpData: UserSignup,
    db: Session = Depends(get_db_session),
) -> UserAuthResponse:
    token = sign_up(name=signUpData.name, email=signUpData.email, password=signUpData.password, db=db).access_token
    return UserAuthResponse(message="Successfully registered.", token=token)


@router.post("/auth/signin", response_model=UserAuthResponse)
def user_signin(
    signInData: UserSignin,
    db: Session = Depends(get_db_session),
) -> UserAuthResponse:
    token = sign_in(email=signInData.email, password=signInData.password, db=db).access_token
    return UserAuthResponse(message="Successfully logged in.", token=token)


@router.post("/auth/google/token", response_model=AccessToken)
def get_access_token_from_google_access_token(
    request: GoogleAccessToken,
    db: Session = Depends(get_db_session),
) -> AccessToken:
    return get_access_token(google_access_token=request.google_access_token, db=db)


@router.post("/google/auth", response_model=AccessToken)
def create_or_signin_account_google(
    code: Annotated[str, Body(embed=True)],
    db: Session = Depends(get_db_session),
) -> AccessToken:
    return create_or_signin_account(code, db)


@router.post("/auth/google/token/invite/{invite_code}", response_model=AccessToken)
def get_access_token_from_google_access_token_with_invite_code(
    request: GoogleAccessToken,
    invite_code: str,
    db: Session = Depends(get_db_session),
) -> AccessToken:
    return get_access_token_with_invite_code(google_access_token=request.google_access_token, code=invite_code, db=db)


@router.post("/google/auth/invite/{invite_code}", response_model=AccessToken)
def create_or_signin_account_google_with_invite_code(
    code: Annotated[str, Body(embed=True)],
    invite_code: str,
    db: Session = Depends(get_db_session),
) -> AccessToken:
    return create_or_signin_account_with_invite_code(code=code, invite_code=invite_code, db=db)


@router.get("/auth/verify-invite-code/{code}", response_model=VerifyInviteCodeResponse)
def verify_code(code: str, db: Session = Depends(get_db_session)) -> VerifyInviteCodeResponse:
    return validate_and_process_invite_code(code, db)
