from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session

from app.auth.schemas import AccessToken
from app.database import get_db_session
from app.main import app


@pytest.fixture
def client(mocker):
    mock_session = MagicMock(spec=Session)
    app.dependency_overrides[get_db_session] = lambda: mock_session

    mock_create_or_signin_account = mocker.patch(
        "app.auth.router.create_or_signin_account", return_value=AccessToken(access_token="mocked_access_token")
    )

    with TestClient(app) as c:
        yield c, mock_session, mock_create_or_signin_account

    app.dependency_overrides.clear()


def test_create_or_signin_account_google(client):
    test_client, mock_session, mock_create_or_signin_account = client

    test_code = "test_google_auth_code"
    expected_access_token = "mocked_access_token"

    response = test_client.post("/google/auth", json={"code": test_code})

    assert response.status_code == 200
    assert response.json() == {"access_token": expected_access_token}

    mock_create_or_signin_account.assert_called_once_with(test_code, mock_session)
