import bcrypt


def verify_password(input_password: str, saved_password: str) -> bool:
    return bcrypt.checkpw(input_password.encode("utf-8"), saved_password.encode("utf-8"))


def hash_password(password: str) -> str:
    hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
    return hashed_password.decode("utf-8")
