import os
from datetime import datetime, timedelta, timezone

import jwt
from dotenv import load_dotenv
from sqlmodel import Session

from app.auth.schemas import AccessToken, AccessTokenData
from app.auth.services.google_auth import (
    get_google_profile,
    retrieve_google_auth_tokens,
)
from app.google_ads.services import GoogleAdsService
from app.user.schemas import UserRole
from app.user.services import upsert_user_account

load_dotenv()
SECRET_KEY = os.environ.get("SECRET_KEY")


def create_access_token(data: AccessTokenData) -> str:
    to_encode = data.model_dump()
    token_lifetime = int(os.getenv("TOKEN_LIFETIME", "15"))  # Default to 15 minutes if not set
    expire = datetime.now(tz=timezone.utc) + timedelta(minutes=token_lifetime)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm="HS256")
    return encoded_jwt


def create_or_signin_account(code: str, db: Session) -> AccessToken:
    google_auth_tokens = retrieve_google_auth_tokens(code)
    user_profile = get_google_profile(google_auth_tokens.access_token)
    user_account = upsert_user_account(refresh_token=google_auth_tokens.refresh_token, user_profile=user_profile, db=db)
    googleads_service = GoogleAdsService(
        db=db,
        refresh_token=user_account.google_refresh_token or "",
        googleads_account_id="None",
        googleads_manager_account_id=None,
    )
    googleads_service.add_update_googleads_accounts(user_account_id=user_account.id)

    access_token = create_access_token(
        data=AccessTokenData(
            email=user_profile.email,
            picture=user_profile.picture,
            name=user_profile.name,
            role=user_account.role if user_account else UserRole.USER,
        )
    )
    return AccessToken(access_token=access_token)
