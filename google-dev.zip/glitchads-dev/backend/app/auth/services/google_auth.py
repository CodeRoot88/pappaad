import os

import httpx
import requests
from dotenv import load_dotenv
from google.ads.googleads.client import GoogleAdsClient
from google_auth_oauthlib.flow import Flow  # type: ignore

from app.auth.exception.exceptions import GoogleAuthenticationErrorException
from app.auth.schemas import GoogleAuthTokens
from app.common_schemas import UserProfile

load_dotenv()

DEVELOPER_TOKEN = os.getenv("GOOGLE_ADS_DEVELOPER_TOKEN")
CLIENT_ID = os.getenv("GOOGLE_ADS_CLIENT_ID")
CLIENT_SECRET = os.getenv("GOOGLE_ADS_CLIENT_SECRET")


def retrieve_google_auth_tokens(code: str) -> GoogleAuthTokens:
    flow = Flow.from_client_config(
        {
            "web": {
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost"],
            }
        },
        scopes=[
            "https://www.googleapis.com/auth/adwords",
            "openid",
            "https://www.googleapis.com/auth/userinfo.profile",
            "https://www.googleapis.com/auth/userinfo.email",
        ],
    )

    flow.redirect_uri = "postmessage"
    flow.fetch_token(code=code)

    credentials = flow.credentials

    access_token = credentials.token
    refresh_token = credentials.refresh_token
    if access_token and refresh_token:
        return GoogleAuthTokens(access_token=access_token, refresh_token=refresh_token)
    else:
        raise GoogleAuthenticationErrorException("Error retrieving Google Auth Tokens")


def get_google_profile(access_token: str) -> UserProfile:
    userinfo_endpoint = "https://www.googleapis.com/oauth2/v3/userinfo"
    response = httpx.get(userinfo_endpoint, headers={"Authorization": f"Bearer {access_token}"})

    data = response.json()
    return UserProfile(name=data["name"], email=data["email"], picture=data["picture"])


def get_google_ads_client(refresh_token: str) -> GoogleAdsClient:
    credentials = {
        "developer_token": DEVELOPER_TOKEN,
        "refresh_token": refresh_token,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "use_proto_plus": False,
    }
    return GoogleAdsClient.load_from_dict(credentials)  # type: ignore


def validate_google_refresh_token(refresh_token: str) -> bool:
    """
    Check if a Google refresh token is valid or expired.

    Args:
        refresh_token (str): The Google refresh token.
        client_id (str): Google OAuth client ID.
        client_secret (str): Google OAuth client secret.

    Returns:
        bool: Validation result with True or False.
    """
    url = "https://oauth2.googleapis.com/token"
    payload = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "refresh_token": refresh_token,
        "grant_type": "refresh_token",
    }

    try:
        response = requests.post(url, data=payload)
        return response.status_code == 200
    except Exception:
        return False
