from sqlmodel import Session

from app.auth.exception.exceptions import DuplicateUserEmailException
from app.auth.services.signin import get_user_access_token
from app.auth.services.password import hash_password
from app.auth.schemas import AccessToken
from app.user.schemas import UserRole
from app.user.models import UserAccount
from app.user.db_ops import get_user_account_by_email, add_user


def sign_up(name: str, email: str, password: str, db: Session) -> AccessToken:
    user_account = get_user_account_by_email(email=email, db=db)
    if user_account:
        raise DuplicateUserEmailException("User Email is already exist.")

    hashed_password = hash_password(password)
    user = UserAccount(
        name=name,
        email=email,
        password=hashed_password,
        role=UserRole.USER,
    )

    userData = add_user(user=user, db=db)
    if not userData:
        raise Exception("An error occured while adding new User.")

    access_token = get_user_access_token(userData).access_token
    return AccessToken(access_token=access_token)
