from fastapi import HTTPException
from sqlmodel import Session

from app.auth.schemas import AccessTokenData
from app.auth.services.signin import create_access_token
from app.user.db_ops import get_user_account_by_email
from app.user.models import UserAccount


def set_impersonate_user(admin: UserAccount, target_user_email: str, db: Session) -> dict[str, str]:
    if admin.email == target_user_email:
        raise HTTPException(status_code=400, detail="Cannot impersonate self")

    impersonated_user = get_user_account_by_email(target_user_email, db)
    if not impersonated_user:
        raise HTTPException(status_code=404, detail="Impersonated User not found")

    access_token = create_access_token(
        data=AccessTokenData(
            email=admin.email,
            picture=admin.picture,
            name=admin.name,
            role=admin.role,
            impersonating_email=impersonated_user.email,
        )
    )

    return {"access_token": access_token}


def unset_impersonate_user(admin: UserAccount, db: Session) -> dict[str, str]:
    access_token = create_access_token(
        data=AccessTokenData(
            email=admin.email,
            picture=admin.picture,
            name=admin.name,
            role=admin.role,
        )
    )

    return {"access_token": access_token}
