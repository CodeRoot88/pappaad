import os
from app.organization.schemas import OrganizationCreateRequest
import jwt
from dotenv import load_dotenv
from sqlmodel import Session
from nanoid import generate  # type: ignore
from datetime import datetime, timedelta, timezone

from app.auth.services.invite import get_validated_invite_code
from app.common_schemas import UserProfile
from app.membership.db_ops import add_invite_code, add_membership, get_membership
from app.membership.models import InviteCode, Membership
from app.membership.schemas import MembershipStatus
from app.organization.services.organization import OrganizationService

from app.auth.exception.exceptions import (
    EmailMismatchException,
    GoogleRefreshTokenEmptyException,
    InvalidInviteCodeException,
    InvalidRefreshTokenException,
    UserEmailNotFoundException,
    UserNotFoundException,
    UserPasswordIncorrectException,
)
from app.auth.schemas import AccessToken, AccessTokenData, GoogleAuthTokens
from app.auth.services.google_auth import (
    validate_google_refresh_token,
    get_google_profile,
    retrieve_google_auth_tokens,
)
from app.auth.services.password import verify_password
from app.google_ads.services import GoogleAdsService
from app.user.db_ops import fetch_user_account_by_email, get_user_account_by_email
from app.user.models import UserAccountData
from app.user.schemas import UserRole
from app.user.services import upsert_user_account

load_dotenv()
SECRET_KEY = os.environ.get("SECRET_KEY")


def create_access_token(data: AccessTokenData) -> str:
    to_encode = data.model_dump()
    token_lifetime = int(os.getenv("TOKEN_LIFETIME", "15"))  # Default to 15 minutes if not set
    expire = datetime.now(tz=timezone.utc) + timedelta(minutes=token_lifetime)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm="HS256")
    return encoded_jwt


def get_user_access_token(userData: UserAccountData) -> AccessToken:
    access_token = create_access_token(
        data=AccessTokenData(
            email=userData.email,
            picture=userData.picture,
            name=userData.name,
            role=userData.role if userData else UserRole.USER,
        )
    )
    return AccessToken(access_token=access_token)


def sign_in(email: str, password: str, db: Session) -> AccessToken:
    user_account = get_user_account_by_email(email=email, db=db)
    if user_account is None:
        raise UserEmailNotFoundException("User Email is not registerd")
    if user_account.password is None:
        raise UserPasswordIncorrectException("User dose not have saved password")
    if not verify_password(input_password=password, saved_password=user_account.password):
        raise UserPasswordIncorrectException("User Password is not correct.")
    access_token = get_user_access_token(user_account).access_token
    return AccessToken(access_token=access_token)


def create_or_update_membership(user_account: UserAccountData, invite_code: InviteCode, db: Session) -> None:
    if invite_code.email != user_account.email:
        raise EmailMismatchException(
            "The email used for signup does not match the email associated with the invitation."
        )
    if not invite_code.organization_id:
        raise InvalidInviteCodeException("Invalid Invite Code.")

    membership = get_membership(organization_id=invite_code.organization_id, user_id=user_account.id, db=db)

    if membership:
        membership.status = MembershipStatus.ACTIVE
        add_membership(membership, db)

    else:
        membership = Membership(
            organization_id=invite_code.organization_id,
            user_id=user_account.id,
            status=MembershipStatus.ACTIVE,
            role=invite_code.role,
        )
        add_membership(membership, db)

    invite_code.valid = False
    add_invite_code(invite_code, db)


def create_organization_if_not_exists(user_account: UserAccountData, db: Session) -> None:
    user = fetch_user_account_by_email(email=user_account.email, db=db)
    if not user:
        raise UserNotFoundException("User Not Found.")
    if not user.organizations:
        organization_create = OrganizationCreateRequest(slug=generate(size=10), name=user.name)
        OrganizationService(user=user_account, db=db).create_organization_and_membership(organization_create)


def create_or_signin_account(code: str, db: Session) -> AccessToken:
    google_auth_tokens = retrieve_google_auth_tokens(code)
    user_profile = get_google_profile(google_auth_tokens.access_token)
    user_account = get_or_create_user_account(google_auth_tokens, user_profile, db)
    handle_google_ads_accounts(user_account, db)
    create_organization_if_not_exists(user_account, db)
    access_token = generate_access_token(user_profile, user_account)
    return AccessToken(access_token=access_token)


def get_or_create_user_account(
    google_auth_tokens: GoogleAuthTokens, user_profile: UserProfile, db: Session
) -> UserAccountData:
    user_account = upsert_user_account(refresh_token=google_auth_tokens.refresh_token, user_profile=user_profile, db=db)
    return user_account


def handle_google_ads_accounts(user_account: UserAccountData, db: Session) -> None:
    if not user_account.google_refresh_token:
        raise GoogleRefreshTokenEmptyException("Google Ads Account Refresh Token is Empty.")

    googleads_service = GoogleAdsService(
        db=db,
        refresh_token=user_account.google_refresh_token,
        googleads_account_id="None",
        googleads_manager_account_id=None,
    )
    googleads_service.add_update_googleads_accounts(user_account_id=user_account.id)


def generate_access_token(user_profile: UserProfile, user_account: UserAccountData) -> str:
    return create_access_token(
        data=AccessTokenData(
            email=user_profile.email,
            picture=user_profile.picture,
            name=user_profile.name,
            role=user_account.role if user_account else UserRole.USER,
        )
    )


def get_access_token(google_access_token: str, db: Session) -> AccessToken:
    user_profile = get_google_profile(google_access_token)
    user_account = get_user_account_by_email(email=user_profile.email, db=db)

    if not user_account:
        raise UserNotFoundException("User Not Found.")
    if not user_account.google_refresh_token:
        raise GoogleRefreshTokenEmptyException("You are logging in for the first time. Please sign up first.")

    if not validate_google_refresh_token(user_account.google_refresh_token):
        raise InvalidRefreshTokenException("Google Refresh Token is invalid.")

    access_token_data = get_user_access_token(user_account)
    return AccessToken(access_token=access_token_data.access_token)


def get_access_token_with_invite_code(google_access_token: str, code: str, db: Session) -> AccessToken:
    validated_invite_code = get_validated_invite_code(code, db)
    user_profile = get_google_profile(google_access_token)
    user_account = get_user_account_by_email(email=user_profile.email, db=db)

    if not user_account:
        raise UserNotFoundException("User Not Found.")

    create_or_update_membership(user_account, validated_invite_code, db)
    return get_access_token(google_access_token, db)


def create_or_signin_account_with_invite_code(code: str, invite_code: str, db: Session) -> AccessToken:
    google_auth_tokens = retrieve_google_auth_tokens(code)
    user_profile = get_google_profile(google_auth_tokens.access_token)
    validated_invite_code = get_validated_invite_code(invite_code, db)

    user_account = get_or_create_user_account(google_auth_tokens, user_profile, db)

    create_or_update_membership(user_account, validated_invite_code, db)
    handle_google_ads_accounts(user_account, db)
    create_organization_if_not_exists(user_account, db)

    access_token = generate_access_token(user_profile, user_account)
    return AccessToken(access_token=access_token)
