from app.membership.models import InviteCode
from sqlmodel import Session
import os

from app.membership.db_ops import get_invite_code_by_code
from app.auth.exception.exceptions import InvalidInviteCodeException
from app.user.db_ops import get_user_account_by_email
from datetime import datetime, timedelta, timezone
from app.auth.services.google_auth import validate_google_refresh_token
from app.auth.schemas import VerifyInviteCodeResponse

INVITE_CODE_EXPIRATION_DAYS = os.environ.get("INVITE_CODE_EXPIRATION_DAYS", 7)


def get_validated_invite_code(code: str, db: Session) -> InviteCode:
    invite_code = get_invite_code_by_code(code, db)
    if not invite_code or not invite_code.valid:
        raise InvalidInviteCodeException("Invalid Invite Code")

    generated_at_utc = invite_code.generated_at.replace(tzinfo=timezone.utc)
    if (generated_at_utc + timedelta(days=int(INVITE_CODE_EXPIRATION_DAYS))) < datetime.now(timezone.utc):
        raise InvalidInviteCodeException("Expired Invite Code")

    return invite_code


def validate_and_process_invite_code(code: str, db: Session) -> VerifyInviteCodeResponse:
    try:
        invite_code = get_validated_invite_code(code, db)
        user_account = get_user_account_by_email(invite_code.email, db)
        is_valid_refresh_token = (
            validate_google_refresh_token(refresh_token=user_account.google_refresh_token)
            if user_account and user_account.google_refresh_token
            else False
        )
        return VerifyInviteCodeResponse(email=invite_code.email, is_valid_refresh_token=is_valid_refresh_token)
    except Exception:
        raise InvalidInviteCodeException("Invalid Invite Code")
