from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Body, Depends, HTTPException, status
from sqlmodel import Session

from app.ad.models import AdBase, AdData, AdState, AdUpdate
from app.ad.services.ad_create import AdCreateService
from app.ad.services.ad_delete import AdDeleteService
from app.ad.services.ad_recommendation import AdRecommendationService
from app.ad.services.ad_update import AdUpdateService
from app.campaign.models import CampaignData, CampaignReadWithoutAssociations
from app.campaign.services import CampaignService, CampaignStateManager
from app.database import get_db_session
from app.endpoint_dependencies import (
    get_current_googleads_account,
    get_current_user,
    get_user_campaign,
)
from app.google_ads.db_ops import get_current_user_selected_google_ads_customer
from app.google_ads.models import GoogleAdsAccount, GoogleAdsAccountData
from app.user.models import UserAccountData

router = APIRouter()


@router.put("/campaigns/{campaign_id}/ads/{ad_id}/state")
def update_ad_state_by_id(
    campaign_id: int,
    ad_id: int,
    state: Annotated[AdState, Body(embed=True)],
    _campaign=Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    try:
        return AdUpdateService.update_ad_state(campaign_id=campaign_id, ad_id=ad_id, state=state, db=db)
    except Exception as e:
        raise e


@router.put("/campaigns/{campaign_id}/ads/{ad_id}", response_model=AdData)
def update_campaign_ad(
    ad_id: int,
    campaign_id: int,
    ad_data: AdUpdate,
    bgts: BackgroundTasks = BackgroundTasks(),
    current_user: UserAccountData = Depends(get_current_user),
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
    googleads_account: GoogleAdsAccountData = Depends(get_current_googleads_account),
):
    ad = AdUpdateService(user=current_user, bgts=bgts, db=db).update_ad(
        campaign_id=campaign_id, ad_id=ad_id, ad_data=ad_data
    )
    csm = CampaignStateManager(db=db, bgts=bgts, campaign=campaign)
    if csm.are_asset_ads_settings_approved() and campaign.budget == 0:
        googleads_account_id = googleads_account.googleads_account_id
        if googleads_account_id:
            CampaignService(user=current_user, db=db, bgts=bgts).set_budget_by_recommendation(
                campaign_id=campaign.id,
                googleads_account_id=googleads_account.googleads_account_id,
                manager_account_id=googleads_account.manager_account_id,
            )
    return ad


@router.delete("/campaigns/{campaign_id}/ads/{ad_id}")
def delete_campaign_ad(
    campaign_id: int,
    ad_id: int,
    background_tasks: BackgroundTasks = BackgroundTasks(),
    db: Session = Depends(get_db_session),
    _campaign: CampaignData = Depends(get_user_campaign),
    current_user: UserAccountData = Depends(get_current_user),
    googleads_account: GoogleAdsAccount = Depends(get_current_googleads_account),
):
    try:
        AdDeleteService(bgts=background_tasks, db=db).delete_ad(
            googleads_account_id=googleads_account.googleads_account_id,
            campaign_id=campaign_id,
            ad_id=ad_id,
            refresh_token=current_user.google_refresh_token,
            manager_account_id=googleads_account.manager_account_id,
        )
    except Exception as e:
        raise e


@router.post("/campaigns/{campaign_id}/ads/")
async def create_ad(
    ad: AdBase,
    db: Session = Depends(get_db_session),
    user: UserAccountData = Depends(get_current_user),
    campaign: CampaignData = Depends(get_user_campaign),
    bgts: BackgroundTasks = BackgroundTasks(),
):
    googleads_account = get_current_user_selected_google_ads_customer(user.id, db)
    if not googleads_account or not user.google_refresh_token:
        raise Exception("Google Ads account not found for ad generation")

    bgts.add_task(
        AdCreateService(
            campaign=CampaignReadWithoutAssociations(**campaign.model_dump()),
            db=db,
            url=ad.url,
            googleads_account_id=googleads_account.googleads_account_id,
            google_refresh_token=user.google_refresh_token,
            bgts=bgts,
        ).create_ad
    )


@router.post("/campaigns/{campaign_id}/ad-recommendation/{ad_recommendation_id}/apply-instant-fix")
def apply_instant_fix(
    ad_recommendation_id: int,
    campaign: CampaignData = Depends(get_user_campaign),
    db: Session = Depends(get_db_session),
):
    try:
        return AdRecommendationService.ad_apply_instant_fix(
            campaign=campaign, ad_recommendation_id=ad_recommendation_id, db=db
        )

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to apply instant fixes.: {e}")
