from sqlmodel import Session
from fastapi import BackgroundTasks, HTTPException

from app.ad.db_ops import (
    AdCreationError,
    delete_ad_in_db,
    get_ad_by_id,
    add_ad,
)
from app.ad.models import AdRecommendation, Ad, AdUpdate

from app.user.models import UserAccountData
from app.campaign.models import Campaign, CampaignData
from app.task_tracking.schemas import TaskTrackingState
from app.task_tracking.db_ops import update_task_tracking

from app.keyword.db_ops import add_keyword
from app.keyword.services import KeywordService

from app.headline.db_ops import add_headline, add_description
from app.headline.services import HeadlineService

from app.google_ads.db_ops import get_current_user_selected_google_ads_customer, get_googleads_ad_by_ad_id
from app.google_ads.services import GoogleAdsService

from app.llm_services import gen_ad_theme, AdKeywordsHeadlinesDescriptions
from app.web_miner.scraper import scrape_url
from app.common_state_enums import RecommendationState

from nanoid import generate


class AdService:
    def __init__(self, user: UserAccountData, bgts: BackgroundTasks, db: Session, campaign: CampaignData | None = None):
        self.user_id = user.id
        self.bgts = bgts
        self.db = db
        self.user = user
        self.campaign = campaign

    def gen_ad_with_state_tracking(self, campaign: Campaign, url: str, task_tracking_id: int):
        try:
            self.gen_ad(campaign, url)
            update_task_tracking(db=self.db, task_id=task_tracking_id, state=TaskTrackingState.COMPLETED)
            return  # Exit the method once the task is successful
        except Exception as e:
            update_task_tracking(
                db=self.db,
                task_id=task_tracking_id,
                state=TaskTrackingState.FAILED,
                error_message=str(e),
            )

    def gen_ad(self, campaign: Campaign, url: str):
        try:
            result = scrape_url(url)
        except Exception as e:
            # Should log instead of raise. no point to catch the exception and raise again.
            raise Exception(f"Failed to scrape {url}: {e}")
        self.campaign = campaign
        if not self.campaign:
            raise Exception("Campaign not found for ad generation")

        googleads_account = get_current_user_selected_google_ads_customer(self.user_id, self.db)

        if not googleads_account:
            raise Exception("Google Ads account not found for ad generation")

        try:
            keyword_service = KeywordService(db=self.db, user=self.user, bgts=self.bgts, campaign=self.campaign)
            keywords = keyword_service.get_new_keywords(
                googleads_account_id=googleads_account.googleads_account_id, content=result, url=url
            )
        except Exception as e:
            raise Exception(f"Failed to get new keywords for {url}: {e}")

        if keywords:
            try:
                if result and self.campaign and self.campaign.business_desc:
                    result = gen_ad_theme(result, self.campaign.business_desc, keywords=keywords[:15])
                    result = result.ad_goal
                else:
                    raise Exception("Failed to generate ad theme")

                headline_service = HeadlineService(db=self.db, bgts=self.bgts, user=self.user)
                headlines = headline_service.generate_headlines_for_ads(result, keywords[:15])
                descriptions = headline_service.generate_descriptions_for_ads(result, keywords[:10])

                if not headlines or not descriptions:
                    raise Exception("Failed to generate ad keywords, headlines and descriptions")

                ad_data = AdKeywordsHeadlinesDescriptions(
                    keywords=keywords[:10], headlines=headlines, descriptions=descriptions.descriptions
                )
            except Exception as e:
                raise Exception(f"Failed to generate ad keywords, headlines and descpitions for {url}: {e}")
            try:
                if not ad_data:
                    raise Exception("Ad data not found")
                if not self.campaign.id:
                    raise Exception("Campaign not exist")
                self.create_ad(ad_data=ad_data, campaign_id=self.campaign.id, url=url, alt_keywords=keywords[15:])
            except Exception as e:
                raise Exception(f"Failed to create ad for {url}: {e}")

    def create_ad(
        self,
        ad_data: AdKeywordsHeadlinesDescriptions,
        campaign_id: int,
        url: str,
        alt_keywords: list[str],
    ):
        ad_create = Ad(
            campaign_id=campaign_id,
            slug=generate(size=10),
            url=url,
        )
        new_ad = add_ad(ad_create, self.db)
        if not new_ad.id:
            raise AdCreationError("Ad creation failed")
        # Find the headlines that correspond to the current keyword
        for headline_entry in ad_data.headlines:
            keyword = add_keyword(new_ad.id, headline_entry["keyword"], self.db)
            # Add the headline to the database and associate it with the keyword
            add_headline(new_ad.id, headline_entry["headline"], keyword.id, self.db)

        for description_text in ad_data.descriptions:
            add_description(new_ad.id, description_text, self.db)

        # Add alternative keywords
        keyword_service = KeywordService(db=self.db, bgts=self.bgts, user=self.user, campaign=self.campaign)

        keyword_service.add_alt_keywords(alt_keywords, new_ad.id)
        keyword_service.set_generic_negatives(new_ad.id)

    def update_ad(self, ad_id: int, ad_data: AdUpdate) -> Ad | None:
        ad = get_ad_by_id(ad_id, self.db)

        if not ad:
            raise HTTPException(status_code=404, detail="Ad not found")

        # Update basic ad information
        ad.url = ad_data.url
        ad.state = ad_data.state

        headline_service = HeadlineService(db=self.db, bgts=self.bgts, user=self.user)
        keyword_service = KeywordService(db=self.db, bgts=self.bgts, user=self.user, campaign=self.campaign)

        headline_service.update_headlines(ad_id, ad_data, self.db)
        headline_service.update_descriptions(ad_id, ad_data, self.db)
        keyword_service.update_keywords(ad_id, ad_data, self.db)

        self.db.add(ad)
        self.db.commit()
        self.db.refresh(ad)

        return ad

    def delete_ad(self, googleads_account_id: str, ad_id: int, refresh_token=None, manager_account_id=None):
        googleads_ad = get_googleads_ad_by_ad_id(ad_id, self.db)

        if googleads_ad:
            try:
                GoogleAdsService(
                    db=self.db,
                    refresh_token=refresh_token,
                    googleads_account_id=googleads_account_id,
                    googleads_manager_account_id=manager_account_id,
                ).delete_ad(ad_id=googleads_ad.googleads_ad_id, ad_group_id=googleads_ad.googleads_ad_group_id)

            except Exception as e:
                print("Failed to delete ad in Google Ads", e)
                raise HTTPException(
                    status_code=400,
                    detail=f"Failed to delete ad in Google Ads {e}",
                )

        delete_ad_in_db(ad_id, self.db)


def check_ad_all_instant_fix_applied(ad_recommendation: AdRecommendation) -> bool:
    """
    Check if all AdRecommendations associated with a CampaignRecommendation
    have the state INSTANT_FIX_APPLIED.
    """
    return all(
        keyword_rec.state == RecommendationState.INSTANT_FIX_APPLIED
        for keyword_rec in ad_recommendation.keyword_recommendations
    )
