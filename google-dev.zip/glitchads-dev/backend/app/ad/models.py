from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Optional

from nanoid import generate
from pydantic import field_validator
from sqlalchemy import Column, ForeignKey, Integer
from sqlmodel import (
    Field,
    Relationship,
    SQLModel,
)

from app.common_state_enums import RecommendationSeverity, RecommendationState, RecommendationType
from app.google_ads.models import GoogleAdsAd, GoogleAdsAdGroup
from app.headline.models import Description, DescriptionData, DescriptionUpdate, Headline, HeadlineData, HeadlineUpdate
from app.keyword.models import (
    AlternativeKeyword,
    Keyword,
    KeywordData,
    KeywordRecommendation,
    KeywordRecommendationData,
    KeywordUpdate,
)

if TYPE_CHECKING:
    from ..campaign.models import Campaign, CampaignRecommendation
    from ..google_ads.models import GoogleAdsKeyword


class AdState(Enum):
    APPROVED = "approved"
    ERROR = "error"
    DRAFT = "draft"


class AdBase(SQLModel):
    slug: str = Field(default_factory=lambda: generate(size=10))
    state: AdState = Field(default=AdState.DRAFT)
    url: str
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )


class AdCreate(AdBase):
    googleads_ad_id: int


class Ad(AdBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

    campaign: Optional["Campaign"] = Relationship(back_populates="ads")
    headlines: list["Headline"] = Relationship(back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"})
    descriptions: list["Description"] = Relationship(
        back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    keywords: list["Keyword"] = Relationship(back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"})
    alternative_keywords: list["AlternativeKeyword"] = Relationship(
        back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    googleads_ad: Optional["GoogleAdsAd"] = Relationship(
        back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    googleads_ad_group: Optional["GoogleAdsAdGroup"] = Relationship(
        back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    ad_recommendations: list["AdRecommendation"] = Relationship(
        back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    googleads_keywords: list["GoogleAdsKeyword"] = Relationship(
        back_populates="ad", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    is_deleted: Optional[bool] = Field(default=False)


class AdData(AdBase):
    id: int
    headlines: list["HeadlineData"]
    descriptions: list["DescriptionData"]
    keywords: list["KeywordData"]
    alternative_keywords: list["AlternativeKeyword"]

    @field_validator("keywords", mode="before")
    def filter_negative_keywords(cls, v):
        # Ensure `v` is a list of KeywordData and filter out `negative=True`
        if isinstance(v, list):
            filtered_keywords = []
            for item in v:
                if isinstance(item, Keyword):
                    keyword = item
                    if keyword.negative is False:
                        filtered_keywords.append(keyword)
                if isinstance(item, dict):
                    keyword = item
                    if keyword["negative"] is False:
                        filtered_keywords.append(keyword)
                # Only include `keyword` if `negative` is exactly `False`
            return filtered_keywords
        return v


class AdUpdate(AdBase):
    headlines: list["HeadlineUpdate"]
    descriptions: list["DescriptionUpdate"]
    keywords: list["KeywordUpdate"]


class AdRecommendation(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    ad_id: int | None = Field(default=None, sa_column=Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))

    campaign_recommendation_id: Optional[int] = Field(foreign_key="campaignrecommendation.id", default=None)
    campaign_recommendation: Optional["CampaignRecommendation"] = Relationship(back_populates="ad_recommendations")
    title: str
    severity: RecommendationSeverity
    description: str
    state: RecommendationState
    recommendation_type: RecommendationType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    ad: list[Ad] = Relationship(back_populates="ad_recommendations")

    keyword_recommendations: list["KeywordRecommendation"] = Relationship(back_populates="ad_recommendation")


class AdRecommendationBase(SQLModel):
    id: Optional[int] = Field(default=None, primary_key=True)
    ad_id: int = Field(foreign_key="ad.id")
    campaign_recommendation_id: Optional[int] = Field(foreign_key="campaignrecommendation.id", default=None)
    title: str
    severity: RecommendationSeverity
    description: str
    state: RecommendationState
    recommendation_type: RecommendationType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AdRecommendationData(AdRecommendationBase):
    ad: AdBase
    keyword_recommendations: list["KeywordRecommendationData"]


class AdCreated(AdBase):
    id: int
