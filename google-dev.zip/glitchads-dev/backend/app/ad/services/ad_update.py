from sqlmodel import Session
from fastapi import BackgroundTasks

from ..db_ops import (
    get_ad_by_id,
    add_ad,
    update_ad_state,
)

from app.campaign.models import CampaignData

from app.ad.models import Ad, AdState, AdUpdate
from app.ad.exception.exceptions import (
    AdUpdateStateErrorException,
    AdNotFoundErrorException,
    AdPermissionErrorException,
)
from app.user.models import UserAccountData

from app.keyword.services import KeywordService

from app.headline.services import HeadlineService


class AdUpdateService:
    def __init__(self, user: UserAccountData, bgts: BackgroundTasks, db: Session, campaign: CampaignData | None = None):
        self.bgts = bgts
        self.db = db
        self.user = user
        self.campaign = campaign

    @staticmethod
    def update_ad_state(campaign_id: int, ad_id: int, state: AdState, db: Session) -> AdState:
        ad = get_ad_by_id(id=ad_id, db=db)
        if not ad:
            raise AdNotFoundErrorException("Ad Not Found")
        if ad.campaign_id != campaign_id:
            raise AdPermissionErrorException("Permission Denied.")
        try:
            updated_ad = update_ad_state(ad=ad, state=state, db=db)
            return updated_ad.state
        except Exception:
            raise AdUpdateStateErrorException("Failed to update Ad state.")

    def update_ad(self, campaign_id: int, ad_id: int, ad_data: AdUpdate) -> Ad | None:
        ad = get_ad_by_id(ad_id, self.db)
        if not ad:
            raise AdNotFoundErrorException("Ad not found")

        if ad.campaign_id != campaign_id:
            raise AdPermissionErrorException("Permission Denied.")

        # Update basic ad information
        ad.url = ad_data.url
        ad.state = ad_data.state

        headline_service = HeadlineService(db=self.db, bgts=self.bgts, user=self.user)
        keyword_service = KeywordService(db=self.db, bgts=self.bgts, user=self.user, campaign=self.campaign)

        # Tack Tracking
        headline_service.update_headlines(ad_id, ad_data, self.db)
        headline_service.update_descriptions(ad_id, ad_data, self.db)
        keyword_service.update_keywords(ad_id, ad_data, self.db)

        add_ad(ad=ad, db=self.db)
        ad = get_ad_by_id(ad_id, self.db)
        return ad
