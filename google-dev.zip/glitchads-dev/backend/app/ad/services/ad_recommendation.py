from sqlmodel import Session
from fastapi import BackgroundTasks

from ..db_ops import (
    get_ad_level_recommendation,
    get_keyword_recommendations,
    remove_keyword_and_update_state,
    update_ad_recommendation_state,
)

from app.campaign.db_ops import (
    get_campaign_level_recommendation,
    update_campaign_recommendation_state,
)

from app.campaign.models import Campaign

from app.ad.models import AdRecommendation
from app.ad.exception.exceptions import AdRecommendationErrorException

from app.common_state_enums import RecommendationState


class AdRecommendationService:
    def __init__(self, bgts: BackgroundTasks, db: Session):
        self.bgts = bgts
        self.db = db

    @staticmethod
    def ad_apply_instant_fix(campaign: Campaign, ad_recommendation_id: int, db: Session) -> dict:
        try:
            from app.campaign.services import check_campaign_all_instant_fix_applied

            ad_recommendation = get_ad_level_recommendation(ad_recommendation_id, db)

            keyword_recommendations = get_keyword_recommendations(ad_recommendation_id, db)
            for keyword_rec in keyword_recommendations:
                remove_keyword_and_update_state(keyword_rec, db)

            if ad_recommendation:
                update_ad_recommendation_state(ad_recommendation, db)

                if ad_recommendation.campaign_recommendation_id and campaign and campaign.id:
                    campaign_recommendation = get_campaign_level_recommendation(
                        campaign.id, ad_recommendation.campaign_recommendation_id, db
                    )

                    if campaign_recommendation and check_campaign_all_instant_fix_applied(campaign_recommendation):
                        update_campaign_recommendation_state(campaign_recommendation, db)

            db.commit()

        except Exception as e:
            db.rollback()
            print(f"Failed to apply instant fixes: {e}")
            raise AdRecommendationErrorException(f"Failed to apply instant fixes: {e}")

        return {"detail": "Instant fixes applied successfully"}

    @staticmethod
    def check_ad_all_instant_fix_applied(ad_recommendation: AdRecommendation) -> bool:
        """
        Check if all AdRecommendations associated with a CampaignRecommendation
        have the state INSTANT_FIX_APPLIED.
        """
        return all(
            keyword_rec.state == RecommendationState.INSTANT_FIX_APPLIED
            for keyword_rec in ad_recommendation.keyword_recommendations
        )
