from fastapi import BackgroundTasks
from nanoid import generate
from sqlmodel import Session

from app.ad.db_ops import add_ad
from app.ad.models import Ad, AdCreated
from app.campaign.models import CampaignReadWithoutAssociations
from app.headline.services.descriptions_create import DescriptionsCreateService
from app.headline.services.headline_create import HeadlineCreateService
from app.keyword.services.keywords_create import AdKeywordsCreateService, FocusedAdKeywordsCreateService
from app.task_tracking.schemas import TaskTrackingType
from app.task_tracking.task_tracking_service_base import TaskTrackingService
from app.web_miner.models import ScrapedData
from app.web_miner.scraper import get_url_content


class AdCreateService(TaskTrackingService):
    def __init__(
        self,
        campaign: CampaignReadWithoutAssociations,
        db: Session,
        url: str,
        googleads_account_id: str,
        google_refresh_token: str,
        bgts: BackgroundTasks,
        google_manager_account_id: str | None = None,
    ):
        super().__init__(db, campaign.id)
        self.campaign = campaign
        self.url = url
        self.googleads_account_id = googleads_account_id
        self.google_refresh_token = google_refresh_token
        self.google_manager_account_id = google_manager_account_id
        self.bgts = bgts

    def create_ad(self) -> None:
        self.execute_task_with_tracking(task_type=TaskTrackingType.AD_GENERATION)

    def run_task(self) -> None:
        self.generate_ad()

    def generate_ad(self) -> None:
        new_ad = self.add_ad_to_db()
        site_data = get_url_content(self.url, self.db)
        self.create_ad_associations(new_ad, site_data, self.googleads_account_id)

    def add_ad_to_db(self) -> AdCreated:
        ad_create = Ad(
            campaign_id=self.campaign_id,
            slug=generate(size=10),
            url=self.url,
        )
        return add_ad(ad_create, self.db)

    def create_ad_associations(self, ad: AdCreated, site_data: ScrapedData, googleads_account_id: str) -> None:
        new_keywords = AdKeywordsCreateService(
            campaign=self.campaign,
            db=self.db,
            url=self.url,
            ad_id=ad.id,
            site_data=site_data,
            googleads_account_id=googleads_account_id,
            google_manager_account_id=self.google_manager_account_id,
            google_refresh_token=self.google_refresh_token,
        ).create_keywords()

        DescriptionsCreateService(
            campaign=self.campaign,
            db=self.db,
            ad_id=ad.id,
            site_data=site_data,
            keyword_texts=[keyword.text for keyword in new_keywords],
        ).create_descriptions()

        headline_texts = []
        for keyword in new_keywords:
            headline = HeadlineCreateService(
                campaign=self.campaign,
                db=self.db,
                ad_id=ad.id,
                keyword=keyword,
                site_data=site_data,
                existing_headline_texts=headline_texts,
            ).create_headline()
            headline_texts.append(headline.text)


class FocusedAdCreateService(AdCreateService):
    def __init__(
        self,
        campaign: CampaignReadWithoutAssociations,
        db: Session,
        url: str,
        googleads_account_id: str,
        google_refresh_token: str,
        bgts: BackgroundTasks,
        number: int,
        google_manager_account_id: str | None = None,
    ):
        super().__init__(campaign, db, url, googleads_account_id, google_refresh_token, bgts, google_manager_account_id)
        self.number = number

    def create_ad(self) -> None:
        self.execute_task_with_tracking(task_type=TaskTrackingType.AD_GENERATION)

    def run_task(self) -> None:
        self.generate_ad()

    def generate_ad(self) -> None:
        new_ad = self.add_ad_to_db()
        site_data = get_url_content(self.url, self.db)
        self.create_ad_associations(new_ad, site_data, self.googleads_account_id)

    def add_ad_to_db(self) -> AdCreated:
        ad_create = Ad(
            campaign_id=self.campaign_id,
            slug=generate(size=10),
            url=self.url,
        )
        return add_ad(ad_create, self.db)

    def create_ad_associations(self, ad: AdCreated, site_data: ScrapedData, googleads_account_id: str) -> None:
        new_keywords = FocusedAdKeywordsCreateService(
            campaign=self.campaign,
            db=self.db,
            url=self.url,
            ad_id=ad.id,
            site_data=site_data,
            googleads_account_id=googleads_account_id,
            google_refresh_token=self.google_refresh_token,
            total_number=450,
            google_manager_account_id=self.google_manager_account_id,
            step=self.number,
        ).create_keywords()

        DescriptionsCreateService(
            campaign=self.campaign,
            db=self.db,
            ad_id=ad.id,
            site_data=site_data,
            keyword_texts=[keyword.text for keyword in new_keywords],
        ).create_descriptions()

        headline_texts = []
        for keyword in new_keywords:
            headline = HeadlineCreateService(
                campaign=self.campaign,
                db=self.db,
                ad_id=ad.id,
                keyword=keyword,
                site_data=site_data,
                existing_headline_texts=headline_texts,
            ).create_headline()
            headline_texts.append(headline.text)
