from sqlmodel import Session
from fastapi import BackgroundTasks

from ..db_ops import (
    delete_ad_in_db,
    get_ad_by_id,
)

from app.ad.exception.exceptions import AdNotFoundErrorException, AdPermissionErrorException

from app.auth.exception.exceptions import GoogleRefreshTokenEmptyException

from app.google_ads.exception.exceptions import GoogleAdsAdDeleteErrorException
from app.google_ads.db_ops import (
    get_googleads_ad_by_ad_id,
)
from app.google_ads.services import GoogleAdsService


class AdDeleteService:
    def __init__(self, bgts: BackgroundTasks, db: Session):
        self.bgts = bgts
        self.db = db

    def delete_ad(
        self, googleads_account_id: str, campaign_id: int, ad_id: int, refresh_token=None, manager_account_id=None
    ):
        ad = get_ad_by_id(ad_id, self.db)
        if not ad:
            raise AdNotFoundErrorException("Ad not found")

        if ad.campaign_id != campaign_id:
            raise AdPermissionErrorException("Ad Not Found")

        if not refresh_token:
            raise GoogleRefreshTokenEmptyException("Google Refresh Token is Empty.")

        googleads_ad = get_googleads_ad_by_ad_id(ad_id, self.db)

        if googleads_ad:
            try:
                GoogleAdsService(
                    db=self.db,
                    refresh_token=refresh_token,
                    googleads_account_id=googleads_account_id,
                    googleads_manager_account_id=manager_account_id,
                ).delete_ad(ad_id=googleads_ad.googleads_ad_id, ad_group_id=googleads_ad.googleads_ad_group_id)

            except Exception as e:
                print("Failed to delete ad in Google Ads", e)
                raise GoogleAdsAdDeleteErrorException(f"Failed to delete ad in Google Ads {e}")

        delete_ad_in_db(ad_id, self.db)
