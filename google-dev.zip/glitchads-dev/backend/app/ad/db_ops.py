from fastapi import HTTPException, status
from sqlmodel import Session, select

from app.common_state_enums import RecommendationState

from app.headline.models import Description, Headline
from app.keyword.models import Keyword, KeywordRecommendation
from .models import (
    Ad,
    AdCreated,
    AdRecommendation,
    AdState,
)

from typing import List, Optional


def add_ad(ad: Ad, db: Session) -> AdCreated:
    db.add(ad)
    db.commit()
    db.refresh(ad)
    return AdCreated.model_validate(ad)


def update_ad_state(ad: Ad, state: AdState, db: Session) -> Ad:
    ad.state = state
    db.add(ad)
    db.commit()
    return ad


def get_keyword_by_id(keyword_id: int, db: Session) -> Keyword | None:
    statement = select(Keyword).where(Keyword.id == keyword_id)
    return db.exec(statement).first()


def delete_ad_in_db(ad_id: int, db: Session):
    statement = select(Ad).where(Ad.id == ad_id)
    ad = db.exec(statement).first()
    if ad is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ad not found")
    db.delete(ad)
    db.commit()
    return {"ad_id": ad.id, "detail": "Ad deleted successfully"}


def get_ad_by_id(id: int, db: Session) -> Ad | None:
    statement = select(Ad).where(Ad.id == id)
    return db.exec(statement).first()


def get_ad_recommendations(campaign_recommendation_id: int, db: Session) -> List[AdRecommendation]:
    """
    Fetches all ad-level recommendations for a given campaign recommendation ID.

    Args:
        campaign_recommendation_id (int): The ID of the campaign recommendation.
        db (Session): The database session.

    Returns:
        List[AdRecommendation]: A list of ad recommendations.

    Raises:
        HTTPException: If no ad recommendations are found for the given campaign recommendation.
    """
    ad_recommendations = (
        db.query(AdRecommendation)
        .filter(AdRecommendation.campaign_recommendation_id == campaign_recommendation_id)
        .all()
    )

    return ad_recommendations


def get_keyword_recommendations(ad_recommendation_id: int, db: Session) -> List[KeywordRecommendation]:
    """
    Fetches all keyword-level recommendations for a given ad recommendation ID.

    Args:
        db (Session): The database session.
        ad_recommendation_id (int): The ID of the ad recommendation.

    Returns:
        List[KeywordRecommendation]: A list of keyword recommendations.

    Raises:
        HTTPException: If no keyword recommendations are found for the given ad recommendation.
    """
    keyword_recommendations = (
        db.query(KeywordRecommendation).filter(KeywordRecommendation.ad_recommendation_id == ad_recommendation_id).all()
    )

    return keyword_recommendations


def remove_keyword_and_update_state(keyword_rec: KeywordRecommendation, db: Session):
    keyword = db.query(Keyword).filter(Keyword.id == keyword_rec.keyword_id).first()
    if keyword:
        keyword.is_deleted = True
        db.add(keyword)
    keyword_rec.state = RecommendationState.INSTANT_FIX_APPLIED
    db.add(keyword_rec)
    db.flush()


def update_ad_recommendation_state(ad_rec: AdRecommendation, db: Session):
    ad_rec.state = RecommendationState.INSTANT_FIX_APPLIED
    db.add(ad_rec)
    db.flush()


def get_ad_level_recommendation(ad_recommendation_id: int, db: Session) -> Optional[AdRecommendation]:
    """
    Fetches all campaign-level recommendations for a given campaign ID.

    Args:
        campaign_id (int): The ID of the campaign.
        db (Session): The database session.

    Returns:
        List[CampaignRecommendation]: A list of campaign recommendations, or an empty list if none are found.
    """
    return db.query(AdRecommendation).filter(AdRecommendation.id == ad_recommendation_id).first()


def get_keyword_level_recommendation(key_recommendation_id: int, db: Session) -> Optional[KeywordRecommendation]:
    """
    Fetches all campaign-level recommendations for a given campaign ID.

    Args:
        campaign_id (int): The ID of the campaign.
        db (Session): The database session.

    Returns:
        List[CampaignRecommendation]: A list of campaign recommendations, or an empty list if none are found.
    """
    recommendations = db.query(KeywordRecommendation).filter(KeywordRecommendation.id == key_recommendation_id).first()

    return recommendations


def remove_headline_by_id(headline_id: int, db: Session):
    statement = select(Headline).where(Headline.id == headline_id)
    headline = db.exec(statement).first()
    if headline is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Headline not found")
    db.delete(headline)
    db.commit()


def get_all_descriptions_by_ad_id(ad_id: int, db: Session) -> List[Description]:
    descriptions = db.exec(select(Description).where(Description.ad_id == ad_id)).all()
    return descriptions


def get_all_keywords_by_ad_id(ad_id: int, db: Session) -> List[Keyword]:
    keywords = db.exec(select(Keyword).where(Keyword.ad_id == ad_id, Keyword.negative == False)).all()  # noqa: E712
    return keywords


# test deploy


def remove_keyword_by_id(keyword_id: int, db: Session):
    statement = select(Keyword).where(Keyword.id == keyword_id)
    keyword = db.exec(statement).first()
    if keyword is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Keyword not found")
    db.delete(keyword)
    db.commit()


def get_keywords_by_ad_id(ad_id: int, db: Session) -> List[Keyword]:
    statement = select(Keyword).where(Keyword.ad_id == ad_id, Keyword.negative == False)  # noqa: E712
    return db.exec(statement).all()


def get_negative_keywords_by_ad_id(ad_id: int, db: Session) -> List[Keyword]:
    statement = select(Keyword).where(Keyword.ad_id == ad_id, Keyword.negative)
    return db.exec(statement).all()
