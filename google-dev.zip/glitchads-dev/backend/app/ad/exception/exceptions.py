class AdUpdateStateErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AdCreationErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AdNotFoundErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AdPermissionErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AdThemeGenerationErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AdURLReachableErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AdRecommendationErrorException(Exception):
    def __init__(self, detail: str):
        self.detail = detail
