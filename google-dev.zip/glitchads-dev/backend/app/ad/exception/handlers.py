from fastapi import Request, status
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError

from .exceptions import (
    AdUpdateStateErrorException,
    AdCreationErrorException,
    AdNotFoundErrorException,
    AdPermissionErrorException,
    AdThemeGenerationErrorException,
    AdURLReachableErrorException,
    AdRecommendationErrorException,
)


def register_ad_exception_handlers(app):
    @app.exception_handler(AdUpdateStateErrorException)
    async def ad_update_state_error_exception_handler(request: Request, exc: AdUpdateStateErrorException):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AdCreationErrorException)
    async def ad_creation_error_exception_handler(request: Request, exc: AdCreationErrorException):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AdNotFoundErrorException)
    async def ad_not_found_error_exception_handler(request: Request, exc: AdNotFoundErrorException):
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AdPermissionErrorException)
    async def ad_permission_error_exception_handler(request: Request, exc: AdPermissionErrorException):
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AdThemeGenerationErrorException)
    async def ad_theme_generation_error_exception_handler(request: Request, exc: AdThemeGenerationErrorException):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AdURLReachableErrorException)
    async def ad_url_reachable_error_exception_handler(request: Request, exc: AdURLReachableErrorException):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AdRecommendationErrorException)
    async def ad_recommendation_error_exception_handler(request: Request, exc: AdRecommendationErrorException):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": exc.detail},
        )

    # Handler for SQLAlchemy Errors
    @app.exception_handler(SQLAlchemyError)
    async def sqlalchemy_exception_handler(request: Request, exc: SQLAlchemyError):
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": f"A database error occurred. {exc}"},
        )

    # Handler for General Exceptions
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": str(exc)},
        )
