from sqlmodel import Field, SQLModel, UniqueConstraint
from typing import Optional
import uuid
from datetime import datetime, timezone
from app.membership.schemas import MembershipRole, MembershipStatus


class MembershipBase(SQLModel):
    user_id: int = Field(default=None, foreign_key="useraccount.id", ondelete="CASCADE")
    organization_id: int = Field(default=None, foreign_key="organization.id", ondelete="CASCADE")
    role: MembershipRole = Field(default=MembershipRole.MEMBER, nullable=False)
    status: MembershipStatus = Field(default=MembershipStatus.PENDING, nullable=False)


class Membership(MembershipBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)


class InviteCodeBase(SQLModel):
    code: uuid.UUID = Field(default_factory=uuid.uuid4, nullable=False, unique=True)
    role: MembershipRole = Field(default=MembershipRole.MEMBER, nullable=False)
    generated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )  # code generated and used to check if it's expired
    valid: bool = Field(default=True, nullable=False)


class InviteCode(InviteCodeBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    organization_id: Optional[int] = Field(default=None, foreign_key="organization.id", ondelete="CASCADE")
    email: str
    __table_args__ = (UniqueConstraint("organization_id", "email", name="email_unique_constraint_organization_id"),)


class InviteCodeData(InviteCodeBase):
    id: int
