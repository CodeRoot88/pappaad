from sqlmodel import Session, select

from app.membership.models import InviteCode, Membership
from typing import Optional


def get_membership(organization_id: int, user_id: int, db: Session) -> Optional[Membership]:
    statement = select(Membership).where(Membership.organization_id == organization_id, Membership.user_id == user_id)
    return db.exec(statement).first()


def add_membership(membership: Membership, db: Session) -> Membership:
    db.add(membership)
    db.commit()
    db.refresh(membership)
    return membership


def add_invite_code(invite_code: InviteCode, db: Session) -> InviteCode:
    db.add(invite_code)
    db.commit()
    db.refresh(invite_code)
    return invite_code


def get_invite_code_by_code(code: str, db: Session) -> Optional[InviteCode]:
    statement = select(InviteCode).where(InviteCode.code == code)
    return db.exec(statement).first()


def get_invite_code_by_organization_and_email(organization_id: int, email: str, db: Session) -> Optional[InviteCode]:
    statement = select(InviteCode).where(InviteCode.organization_id == organization_id, InviteCode.email == email)
    return db.exec(statement).first()
