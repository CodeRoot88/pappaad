from datetime import datetime, timezone
from typing import TYPE_CHECKING, Optional

from sqlalchemy import ForeignKey, Integer
from sqlmodel import Column, Field, Relationship, SQLModel

from pydantic import field_validator

from app.common_state_enums import RecommendationSeverity, RecommendationState, RecommendationType
from helper.check_emoji import validate_no_emojis

if TYPE_CHECKING:
    from ..ad.models import Ad, AdRecommendation
    from ..headline.models import Headline


class KeywordBase(SQLModel):
    text: str
    is_deleted: bool | None = Field(default=None)

    @field_validator("text")
    def validate_text_no_emojis(cls, value: str) -> str:
        return validate_no_emojis(value)


class Keyword(KeywordBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    ad: "Ad" = Relationship(back_populates="keywords")
    ad_id: int | None = Field(default=None, sa_column=Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))
    negative: bool = False
    default_negative: bool = False
    keyword_recommendations: list["KeywordRecommendation"] = Relationship(
        back_populates="keyword", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    headlines: list["Headline"] = Relationship(
        back_populates="keyword", sa_relationship_kwargs={"cascade": "all, delete"}
    )
    is_deleted: Optional[bool] = Field(default=False)


class KeywordReadWithoutAssociatedData(KeywordBase):
    id: int


class KeywordData(KeywordBase):
    id: int
    negative: bool


class KeywordCreate(KeywordBase):
    pass


class KeywordUpdate(KeywordBase):
    id: int | None = Field(default=None)


class KeywordRecommendationBase(SQLModel):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    severity: RecommendationSeverity
    description: str
    state: RecommendationState
    recommendation_type: RecommendationType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class KeywordRecommendationData(KeywordRecommendationBase):
    keyword: KeywordData


class KeywordRecommendation(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    keyword_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("keyword.id", ondelete="CASCADE"))
    )

    keyword: Keyword | None = Relationship(back_populates="keyword_recommendations")
    ad_recommendation_id: Optional[int] = Field(foreign_key="adrecommendation.id", default=None)
    ad_recommendation: Optional["AdRecommendation"] = Relationship(back_populates="keyword_recommendations")
    title: str
    severity: RecommendationSeverity
    description: str
    state: RecommendationState
    recommendation_type: RecommendationType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AlternativeKeywordBase(SQLModel):
    text: str
    ad_id: int = Field(default=None, sa_column=Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))


class AlternativeKeyword(AlternativeKeywordBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    ad: "Ad" = Relationship(back_populates="alternative_keywords")


class AlternativeKeywordRead(AlternativeKeywordBase):
    id: int
