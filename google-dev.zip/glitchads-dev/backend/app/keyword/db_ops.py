from typing import Optional

from sqlmodel import Session, select

from app.common_state_enums import RecommendationState
from app.keyword.models import (
    AlternativeKeyword,
    AlternativeKeywordRead,
    Keyword,
    KeywordReadWithoutAssociatedData,
    KeywordRecommendation,
)


def add_keyword(ad_id: int, text: str, db: Session) -> KeywordReadWithoutAssociatedData:
    keyword = Keyword(ad_id=ad_id, text=text)
    db.add(keyword)
    db.commit()
    db.refresh(keyword)
    return KeywordReadWithoutAssociatedData.model_validate(keyword)


def add_keywords(ad_id: int, keyword_texts: list[str], db: Session) -> list[KeywordReadWithoutAssociatedData]:
    keywords = []
    for keyword_text in keyword_texts:
        keyword = Keyword(ad_id=ad_id, text=keyword_text)
        db.add(keyword)
        keywords.append(keyword)
    db.commit()
    for keyword in keywords:
        db.refresh(keyword)
    return [KeywordReadWithoutAssociatedData.model_validate(keyword) for keyword in keywords]


def add_alternative_keywords(ad_id: int, keyword_texts: list[str], db: Session) -> list[AlternativeKeywordRead]:
    keywords = []
    for keyword_text in keyword_texts:
        keyword = AlternativeKeyword(ad_id=ad_id, text=keyword_text)
        db.add(keyword)
        keywords.append(keyword)
    db.commit()
    for keyword in keywords:
        db.refresh(keyword)
    return [AlternativeKeywordRead.model_validate(keyword) for keyword in keywords]


def get_keyword_by_id(keyword_id: int, db: Session) -> Keyword | None:
    statement = select(Keyword).where(Keyword.id == keyword_id)
    return db.exec(statement).first()


def add_negative_keyword(ad_id: int, text: str, db: Session) -> Keyword:
    keyword = Keyword(ad_id=ad_id, text=text, negative=True)
    db.add(keyword)
    db.commit()
    db.refresh(keyword)
    return keyword


def get_keyword_recommendations(ad_recommendation_id: int, db: Session) -> list[KeywordRecommendation]:
    keyword_recommendations = db.exec(
        select(KeywordRecommendation).where(KeywordRecommendation.ad_recommendation_id == ad_recommendation_id)
    ).all()

    return list(keyword_recommendations)


def remove_keyword_and_update_state(keyword_rec: KeywordRecommendation, db: Session):
    keyword = db.exec(select(Keyword).where(Keyword.id == keyword_rec.keyword_id)).first()
    if keyword:
        keyword.is_deleted = True
        db.add(keyword)
    keyword_rec.state = RecommendationState.INSTANT_FIX_APPLIED
    db.add(keyword_rec)
    db.commit()


def get_keyword_level_recommendation(key_recommendation_id: int, db: Session) -> Optional[KeywordRecommendation]:
    recommendation = db.exec(
        select(KeywordRecommendation).where(KeywordRecommendation.id == key_recommendation_id)
    ).first()

    return recommendation


def get_all_keywords_by_ad_id(ad_id: int, db: Session) -> list[Keyword]:
    keywords = db.exec(select(Keyword).where(Keyword.ad_id == ad_id, Keyword.negative == False)).all()  # noqa
    return list(keywords)


# test deploy


def remove_keyword_by_id(keyword_id: int, db: Session):
    statement = select(Keyword).where(Keyword.id == keyword_id)
    keyword = db.exec(statement).first()
    if keyword is None:
        raise ValueError(f"Keyword with id {keyword_id} not found")
    db.delete(keyword)
    db.commit()


def get_keywords_by_ad_id(ad_id: int, db: Session) -> list[Keyword]:
    statement = select(Keyword).where(Keyword.ad_id == ad_id, Keyword.negative == False)  # noqa
    return list(db.exec(statement).all())


def get_negative_keywords_by_ad_id(ad_id: int, db: Session) -> list[Keyword]:
    statement = select(Keyword).where(Keyword.ad_id == ad_id, Keyword.negative)
    return list(db.exec(statement).all())


def add_google_alt_keyword(ad_id: int, text: str, db: Session):
    keyword = AlternativeKeyword(ad_id=ad_id, text=text)
    db.add(keyword)
    db.commit()


def get_google_alt_keywords_by_ad_id(ad_id: int, db: Session):
    statement = select(AlternativeKeyword).where(AlternativeKeyword.ad_id == ad_id)
    return db.exec(statement).all()
