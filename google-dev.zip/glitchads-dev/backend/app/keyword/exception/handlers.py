from fastapi import Request
from fastapi.responses import JSONResponse

from .exceptions import KeywordGenerationErrorException


def register_keyword_exception_handlers(app):
    @app.exception_handler(KeywordGenerationErrorException)
    async def keyword_generation_error_exception_handler(request: Request, exc: KeywordGenerationErrorException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )
