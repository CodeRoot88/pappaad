from google.ads.googleads.client import GoogleAdsClient
from sqlmodel import Session

from app.campaign.models import CampaignReadWithoutAssociations
from app.data import negative_keywords
from app.google_client_setup import initialize_googleads_client
from app.keyword.db_ops import add_alternative_keywords, add_keywords
from app.keyword.models import KeywordReadWithoutAssociatedData
from app.recommendations.new_keywords.generate_new_keywords_recommendation import gen_new_keywords_for_ad
from app.task_tracking.schemas import TaskTrackingType
from app.task_tracking.task_tracking_service_base import TaskTrackingService
from app.web_miner.models import ScrapedData


class AdKeywordsCreateService(TaskTrackingService[list[KeywordReadWithoutAssociatedData]]):
    def __init__(
        self,
        campaign: CampaignReadWithoutAssociations,
        db: Session,
        url: str,
        ad_id: int,
        site_data: ScrapedData,
        googleads_account_id: str,
        google_refresh_token: str,
        google_manager_account_id: str | None = None,
        total_number=60,
    ):
        super().__init__(db, campaign.id)
        self.campaign = campaign
        self.url = url
        self.ad_id = ad_id
        self.site_data = site_data
        self.googleads_account_id = googleads_account_id
        self.google_refresh_token = google_refresh_token
        self.google_manager_account_id = google_manager_account_id
        self.total_number = total_number

    def create_keywords(self) -> list[KeywordReadWithoutAssociatedData]:
        return self.execute_task_with_tracking(task_type=TaskTrackingType.KEYWORDS_GENERATION)

    def run_task(self) -> list[KeywordReadWithoutAssociatedData]:
        return self.generate_keywords()

    def generate_keywords(self) -> list[KeywordReadWithoutAssociatedData]:
        keywords = self.get_new_keywords()
        new_keywords = add_keywords(ad_id=self.ad_id, keyword_texts=keywords[:15], db=self.db)
        add_alternative_keywords(ad_id=self.ad_id, keyword_texts=keywords[15:], db=self.db)
        return new_keywords

    def get_new_keywords(self):
        client: GoogleAdsClient = initialize_googleads_client(self.google_refresh_token, self.google_manager_account_id)

        new_keywords = set(
            gen_new_keywords_for_ad(
                client=client,
                googleads_account_id=self.googleads_account_id,
                url=self.site_data.url,
                content=self.site_data.content,
                business_desc=self.campaign.business_desc or "",
                total_number=self.total_number,
            )
        )
        new_keywords -= set(negative_keywords.generic_negatives())
        return list(new_keywords)


class FocusedAdKeywordsCreateService(AdKeywordsCreateService):
    def __init__(
        self,
        campaign: CampaignReadWithoutAssociations,
        db: Session,
        url: str,
        ad_id: int,
        site_data: ScrapedData,
        googleads_account_id: str,
        google_refresh_token: str,
        google_manager_account_id: str | None = None,
        total_number=150,
        step=0,
    ):
        super().__init__(
            campaign=campaign,
            db=db,
            url=url,
            ad_id=ad_id,
            site_data=site_data,
            googleads_account_id=googleads_account_id,
            google_refresh_token=google_refresh_token,
            google_manager_account_id=google_manager_account_id,
            total_number=total_number,
        )
        step_increment = 10
        self.step = step * step_increment
        self.increment = self.step + step_increment

    def run_task(self) -> list[KeywordReadWithoutAssociatedData]:
        return self.generate_focused_keywords()

    def generate_focused_keywords(self) -> list[KeywordReadWithoutAssociatedData]:
        keywords = self.get_new_keywords()
        new_keywords = add_keywords(ad_id=self.ad_id, keyword_texts=keywords[self.step : (self.increment)], db=self.db)
        add_alternative_keywords(
            ad_id=self.ad_id, keyword_texts=keywords[len(keywords) - self.increment : self.step], db=self.db
        )
        return list(new_keywords)
