from fastapi import BackgroundTasks
from sqlmodel import Session
from google.ads.googleads.client import GoogleAdsClient

from app.campaign.models import Campaign

from app.ad.models import AdUpdate
from app.ad.db_ops import (
    get_all_keywords_by_ad_id,
    remove_keyword_by_id,
)

from app.keyword.db_ops import add_keyword, add_negative_keyword
from app.keyword.exception.exceptions import KeywordGenerationErrorException

from app.headline.db_ops import add_headline, get_all_headlines_by_ad_id
from app.google_client_setup import initialize_googleads_client
from app.recommendations.new_keywords.generate_new_keywords_recommendation import gen_new_keywords_for_ad
from app.user.models import UserAccountData
from app.llm_services import gen_ad_keyword_headline
from app.web_miner.scraper import scrape_url
from app.data.negative_keywords import generic_negatives


class KeywordService:
    def __init__(self, db: Session, user: UserAccountData, bgts: BackgroundTasks, campaign: Campaign | None = None):
        self.db = db
        self.user = user
        self.bgts = bgts
        self.campaign = campaign

    def set_generic_negatives(self, ad_id: int):
        self.bgts.add_task(self.add_generic_negatives, ad_id)

    def add_generic_negatives(self, ad_id: int):
        negative_keywords = generic_negatives()
        for text in negative_keywords:
            add_negative_keyword(ad_id, text, self.db)

    def get_new_keywords(self, googleads_account_id: str, content: str, url: str):
        if not self.campaign:
            return ValueError("Campaign does not exist")

        if not self.campaign.googleads_account:
            return ValueError("Google Ads does not exist")
        client: GoogleAdsClient = initialize_googleads_client(
            self.user.google_refresh_token, self.campaign.googleads_account.manager_account_id
        )
        try:
            new_keywords = gen_new_keywords_for_ad(
                client=client,
                googleads_account_id=googleads_account_id,
                url=url,
                content=content,
                business_desc=self.campaign.business_desc or "",
                num=60,
            )
        except Exception as e:
            raise KeywordGenerationErrorException(f"Failed to get new keywords for {url}: {e}")
        return new_keywords

    def update_keywords(self, ad_id, ad_data: AdUpdate, db):
        current_keywords = get_all_keywords_by_ad_id(ad_id, db)

        # Create a set of keyword IDs from the input
        input_keyword_ids = {kw.id for kw in ad_data.keywords if hasattr(kw, "id") and kw.id}
        # Update or delete existing keywords
        for current_keyword in current_keywords:
            if current_keyword.id in input_keyword_ids:
                updated_keyword = next(kw for kw in ad_data.keywords if kw.id == current_keyword.id)
                current_keyword.text = updated_keyword.text
                current_keyword.is_deleted = updated_keyword.is_deleted
            else:
                if current_keyword.id:
                    remove_keyword_by_id(current_keyword.id, db)

        # Add new keywords
        try:
            result = scrape_url(ad_data.url)
        except Exception as e:
            raise Exception(f"Failed to scrape {ad_data.url}: {e}")
        for keyword in ad_data.keywords:
            if not hasattr(keyword, "id") or not keyword.id:
                new_keyword = add_keyword(ad_id, keyword.text, db)

                current_headlines = get_all_headlines_by_ad_id(ad_id, db)

                if len(current_headlines) < 15:
                    headline_text = None
                    try:
                        headline_text = gen_ad_keyword_headline(result, keyword.text).headline
                    except Exception as e:
                        raise Exception(f"Failed to generate headline: {e}")

                    add_headline(ad_id=ad_id, text=headline_text, keyword_id=new_keyword.id, db=db)
