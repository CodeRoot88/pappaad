import re

# Optional country code pattern
country_code_pattern = r"^(?:/[a-z]{2})?"


exclusion_patterns = [
    # Legal and policy pages
    r"/terms(?:[-_](?:of[-_]?service|and[-_]?conditions))?/?$",
    r"/terms[-_]?of[-_]?use(?:/.*)?$",
    r"/conditions(?:[-_](?:of[-_]?use))?/?$",
    r"/privacy[-_]?policy/?$",
    r"/legal/?$",
    r"/disclaimer/?$",
    r"/copyright/?$",
    r"/acceptable[-_]?use[-_]?policy/?$",
    r"/aup/?$",  # Acronym for Acceptable Use Policy
    r"/eula/?$",  # End User License Agreement
    r"/tos/?$",  # Terms of Service
    r"/cookie[-_]?policy/?$",
    r"/gdpr/?$",  # General Data Protection Regulation
    r"/ccpa/?$",  # California Consumer Privacy Act
    r"/data[-_]?protection/?$",
    r"/impressum/?$",  # Common in German-speaking countries
    r"/site[-_]?notice/?$",
    r"/return[-_]?policy/?$",
    r"/shipping[-_]?policy/?$",
    r"/refund[-_]?policy/?$",
    r"/intellectual[-_]?property/?$",
    r"/licensing[-_]?(?:information|info)?/?$",
    # Blog, news, and article pages
    r"/blog(?:/.*)?$",  # Matches /blog and all subpages
    r"/article(?:/.*)?$",  # Matches /article and all subpages
    r"/news(?:room)?(?:/.*)?$",  # Matches /news, /newsroom, and all subpages
    r"/press[-_]?release(?:s)?(?:/.*)?$",  # Matches /press-release(s) and all subpages
    r"/media[-_]?center(?:/.*)?$",  # Matches /media-center and all subpages
    r"/publication(?:s)?(?:/.*)?$",
    # User engagement and subscription pages
    r"/subscribe/?$",
    r"/newsletter/?$",
    r"/sign[-_]?up/?$",
    r"/register/?$",
    r"/login/?$",
    r"/logout/?$",
    r"/account/?$",
    # Contact and support pages
    r"/contact(?:[-_]?(?:us))?/?$",
    r"/support/?$",
    r"/help[-_]?center/?$",
    r"/faq(?:s)?/?$",  # Updated to include 'faqs'
    r"/feedback/?$",
    # Social media and community pages
    r"/community/?$",
    r"/forums?/?$",
    r"/social[-_]?media/?$",
    # Career and job pages
    r"/careers?/?$",
    r"/jobs?/?$",
    r"/work[-_]?(?:with[-_]?us|for[-_]?us)?/?$",
    # Utility pages
    r"/search/?$",
    r"/sitemap/?$",
    r"/rss/?$",
    r"/feed/?$",
    # File types (often not relevant for ads)
    r"\.(?:pdf|doc|docx|ppt|pptx|xls|xlsx|zip|rar)$",
    # Calendar and event pages
    r"/events?/?$",
    r"/calendar/?$",
    r"/schedule/?$",
    # Localization and language pages
    r"/languages?/?$",
    r"/regions?/?$",
    r"/countries?/?$",
    # Archive pages
    r"/archives?/?$",
    r"/history/?$",
    # Shopping cart and checkout pages
    r"/cart/?$",
    r"/checkout/?$",
    r"/basket/?$",
    # User-generated content
    r"/reviews?/?$",
    r"/testimonials?/?$",
    r"/ratings?/?$",
    r"/privacy/?$",
    r"/privacy[-_]?(?:notice|statement|policy|center|hub)/?$",
    r"/data[-_]?(?:privacy|protection|usage|collection|retention)/?$",
    r"/personal[-_]?information/?$",
    r"/opt[-_]?(?:out|in)/?$",
    r"/do[-_]?(?:not[-_]?sell[-_]?my[-_]?info(?:rmation)?)?/?$",
    r"/california[-_]?(?:privacy[-_]rights)/?$",
    r"/eu[-_]?(?:privacy[-_]rights)/?$",
    r"/gdpr[-_]?(?:compliance|info(?:rmation)?)?/?$",
    r"/ccpa[-_]?(?:compliance|info(?:rmation)?)?/?$",
    r"/privacy[-_]?(?:settings)/?$",
    r"/cookie[-_]?(?:preferences|settings|management)/?$",
    r"/security/?$",
    r"/security[-_]?(?:policy|notice|statement|center|hub)/?$",
    r"/information[-_]?(?:security)/?$",
    r"/cyber[-_]?(?:security)/?$",
    r"/data[-_]?(?:security)/?$",
    r"/ssl[-_]?(?:security)/?$",
    r"/secure[-_]?(?:shopping)/?$",
    r"/fraud[-_]?(?:prevention|protection)/?$",
    r"/phishing[-_]?(?:awareness)/?$",
    r"/identity[-_]?(?:theft[-_]?(?:protection))/?$",
    r"/vulnerability[-_]?(?:disclosure)/?$",
    r"/bug[-_]?(?:bounty)/?$",
    r"/responsible[-_]?(?:disclosure)/?$",
    r"/two[-_]?(?:factor[-_]?(?:authentication))/?$",
    r"/2fa/?$",
    r"/mfa/?$",  # Multi-factor authentication
    r"/password[-_]?(?:policy|security|requirements)/?$",
    r"/account[-_]?(?:security)/?$",
    r"/security[-_]?(?:faq)/?$",
    r"/security[-_]?(?:best[-_]?(?:practices))/?$",
    r"/data[-_]?(?:breach[-_]?(?:notification|response))/?$",
    r"/incident[-_]?(?:response)/?$",
    r"/safe[-_]?(?:browsing)/?$",
    r"/online[-_]?(?:safety)/?$",
    r"/child[-_]?(?:ren)?[-_]?(?:privacy|safety|protection)/?$",
    r"/coppa[-_]?(?:compliance|info(?:rmation)?)?/?$",  # Children's Online Privacy
    r"\.(?:pdf|jpg|png|gif|svg)$",
    # Add pricing exclusion
    r"/pricing/?$",
    r"/sitemap(?:[_-]index)?(?:\d+)?\.xml(?:\.gz)?/?$",  # Matches /sitemap.xml, /sitemap_index.xml, /sitemap1.xml, /sitemap.xml.gz, etc.
    r"/sitemap(?:/sitemap(?:[_-]index)?(?:\d+)?\.xml(?:\.gz)?)?/?$",  # Matches /sitemap/sitemap.xml, /sitemap/sitemap_index.xml.gz, etc.
    r"/team(?:/.*)?$",
]


# Integrate optional country code into each pattern
exclusion_patterns_with_country_code = [r"^(?:/[a-z]{2})?" + pattern for pattern in exclusion_patterns]

# Compile the updated exclusion patterns with IGNORECASE flag
compiled_exclusion_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in exclusion_patterns_with_country_code]
