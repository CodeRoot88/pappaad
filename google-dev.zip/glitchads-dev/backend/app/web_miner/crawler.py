import re
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from app.web_miner.crawler_exclusion_patterns import exclusion_patterns


async def get_robots_txt(client: httpx.AsyncClient, base_url: str) -> str | None:
    robots_url = urljoin(base_url, "/robots.txt")
    response = await client.get(robots_url)
    if response.status_code == 200:
        return response.text
    return None


async def get_sitemap_url(robots_txt: str) -> str | None:
    if robots_txt:
        for line in robots_txt.split("\n"):
            if line.lower().startswith("sitemap:"):
                return line.split(": ")[1].strip()
    return None


async def parse_sitemap(client: httpx.AsyncClient, sitemap_url: str, exclude: list) -> list[str]:
    response = await client.get(sitemap_url)
    if response.status_code != 200:
        return []

    urls = []
    root = ET.fromstring(response.content)

    # Check if this is a sitemap index
    if root.tag.endswith("sitemapindex"):
        # This is a sitemap index, so we need to parse each linked sitemap
        for sitemap in root.findall(".//{http://www.sitemaps.org/schemas/sitemap/0.9}loc"):
            sub_sitemap_url = sitemap.text
            sub_urls = await parse_sitemap(client, sub_sitemap_url, exclude)
            urls.extend(sub_urls)
    else:
        # This is a regular sitemap
        for url in root.findall(".//{http://www.sitemaps.org/schemas/sitemap/0.9}loc"):
            if not any(re.search(pattern, url.text) for pattern in exclude):
                urls.append(url.text)

    return urls


async def find_general_sitemaps(client: httpx.AsyncClient, base_url: str, exclude: list) -> str | None:
    common_sitemap_paths = [
        "/sitemap.xml",
        "/sitemap_index.xml",
        "/sitemap1.xml",
        "/sitemap/sitemap.xml",
        "/sitemap/sitemap_index.xml",
        "/sitemap_index.xml.gz",
        "/sitemap.xml.gz",
        "/sitemap_index.xml.gz",
    ]

    for path in common_sitemap_paths:
        sitemap_url = urljoin(base_url, path)
        try:
            response = await client.get(sitemap_url, timeout=10.0)
            if response.status_code == 200:
                return sitemap_url
        except httpx.RequestError:
            pass


def normalize_domain(netloc: str) -> str:
    netloc = netloc.lower()
    if netloc.startswith("www."):
        return netloc[4:]
    return netloc


async def crawl_website(client: httpx.AsyncClient, start_url: str, max_pages: int = 100, exclude: list = []):
    visited_urls = set()
    to_visit = [start_url]
    base_domain = normalize_domain(urlparse(start_url).netloc)
    while to_visit and len(visited_urls) < max_pages:
        current_url = to_visit.pop(0)
        if current_url in visited_urls:
            continue
        if any(re.search(pattern, current_url) for pattern in exclude):
            continue
        try:
            response = await client.get(current_url)
            final_url = str(response.url)

            if response.status_code == 200:
                if final_url not in visited_urls:
                    visited_urls.add(final_url)
                    soup = BeautifulSoup(response.text, "html.parser")
                    for link in soup.find_all("a", href=True):
                        href = link["href"]
                        if href.startswith("mailto:") or href.startswith("tel:"):
                            continue
                        full_url = urljoin(final_url, href)
                        parsed_full_url = urlparse(full_url)

                        if (
                            normalize_domain(parsed_full_url.netloc) == base_domain
                            and full_url not in visited_urls
                            and not any(re.search(pattern, full_url) for pattern in exclude)
                        ):
                            to_visit.append(full_url)
            else:
                print(f"Failed to crawl: {current_url}, Status code: {response.status_code}")
        except Exception as e:
            print(f"Error crawling {current_url}: {str(e)}")
    return list(visited_urls)


def format_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        return f"https://{url}"
    return url


async def crawl(start_url, exclude=exclusion_patterns):
    async with httpx.AsyncClient(follow_redirects=True) as client:
        start_url = format_url(start_url)
        robots_txt = await get_robots_txt(client, start_url)
        sitemap_url = None
        if robots_txt:
            sitemap_url = await get_sitemap_url(robots_txt)
        if not sitemap_url:
            sitemap_url = await find_general_sitemaps(client, start_url, exclude)
        urls = []
        exclude_patterns = [r"\.pdf$", r"\.jpg$", r"\.png$", r"\.gif$", r"\.svg$"]
        if sitemap_url:
            print(f"Sitemap found: {sitemap_url}")
            try:
                urls = await parse_sitemap(client, sitemap_url, exclude)
                return urls
            except Exception as e:
                print(f"Error parsing sitemap: {str(e)}")
        if not urls:
            urls = await crawl_website(client, start_url, exclude=exclude_patterns)

        return urls


async def get_site_links(website: str) -> list[str]:
    results = await crawl(website.strip())
    if results:
        return results
    return []
