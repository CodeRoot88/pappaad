import logging
import os
import re
import time
from urllib.parse import urlparse, urlunparse

import httpx
from dotenv import load_dotenv
from sqlmodel import Session


from app.web_miner.crawler_exclusion_patterns import compiled_exclusion_patterns
from app.web_miner.db_ops import add_scraped_data, get_scraped_data_by_url
from app.web_miner.models import ScrapedData

logger = logging.getLogger(__name__)

_ = load_dotenv()


def normalize_url(url: str) -> str:
    if url.endswith("/"):
        return url.rstrip("/")
    return url


def normalize_netloc(netloc: str) -> str:
    return netloc.lower().lstrip("www.")


def clean_links(links_dict: dict, base_url: str) -> list:
    """
    Cleans the links by extracting URLs, removing those with '#' or '?',
    and ensuring they are internal links based on the base URL.

    :param links_dict: Dictionary containing link descriptions and URLs.
    :param base_url: The base URL to determine internal links.
    :return: A list of cleaned, internal URLs.
    """
    cleaned_links = set()
    parsed_base = urlparse(base_url)

    base_netloc = normalize_netloc(parsed_base.netloc)
    base_scheme = parsed_base.scheme
    for url in links_dict.values():
        try:
            parsed_url = urlparse(url)

            if not (parsed_url.scheme and parsed_url.netloc and parsed_url.path):
                continue

            url_netloc = normalize_netloc(parsed_url.netloc)
            if parsed_url.scheme != base_scheme or url_netloc != base_netloc:
                continue

            cleaned_url = urlunparse(
                (
                    parsed_url.scheme,
                    parsed_url.netloc,
                    parsed_url.path,
                    "",  # params
                    "",  # query
                    "",  # fragment
                )
            )

            cleaned_url = normalize_url(cleaned_url)
            path = urlparse(cleaned_url).path
            if any(pattern.fullmatch(path) for pattern in compiled_exclusion_patterns):
                continue
            cleaned_links.add(cleaned_url)
        except Exception as e:
            logger.error(f"Error processing URL {url}: {e}")

    return list(cleaned_links)


def scrape_url(url: str, retries: int = 3, delay: float = 1) -> ScrapedData:
    from app.llm_services import gen_business_description

    jina_token = os.environ.get("JINA_API_KEY")
    if not jina_token:
        raise Exception("JINA API KEY not found in environment variables")
    url = url.strip()
    headers = {
        "Authorization": f"Bearer {jina_token}",
        "X-Retain-Images": "none",
        "X-With-Links-Summary": "true",
        "Accept": "application/json",
    }

    for attempt in range(retries):
        try:
            response = httpx.get(f"https://r.jina.ai/{url}", headers=headers)
            if response.status_code != 200:
                raise Exception(
                    f"Failed to scrape URL: {url}, Status Code: {response.status_code}, Response: {response.text}"
                )
            result = response.json()
            data = result["data"]

            data["links"] = clean_links(data["links"], url)
            data["description"] = gen_business_description(data["content"]).business_desc
            return ScrapedData(**result["data"])

        except Exception as e:
            if attempt < retries - 1:
                print(f"Retrying in {delay} seconds due to error: {e}")
                time.sleep(delay)
            else:
                raise Exception(f"Max retries reached. Last error: {e}")
    raise Exception("Unexpected error: All retries exhausted without returning data.")


def is_url_reachable(url: str) -> bool:
    try:
        response = httpx.get(url)
        status = response.status_code
        if 200 <= status < 400:
            return True
    except Exception as e:
        print(e)
    return False


def remove_image_tags(text):
    # Regular expression pattern to match image tags
    pattern = r"!\[.*?\]\(.*?\)"

    # Remove the image tags
    cleaned_text = re.sub(pattern, "", text)

    # Remove any extra newlines that might be left after removing images
    cleaned_text = re.sub(r"\n{3,}", "\n\n", cleaned_text)

    return cleaned_text.strip()


def scrape_and_save_data(url: str, db: Session):
    data = scrape_url(url)
    add_scraped_data(data, db)
    return data


def add_trailing_slash(url):
    if "?" not in url:
        return url if url.endswith("/") else url + "/"
    return url


def strip_url(url):
    parsed = urlparse(url)
    stripped = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
    return stripped


def get_url_content(url: str, db: Session) -> ScrapedData:
    url = strip_url(url)
    url = add_trailing_slash(url)
    data = get_scraped_data_by_url(url, db)
    if not data:
        return scrape_and_save_data(url, db)
    return data
