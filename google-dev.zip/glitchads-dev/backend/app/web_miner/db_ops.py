from sqlmodel import Session, select

from app.web_miner.models import ScrapedData


def add_scraped_data(data: ScrapedData, db: Session) -> None:
    result = db.exec(select(ScrapedData).where(ScrapedData.url == data.url)).first()
    if result:
        result.content = data.content
        db.add(result)
    else:
        db.add(data)
    db.commit()


def get_scraped_data_by_url(url: str, db: Session) -> ScrapedData | None:
    result = db.exec(select(ScrapedData).where(ScrapedData.url == url))
    return result.first()
