from enum import Enum

from pydantic import BaseModel


class TaskTrackingState(str, Enum):
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskTrackingType(str, Enum):
    AD_GENERATION = "ad_generation"
    SITE_LINK_GENERATION = "site_link_generation"
    TCPA_GENERATION = "tcpa_generation"
    KEYWORDS_GENERATION = "keywords_generation"
    HEADLINE_GENERATION = "headline_generation"
    DESCRIPTIONS_GENERATION = "descriptions_generation"


class TaskTrackingSummary(BaseModel):
    total: int
    in_progress: int
    completed: int
    failed: int


class TaskTrackingResponse(BaseModel):
    ad_generation: TaskTrackingSummary
    site_link_generation: TaskTrackingSummary
    tcpa_generation: TaskTrackingSummary
    keywords_generation: TaskTrackingSummary
    headline_generation: TaskTrackingSummary
    descriptions_generation: TaskTrackingSummary
