from typing import Optional

from sqlmodel import Session, select, func

from app.task_tracking.models import TaskTracking, TaskTrackingData
from app.task_tracking.schemas import TaskTrackingState, TaskTrackingType, TaskTrackingSummary


def create_task_tracking(db: Session, campaign_id: int, task_type: TaskTrackingType) -> TaskTrackingData:
    task = TaskTracking(campaign_id=campaign_id, task_type=task_type)
    db.add(task)
    db.commit()
    db.refresh(task)

    return TaskTrackingData.model_validate(task)


def update_task_tracking(
    db: Session, task_id: int, state: TaskTrackingState, error_message: Optional[str] = None
) -> None:
    statement = select(TaskTracking).where(TaskTracking.id == task_id)
    task = db.exec(statement).first()
    if task:
        task.state = state
        if error_message:
            task.error_message = error_message
        db.commit()
        db.refresh(task)


def get_campaign_task_trackings(db: Session, campaign_id: int, task_type: TaskTrackingType) -> list[TaskTracking]:
    statement = select(TaskTracking).where(TaskTracking.campaign_id == campaign_id, TaskTracking.task_type == task_type)
    tasks = db.exec(statement).all()
    return list(tasks)


def get_campaign_task_tracking_summary(
    db: Session, campaign_id: int, task_type: TaskTrackingType
) -> TaskTrackingSummary:
    tasks = get_campaign_task_trackings(db, campaign_id, task_type)
    return TaskTrackingSummary(
        total=len(tasks),
        in_progress=len([task for task in tasks if task.state == TaskTrackingState.IN_PROGRESS]),
        completed=len([task for task in tasks if task.state == TaskTrackingState.COMPLETED]),
        failed=len([task for task in tasks if task.state == TaskTrackingState.FAILED]),
    )


def get_all_campaign_task_tracking_summary(db: Session, campaign_id: int) -> dict[str, TaskTrackingSummary]:
    summary_dict = {
        task_type.value: TaskTrackingSummary(total=0, in_progress=0, completed=0, failed=0)
        for task_type in TaskTrackingType
    }

    statement = (
        select(TaskTracking.task_type, TaskTracking.state, func.count().label("count"))
        .where(TaskTracking.campaign_id == campaign_id)
        .group_by(TaskTracking.task_type, TaskTracking.state)
    )
    results = db.exec(statement).all()

    for task_type, state, count in results:
        key = task_type.lower()
        summary = summary_dict[key]
        summary.total += count
        if state == TaskTrackingState.IN_PROGRESS:
            summary.in_progress += count
        elif state == TaskTrackingState.COMPLETED:
            summary.completed += count
        elif state == TaskTrackingState.FAILED:
            summary.failed += count

    return summary_dict
