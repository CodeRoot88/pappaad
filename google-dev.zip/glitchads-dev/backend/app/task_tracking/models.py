from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from sqlalchemy.sql import func
from sqlmodel import (
    Field,
    Relationship,
    SQLModel,
)

from app.task_tracking.schemas import TaskTrackingState, TaskTrackingType

if TYPE_CHECKING:
    from app.campaign.models import Campaign


class TaskTrackingBase(SQLModel):
    task_type: TaskTrackingType
    state: TaskTrackingState = Field(default=TaskTrackingState.IN_PROGRESS)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(timezone.utc), nullable=False, sa_column_kwargs={"onupdate": func.now()}
    )
    error_message: str | None = None


# Name this model TaskTracking so we won't confuse it with background tasks in FastAPI
class TaskTracking(TaskTrackingBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: Optional[int] = Field(foreign_key="campaign.id")
    campaign: "Campaign" = Relationship(back_populates="task_trackings")


class TaskTrackingData(TaskTrackingBase):
    id: int
