from typing import Optional

from fastapi import APIRouter, Depends
from sqlmodel import Session

from app.campaign.models import CampaignData
from app.database import get_db_session
from app.endpoint_dependencies import get_user_campaign
from app.task_tracking.db_ops import get_all_campaign_task_tracking_summary, get_campaign_task_tracking_summary
from app.task_tracking.schemas import TaskTrackingResponse, TaskTrackingType

router = APIRouter()


@router.get("/campaigns/{campaign_id}/task-tracking", response_model=TaskTrackingResponse)
def get_campaign_task_tracking(
    task_type: Optional[TaskTrackingType] = None,
    db: Session = Depends(get_db_session),
    campaign: CampaignData = Depends(get_user_campaign),
):
    if task_type:
        summary = get_campaign_task_tracking_summary(db, campaign.id, task_type)
        return TaskTrackingResponse(**{task_type.value: summary})
    else:
        summaries = get_all_campaign_task_tracking_summary(db, campaign.id)
        return TaskTrackingResponse(**summaries)
