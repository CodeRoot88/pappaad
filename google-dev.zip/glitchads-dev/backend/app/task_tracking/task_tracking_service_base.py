import logging
from abc import ABC, abstractmethod
from typing import Generic, Optional, TypeVar

from sqlmodel import Session

from app.database import engine
from app.task_tracking.db_ops import create_task_tracking, update_task_tracking
from app.task_tracking.schemas import TaskTrackingState, TaskTrackingType

logger = logging.getLogger(__name__)

T = TypeVar("T")


class TaskTrackingService(ABC, Generic[T]):
    def __init__(self, db: Session, campaign_id: int):
        self.campaign_id = campaign_id
        self.db = db

    def execute_task_with_tracking(self, task_type: TaskTrackingType) -> T:
        task_tracking = create_task_tracking(db=self.db, campaign_id=self.campaign_id, task_type=task_type)
        logger.info(f"Started task {task_type} for campaign {self.campaign_id} with Task ID {task_tracking.id}")
        try:
            result = self.run_task()
            self.complete_task(task_tracking.id)
            logger.info(f"Completed task {task_type} for Task ID {task_tracking.id}")
            return result
        except Exception as e:
            self.db.rollback()
            try:
                with Session(engine) as new_session:
                    self.fail_task(task_id=task_tracking.id, error_message=str(e), db=new_session)
                    logger.info(f"Marked Task ID {task_tracking.id} as FAILED")
            except Exception as update_error:
                logger.critical(f"Failed to update task tracking after exception: {update_error}")

            logger.error(f"Failed task {task_type} for Task ID {task_tracking.id}: {e}")
            raise

    def complete_task(self, task_id: int) -> None:
        update_task_tracking(self.db, task_id, TaskTrackingState.COMPLETED)

    def fail_task(
        self,
        task_id: int,
        db: Session,
        error_message: Optional[str] = None,
    ) -> None:
        update_task_tracking(db, task_id, TaskTrackingState.FAILED, error_message)

    @abstractmethod
    def run_task(self) -> T:
        """Implement the actual task logic here."""
        pass
