from sqlmodel import Session

from app.campaign.models import CampaignReadWithoutAssociations
from app.headline.db_ops import add_descriptions
from app.llm_services import gen_ad_descriptions
from app.task_tracking.schemas import TaskTrackingType
from app.task_tracking.task_tracking_service_base import TaskTrackingService
from app.web_miner.models import ScrapedData


class DescriptionsCreateService(TaskTrackingService):
    def __init__(
        self,
        campaign: CampaignReadWithoutAssociations,
        db: Session,
        ad_id: int,
        site_data: ScrapedData,
        keyword_texts: list[str],
    ):
        super().__init__(db, campaign.id)
        self.campaign = campaign
        self.ad_id = ad_id
        self.site_data = site_data
        self.keyword_texts = keyword_texts

    def create_descriptions(self) -> None:
        return self.execute_task_with_tracking(task_type=TaskTrackingType.DESCRIPTIONS_GENERATION)

    def run_task(self) -> None:
        return self.generate_descriptions()

    def generate_descriptions(self) -> None:
        descriptions = gen_ad_descriptions(self.site_data.content, self.keyword_texts)
        add_descriptions(ad_id=self.ad_id, texts=descriptions, db=self.db)
