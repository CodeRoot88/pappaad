from sqlmodel import Session

from app.campaign.models import CampaignReadWithoutAssociations
from app.headline.db_ops import add_headline
from app.headline.models import Headline
from app.keyword.models import KeywordReadWithoutAssociatedData
from app.llm_services import gen_ad_keyword_headline
from app.task_tracking.schemas import TaskTrackingType
from app.task_tracking.task_tracking_service_base import TaskTrackingService
from app.web_miner.models import ScrapedData


class HeadlineCreateService(TaskTrackingService[Headline]):
    def __init__(
        self,
        campaign: CampaignReadWithoutAssociations,
        db: Session,
        ad_id: int,
        site_data: ScrapedData,
        keyword: KeywordReadWithoutAssociatedData,
        existing_headline_texts: list[str],
    ):
        super().__init__(db, campaign.id)
        self.campaign = campaign
        self.ad_id = ad_id
        self.site_data = site_data
        self.keyword = keyword
        self.existing_headline_texts = existing_headline_texts

    def create_headline(self) -> Headline:
        return self.execute_task_with_tracking(task_type=TaskTrackingType.HEADLINE_GENERATION)

    def run_task(self) -> Headline:
        return self.generate_headline()

    def generate_headline(self) -> Headline:
        generated_headline = gen_ad_keyword_headline(
            self.site_data.content, self.keyword.text, existing_headlines=self.existing_headline_texts
        )
        return add_headline(ad_id=self.ad_id, text=generated_headline.headline, keyword_id=self.keyword.id, db=self.db)
