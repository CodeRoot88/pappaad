import concurrent.futures

from fastapi import BackgroundTasks
from sqlmodel import Session

from app.campaign.models import CampaignData
from app.ad.models import AdUpdate
from app.headline.db_ops import (
    remove_headline_by_id,
    get_all_descriptions_by_ad_id,
    remove_description_by_id,
)
from app.headline.db_ops import add_headline, add_description, get_all_headlines_by_ad_id
from app.headline.exception.exceptions import HeadlineCreationErrorException

from app.llm_services import gen_ad_descriptions, gen_ad_keyword_headline
from app.user.models import UserAccountData


class HeadlineService:
    def __init__(self, db: Session, user: UserAccountData, bgts: BackgroundTasks, campaign: CampaignData | None = None):
        self.db = db
        self.user = user
        self.bgts = bgts
        self.campaign = campaign

    def generate_headlines_for_ads(self, result: str, keywords: list[str]):
        headlines = []

        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(gen_ad_keyword_headline, result, keyword) for keyword in keywords[:15]]
            failed_tasks = 0
            for future in concurrent.futures.as_completed(futures):
                try:
                    headline = future.result()
                    headlines.append({"keyword": headline.keyword, "headline": headline.headline})
                except Exception:
                    failed_tasks += 1

        return headlines

    def generate_descriptions_for_ads(self, result: str, keywords: list[str]):
        return gen_ad_descriptions(result, keywords[:10])

    def update_headlines(self, ad_id: int, ad_data: AdUpdate, db):
        # Update headlines
        result = get_all_headlines_by_ad_id(ad_id, db)
        current_headlines = result

        # Create a set of headline IDs from the input
        input_headline_ids = {hl.id for hl in ad_data.headlines if hasattr(hl, "id") and hl.id}

        # Update or delete existing headlines
        for current_headline in current_headlines:
            if current_headline.id in input_headline_ids:
                # Update existing headline
                updated_headline = next(hl for hl in ad_data.headlines if hl.id == current_headline.id)
                current_headline.text = updated_headline.text
            else:
                if not current_headline:
                    raise HeadlineCreationErrorException("Headline id does not exist")
                remove_headline_by_id(headline_id=current_headline.id, db=db)

        # Add new headlines
        for headline in ad_data.headlines:
            if not hasattr(headline, "id") or not headline.id:
                add_headline(ad_id=ad_id, text=headline.text, keyword_id=None, db=db)

    def update_descriptions(self, ad_id, ad_data: AdUpdate, db):
        descriptions = get_all_descriptions_by_ad_id(ad_id, db)
        for description in descriptions:
            if not description.id:
                raise HeadlineCreationErrorException("Description id does not exist")
            remove_description_by_id(description.id, db)
        for description in ad_data.descriptions:
            add_description(ad_id, description.text, db)
