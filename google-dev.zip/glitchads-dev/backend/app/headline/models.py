from typing import Optional, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Column, Relationship
from sqlalchemy import Integer, ForeignKey

from pydantic import field_validator

from helper.check_emoji import validate_no_emojis

# from ..ad.models import Ad
if TYPE_CHECKING:
    from ..ad.models import Ad
    from ..keyword.models import Keyword

if TYPE_CHECKING:
    from ..ad.models import Ad


class HeadlineData(SQLModel):
    id: int
    text: str


class HeadlineBase(SQLModel):
    text: str

    @field_validator("text")
    def validate_text_no_emojis(cls, value: str) -> str:
        return validate_no_emojis(value)


class HeadlineCreate(HeadlineBase):
    pass


class HeadlineUpdate(HeadlineBase):
    id: int | None = Field(default=None)


class DescriptionBase(SQLModel):
    text: str

    @field_validator("text")
    def validate_text_no_emojis(cls, value: str) -> str:
        return validate_no_emojis(value)


class Description(DescriptionBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    ad_id: int | None = Field(default=None, sa_column=Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))
    ad: "Ad" = Relationship(back_populates="descriptions")


class DescriptionCreate(DescriptionBase):
    pass


class DescriptionUpdate(DescriptionBase):
    id: int | None = Field(default=None)


class DescriptionData(DescriptionBase):
    id: int


class Headline(HeadlineBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    keyword_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("keyword.id", ondelete="CASCADE"))
    )
    ad_id: int | None = Field(default=None, sa_column=Column(Integer, ForeignKey("ad.id", ondelete="CASCADE")))
    ad: "Ad" = Relationship(back_populates="headlines")
    keyword: Optional["Keyword"] = Relationship(back_populates="headlines")
