from fastapi import Request
from fastapi.responses import JSONResponse

from .exceptions import (
    HeadlineCreationErrorException,
    LLMHeadlineGenerationErrorException,
    LLMDescriptionGenerationErrorException,
)


def register_headline_exception_handlers(app):
    @app.exception_handler(HeadlineCreationErrorException)
    async def headline_creation_error_exception_handler(request: Request, exc: HeadlineCreationErrorException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )

    @app.exception_handler(LLMHeadlineGenerationErrorException)
    async def llm_headline_generation_error_exception_handler(
        request: Request, exc: LLMHeadlineGenerationErrorException
    ):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )

    @app.exception_handler(LLMDescriptionGenerationErrorException)
    async def llm_description_generation_error_exception_handler(
        request: Request, exc: LLMDescriptionGenerationErrorException
    ):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
        )
