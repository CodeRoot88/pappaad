from fastapi import HTTPException, status


class HeadlineCreationErrorException(HTTPException):
    def __init__(self, detail: str):
        self.status_code = status.HTTP_400_BAD_REQUEST
        self.detail = detail


class LLMHeadlineGenerationErrorException(HTTPException):
    def __init__(self, detail: str):
        self.status_code = status.HTTP_400_BAD_REQUEST
        self.detail = detail


class LLMDescriptionGenerationErrorException(HTTPException):
    def __init__(self, detail: str):
        self.status_code = status.HTTP_400_BAD_REQUEST
        self.detail = detail
