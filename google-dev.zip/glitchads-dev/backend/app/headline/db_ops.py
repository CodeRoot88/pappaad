from sqlmodel import Session, select

from app.headline.models import Description, Headline


def add_headline(ad_id: int, text: str, keyword_id: int | None, db: Session) -> Headline:
    headline = Headline(ad_id=ad_id, text=text, keyword_id=keyword_id)
    db.add(headline)
    db.commit()
    db.refresh(headline)
    return headline


def add_description(ad_id: int, text: str, db: Session) -> Description:
    description = Description(ad_id=ad_id, text=text)
    db.add(description)
    db.commit()
    db.refresh(description)
    return description


def add_descriptions(ad_id: int, texts: list[str], db: Session) -> None:
    for text in texts:
        description = Description(ad_id=ad_id, text=text)
        db.add(description)

    db.commit()


def get_all_headlines_by_ad_id(ad_id: int, db: Session) -> list[Headline]:
    statement = select(Headline).where(Headline.ad_id == ad_id)
    headlines = db.exec(statement).all()
    return list(headlines)


def remove_headline_by_id(headline_id: int, db: Session) -> Headline | None:
    headline = db.exec(select(Headline).where(Headline.id == headline_id)).first()
    if not headline:
        return None
    db.delete(headline)
    db.commit()


def get_all_descriptions_by_ad_id(ad_id: int, db: Session) -> list[Description]:
    descriptions = db.exec(select(Description).where(Description.ad_id == ad_id)).all()
    return list(descriptions)


def remove_description_by_id(description_id: int, db: Session) -> None:
    description = db.exec(select(Description).where(Description.id == description_id)).first()
    if not description:
        return None
    db.delete(description)
    db.commit()
