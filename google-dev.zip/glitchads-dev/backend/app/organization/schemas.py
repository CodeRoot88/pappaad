from pydantic import BaseModel
from app.organization.models import Organization
from app.membership.schemas import MembershipRole, MembershipStatus


class OrganizationWithMembership(BaseModel):
    organization: Organization
    role: MembershipRole
    status: MembershipStatus


class OrganizationCreateRequest(BaseModel):
    slug: str
    name: str


class OrganizationUpdateRequest(BaseModel):
    name: str
