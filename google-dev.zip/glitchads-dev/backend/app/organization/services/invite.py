import os

from sqlmodel import Session
from datetime import datetime, timezone
from app.auth.schemas import InviteUserRequest
from app.organization.db_ops import get_organization_by_id
from app.user.db_ops import get_user_account_by_email
from uuid import uuid4
from app.email_services import EmailService
from app.organization.exception.exceptions import AlreadyOrganizationMemberException, OrganizationNotFoundException
from app.membership.db_ops import (
    add_invite_code,
    get_invite_code_by_organization_and_email,
    get_membership,
)
from app.membership.schemas import MembershipStatus
from app.membership.models import InviteCode

FRONTEND_DOMAIN_URL = os.environ.get("FRONTEND_DOMAIN_URL", "http://localhost:5173")


async def send_invitation_to_user(organization_id: int, request: InviteUserRequest, db: Session) -> None:
    organization = get_organization_by_id(organization_id, db)
    if not organization:
        raise OrganizationNotFoundException("Organization Not Found.")

    user = get_user_account_by_email(request.email.lower(), db)

    # Initialize membership with None
    membership = None
    if user:
        membership = get_membership(organization_id=organization.id, user_id=user.id, db=db)

    # raise error if user is already a member of the organization
    if membership and membership.status == MembershipStatus.ACTIVE:
        raise AlreadyOrganizationMemberException("User is already a member of the organization.")

    invite_signup_code = uuid4()

    invite_code = get_invite_code_by_organization_and_email(
        organization_id=organization.id, email=request.email.lower(), db=db
    )

    if not invite_code:
        invite_code = InviteCode(
            code=invite_signup_code, organization_id=organization.id, email=request.email.lower(), role=request.role
        )
        invite_code = add_invite_code(invite_code, db)
    else:
        invite_code.code = invite_signup_code
        invite_code.valid = True
        invite_code.generated_at = datetime.now(timezone.utc)
        invite_code = add_invite_code(invite_code, db)

    url_domain = f"{FRONTEND_DOMAIN_URL}/invite-signup/{invite_signup_code}"
    await EmailService.send_email(
        address=request.email,
        subject="Invitation to join organization",
        message=f"Hello {request.name}, you have been invited to join the organization {organization.name}. Please click the following link to accept the invitation: {url_domain}",
    )
