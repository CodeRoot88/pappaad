from fastapi import Depends
from sqlmodel import Session

from app.database import get_db_session

from app.organization.db_ops import (
    fetch_organization_by_id,
    get_organization_by_id,
    get_organization_by_slug,
    get_organization_with_membership_by_organization_id_and_user_id,
    get_organization_with_users_by_organization_id,
    get_organizations_with_membership_by_user_id,
    remove_organization_db,
)
from app.organization.exception.exceptions import OrganizationNotFoundException

from app.membership.db_ops import add_membership

from app.user.models import UserAccountData
from app.user.schemas import UserAccountWithMembership

from app.organization.models import (
    Organization,
    OrganizationData,
    OrganizationDataWithMembership,
    OrganizationDataWithUsersMembership,
)
from app.organization.db_ops import add_organization
from app.organization.schemas import OrganizationCreateRequest, OrganizationUpdateRequest
from app.membership.models import Membership
from app.membership.schemas import MembershipData, MembershipRole, MembershipStatus


def get_organization_by_slug_or_id(
    organization_slug: str | None = None, organization_id: int | None = None, db: Session = Depends(get_db_session)
) -> OrganizationData:
    organization = None
    if organization_slug:
        organization = get_organization_by_slug(organization_slug, db)
    if not organization and organization_id:
        organization = get_organization_by_id(organization_id, db)
    if not organization:
        raise OrganizationNotFoundException("Organization Not Found")
    return organization


def update_organization(
    organization_id: int, organization_update: OrganizationUpdateRequest, db: Session
) -> OrganizationData:
    organization = fetch_organization_by_id(id=organization_id, db=db)
    if not organization:
        raise OrganizationNotFoundException("Organization Not Found.")
    organization.name = organization_update.name
    return add_organization(organization, db)


def remove_organization(organization_id: int, db: Session):
    organization = fetch_organization_by_id(organization_id, db)
    if not organization:
        raise OrganizationNotFoundException("Organization Not Found.")
    return remove_organization_db(organization, db=db)


class OrganizationService:
    def __init__(self, user: UserAccountData, db: Session):
        self.db = db
        self.user = user

    def create_organization_and_membership(self, organization_create: OrganizationCreateRequest) -> OrganizationData:
        organization = Organization(name=organization_create.name, slug=organization_create.slug)
        created_organization = add_organization(organization=organization, db=self.db)

        membership = Membership(
            user_id=self.user.id,
            organization_id=created_organization.id,
            role=MembershipRole.OWNER,
            status=MembershipStatus.ACTIVE,
        )
        add_membership(membership=membership, db=self.db)
        return created_organization

    def get_user_organizations(self) -> list[OrganizationDataWithMembership]:
        return get_organizations_with_membership_by_user_id(user_id=self.user.id, db=self.db)

    def get_organization_with_users_with_membership_by_slug_or_id(
        self,
        organization_slug: str | None = None,
        organization_id: int | None = None,
    ) -> OrganizationDataWithUsersMembership:
        organization_data = get_organization_by_slug_or_id(organization_slug, organization_id, self.db)
        if not organization_data:
            raise OrganizationNotFoundException("Organization Not Found.")

        organization_with_membership = get_organization_with_membership_by_organization_id_and_user_id(
            user_id=self.user.id, organization_id=organization_data.id, db=self.db
        )
        if not organization_with_membership:
            raise OrganizationNotFoundException("Organization Does not have any members.")

        organization, membership = organization_with_membership

        users_result = get_organization_with_users_by_organization_id(organization_data.id, self.db)

        users = [
            UserAccountWithMembership(
                name=user.name,
                email=user.email,
                role=user.role,
                membership=MembershipData(role=membership.role, status=membership.status),
            )
            for user, membership in users_result
        ]

        organization_users_with_membership = OrganizationDataWithUsersMembership(
            id=organization.id,
            slug=organization.slug,
            name=organization.name,
            membership=MembershipData(role=membership.role, status=membership.status),
            users=users,
        )

        return organization_users_with_membership
