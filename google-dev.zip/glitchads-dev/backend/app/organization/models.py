from sqlmodel import Field, Relationship, SQLModel
from typing import TYPE_CHECKING, Optional

from datetime import datetime, timezone

from app.membership.models import Membership
from app.membership.schemas import MembershipData
from app.user.schemas import UserAccountWithMembership

if TYPE_CHECKING:
    from app.membership.models import Membership
    from app.user.models import UserAccount


class OrganizationBase(SQLModel):
    slug: str = Field(nullable=False, unique=True, index=True)
    name: str = Field(nullable=False, unique=True, index=True)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Organization(OrganizationBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True, index=True)
    users: list["UserAccount"] = Relationship(back_populates="organizations", link_model=Membership)


class OrganizationData(OrganizationBase):
    id: int


class OrganizationDataWithMembership(OrganizationData):
    membership: MembershipData


class OrganizationDataWithUsersMembership(OrganizationDataWithMembership):
    users: list["UserAccountWithMembership"]
