from typing import Sequence
from app.membership.models import Membership
from app.membership.schemas import MembershipData
from app.user.models import UserAccount
from sqlmodel import Session, select

from app.organization.models import Organization, OrganizationData, OrganizationDataWithMembership


def add_organization(organization: Organization, db: Session) -> OrganizationData:
    db.add(organization)
    db.commit()
    db.refresh(organization)
    db.commit()

    return OrganizationData.model_validate(organization)


def get_organization_by_slug(slug: str, db: Session) -> OrganizationData | None:
    statement = select(Organization).where(Organization.slug == slug)
    organization = db.exec(statement).first()
    if organization:
        return OrganizationData.model_validate(organization)
    return None


def get_organization_by_id(id: int, db: Session) -> OrganizationData | None:
    statement = select(Organization).where(Organization.id == id)
    organization = db.exec(statement).first()
    if organization:
        return OrganizationData.model_validate(organization)
    return None


def fetch_organization_by_id(id: int, db: Session) -> Organization | None:
    statement = select(Organization).where(Organization.id == id)
    return db.exec(statement).first()


def get_organizations_with_membership_by_user_id(user_id: int, db: Session) -> list[OrganizationDataWithMembership]:
    statement = (
        select(
            Organization,
            Membership,
        )
        .join(Membership)
        .join(UserAccount)
        .where(UserAccount.id == user_id)
    )
    results = db.exec(statement).all()

    organizations = [
        OrganizationDataWithMembership(
            id=org.id,
            slug=org.slug,
            name=org.name,
            membership=MembershipData(role=membership.role, status=membership.status),
        )
        for org, membership in results
    ]

    return organizations


def get_organization_with_membership_by_organization_id_and_user_id(
    user_id: int, organization_id: int, db: Session
) -> tuple[Organization, Membership] | None:
    statement = (
        select(Organization, Membership)
        .join(Membership)
        .join(UserAccount)
        .where(Organization.id == organization_id)
        .where(UserAccount.id == user_id)
    )
    return db.exec(statement).first()


def get_organization_with_users_by_organization_id(
    organization_id: int, db: Session
) -> Sequence[tuple[UserAccount, Membership]]:
    users_statement = (
        select(UserAccount, Membership).join(Membership).join(Organization).where(Organization.id == organization_id)
    )
    return db.exec(users_statement).all()


def remove_organization_db(organization: Organization, db: Session) -> None:
    db.delete(organization)
    db.commit()
