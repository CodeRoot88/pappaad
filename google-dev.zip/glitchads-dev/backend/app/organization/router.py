from app.organization.models import (
    Organization,
    OrganizationData,
    OrganizationDataWithMembership,
    OrganizationDataWithUsersMembership,
)
from app.organization.schemas import OrganizationCreateRequest, OrganizationUpdateRequest
from app.organization.services.organization import OrganizationService, remove_organization, update_organization
from app.user.models import UserAccountData
from fastapi import APIRouter, Depends, status
from sqlmodel import Session

from app.database import get_db_session
from app.endpoint_dependencies import check_organization_member, check_organization_owner, get_current_user

from app.membership.models import Membership
from app.auth.schemas import InviteUserRequest
from app.organization.services.invite import send_invitation_to_user

router = APIRouter()


@router.post("/organizations/{organization_id}/invite", status_code=status.HTTP_201_CREATED)
async def invite_user_to_organization(
    organization_id: int,
    request: InviteUserRequest,
    db: Session = Depends(get_db_session),
    owner: "Membership" = Depends(check_organization_owner),
):
    return await send_invitation_to_user(organization_id=organization_id, request=request, db=db)


@router.get("/organizations", response_model=list[OrganizationDataWithMembership])
def get_organizations(
    current_user: UserAccountData = Depends(get_current_user),
    db: Session = Depends(get_db_session),
):
    return OrganizationService(user=current_user, db=db).get_user_organizations()


@router.post("/organizations", response_model=Organization)
def create_organization(
    organization_create: OrganizationCreateRequest,
    current_user: UserAccountData = Depends(get_current_user),
    db: Session = Depends(get_db_session),
):
    return OrganizationService(user=current_user, db=db).create_organization_and_membership(organization_create)


@router.get("/organizations/{organization_slug}", response_model=OrganizationDataWithUsersMembership)
def get_organization_by_slug(
    organization_slug: str,
    current_user: UserAccountData = Depends(get_current_user),
    db: Session = Depends(get_db_session),
    member=Depends(check_organization_member),
):
    return OrganizationService(user=current_user, db=db).get_organization_with_users_with_membership_by_slug_or_id(
        organization_slug=organization_slug
    )


@router.put("/organizations/{organization_id}", response_model=OrganizationData)
def update_organization_by_id(
    organization_id: int,
    organization_update: OrganizationUpdateRequest,
    db: Session = Depends(get_db_session),
    owner: "Membership" = Depends(check_organization_owner),
):
    return update_organization(organization_id=organization_id, organization_update=organization_update, db=db)


@router.delete("/organizations/{organization_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_organization_by_id(
    organization_id: int,
    current_user: UserAccountData = Depends(get_current_user),
    db: Session = Depends(get_db_session),
    owner=Depends(check_organization_owner),
):
    return remove_organization(organization_id=organization_id, db=db)
