from fastapi import Request, status
from fastapi.responses import JSONResponse

from .exceptions import (
    OrganizationPermissionException,
    OrganizationNotFoundException,
    AlreadyOrganizationMemberException,
)


def register_organization_exception_handlers(app):  # type: ignore
    @app.exception_handler(OrganizationPermissionException)  # type: ignore
    async def organization_permission_error_exception_handler(request: Request, exc: OrganizationPermissionException):
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={"detail": exc.detail},
        )

    @app.exception_handler(OrganizationNotFoundException)  # type: ignore
    async def organization_not_found_exception_handler(request: Request, exc: OrganizationNotFoundException):
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": exc.detail},
        )

    @app.exception_handler(AlreadyOrganizationMemberException)  # type: ignore
    async def handle_organization_membership_already_exists_exception(
        request: Request, exc: AlreadyOrganizationMemberException
    ):
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": exc.detail},
        )
