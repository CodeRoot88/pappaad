class OrganizationPermissionException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class OrganizationNotFoundException(Exception):
    def __init__(self, detail: str):
        self.detail = detail


class AlreadyOrganizationMemberException(Exception):
    def __init__(self, detail: str):
        self.detail = detail
