import logging

import instructor
from dotenv import load_dotenv
from google.ads.googleads.client import GoogleAdsClient
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.v18.enums.types.keyword_plan_network import KeywordPlanNetworkEnum
from openai import OpenAI
from pydantic import BaseModel
from sqlmodel import Session, select

from app.keyword.db_ops import add_keyword
from app.ad.models import Ad, AdRecommendation
from app.campaign.models import Campaign, CampaignState
from app.common_state_enums import RecommendationType
from app.web_miner.scraper import scrape_url
from app.recommendations.new_keywords.new_keywords_recommendation_report import GoogleAdsReportIntegration
from app.recommendations.recommendation_utils import (
    create_ad_recommendation,
    create_campaign_recommendation,
    create_keyword_recommendation,
)

from ...google_client_setup import initialize_googleads_client

_ = load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

OPENAI_CLIENT = instructor.from_openai(OpenAI())


class BusinessDescription(BaseModel):
    content: str


def generate_business_description(content: str) -> BusinessDescription:
    prompt = (
        f"Based on the following website content, provide a concise business description in 2-3 sentences:\n\n{content}"
    )
    result = OPENAI_CLIENT.chat.completions.create(
        model="gpt-4o-mini",
        response_model=BusinessDescription,
        messages=[
            {
                "role": "system",
                "content": "You are a helpful assistant that generates concise business descriptions based on website content.",
            },
            {"role": "user", "content": prompt},
        ],
    )
    return result


class KeywordMetrics(BaseModel):
    avg_monthly_searches: int
    competition_index: float
    low_top_of_page_bid: float
    high_top_of_page_bid: float


def get_keyword_metrics(client, customer_id, keywords) -> dict[str, KeywordMetrics]:
    keyword_plan_idea_service = client.get_service("KeywordPlanIdeaService")
    request = client.get_type("GenerateKeywordHistoricalMetricsRequest")
    request.customer_id = customer_id
    request.keywords.extend(keywords)
    request.geo_target_constants.append(client.get_service("GeoTargetConstantService").geo_target_constant_path(2826))
    request.keyword_plan_network = client.enums.KeywordPlanNetworkEnum.GOOGLE_SEARCH
    request.language = "languageConstants/1000"  # English
    response = keyword_plan_idea_service.generate_keyword_historical_metrics(request=request)
    keyword_metrics = {}

    for result in response.results:
        if not hasattr(result, "keyword_metrics"):
            continue
        metrics = result.keyword_metrics
        if (
            metrics
            and hasattr(metrics, "avg_monthly_searches")
            and hasattr(metrics, "competition_index")
            and hasattr(metrics, "low_top_of_page_bid")
            and hasattr(metrics, "high_top_of_page_bid")
        ):
            keyword_metrics[result.text] = KeywordMetrics(
                **{
                    "avg_monthly_searches": metrics.avg_monthly_searches,
                    "competition_index": metrics.competition_index,
                    "low_top_of_page_bid": metrics.low_top_of_page_bid_micros / 1_000_000,
                    "high_top_of_page_bid": metrics.high_top_of_page_bid_micros / 1_000_000,
                }
            )

    return keyword_metrics


def calculate_keyword_score(metrics: KeywordMetrics):
    avg_monthly_searches = metrics.avg_monthly_searches
    competition_index = metrics.competition_index
    avg_bid = (metrics.low_top_of_page_bid + metrics.high_top_of_page_bid) / 2

    search_score = min(avg_monthly_searches / 1000000, 1)
    competition_score = 1 - (competition_index / 100)
    bid_score = min(avg_bid / 10, 1)

    score = (search_score * 0.4) + (competition_score * 0.4) + (bid_score * 0.2)
    return score


class KeywordData(BaseModel):
    avg_monthly_searches: int
    competition: float
    keyword: str


def generate_keyword_ideas(
    client: GoogleAdsClient, customer_id, page_url, keyword_texts=None, language_id="1000"
) -> list[KeywordData]:
    if not (keyword_texts or page_url):
        raise ValueError("At least one of keywords or page URL is required, but neither was specified.")

    keyword_plan_idea_service = client.get_service("KeywordPlanIdeaService")
    google_ads_service = client.get_service("GoogleAdsService")
    keyword_plan_network = KeywordPlanNetworkEnum.KeywordPlanNetwork.GOOGLE_SEARCH
    language_rn = google_ads_service.language_constant_path(language_id)
    request = client.get_type("GenerateKeywordIdeasRequest")

    request = {
        "customer_id": customer_id,
        "language": language_rn,
        "include_adult_keywords": False,
        "keyword_plan_network": keyword_plan_network,
    }

    if keyword_texts and page_url:
        request["keyword_and_url_seed"] = {
            "url": page_url,
            "keywords": keyword_texts,
        }
    elif keyword_texts:
        request["keyword_seed"] = {
            "keywords": keyword_texts,
        }
    elif page_url:
        request["url_seed"] = {
            "url": page_url,
        }

    keyword_ideas = keyword_plan_idea_service.generate_keyword_ideas(request=request)

    ideas = []
    for idea in keyword_ideas:
        competition_value = idea.keyword_idea_metrics.competition
        ideas.append(
            KeywordData(
                **{
                    "keyword": idea.text,
                    "competition": competition_value,
                    "avg_monthly_searches": idea.keyword_idea_metrics.avg_monthly_searches
                    if hasattr(idea.keyword_idea_metrics, "avg_monthly_searches")
                    else 0,
                }
            )
        )
    return ideas


class GPTKeywords(BaseModel):
    keywords: list[str]


def generate_gpt4_keywords(business_description, scraped_content, n_suggestions=20) -> list[str]:
    prompt = f"""
    Generate {n_suggestions} relevant keywords related to the following business description and website content:
    Business Description: {business_description}
    Website Content:
    {scraped_content[:1000]}  # Limiting to first 1000 characters to avoid token limits
    Provide only the keywords, separated by commas."""

    try:
        result = OPENAI_CLIENT.chat.completions.create(
            model="gpt-4o-mini",
            response_model=GPTKeywords,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant that generates relevant keywords for digital marketing campaigns based on business descriptions and website content.",
                },
                {"role": "user", "content": prompt},
            ],
        )
        return result.keywords
    except Exception:
        return []


class ScoredKeyword(BaseModel):
    keyword: str
    score: float
    metrics: KeywordMetrics


def get_combined_keywords(
    client: GoogleAdsClient, customer_id: str, url: str, url_content: str, business_description: str
) -> list[ScoredKeyword]:
    gpt4_keywords = generate_gpt4_keywords(business_description, url_content)

    google_ads_keywords = generate_keyword_ideas(client, customer_id, url)

    all_keywords = [kw.keyword for kw in google_ads_keywords] + gpt4_keywords
    keyword_metrics = get_keyword_metrics(client, customer_id, all_keywords)

    scored_keywords: list[ScoredKeyword] = []
    for keyword in all_keywords:
        if keyword in keyword_metrics:
            score = calculate_keyword_score(keyword_metrics[keyword])
            if not score:
                score = 0.1
        else:
            score = 0.1
        scored_keywords.append(
            ScoredKeyword(
                **{
                    "keyword": keyword,
                    "score": score,
                    "metrics": keyword_metrics.get(
                        keyword,
                        KeywordMetrics(
                            avg_monthly_searches=0, competition_index=0, low_top_of_page_bid=0, high_top_of_page_bid=0
                        ),
                    ),
                }
            )
        )

    sorted_keywords = sorted(scored_keywords, key=lambda x: x.score, reverse=True)
    return sorted_keywords[:50]


def get_keyword_historical_metrics(client: GoogleAdsClient, customer_id: str, keywords: list[str]):
    keyword_plan_idea_service = client.get_service("KeywordPlanIdeaService")
    request = client.get_type("GenerateKeywordHistoricalMetricsRequest")
    request.customer_id = customer_id
    request.keywords.extend(keywords)
    request.geo_target_constants.append(
        client.get_service("GeoTargetConstantService").geo_target_constant_path(2826)  # UK
    )
    request.keyword_plan_network = client.enums.KeywordPlanNetworkEnum.GOOGLE_SEARCH
    request.language = "languageConstants/1000"  # English

    try:
        response = keyword_plan_idea_service.generate_keyword_historical_metrics(request=request)
        keyword_metrics = {}
        for result in response.results:
            if not hasattr(result, "keyword_metrics"):
                continue
            metrics = result.keyword_metrics
            if (
                metrics
                and hasattr(metrics, "avg_monthly_searches")
                and hasattr(metrics, "competition_index")
                and hasattr(metrics, "low_top_of_page_bid")
                and hasattr(metrics, "high_top_of_page_bid")
            ):
                keyword_metrics[result.text] = {
                    "avg_monthly_searches": metrics.avg_monthly_searches,
                    "competition_index": metrics.competition_index,
                    "low_top_of_page_bid": metrics.low_top_of_page_bid_micros / 1_000_000,
                    "high_top_of_page_bid": metrics.high_top_of_page_bid_micros / 1_000_000,
                }
        return keyword_metrics
    except GoogleAdsException as ex:
        print(f"Request failed with status: {ex.error.code().name} and message: {ex.error}")
        return {}


def gen_new_keywords_for_ad(
    client: GoogleAdsClient,
    googleads_account_id: str,
    url: str,
    content: str,
    business_desc: str,
    total_number: int = 10,
) -> list[str]:
    combined_keywords = get_combined_keywords(
        customer_id=googleads_account_id,
        url=url,
        url_content=content,
        client=client,
        business_description=business_desc,
    )
    report_integration = GoogleAdsReportIntegration(client, googleads_account_id)
    keyword_report = report_integration.keyword_performance_report()
    report_dict = {item["keyword"]: item for item in keyword_report}

    # Get historical metrics for keywords in the report
    historical_metrics = get_keyword_historical_metrics(
        client, googleads_account_id, [item["keyword"] for item in keyword_report]
    )

    # Refine keywords based on report data and historical metrics
    refined_keywords = []
    for keyword in combined_keywords:
        keyword_text = keyword.keyword
        if keyword_text in report_dict:
            report = report_dict[keyword_text]
            metrics = {
                "keyword": keyword_text,
                "avg_monthly_searches": report.get("average_monthly_searches"),
                "competition_index": report.get("competition"),
            }
            # Fill in missing metrics with historical data
            if keyword_text in historical_metrics:
                hist_metrics = historical_metrics[keyword_text]
                if metrics["avg_monthly_searches"] is None:
                    metrics["avg_monthly_searches"] = hist_metrics["avg_monthly_searches"]
                if metrics["competition_index"] is None:
                    metrics["competition_index"] = hist_metrics["competition_index"]
                metrics["low_top_of_page_bid"] = hist_metrics["low_top_of_page_bid"]
                metrics["high_top_of_page_bid"] = hist_metrics["high_top_of_page_bid"]

            # If we have all necessary metrics calculate the score
            if all(
                metrics.get(key) is not None
                for key in ["avg_monthly_searches", "competition_index", "low_top_of_page_bid", "high_top_of_page_bid"]
            ):
                score = calculate_keyword_score(metrics)
                refined_keywords.append({"keyword": keyword_text, "score": score})
        else:
            # For keywords not in the report we use the original score from Keywords.py
            refined_keywords.append({"keyword": keyword_text, "score": keyword.score})

    # Sort refined keywords by score
    sorted_keywords = sorted(refined_keywords, key=lambda x: x["score"], reverse=True)

    new_keywords = [keyword["keyword"] for keyword in sorted_keywords[:total_number]]
    return new_keywords


def gen_ad_new_keywords_recommendation(
    googleads_account_id: str, ad: Ad, client: GoogleAdsClient, db: Session
) -> tuple[AdRecommendation | None, list[str]]:
    if not ad.id:
        logger.error("Ad has no ID, skipping processing")
        return None, []
    try:
        content = scrape_url(ad.url)
    except Exception as e:
        logger.error(f"Failed to scrape content from URL {ad.url}: {e}")
        return None, []

    business_desc = generate_business_description(content).content

    new_keywords = gen_new_keywords_for_ad(
        client=client,
        googleads_account_id=googleads_account_id,
        url=ad.url,
        content=content,
        business_desc=business_desc,
        num=10,
    )
    ad_rec = create_ad_recommendation(
        db, ad.id, f'New keywords recommendation: {", ".join(new_keywords)}', RecommendationType.NEW_KEYWORD
    )
    keyword_recommendations = []
    for keyword in new_keywords:
        new_keyword = add_keyword(ad.id, keyword, db)
        keyword_rec = create_keyword_recommendation(db, new_keyword, "", RecommendationType.NEW_KEYWORD)
        keyword_recommendations.append(keyword_rec)

    for kw_rec in keyword_recommendations:
        kw_rec.ad_recommendation_id = ad_rec.id

    db.commit()
    return ad_rec, new_keywords


def gen_campaign_new_keywords_recommendation(db: Session, campaign: Campaign):
    if not campaign.id:
        logger.error(f"Campaign {campaign.id} has no ID, skipping processing")
        return

    user = campaign.user_account

    if not user:
        raise ValueError("User dose not exist.")
    if not campaign.googleads_account:
        raise ValueError("Ads customer does not exist.")
    client = initialize_googleads_client(user.google_refresh_token)

    if not campaign.googleads_account.googleads_account_id:
        raise ValueError("Google Ads account does not exist.")

    googleads_account_id = campaign.googleads_account.googleads_account_id
    ad_recommendations = []
    new_keywords = []
    campagin_ads = campaign.ads
    for ad in campagin_ads:
        ad_rec, new_keywords = gen_ad_new_keywords_recommendation(
            googleads_account_id=googleads_account_id, ad=ad, client=client, db=db
        )
        ad_recommendations.append(ad_rec)
        new_keywords.extend(new_keywords)
    campagin_rec = create_campaign_recommendation(
        db, campaign.id, f'New keywords recommendation: {", ".join(new_keywords)}', RecommendationType.NEW_KEYWORD
    )
    for ad_rec in ad_recommendations:
        if ad_rec and campagin_rec.id:
            ad_rec.campaign_recommendation_id = campagin_rec.id
            db.add(ad_rec)
    db.commit()


def generate_new_keywords_recommendation(db: Session):
    campaigns = db.exec(select(Campaign).where(Campaign.state != CampaignState.DRAFT)).all()
    for campaign in campaigns:
        gen_campaign_new_keywords_recommendation(db, campaign)
