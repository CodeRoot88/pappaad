import pandas as pd
from app.llm_services import get_theme_representation, evaluate_keyword_fitness


# Mock implementations - replace with your actual logic
def evaluate_theme(keywords: list[str], contextual_info: str = "") -> dict:
    """Produce a theme representation from a list of keywords."""
    theme = get_theme_representation(contextual_info, keywords)
    return {"theme_representation": theme}


def get_fitness_score_to_theme(keyword: str, theme: dict, training_keywords: list[str]) -> float:
    """Compute how well 'keyword' fits 'theme'."""
    return evaluate_keyword_fitness(
        candidate_keyword=keyword,
        training_keywords=training_keywords,
        theme_representation=theme["theme_representation"],
    )


def iterative_convergence(
    initial_keywords,
    candidate_keywords,
    contextual_info: str = "",
    top_k=10,
    max_iterations=10,
    convergence_threshold=0.95,
):
    """
    Iteratively refine a set of keywords to converge on a stable theme.

    Parameters:
    - initial_keywords (list[str]): The starting set of keywords (e.g., 10 existing keywords).
    - candidate_keywords (list[str]): The pool of candidate keywords (e.g., 100 candidates).
    - contextual_info (str): Additional contextual information to use for theme evaluation.
    - top_k (int): How many top keywords to carry forward each iteration.
    - max_iterations (int): Maximum number of iterations to run.
    - convergence_threshold (float): Ratio of overlap needed to consider we have converged
      (e.g., if 95% of top keywords are the same as the previous iteration, stop).

    Returns:
    - final_keywords (list[str]): The converged list of top_k keywords.
    - final_theme (dict): The theme derived from these final keywords.
    """

    current_keywords = initial_keywords.copy()
    previous_top_keywords = set(current_keywords)

    for iteration in range(1, max_iterations + 1):
        # 1. Evaluate current theme from current top keywords
        theme = evaluate_theme(current_keywords, contextual_info)

        # 2. Compute fitness for all keywords (existing + candidates)
        all_keywords = current_keywords + candidate_keywords
        scores = []
        for kw in all_keywords:
            score = get_fitness_score_to_theme(kw, theme, current_keywords)
            scores.append({"Search keyword": kw, "Fitness to Theme": score})

        df = pd.DataFrame(scores)
        df = df.sort_values("Fitness to Theme", ascending=False).reset_index(drop=True)

        # 3. Select top_k keywords to represent theme in the next iteration
        new_top_keywords = df["Search keyword"].head(top_k).tolist()

        # Check convergence: what fraction of these top_k are the same as the last iteration?
        overlap = len(set(new_top_keywords) & previous_top_keywords) / top_k

        print(f"Iteration {iteration}: top keywords = {new_top_keywords}, overlap = {overlap:.2f}")

        if overlap >= convergence_threshold:
            # We consider this 'converged' if the new set is mostly the same as the old set
            return new_top_keywords, theme

        # Update for next iteration
        current_keywords = new_top_keywords
        previous_top_keywords = set(new_top_keywords)

    # If we reach max_iterations without hitting the threshold, return whatever we have
    return current_keywords, evaluate_theme(current_keywords)
