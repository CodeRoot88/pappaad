import logging

import instructor
from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel
from sqlmodel import Session, select

from app.keyword.db_ops import add_keyword
from app.ad.models import Ad, AdRecommendation
from app.campaign.models import Campaign
from app.common_state_enums import RecommendationType
from app.web_miner.scraper import scrape_url
from app.recommendations.recommendation_utils import (
    create_ad_recommendation,
    create_campaign_recommendation,
    create_keyword_recommendation,
)

_ = load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

OPENAI_CLIENT = instructor.from_openai(OpenAI())


class BusinessDescription(BaseModel):
    content: str


def generate_business_description(content: str) -> BusinessDescription:
    prompt = (
        f"Based on the following website content, provide a concise business description in 2-3 sentences:\n\n{content}"
    )
    result = OPENAI_CLIENT.chat.completions.create(
        model="gpt-4o-mini",
        response_model=BusinessDescription,
        messages=[
            {
                "role": "system",
                "content": "You are a helpful assistant that generates concise business descriptions based on website content.",
            },
            {"role": "user", "content": prompt},
        ],
    )
    return result


class GPTKeywords(BaseModel):
    keywords: list[str]


def generate_gpt4_keywords(business_description, scraped_content, n_suggestions=20) -> list[str]:
    prompt = f"""
    Generate {n_suggestions} relevant keywords related to the following business description and website content:
    Business Description: {business_description}
    Website Content:
    {scraped_content[:1000]}  # Limiting to first 1000 characters to avoid token limits
    Provide only the keywords, separated by commas."""

    try:
        result = OPENAI_CLIENT.chat.completions.create(
            model="gpt-4o-mini",
            response_model=GPTKeywords,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant that generates relevant keywords for digital marketing campaigns based on business descriptions and website content.",
                },
                {"role": "user", "content": prompt},
            ],
        )
        return result.keywords
    except Exception:
        return []


def gen_mock_ad_new_keywords_recommendation(
    db: Session, ad: Ad, keywords_per_ad: int
) -> tuple[AdRecommendation | None, list[str]]:
    if not ad.id:
        logger.error("Ad has no ID, skipping processing")
        return None, []
    try:
        content = scrape_url(ad.url)
    except Exception as e:
        logger.error(f"Failed to scrape content from URL {ad.url}: {e}")
        return None, []

    business_description = generate_business_description(content).content
    keywords = generate_gpt4_keywords(business_description, content, keywords_per_ad)
    ad_new_keywords = []
    keyword_recommendations = []

    for keyword in keywords:
        new_keyword = add_keyword(ad.id, keyword, db)
        kw_rec = create_keyword_recommendation(db, new_keyword, "", RecommendationType.NEW_KEYWORD)
        ad_new_keywords.append(keyword)
        keyword_recommendations.append(kw_rec)

    ad_rec = create_ad_recommendation(
        db, ad.id, f'New keywords recommendation: {", ".join(keywords)}', RecommendationType.NEW_KEYWORD
    )
    for kw_rec in keyword_recommendations:
        kw_rec.ad_recommendation_id = ad_rec.id

    db.commit()
    return ad_rec, keywords


def gen_mock_campaign_new_keywords_recommendation(
    db: Session, campaign: Campaign, ads_per_campaign: int, keywords_per_ad: int
):
    if not campaign.id:
        logger.error(f"Campaign {campaign.id} has no ID, skipping processing")
        return

    ad_recommendations = []
    new_keywords = []
    campagin_ads = campaign.ads
    for ad in campagin_ads[:ads_per_campaign]:
        ad_rec, new_keywords = gen_mock_ad_new_keywords_recommendation(db, ad, keywords_per_ad)
        if ad_rec:
            ad_recommendations.append(ad_rec)
        new_keywords.extend(new_keywords)
    campagin_rec = create_campaign_recommendation(
        db, campaign.id, f'New keywords recommendation: {", ".join(new_keywords)}', RecommendationType.NEW_KEYWORD
    )
    for ad_rec in ad_recommendations:
        ad_rec.campaign_recommendation_id = campagin_rec.id
        db.add(ad_rec)
    db.commit()


def generate_mock_new_keywords_recommendation(
    db: Session, num_campaigns_to_process: int = 5, ads_per_campaign: int = 2, keywords_per_ad: int = 3
):
    campaigns = db.exec(select(Campaign).limit(num_campaigns_to_process)).all()
    for campaign in campaigns:
        gen_mock_campaign_new_keywords_recommendation(db, campaign, ads_per_campaign, keywords_per_ad)
    db.commit()
