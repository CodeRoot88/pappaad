""" "
This file retrives the keyword performance data (impressions, clicks, conversions, cost) for
existing keywords in the account.

"""

from datetime import datetime, timedelta


class GoogleAdsReportIntegration:
    def __init__(self, client, google_ads_account_id, campaign_id=None):
        self.client = client
        self.google_ads_account_id = google_ads_account_id
        self.campaign_id = campaign_id

    def performance_report(self):
        """Fetches performance report for the last month."""
        client = self.client
        customer_id = self.google_ads_account_id
        campaign_id = self.campaign_id

        # Define the GAQL query
        if not campaign_id:
            query = f"""
            SELECT
                metrics.clicks,
                metrics.impressions,
                metrics.conversions,
                metrics.cost_micros,
                segments.date
            FROM
                campaign
            WHERE
                segments.date BETWEEN '{(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")}'
                AND '{datetime.now().strftime("%Y-%m-%d")}'
            """
        else:
            query = f"""
            SELECT
                metrics.clicks,
                metrics.impressions,
                metrics.conversions,
                metrics.cost_micros,
                segments.date
            FROM
                campaign
            WHERE
                segments.date BETWEEN '{(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")}'
                AND '{datetime.now().strftime("%Y-%m-%d")}'
                AND campaign.id = {campaign_id}
            """

        # Execute the query
        googleads_service = client.get_service("GoogleAdsService")
        response = googleads_service.search_stream(query=query, customer_id=customer_id)
        # Process the response
        results = [["date", "clicks", "impressions", "conversions", "cost_per_click", "cost"]]
        for batch in response:
            for row in batch.results:
                clicks = row.metrics.clicks
                impressions = row.metrics.impressions
                conversions = row.metrics.conversions
                cost = row.metrics.cost_micros / 1e6  # Convert from micros to units
                cost_per_click = cost / clicks if clicks > 0 else 0
                date = row.segments.date
                results.append((date, clicks, impressions, conversions, cost_per_click, cost))

        results = "\n".join([",".join(map(str, row)) for row in results])

        return results

    def keyword_performance_report(self):
        client = self.client
        customer_id = self.google_ads_account_id
        return get_keyword_performance_report(client, customer_id)

    def get_top_performing_url(self):
        client = self.client
        customer_id = self.google_ads_account_id

        ga_service = client.get_service("GoogleAdsService")

        query = """
        SELECT
        ad_group_ad.final_urls,
        metrics.clicks,
        metrics.conversions,
        metrics.cost_micros
        FROM
        ad_group_ad
        WHERE
        segments.date DURING LAST_30_DAYS
        ORDER BY
        metrics.conversions DESC
        LIMIT 1
        """

        response = ga_service.search_stream(customer_id=customer_id, query=query)

        for batch in response:
            for row in batch.results:
                return row.ad_group_ad.final_urls[0].url


def get_keyword_performance_report(client, customer_id):
    ga_service = client.get_service("GoogleAdsService")
    query = """
    SELECT
        ad_group_criterion.criterion_id,
        ad_group_criterion.keyword.text,
        metrics.impressions,
        metrics.clicks,
        metrics.cost_micros,
        metrics.conversions
    FROM keyword_view
    WHERE segments.date DURING LAST_30_DAYS
    ORDER BY metrics.impressions DESC
    LIMIT 1000
    """

    response = ga_service.search_stream(customer_id=customer_id, query=query)

    keyword_report = []
    for batch in response:
        for row in batch.results:
            keyword_report.append(
                {
                    "keyword": row.ad_group_criterion.keyword.text,
                    "impressions": row.metrics.impressions,
                    "clicks": row.metrics.clicks,
                    "cost": row.metrics.cost_micros / 1000000,
                    "conversions": row.metrics.conversions,
                }
            )

    return keyword_report
