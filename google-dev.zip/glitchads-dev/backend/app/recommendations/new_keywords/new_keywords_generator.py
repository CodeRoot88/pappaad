from app.recommendations.recommendation_utils import RecommendationGenerator

from app.recommendations.new_keywords.generate_new_keywords_recommendation import (
    generate_new_keywords_recommendation,
)
from app.recommendations.new_keywords.generate_mock_new_keywords_recommendation import (
    generate_mock_new_keywords_recommendation,
)


class NewKeywordsRecommendation(RecommendationGenerator):
    def generate(self, **kwargs):
        env = self.env

        if env in ["prod", "staging"]:
            generate_new_keywords_recommendation(self.db)
        else:
            generate_mock_new_keywords_recommendation(self.db, **kwargs)
