# get last 4 weeks keywords
# determine if conversions were high and cost per conversion was low
# if so do nothing
# if not, generate new keywords

# if conversions were low, but reach was high, generate more specific keywords
# if conversions were high, but reach was low, generate more generic keywords
# if conversions were low, but reach was low, generate new keywords


from app.google_ads_integration.report import GoogleAdsReportIntegration
from app.google_ads_integration.client import GoogleAdsClient
from app.recommendations.keyword_pruning.normalization import calculate_performance_scores, top_keywords_by_reach
from app.llm_services import generate_specific_keywords, generate_generic_keywords


def generate_optimised_keywords(
    client: GoogleAdsClient,
    customer_id: str,
    url: str,
    url_content: str,
    business_description: str,
    ad_group_id: str,
    number_of_keywords: int = 10,
):
    report_integration = GoogleAdsReportIntegration(
        client=client,
        googleads_account_id=customer_id,
    )
    current_keywords = report_integration.ad_group_keyword_performance_by_week(ad_group_id=ad_group_id, weeks=4)
    performance_scores = calculate_performance_scores(current_keywords)
    reach = performance_scores["reach_score"]
    conversions = performance_scores["conversion_score"]
    print("current_keywords")
    print(current_keywords)
    print("performance_scores")
    print(performance_scores)
    print("reach")
    print(reach)
    print("conversions")
    print(conversions)
    if reach > 0.5 and conversions > 0.5:
        return
    elif reach > 0.5 and conversions < 0.5:
        new_keywords = generate_more_specific_keywords(
            client, customer_id, url, url_content, business_description, current_keywords
        )
        old_keywords = top_keywords_by_reach(current_keywords, number_of_keywords)
        keywords = new_keywords + old_keywords
    else:
        new_keywords = generate_more_generic_keywords(
            client, customer_id, url, url_content, business_description, current_keywords
        )

    return keywords[:number_of_keywords]


def generate_more_specific_keywords(
    client: GoogleAdsClient,
    customer_id: str,
    url: str,
    url_content: str,
    business_description: str,
    current_keywords: list[str],
):
    keywords = generate_specific_keywords(url_content, current_keywords)
    return keywords


def generate_more_generic_keywords(
    client: GoogleAdsClient,
    customer_id: str,
    url: str,
    url_content: str,
    business_description: str,
    current_keywords: list[str],
):
    keywords = generate_generic_keywords(url_content, current_keywords)
    return keywords
