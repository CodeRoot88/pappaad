from .new_keywords_generator import NewKeywordsRecommendation

__all__ = [
    "NewKeywordsRecommendation",
]
