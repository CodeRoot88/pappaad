def derive_theme_representation(contextual_info, keywords):
    """
    Construct a prompt to send to an LLM that returns a theme representation.

    Parameters:
    - contextual_info (str): Additional context that helps the LLM understand the domain,
      target audience, marketing goals, or brand tone.
    - keywords (list of str): The set of keywords from which we want to derive a common theme.

    Returns:
    - str: A prompt string suitable for sending to an LLM.
    """
    # Join the keywords into a bullet point list or comma-separated list for clarity
    keyword_list_str = "\n- " + "\n- ".join(keywords)

    # Constructing the LLM prompt
    prompt = f"""
You are an expert marketing strategist with a deep understanding of consumer psychology, brand messaging, and search intent.

Contextual Information:
{contextual_info}

Below is a set of keywords. These keywords are currently being considered as part of a keyword strategy. 
Your task is to examine these keywords and produce a concise, structured theme representation that captures the underlying concept, 
message, or topic that these keywords collectively represent. The theme representation should be a short paragraph or a few bullet points 
that describe the conceptual space these keywords occupy, highlighting the common threads, user intent, and any relevant semantic grouping.

Keywords:
{keyword_list_str}

Please return a single, cohesive 'theme representation' that best fits these keywords within the provided context.
"""

    return prompt


def evaluate_keyword_fitness_to_theme(candidate_keyword, training_keywords, theme_representation):
    """
    Construct a prompt to send to an LLM that evaluates how well a candidate keyword fits a given theme.

    Parameters:
    - candidate_keyword (str): The keyword we want to evaluate.
    - training_keywords (list of str): The original set of 10 keywords used to establish the theme.
    - theme_representation (str): The theme representation derived from those 10 keywords.

    Returns:
    - str: A prompt string suitable for sending to an LLM.
    """
    training_list_str = "\n- " + "\n- ".join(training_keywords)

    prompt = f"""
You are an expert in semantic analysis, marketing strategy, and keyword intent classification.

You have a previously established theme representation derived from the following set of 10 keywords:
{training_list_str}

The theme representation is:
"{theme_representation}"

Now, consider the following candidate keyword:
"{candidate_keyword}"

Your task:
1. Evaluate how closely this candidate keyword aligns with the given theme representation.
2. Consider semantic similarity, user intent, conceptual relevance, and the underlying topic space.
3. Provide a concise explanation describing why you believe the keyword does or does not fit the theme.
4. Assign a "Fitness to Theme" score, where:
   - 0.0 means completely unrelated,
   - 0.5 means moderately related,
   - 1.0 means perfectly aligned.

   Response is 0-1 as a float.

respond with just a float
"""
    return prompt
