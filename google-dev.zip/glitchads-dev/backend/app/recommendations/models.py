from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import ForeignKey, Integer
from sqlmodel import Column, Field, Relationship, SQLModel
from app.campaign.models import Campaign


class ActionLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campaign_id: int | None = Field(
        default=None, sa_column=Column(Integer, ForeignKey("campaign.id", ondelete="CASCADE"))
    )
    campaign: Optional["Campaign"] = Relationship(back_populates="action_logs")
    log: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
