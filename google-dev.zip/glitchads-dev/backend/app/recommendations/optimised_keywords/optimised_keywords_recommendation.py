from app.campaign.models import Campaign, CampaignState
from app.common_state_enums import RecommendationType
from app.keyword.db_ops import add_keyword
from app.recommendations.recommendation_utils import RecommendationGenerator
from app.recommendations.new_keywords.generate_optimised_keywords import generate_optimised_keywords
from app.recommendations.recommendation_utils import (
    create_ad_recommendation,
    create_campaign_recommendation,
    create_keyword_recommendation,
)
from app.google_client_setup import initialize_googleads_client
from app.web_miner.scraper import scrape_url

import logging

logger = logging.getLogger(__name__)


class OptimisedKeywordsRecommendation(RecommendationGenerator):
    def generate_for_campaign(self, campaign: Campaign, ads_per_campaign: int, keywords_per_ad: int):
        if not campaign.user_account or not campaign.googleads_account:
            return

        client = initialize_googleads_client(campaign.user_account.google_refresh_token)
        googleads_account_id = campaign.googleads_account.googleads_account_id

        ad_recommendations = []
        optimised_keywords = []

        for ad in campaign.ads[:ads_per_campaign]:
            try:
                content = scrape_url(ad.url)
                new_keywords = generate_optimised_keywords(
                    client=client,
                    customer_id=googleads_account_id,
                    url=ad.url,
                    url_content=content,
                    business_description=ad.description,
                    ad_group_id=ad.googleads_ad_group_id,
                    number_of_keywords=keywords_per_ad,
                )

                if new_keywords:
                    ad_rec = create_ad_recommendation(
                        self.db,
                        ad.id,
                        f'Optimised keywords recommendation: {", ".join(new_keywords)}',
                        RecommendationType.OPTIMISED_KEYWORD,
                    )

                    keyword_recommendations = []
                    for keyword in new_keywords:
                        new_keyword = add_keyword(ad.id, keyword, self.db)
                        keyword_rec = create_keyword_recommendation(
                            self.db, new_keyword, "", RecommendationType.OPTIMISED_KEYWORD
                        )
                        keyword_recommendations.append(keyword_rec)

                    for kw_rec in keyword_recommendations:
                        kw_rec.ad_recommendation_id = ad_rec.id

                    ad_recommendations.append(ad_rec)
                    optimised_keywords.extend(new_keywords)

            except Exception as e:
                logger.error(f"Error processing ad {ad.id}: {str(e)}")
                continue

        if optimised_keywords:
            campaign_rec = create_campaign_recommendation(
                self.db,
                campaign.id,
                f'Optimised keywords recommendation: {", ".join(optimised_keywords)}',
                RecommendationType.OPTIMISED_KEYWORD,
            )

            for ad_rec in ad_recommendations:
                if ad_rec and campaign_rec.id:
                    ad_rec.campaign_recommendation_id = campaign_rec.id
                    self.db.add(ad_rec)

        self.db.commit()

    def generate(self, num_campaigns_to_process: int, ads_per_campaign: int, keywords_per_ad: int):
        campaigns = (
            self.db.query(Campaign).filter(Campaign.state != CampaignState.DRAFT).limit(num_campaigns_to_process).all()
        )

        for campaign in campaigns:
            self.generate_for_campaign(campaign, ads_per_campaign, keywords_per_ad)
