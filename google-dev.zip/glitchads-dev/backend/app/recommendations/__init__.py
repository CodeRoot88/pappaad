from .underperforming_keywords import UnderperformingKeywordsRecommendation

__all__ = [
    "UnderperformingKeywordsRecommendation",
]
