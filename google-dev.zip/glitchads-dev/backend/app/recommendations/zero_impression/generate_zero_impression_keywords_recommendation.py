import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from google.ads.googleads.client import GoogleAdsClient
from google.ads.googleads.errors import GoogleAdsException
from pydantic import BaseModel
from sqlmodel import Session, select

from app.ad.models import Ad
from app.data import negative_keywords
from app.google_ads.models import GoogleAdsAd, GoogleAdsCampaign
from app.google_client_setup import initialize_googleads_client
from app.keyword.db_ops import add_keywords, remove_keyword_by_id
from app.recommendations.db_ops import add_action_log
from app.recommendations.models import ActionLog
from app.recommendations.new_keywords.generate_new_keywords_recommendation import gen_new_keywords_for_ad
from app.recommendations.underperforming_keywords.underperforming_keywords_helpers import (
    KeywordPerformance,
)
from app.web_miner.scraper import get_url_content

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def delete_zero_impression_keywords(db: Session, ad: Ad, ad_group_keywords: list[KeywordPerformance]) -> list[str]:
    ad_zero_impression_keywords = []

    for keyword in ad.keywords:
        keyword_metrics = next((k for k in ad_group_keywords if k.keyword_text == keyword.text), None)
        if keyword_metrics:
            ad_zero_impression_keywords.append(keyword.text)
            if keyword.id:
                remove_keyword_by_id(keyword.id, db)

    return ad_zero_impression_keywords


def create_new_keywords(
    client: GoogleAdsClient,
    db: Session,
    ad: Ad,
    deleted_keywords_texts: list[str],
    googleads_account_id: str,
    business_desc: str | None = None,
):
    if not ad.id:
        logger.error(f"Ad {ad.id} has no ID, skipping new keyword creation")
        return
    content = get_url_content(ad.url, db).content
    new_keywords = set(
        gen_new_keywords_for_ad(
            client=client,
            googleads_account_id=googleads_account_id,
            url=ad.url,
            content=content,
            business_desc=business_desc or "",
            total_number=len(deleted_keywords_texts) * 2,
        ),
    )
    new_keywords -= set(negative_keywords.generic_negatives())
    new_keywords -= set(deleted_keywords_texts)
    new_keywords = list(new_keywords)
    if len(new_keywords) > len(deleted_keywords_texts):
        new_keywords = new_keywords[: len(deleted_keywords_texts)]

    return add_keywords(ad_id=ad.id, keyword_texts=new_keywords, db=db)


def get_googleads_ads(db: Session, campaign_id: int) -> list[GoogleAdsAd]:
    result = db.exec(select(GoogleAdsAd).join(Ad).where(Ad.campaign_id == campaign_id)).all()
    return list(result)


class ZeroImpressionKeyword(BaseModel):
    ad_group_id: str
    keyword_text: str


def get_zero_impression_keywords(
    client, googleads_account_id, googleads_campaign_id, days=30
) -> list[KeywordPerformance] | None:
    end_date = datetime.now(timezone.utc).date()
    start_date = end_date - timedelta(days=days)

    query = f"""
        SELECT
            ad_group.id,
            ad_group_criterion.keyword.text,
            metrics.clicks,
            metrics.impressions,
            metrics.cost_micros,
            metrics.conversions
        FROM keyword_view
        WHERE
            segments.date BETWEEN '{start_date}' AND '{end_date}'
            AND campaign.id = {googleads_campaign_id}
            AND metrics.impressions = 0
    """

    googleads_service = client.get_service("GoogleAdsService")
    keyword_data = []
    try:
        response = googleads_service.search_stream(customer_id=googleads_account_id, query=query)
        for batch in response:
            for row in batch.results:
                keyword_data.append(
                    ZeroImpressionKeyword(
                        ad_group_id=str(row.ad_group.id),
                        keyword_text=row.ad_group_criterion.keyword.text,
                    )
                )

        return keyword_data

    except GoogleAdsException as ex:
        logger.error(f"Request failed with status {ex.error.code().name}")
        logger.error(f"Failure message: {ex.failure.errors[0].message}")
        return None


def get_zero_impression_keywords_data(
    client: GoogleAdsClient, googleads_campaign: GoogleAdsCampaign, googleads_account_id: str
) -> list[KeywordPerformance] | None:
    try:
        keyword_data = get_zero_impression_keywords(
            client=client,
            googleads_account_id=googleads_account_id,
            googleads_campaign_id=googleads_campaign.googleads_campaign_id,
        )
        if not keyword_data:
            logger.error(f"No keyword data for campaign {googleads_campaign.id}")
            return None
        return keyword_data
    except GoogleAdsException:
        logger.error(f"Failed to retrieve keyword data for campaign {googleads_campaign.id}")
        return None


def gen_campaign_zero_impression_keywords_recommendation(db: Session, googleads_campaign: GoogleAdsCampaign):
    campaign = googleads_campaign.campaign
    if not campaign or not campaign.id:
        logger.error(f"No campaign found for google ads campaign {googleads_campaign.id}")
        return
    googleads_account = campaign.googleads_account
    if not googleads_account:
        logger.error(f"No google ads account found for campaign {campaign.id}")
        return
    user_account = None
    if campaign:
        user_account = campaign.user_account
    if not user_account or not user_account.google_refresh_token:
        logger.error(f"No user account found for campaign {campaign.id}")
        return
    try:
        client = initialize_googleads_client(user_account.google_refresh_token, googleads_account.manager_account_id)
    except Exception as ex:
        logger.error(f"Failed to initialize google ads client for campaign {campaign.id}, error: {ex}")
        return
    zero_impression_keywords = get_zero_impression_keywords_data(
        client, googleads_campaign, googleads_account.googleads_account_id
    )
    if not zero_impression_keywords:
        return
    keyword_data_by_group = defaultdict(list)
    for kw in zero_impression_keywords:
        keyword_data_by_group[str(kw.ad_group_id)].append(kw)

    googleads_ads = get_googleads_ads(db, campaign.id)

    for googleads_ad in googleads_ads:
        ad = googleads_ad.ad
        ad_group_keywords = keyword_data_by_group.get(googleads_ad.googleads_ad_group_id, [])
        deleted_keywords_texts = delete_zero_impression_keywords(db, ad, ad_group_keywords)
        new_keywords = create_new_keywords(
            client, db, ad, deleted_keywords_texts, googleads_account.googleads_account_id
        )
        if not len(deleted_keywords_texts):
            continue
        deleted_keywords_str = ", ".join(deleted_keywords_texts)
        if new_keywords:
            added_keywords_str = ", ".join([new_keyword.text for new_keyword in new_keywords])
        else:
            added_keywords_str = ""
        if added_keywords_str:
            log_message = (
                f"Replaced zero impression keywords: {deleted_keywords_str} "
                f"with new keywords: {added_keywords_str} for Ad  {ad.url} ({ad.slug})"
            )
        else:
            log_message = f"Deleted zero impression keywords: {deleted_keywords_str} for Ad {ad.url} ({ad.slug})"
        add_action_log(ActionLog(campaign_id=campaign.id, log=log_message), db)


def generate_zero_impression_keywords_recommendation(db: Session):
    googleads_campaigns = db.exec(select(GoogleAdsCampaign)).all()
    for googleads_campaign in googleads_campaigns:
        gen_campaign_zero_impression_keywords_recommendation(db, googleads_campaign)
