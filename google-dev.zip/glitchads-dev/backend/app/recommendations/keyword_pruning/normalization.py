import pandas as pd
import numpy as np
from app.google_ads_integration.report import GoogleAdsReportIntegration


def refine_keywords(report: GoogleAdsReportIntegration, new_keywords: list, drop_count=3, base_weights=None):
    """
    Refine the keyword dataset by dropping the worst-performing keywords and adding new ones.

    Parameters:
    - report (GoogleAdsReportIntegration): Initialized report integration with performance data
    - new_keywords (list of dict): New keyword entries to add after pruning worst performers
    - drop_count (int): Number of keywords to drop
    - base_weights (dict): Optional dict of current weights

    Returns:
    - refined_data (pd.DataFrame): The refined dataset with new keywords added
    - new_weights (dict): A dictionary of updated weights for the next iteration
    """
    # Get performance data from report
    performance_data = report.ad_group_keyword_performance_report()

    # Convert performance data to DataFrame - updated to match new report structure
    data = pd.DataFrame(
        [
            {
                "Search keyword": item["keyword"],
                "Ad Group": item["ad_group_name"],
                "Campaign": item["campaign_name"],
                "Match Type": item["match_type"],
                "Impr.": item["impressions"],
                "Clicks": item["clicks"],
                "Conversions": item["conversions"],
                "Cost": item["cost"],
                "CTR": item["ctr"],
                "CVR": item["cvr"],
                "Fitness to Theme": 0.5,  # Default theme fitness
            }
            for item in performance_data
        ]
    )

    # If data is empty, initialize with new keywords only
    if data.empty and new_keywords:
        return pd.DataFrame(new_keywords), base_weights

    # Default weights if none provided
    if base_weights is None:
        base_weights = {"CVR": 0.4, "CTR": 0.2, "Conv": 0.2, "Theme": 0.2}

    # Normalization helper
    def min_max_scale(series):
        if series.max() == series.min():
            return pd.Series([0.5] * len(series), index=series.index)
        return (series - series.min()) / (series.max() - series.min())

    # Normalize metrics
    data["CTR_norm"] = min_max_scale(data["CTR"])
    data["CVR_norm"] = min_max_scale(data["CVR"])
    data["Conv_norm"] = min_max_scale(data["Conversions"])
    data["Theme_norm"] = min_max_scale(data["Fitness to Theme"])

    # Composite Score Calculation
    data["Composite Score"] = (
        data["CVR_norm"] * base_weights["CVR"]
        + data["CTR_norm"] * base_weights["CTR"]
        + data["Conv_norm"] * base_weights["Conv"]
        + data["Theme_norm"] * base_weights["Theme"]
    )

    # Identify worst performers
    worst_keywords = data.nsmallest(drop_count, "Composite Score")["Search keyword"]

    # Remove the worst performers
    refined_data = data[~data["Search keyword"].isin(worst_keywords)].copy()

    # Add the new keywords
    new_keywords_df = pd.DataFrame(new_keywords)
    if not new_keywords_df.empty:
        # Ensure required columns exist
        for col in ["Impr.", "Clicks", "Conversions"]:
            if col not in new_keywords_df.columns:
                new_keywords_df[col] = 0
        if "Fitness to Theme" not in new_keywords_df.columns:
            new_keywords_df["Fitness to Theme"] = 0.5  # default neutral value

        new_keywords_df["CTR"] = new_keywords_df["Clicks"] / new_keywords_df["Impr."].replace(0, np.nan)
        new_keywords_df["CTR"] = new_keywords_df["CTR"].fillna(0)
        new_keywords_df["CVR"] = new_keywords_df["Conversions"] / new_keywords_df["Clicks"].replace(0, np.nan)
        new_keywords_df["CVR"] = new_keywords_df["CVR"].fillna(0)

        # For new keywords, neutral normalizations
        new_keywords_df["CTR_norm"] = 0.5
        new_keywords_df["CVR_norm"] = 0.5
        new_keywords_df["Conv_norm"] = 0.5
        # For Theme, attempt min-max scaling with existing data + new:
        combined_theme = pd.concat(
            [refined_data["Fitness to Theme"], new_keywords_df["Fitness to Theme"]], ignore_index=True
        )
        combined_theme_norm = min_max_scale(combined_theme)
        # Assign the last part of combined_theme_norm (corresponding to new kws) back
        new_keywords_count = len(new_keywords_df)
        new_keywords_df["Theme_norm"] = combined_theme_norm.iloc[-new_keywords_count:]

        new_keywords_df["Composite Score"] = (
            new_keywords_df["CVR_norm"] * base_weights["CVR"]
            + new_keywords_df["CTR_norm"] * base_weights["CTR"]
            + new_keywords_df["Conv_norm"] * base_weights["Conv"]
            + new_keywords_df["Theme_norm"] * base_weights["Theme"]
        )

        refined_data = pd.concat([refined_data, new_keywords_df], ignore_index=True)

    # Drop normalization columns if not needed in the final output
    refined_data.drop(columns=["CTR_norm", "CVR_norm", "Conv_norm", "Theme_norm"], inplace=True, errors="ignore")

    # Dynamically adjust weights for the next iteration
    avg_ctr = refined_data["CTR"].mean()
    avg_cvr = refined_data["CVR"].mean()
    avg_conv = refined_data["Conversions"].mean()
    avg_theme = refined_data["Fitness to Theme"].mean()

    # Copy current weights
    new_weights = base_weights.copy()

    # Adjust weights based on performance heuristics
    if avg_ctr < 0.05:
        new_weights["CTR"] *= 1.1
    if avg_cvr < 0.02:
        new_weights["CVR"] *= 1.1
    if avg_conv < 1:
        new_weights["Conv"] *= 1.1
    if avg_theme < 0.5:
        new_weights["Theme"] *= 1.1

    # Normalize weights
    total_weight = sum(new_weights.values())
    for k in new_weights.keys():
        new_weights[k] = new_weights[k] / total_weight

    return refined_data, new_weights


def calculate_performance_scores(performance_data: list, thresholds: dict = None) -> dict:
    """
    Calculate normalized scores (0-1) for conversions and reach.

    Parameters:
    - performance_data (list): List of dictionaries containing keyword performance data
        Each dict should have 'conversions' and 'impressions' keys
    - thresholds (dict): Optional dictionary containing min/max thresholds for each metric
        Format: {
            'conversions': {'min': 0, 'max': 100},
            'impressions': {'min': 0, 'max': 10000}
        }

    Returns:
    - dict: Normalized scores for each metric between 0 and 1
    """
    # Default thresholds if none provided
    default_thresholds = {
        "conversions": {"min": 1, "max": 100},  # 100 conversions
        "impressions": {"min": 100, "max": 10000},  # 10,000 impressions
    }
    thresholds = thresholds or default_thresholds

    # Convert to DataFrame for easier calculations
    df = pd.DataFrame(performance_data)

    def normalize(series, min_val, max_val):
        """Normalize values where higher is better"""
        # Clip values to thresholds
        series = series.clip(min_val, max_val)
        if max_val == min_val:
            return pd.Series([0.5] * len(series))
        return (series - min_val) / (max_val - min_val)

    # Calculate normalized scores with thresholds
    conversion_score = normalize(
        df["conversions"], thresholds["conversions"]["min"], thresholds["conversions"]["max"]
    ).mean()

    reach_score = normalize(
        df["impressions"], thresholds["impressions"]["min"], thresholds["impressions"]["max"]
    ).mean()

    return {"conversion_score": float(conversion_score), "reach_score": float(reach_score)}


def top_keywords_by_reach(performance_data: list, number_of_keywords: int = 10):
    df = pd.DataFrame(performance_data)
    df = df.sort_values(by="impressions", ascending=False)
    return df["Search keyword"].head(number_of_keywords).tolist()


def top_keywords_by_conversions(performance_data: list, number_of_keywords: int = 10):
    df = pd.DataFrame(performance_data)
    df = df.sort_values(by="conversions", ascending=False)
    return df["Search keyword"].head(number_of_keywords).tolist()
