from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from sqlmodel import Session

from app.google_ads_integration.report import GoogleAdsReportIntegration
from app.llm_services import get_theme_representation, evaluate_keyword_fitness

import pandas as pd


def evaluate_theme_by_ad_id(
    db: Session,
    google_ads_client,
    googleads_account_id: str,
    googleads_ad_group_id: str,
    weeks: int = 6,
) -> Optional[Dict[str, Any]]:
    """
    Evaluate the best theme performance for a given ad over a specified number of weeks.

    Parameters:
    - ad_id: The ID of the ad to analyze
    - db: Database session
    - google_ads_client: Initialized Google Ads client
    - googleads_account_id: Google Ads account ID
    - weeks: Number of weeks of data to analyze (default: 6)

    Returns:
    - Dictionary containing the best performing theme data and metrics
    """
    # Input validation
    if weeks < 1:
        raise ValueError("Number of weeks must be at least 1")

    # # Get the ad group information from our database
    # ad_group = get_googleads_ad_group_by_ad_id(ad_id, db)
    # if not ad_group:
    #     return None

    # Initialize Google Ads report integration
    report_integration = GoogleAdsReportIntegration(
        client=google_ads_client,
        googleads_account_id=googleads_account_id,
    )

    # Get the keyword performance data for specified weeks
    print("googleads_ad_group_id")
    print(googleads_ad_group_id)
    keyword_data = report_integration.ad_group_keyword_performance_by_week(
        ad_group_id=googleads_ad_group_id, weeks=weeks
    )
    # keyword_data = report_integration.ad_group_keyword_performance_by_week(
    #     ad_group_id=ad_group.googleads_ad_group_id, weeks=weeks
    # )
    # Only generate theme fitness if not already present
    if any("theme_fitness" not in kw for kw in keyword_data):
        # Extract keywords for theme evaluation
        keywords = [kw["keyword"] for kw in keyword_data]

        # Get theme representation using LLM
        theme_representation = get_theme_representation("", keywords)  # Empty context for now

        # Add theme fitness scores only for keywords missing it
        for kw in keyword_data:
            if "theme_fitness" not in kw:
                kw["theme_fitness"] = evaluate_keyword_fitness(
                    candidate_keyword=kw["keyword"],
                    training_keywords=keywords,
                    theme_representation=theme_representation,
                )
    else:
        # If all keywords have theme_fitness, use the existing theme representation
        theme_representation = keyword_data[0].get("theme_representation", "")

    # Group data by week
    weeks_data = group_data_by_weeks(keyword_data, weeks)

    if not weeks_data:
        return None

    result = evaluate_theme_performance(weeks_data)
    result["theme_representation"] = theme_representation
    result["keywords"] = keyword_data
    return result


def group_data_by_weeks(keyword_data: List[Dict[str, Any]], weeks: int) -> List[Dict[str, Any]]:
    """
    Group keyword performance data into weekly chunks.

    Parameters:
    - keyword_data: Raw keyword performance data
    - weeks: Number of weeks to group data into

    Returns:
    - List of weekly data dictionaries
    """
    weeks_data = []
    current_date = datetime.now()

    for week_num in range(weeks):
        week_start = current_date - timedelta(days=(week_num + 1) * 7)
        week_end = current_date - timedelta(days=week_num * 7)

        week_keywords = [
            {
                "keyword": kw["keyword"],
                "Impr.": kw["impressions"],
                "Clicks": kw["clicks"],
                "Conversions": kw["conversions"],
                "Fitness to Theme": kw["cvr"],  # Using CVR as a proxy for theme fitness
            }
            for kw in keyword_data
            if week_start.strftime("%Y-%m-%d") <= kw["date"] <= week_end.strftime("%Y-%m-%d")
        ]

        if week_keywords:  # Only add weeks that have data
            weeks_data.append({"week": week_start.strftime("%Y-%m-%d"), "theme": week_keywords})

    return weeks_data


def evaluate_theme_performance(weeks_data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluate theme performance across multiple weeks of data.

    Parameters:
    - weeks_data: List of weekly theme data

    Returns:
    - Dictionary containing best performing theme and metrics
    """
    theme_metrics = []

    # Step 1: Compute aggregated metrics per theme (week)
    for entry in weeks_data:
        week = entry["week"]
        theme_keywords = entry["theme"]

        df = pd.DataFrame(theme_keywords)

        total_impr = df["Impr."].sum()
        total_clicks = df["Clicks"].sum()
        total_conversions = df["Conversions"].sum()
        avg_fitness = df["Fitness to Theme"].mean()

        ctr = total_clicks / total_impr if total_impr > 0 else 0
        cvr = total_conversions / total_clicks if total_clicks > 0 else 0

        theme_metrics.append(
            {"week": week, "CTR": ctr, "CVR": cvr, "Conversions": total_conversions, "Avg Fitness": avg_fitness}
        )

    metrics_df = pd.DataFrame(theme_metrics)

    # Step 2: Normalize metrics using min-max scaling
    def min_max_scale(series):
        if series.max() == series.min():
            return pd.Series([0.5] * len(series), index=series.index)
        return (series - series.min()) / (series.max() - series.min())

    metrics_df["CTR_norm"] = min_max_scale(metrics_df["CTR"])
    metrics_df["CVR_norm"] = min_max_scale(metrics_df["CVR"])
    metrics_df["Conv_norm"] = min_max_scale(metrics_df["Conversions"])
    metrics_df["Fitness_norm"] = min_max_scale(metrics_df["Avg Fitness"])

    # Define weights for composite score
    weights = {"CVR": 0.4, "CTR": 0.2, "Conv": 0.2, "Fitness": 0.2}

    # Compute composite score
    metrics_df["Composite Score"] = (
        metrics_df["CVR_norm"] * weights["CVR"]
        + metrics_df["CTR_norm"] * weights["CTR"]
        + metrics_df["Conv_norm"] * weights["Conv"]
        + metrics_df["Fitness_norm"] * weights["Fitness"]
    )

    # Get best performing week
    best_row = metrics_df.loc[metrics_df["Composite Score"].idxmax()]
    best_week = best_row["week"]

    # Get original theme data for best week
    best_theme_data = next(item for item in weeks_data if item["week"] == best_week)

    return {
        "week": best_week,
        "theme": best_theme_data["theme"],
        "metrics": {
            "CTR": best_row["CTR"],
            "CVR": best_row["CVR"],
            "Conversions": best_row["Conversions"],
            "Avg Fitness": best_row["Avg Fitness"],
            "Composite Score": best_row["Composite Score"],
        },
    }


def evaluate_best_campaign_theme(best_themes_from_adgroups: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluate the best theme across multiple ad groups in a campaign.

    Parameters:
    - best_themes_from_adgroups: List of best themes from different ad groups

    Returns:
    - Dictionary containing the best performing theme at campaign level
    """
    df = pd.DataFrame(best_themes_from_adgroups)

    # Normalize metrics
    def min_max_scale(series):
        if series.max() == series.min():
            return pd.Series([0.5] * len(series), index=series.index)
        return (series - series.min()) / (series.max() - series.min())

    df["CTR_norm"] = min_max_scale(df["CTR"])
    df["CVR_norm"] = min_max_scale(df["CVR"])
    df["Conv_norm"] = min_max_scale(df["Conversions"])
    df["Fitness_norm"] = min_max_scale(df["Avg Fitness"])

    weights = {"CVR": 0.4, "CTR": 0.2, "Conv": 0.2, "Fitness": 0.2}

    df["Composite Score"] = (
        df["CVR_norm"] * weights["CVR"]
        + df["CTR_norm"] * weights["CTR"]
        + df["Conv_norm"] * weights["Conv"]
        + df["Fitness_norm"] * weights["Fitness"]
    )

    best_row = df.loc[df["Composite Score"].idxmax()]

    return {
        "adgroup_id": best_row["adgroup_id"],
        "theme_representation": best_row["theme_representation"],
        "metrics": {
            "CTR": best_row["CTR"],
            "CVR": best_row["CVR"],
            "Conversions": best_row["Conversions"],
            "Avg Fitness": best_row["Avg Fitness"],
            "Composite Score": best_row["Composite Score"],
        },
    }
