import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from app.google_ads.db_ops import get_googleads_campaign_by_campaign_id
from google.ads.googleads.errors import GoogleAdsException
from sqlmodel import Session, select

from app.ad.models import Ad, AdRecommendation
from app.keyword.models import Keyword
from app.campaign.models import Campaign, CampaignState
from app.google_ads.models import GoogleAdsAd

from ...google_client_setup import initialize_googleads_client
from app.recommendations.underperforming_keywords.underperforming_keywords_helpers import (
    KeywordPerformance,
    create_ad_recommendation,
    create_campaign_recommendation,
    create_keyword_recommendation,
    generate_underperforming_keyword_description,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def gen_ad_underperforming_keywords_recommendation(
    db: Session, ad: Ad, ad_group_keywords: list[KeywordPerformance]
) -> tuple[list[Keyword], AdRecommendation | None]:
    ad_underperforming_keywords = []

    for keyword in ad.keywords:
        keyword_metrics = next((k for k in ad_group_keywords if k.keyword_text == keyword.text), None)
        if keyword_metrics:
            create_keyword_recommendation(db, keyword, keyword_metrics)
            ad_underperforming_keywords.append(keyword)

    ad_recommendation = None
    if ad_underperforming_keywords:
        if not ad.id:
            logger.error(f"Ad {ad.id} has no ID, skipping ad recommendation creation")
        else:
            description = generate_underperforming_keyword_description(
                ad_underperforming_keywords, ad_underperforming_keywords
            )
            ad_recommendation = create_ad_recommendation(db, ad.id, description)

    return ad_underperforming_keywords, ad_recommendation


def get_googleads_ads(db: Session, campaign_id: int) -> list[GoogleAdsAd]:
    result = db.exec(select(GoogleAdsAd).join(Ad).where(Ad.campaign_id == campaign_id)).all()
    return list(result)


def get_underperforming_keywords(
    client, googleads_account_id, googleads_campaign_id, limit=5, days=30
) -> list[KeywordPerformance] | None:
    end_date = datetime.now(timezone.utc).date()
    start_date = end_date - timedelta(days=days)

    query = f"""
        SELECT
            ad_group.id,
            ad_group_criterion.keyword.text,
            metrics.clicks,
            metrics.impressions,
            metrics.cost_micros,
            metrics.conversions
        FROM keyword_view
        WHERE
            segments.date BETWEEN '{start_date}' AND '{end_date}'
            AND campaign.id = {googleads_campaign_id}
        ORDER BY metrics.impressions DESC
        LIMIT 1000
    """

    googleads_service = client.get_service("GoogleAdsService")
    keyword_data = []

    try:
        response = googleads_service.search_stream(customer_id=googleads_account_id, query=query)
        for batch in response:
            for row in batch.results:
                keyword_data.append(
                    KeywordPerformance(
                        ad_group_id=row.ad_group.id,
                        keyword_text=row.ad_group_criterion.keyword.text,
                        clicks=row.metrics.clicks,
                        impressions=row.metrics.impressions,
                        cost=row.metrics.cost_micros / 1e6,
                        conversions=row.metrics.conversions,
                    )
                )

        # Filter and sort underperforming keywords
        return sorted(
            [kp for kp in keyword_data if kp.impressions > 0],
            key=lambda x: (x.impressions, -x.clicks),
        )[:limit]

    except GoogleAdsException as ex:
        logger.error(f"Request failed with status {ex.error.code().name}")
        logger.error(f"Failure message: {ex.failure.errors[0].message}")
        return None


def get_underperforming_keywords_data(campaign: Campaign, db: Session) -> list[KeywordPerformance] | None:
    user = campaign.user_account
    if not user:
        raise ValueError("User dose not exist.")
    client = initialize_googleads_client(user.google_refresh_token)

    googleads_campaign = get_googleads_campaign_by_campaign_id(campaign_id=campaign.id, db=db)

    if not googleads_campaign:
        logger.error(f"No google ads campaign found. Glitch Campaign id: {campaign.id}")
        return None

    try:
        if not campaign.googleads_account or not campaign.googleads_account.googleads_account_id:
            raise ValueError("No googleads ads account!")

        keyword_data = get_underperforming_keywords(
            client=client,
            googleads_account_id=campaign.googleads_account.googleads_account_id,
            googleads_campaign_id=googleads_campaign.googleads_campaign_id,
        )
        if not keyword_data:
            return None
        return keyword_data
    except GoogleAdsException:
        logger.error(f"Failed to retrieve keyword data for campaign {campaign.id}")
        return None


def gen_campaign_underperforming_keywords_recommendation(db: Session, campaign: Campaign):
    # this should use CampaignData type so we should not need to check campagin.id
    if not campaign.id:
        logger.error(f"Campaign {campaign.id} has no ID, skipping processing")
        return None

    bad_keyword_data = get_underperforming_keywords_data(campaign, db)
    if not bad_keyword_data:
        return
    keyword_data_by_group = defaultdict(list)
    for kw in bad_keyword_data:
        keyword_data_by_group[str(kw.ad_group_id)].append(kw)

    googleads_ads = get_googleads_ads(db, campaign.id)
    campaign_underperforming_keywords = []
    ad_recommendations = []
    for googleads_ad in googleads_ads:
        ad = googleads_ad.ad
        ad_group_keywords = keyword_data_by_group.get(googleads_ad.googleads_ad_group_id, [])

        ad_underperforming_keywords, ad_recommendation = gen_ad_underperforming_keywords_recommendation(
            db, ad, ad_group_keywords
        )

        campaign_underperforming_keywords.extend(ad_underperforming_keywords)
        if ad_recommendation:
            ad_recommendations.append(ad_recommendation)

    if campaign_underperforming_keywords:
        description = generate_underperforming_keyword_description(campaign_underperforming_keywords, bad_keyword_data)
        campaign_recommendation = create_campaign_recommendation(
            db=db, campaign_id=campaign.id, description=description
        )
        for ad_rec in ad_recommendations:
            ad_rec.campaign_recommendation_id = campaign_recommendation.id

    logger.info(f"Processed campaign {campaign.id}: {len(campaign_underperforming_keywords)} underperforming keywords")


def generate_underperforming_keywords_recommendation(db: Session):
    campaigns = db.exec(select(Campaign).where(Campaign.state != CampaignState.DRAFT)).all()
    for campaign in campaigns:
        gen_campaign_underperforming_keywords_recommendation(db, campaign)
