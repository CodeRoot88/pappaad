from .underperforming_keywords_generator import UnderperformingKeywordsRecommendation

__all__ = [
    "UnderperformingKeywordsRecommendation",
]
