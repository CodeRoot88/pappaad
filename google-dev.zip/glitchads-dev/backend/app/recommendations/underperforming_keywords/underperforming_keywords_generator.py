import logging

from app.recommendations.recommendation_utils import RecommendationGenerator

from app.recommendations.underperforming_keywords.generate_underperforming_keywords_recommendation import (
    generate_underperforming_keywords_recommendation,
)
from app.recommendations.underperforming_keywords.generate_mock_underperforming_keywords_recommendation import (
    generate_mock_underperforming_keywords_recommendation,
)

logger = logging.getLogger(__name__)


class UnderperformingKeywordsRecommendation(RecommendationGenerator):
    def generate(self, **kwargs):
        env = self.env

        if env in ["prod", "staging"]:
            generate_underperforming_keywords_recommendation(self.db)
        else:
            generate_mock_underperforming_keywords_recommendation(self.db, **kwargs)
