from random import randint, sample, uniform

from sqlmodel import Session, select

from app.campaign.models import Campaign

from app.recommendations.underperforming_keywords.underperforming_keywords_helpers import (
    KeywordPerformance,
    create_ad_recommendation,
    create_campaign_recommendation,
    create_keyword_recommendation,
    generate_underperforming_keyword_description,
)


def get_random_keyword_metrics(ad_id: int, text: str) -> KeywordPerformance:
    return KeywordPerformance(
        **{
            "clicks": randint(0, 10),
            "impressions": randint(100, 1000),
            "cost": round(uniform(10, 200), 2),
            "conversions": randint(0, 10),
            "ad_group_id": str(ad_id),
            "keyword_text": text,
        }
    )


def process_ad(db: Session, ad, keywords_per_ad: int):
    ad_underperforming_keywords = []
    keyword_recommendations = []
    keyword_metrics = []
    keywords = sample(ad.keywords, k=min(keywords_per_ad, len(ad.keywords)))

    for keyword in keywords:
        metrics = get_random_keyword_metrics(ad.id, keyword.text)
        keyword_recommendation = create_keyword_recommendation(db, keyword, metrics)
        ad_underperforming_keywords.append(keyword)
        keyword_recommendations.append(keyword_recommendation)
        keyword_metrics.append(metrics)
    if not ad.id:
        raise ValueError("Ad ID is required to create an ad recommendation")

    if ad_underperforming_keywords:
        description = generate_underperforming_keyword_description(ad_underperforming_keywords, keyword_metrics)
        ad_recommendation = create_ad_recommendation(db, ad.id, description)
        for kw_rec in keyword_recommendations:
            kw_rec.ad_recommendation_id = ad_recommendation.id
        return ad_recommendation, ad_underperforming_keywords, keyword_metrics
    return None, [], []


def process_campaign(db: Session, campaign: Campaign, ads_per_campaign: int, keywords_per_ad: int):
    campaign_underperforming_ads = []
    campaign_underperforming_keywords = []
    underperforming_keywords_metrics = []
    ads = sample(campaign.ads, min(ads_per_campaign, len(campaign.ads)))

    for ad in ads:
        ad_recommendation, ad_underperforming_keywords, keyword_metrics = process_ad(db, ad, keywords_per_ad)
        if ad_recommendation:
            campaign_underperforming_ads.append(ad_recommendation)
            campaign_underperforming_keywords.extend(ad_underperforming_keywords)
            underperforming_keywords_metrics.extend(keyword_metrics)
    if campaign_underperforming_ads:
        if not campaign.id:
            raise ValueError("Campaign ID is required to create a campaign recommendation")
        description = generate_underperforming_keyword_description(
            campaign_underperforming_keywords, underperforming_keywords_metrics
        )
        campaign_recommendation = create_campaign_recommendation(
            db=db, campaign_id=campaign.id, description=description
        )

        for ad_rec in campaign_underperforming_ads:
            ad_rec.campaign_recommendation_id = campaign_recommendation.id
    db.commit()


def generate_mock_underperforming_keywords_recommendation(
    db: Session, num_campaigns_to_process: int = 5, ads_per_campaign: int = 2, keywords_per_ad: int = 3
):
    campaigns = db.exec(select(Campaign).limit(num_campaigns_to_process)).all()
    for campaign in campaigns:
        process_campaign(db, campaign, ads_per_campaign, keywords_per_ad)
