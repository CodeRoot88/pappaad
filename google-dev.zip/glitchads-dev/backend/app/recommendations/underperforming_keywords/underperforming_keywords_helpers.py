import logging
from datetime import datetime, timezone

from dotenv import load_dotenv
from pydantic import BaseModel
from sqlmodel import Session

from app.ad.models import AdRecommendation
from app.keyword.models import Keyword, KeywordRecommendation
from app.campaign.models import CampaignRecommendation
from app.common_state_enums import RecommendationSeverity, RecommendationState, RecommendationType

_ = load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


class KeywordPerformance(BaseModel):
    ad_group_id: str
    keyword_text: str
    clicks: int
    impressions: int
    cost: float
    conversions: float


def concatenate_keywords(keywords: list[Keyword]) -> str:
    return ", ".join([keyword.text for keyword in keywords])


def generate_underperforming_keyword_description(
    keywords: list[Keyword], keyword_metrics: list[KeywordPerformance]
) -> str:
    underperforming = []
    zero_clicks = []

    for keyword in keywords:
        metric = next((m for m in keyword_metrics if m.keyword_text == keyword.text), None)
        if metric:
            if metric.clicks == 0:
                zero_clicks.append(keyword)
            elif calculate_severity(metric) == RecommendationSeverity.FIX:
                underperforming.append(keyword)

    description = ""
    if underperforming:
        description += f"Keywords like {concatenate_keywords(underperforming)} are underperforming due to low conversions and high costs per click. "
    if zero_clicks:
        description += f"Additionally, terms like {concatenate_keywords(zero_clicks)} are generating impressions but receiving zero clicks, indicating poor relevance and targeting issues."

    return description if description else "No significant performance issues detected for the current keywords."


def calculate_severity(metrics: KeywordPerformance) -> RecommendationSeverity:
    """Demonstrate we can change the severity based on actual metrics"""
    ctr = metrics.clicks / metrics.impressions if metrics.impressions > 0 else 0
    cpc = metrics.cost / metrics.clicks if metrics.clicks > 0 else 0

    if ctr < 0.01 or cpc > 2:
        return RecommendationSeverity.FIX
    elif ctr < 0.05 or cpc > 1:
        return RecommendationSeverity.FIX
    else:
        return RecommendationSeverity.FIX


def create_keyword_recommendation(db: Session, keyword: Keyword, metrics: KeywordPerformance) -> KeywordRecommendation:
    severity = calculate_severity(metrics)

    if not keyword.id:
        logger.error(f"Keyword {keyword.id} has no ID, skipping recommendation creation")
        raise ValueError("Keyword has no ID")
    keyword_recommendation = KeywordRecommendation(
        keyword_id=keyword.id,
        title="Underperforming Keyword",
        severity=severity,
        description=f"{keyword.text}: clicks {metrics.clicks}, impressions {metrics.impressions}, cost ${metrics.cost:.2f}, conversions {metrics.conversions}",
        state=RecommendationState.PENDING,
        recommendation_type=RecommendationType.UNDERPERFORMING_KEYWORD,
        created_at=datetime.now(timezone.utc),
    )
    db.add(keyword_recommendation)
    db.commit()
    db.refresh(keyword_recommendation)
    return keyword_recommendation


def create_ad_recommendation(db: Session, ad_id: int, description: str) -> AdRecommendation:
    ad_recommendation = AdRecommendation(
        ad_id=ad_id,
        title="Underperforming Keywords in Ad",
        severity=RecommendationSeverity.FIX,
        description=description,
        state=RecommendationState.PENDING,
        recommendation_type=RecommendationType.UNDERPERFORMING_KEYWORD,
        created_at=datetime.now(timezone.utc),
    )
    db.add(ad_recommendation)
    db.commit()
    db.refresh(ad_recommendation)
    return ad_recommendation


def create_campaign_recommendation(db: Session, campaign_id: int, description: str) -> CampaignRecommendation:
    campaign_recommendation = CampaignRecommendation(
        campaign_id=campaign_id,
        title="Campaign Performance Issues",
        severity=RecommendationSeverity.FIX,
        description=description,
        state=RecommendationState.PENDING,
        recommendation_type=RecommendationType.UNDERPERFORMING_KEYWORD,
        created_at=datetime.now(timezone.utc),
    )
    db.add(campaign_recommendation)
    db.commit()
    db.refresh(campaign_recommendation)
    return campaign_recommendation
