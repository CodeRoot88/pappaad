from sqlmodel import Session

from app.campaign.models import CampaignData
from app.recommendations.db_ops import get_action_logs_by_campaign_id
from app.recommendations.models import ActionLog
from app.recommendations.zero_impression.generate_zero_impression_keywords_recommendation import (
    gen_campaign_zero_impression_keywords_recommendation,
)


def get_campaign_action_logs(campaign: CampaignData, db: Session) -> list[ActionLog]:
    if campaign.googleads_campaign is None:
        return []
    return get_action_logs_by_campaign_id(campaign.id, db)


def run_zero_impression_optimisation(campaign: CampaignData, db: Session):
    if campaign.googleads_campaign is None:
        raise Exception("Campaign has no Google Ads campaign")
    return gen_campaign_zero_impression_keywords_recommendation(db, campaign.googleads_campaign)
