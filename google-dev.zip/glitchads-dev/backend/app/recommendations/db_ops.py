from sqlmodel import Session, select

from app.recommendations.models import ActionLog


def add_action_log(action_log: ActionLog, db: Session) -> ActionLog:
    db.add(action_log)
    db.commit()
    db.refresh(action_log)
    return action_log


def get_action_logs_by_campaign_id(campaign_id: int, db: Session) -> list[ActionLog]:
    return list(db.exec(select(ActionLog).where(ActionLog.campaign_id == campaign_id)).all())
