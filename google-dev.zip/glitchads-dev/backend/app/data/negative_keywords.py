def generic_negatives():
    return """2nd hand
abbreviations
about
accident
act
act of
acts
adopt
advice
advisory
agencies
agency
airfare
airline
airlines
airplane
airplanes
ajax
ale
alibaba
alone
amtrak
and garden
animal
animals
anime
answer
antique
antiques
apartment
apartments
app
apple
apps
architecture
architecture
arena
army
article
articles
assasin
assembly
association
associations
attorney
auction
auctions
auto
automobile
Automotive Industry
autos
avis
bad review
bank
bargain
bargains
beat
blog
blogs
blowout
blues
boat
boats
bono
book
books
brothel
build
builders
bulletin
bulletins
burn
burn
burner
burner
bus
c++
calculator
canada
car
career
careers
cars
case studies
case study
casual encounters
cat
catholic
cats
cd
CEO
certification
certifications
channel
charity
chart
cheap
cheap
cheapest
chicks
chop
christian
civil suit
class
classes
classic
classical
classifieds
cleaning
clearance
clip art
close out
close out
close outs
closeout
closeouts
club
clubs
cnn
code
collectible
collectibles
college
colleges
community
community
comparison
comparisons
compliance
computer
computers
condo
conference
conferences
consigement
consignment
conspiracy
construction
consultants
consulting
consumer
contest
contractor
controls
copyright
council
councils
county court
coupon
coupon code
coupon discount
coupons
course
courses
courts
crack
craft
crafts
craiglist
craigslist
crash
crashes
create
create
creating
curriculum vitae
custom
customer
customized
CV
data
dating
dbase
deal
deals
death
decor
decorating
define
definition
degree
delphi
department
dept
derby
design
designer
desktop
desktop
developer
developers
diagnose
diagram
dictionary
dimensions
direct hire
direct placement
directions
discount
discount code
discount codes
discounted
discounts
disk
disk
disney
diy
do it yourself
do it yourselfer
do-it-yourself
document
documentary
documents
dog
dogs
doll
download
downloads
drawing
drawings
drop shipping
dvd
ebay
education
employer
employers
employment
enterprise
Entertainment
episode
episodes
error
error code
exam
example
examples
exams
excel
exe
expensive
expo
export
exporter
exporters
facebook
fake
FAQ
festival
file
filemaker
files
film
films
finance
financial
financial aid
Financial Services
firm
firms
flash
flight
flights
for dummies
for rent
forum
forums
foundations
founder
fox
franchise
fraud
free
free sample
freelance
freelancer
freelancers
freelancing
freeware
full
full time
full-time
fumigation
fundraiser
furnishings
furniture
gamble
gambling
game
games
garages
glass
gnu
goods
government
grant
graphic
graphics
grind
guide
guides
hack
hacks
half off
half price
half priced
hand crafted
hand made
handmade
haunted
head hunter
health care
Healthcare
help
hertz
high end
hire
hiring
history
hobbies
hobby
home
home depot
homemade
homes
how
how are
how can
how can I
how do
how do I
how does
how is
how to
how-to
human resources
ice
icon
icons
ideas
ikea
illegal
illustration
illustrations
image
images
import
importer
importers
improvement
income
independent contractors
inexpensive
info
information
infringement
inspection
institute
institutes
instruction
instruction guide
instructions
instructor
instructors
insurance
interiors
intern
internet special
interns
internship
internships
investigate
irs
itunes
j-peg
j-pegs
jackpot
java
job
job opening
job openings
jobs
journal
journals
jpeg
jpegs
jpg
jpg's
key gen
kill
kinky
kmart
knock off
laptop
laptops
law
law firm
laws
lawsuit
lawyer
lawyers
layout
layouts
learn about
legal
legislation
libraries
library
license
like new
linux
liquidation
loan
loans
logo
logos
looking for work
lottery
lotto
low cost
low price
lowest cost
lowest price
luxurious
luxury
lyric
lyrics
mac
macintosh
made in china
magazine
magazines
make
makeover
making
management
manual
manuals
map
maps
mdb
meaning
meaning of
measurement
mechanic
mega millions
metrics
microsoft
military
model
models
moisture
mold
mortgage
movie
movies
mp3
msnbc
mtv
murder
music
music video
myspace
mysql
naked
national
negative review
new hires
news
newsletter
newsletters
newspaper
newspapers
non profit
nude
nursing
occupation
occupations
odd lots
ok google
okay google
online special
open source
opening
openings
opinion
opinions
opportunities
opportunity
oprah
os x
osx
outback
outlet
outlets
overstock
paralegal
paralegals
parking
part time
part-time
parts
party
password
pdf
pdfs
personals
pet
pets
photo
photograph
photographs
photos
php
pics
picture
pictures
pixar
plan
plane
plans
plants
play
police
porn
porno
position
positions
powerball
price
prices
pricing
program
programs
project
promo code
promo codes
promotional code
promotional codes
public domain
question
quiz
quote
quotes
rating
real estate
rebate
rebates
recall
recalled
recipe
recruiter
recruiters
recruiting
recruitment
refi
refinance
refinancing
refurbished
regarding
registration
regulation
regulations
remainder
remainders
remedies
remodeling
rent
rental
rentals
renting
repair
Repairer
repairs
replace
replacement
repo
report
reports
repossessed
repossession
resale
research
reset
resource
resources
resume
resumes
retail
retailer
retailers
review
reviews
ringtone
ringtones
rip
ripped
road
rules
safety
salaries
salary
sale
sales
sample
sample
samples
saying
scam
scams
scandal
schema
school
schooling
schools
seat cover
second hand
security
seized
Selling Real Estate
semester
seminar
seminars
send
sending
seond hand
seond-hand
serial code
serial number
server
service
services
setup
sex
sexy
shareware
sheet
shoe
shoes
shopping network
short cut
short cuts
shortcut
shortcuts
show
showroom
shows
sisterhood
sketch
sketches
soft ware
software
source
speaker
specifications
specs
speed
speeding
spreadsheet
sql
staffing
standards
starbucks
start up
start-up
start-ups
startup
statistics
stats
steak
step by step
stock
stocks
store
strategies
strategy
student
students
sublease
success stories
success story
sued
support
surplus
target
teacher
teachers
Technology Commerce
television
temp
template
templates
temporary
term
terminology
terms
test
textbook
textbooks
theater
themes
theories
theory
thrift
thrifty
ticket
tip
tips
torrent
torrents
tours
toy
toys
trademark
traffic
trail
trailer
train
training
Travel
traveling
tree
troubleshoot
troubleshooting
tutor
tutorial
tutorials
tutors
tv
Universal
universities
university
unix
used
user manual
utube
values
vb
vehicle
vehicles
versus
video
videos
vintage
violence
violent
visual basic
vs
waffle
walmart
warehouse
warehouses
warez
warped tour
warranties
warranty
wash
watch
watches
wayfair
weather
what are
what i
what is
white
white paper
white papers
wholesale
wholesales
wiki
wikipedia
windows
windows 10
windows 2000
windows 7
windows 8
windows 8.1
windows xp
won't
wordpress
work
workshop
workshops
x-rated
xls
xml
xsl
xxx
you tube
youtube""".split("\n")
