import emoji


# https://stackoverflow.com/questions/51217909/removing-all-emojis-from-text
def validate_no_emojis(value: str) -> str:
    if emoji.replace_emoji(value, "") != value:
        raise ValueError("Emojis are not allowed in this field")
    return value
