set -xeu

# Load environment variables from the .env file
if [ -f .env ]; then
  while IFS= read -r line; do
    if [[ ! "$line" =~ ^# && -n "$line" ]]; then
      export "$line"
    fi
  done < .env
else
  echo ".env file not found!"
  exit 1
fi

# Use the environment variables for the database name and port
DB_NAME=${DB_NAME:-glitchads}
DB_PORT=${DB_PORT:-5432}
DB_HOST=${DB_HOST:-localhost}
DB_USER=${DB_USER:-postgres}
DB_PASSWORD=${DB_PASSWORD:-}

export PGPASSWORD=$DB_PASSWORD

# Drop the existing database
dropdb -h $DB_HOST -p $DB_PORT -U $DB_USER $DB_NAME || true

# Create a new database
createdb -h $DB_HOST -p $DB_PORT -U $DB_USER $DB_NAME

# Run the Python script to set up the database schema
source .venv/bin/activate
alembic upgrade head

# Set the directory containing the CSV file and the SQL script
CSV_DIR="app"
CSV_FILE="geotargets-2024-09-26.csv"
SQL_SCRIPT="geoloader.sql"

# Generate the full path for the CSV file
CSV_FILE_PATH="$(pwd)/$CSV_DIR/$CSV_FILE"

# Check if the CSV file exists
if [ ! -f "$CSV_FILE_PATH" ]; then
  echo "CSV file not found: $CSV_FILE_PATH"
  exit 1
fi

# Print the current directory and list files for debugging
echo "Current directory: $(pwd)"

# Execute the SQL script
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -v csv_file=$CSV_FILE_PATH -f $CSV_DIR/$SQL_SCRIPT

echo "Database reset and data loaded successfully."
  echo "CSV file not found: $CSV_FILE_PATH"
  exit 1
fi

# Print the current directory and list files for debugging
echo "Current directory: $(pwd)"

# Execute the SQL script
psql -p $DB_PORT -d $DB_NAME -v csv_file=$CSV_FILE_PATH -f $CSV_DIR/$SQL_SCRIPT

echo "Database reset and data loaded successfully."