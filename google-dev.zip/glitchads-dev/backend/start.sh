#!/bin/bash

set -eu

uv sync
uv run pre-commit install

echo "Running Alembic migrations..."

uv run alembic upgrade head

echo "Starting FastAPI development server..."
uv run fastapi dev app/main.py
