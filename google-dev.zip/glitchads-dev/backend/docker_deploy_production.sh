#!/bin/bash

# Exit the script if any command fails
set -e

# Step 1: Build the Docker image without cache
echo "Building the production Docker image..."
docker buildx build --platform linux/amd64 --no-cache -t glitchads-prod .

# Step 2: Tag the Docker image
echo "Tagging the production Docker image..."
docker tag glitchads-prod:latest europe-west4-docker.pkg.dev/gltichv2/glitch/glitchads-prod:latest

# Step 3: Push the Docker image to the registry
echo "Pushing the production Docker image..."
docker push europe-west4-docker.pkg.dev/gltichv2/glitch/glitchads-prod:latest

echo "Production Docker image deployed successfully!"
