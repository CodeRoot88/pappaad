# Glitch Ads Backend

## Pyproject.toml

* Python version
Chose 3.12 and above, so we are starting at a latest version of python, make it easier
to upgrade in the future.

* Using [uv](https://github.com/astral-sh/uv)

The new python package management tool. From the author who created the ruff, a super
fast linter. We will discuss it later. Python world has too many package management
tools. UV is one of the better ones. It's written in Rust, and it's fast. But it's also
using more compatible with pip. It's built on top of pip-tools which is a popular
tool. Poetry is another popular alternative, but it has its own standards which is not
as same as the python pip one, may not be for the future.

* `main.py` is for api endpoints
* We use pydantic and fastapi
* `db_ops.py` is for database only operations
* `services.py` is for business logic
* `models.py` is for all data models configured using sqlmodel

## Local dev env set up

* Setup Virtual env and install dependencies
```
./start.sh
```

* Create a postgresql DB

```
# This is an example, you can create db in any name you want
createdb glitchads
```

* Copy `.env.example` -> `.env` and update the postgresql url


* Create db schema via SqlModel (SqlAlchemy) and import geo targets

```
cd backend
chmod +x resetdb.sh
./resetdb.sh
```

* run dev server

```
./start.sh
```


## Campaign slug and primary key

Need to generate a slug like key for Campaign object.
We should use bigint as primary key for our db. UUID is not good idea for DB primary key.
There are many reasons for it. I will not list them all here.
I came across [ULID](https://github.com/ulid/spec) and [Nano
ID](https://github.com/ai/nanoid)
UlID is cool if we want to use it as primary key but I think big int is easier. Unless you need db sharding, which I don't think we do.
But for slug, I think it's a bit too long. So I opted with NanoID(10) to generate a 10
char slug.

## Deployment

### Staging

* Push the docker image to google cloud artifact repo
```
gcloud auth login

./docker_deploy_staging.sh
```

* when there are migrations to be run, you need do download `cloud-sql-proxy` [here](https://cloud.google.com/sql/docs/mysql/sql-proxy).
Then run

```
./cloud-sql-proxy --port 5433 gltichv2:europe-west4:glitchads-staging

 psql -h 127.0.0.1 -p 5433 -U postgres -d glitchads
```
If you can log in to the PostgreSQL shell, it means the proxy is set up correctly. Sometimes you need to run a Google Cloud auth command, which is slightly different from the one used for Docker push.

```
gcloud auth application-default login
```

Once you can access she postgres shell via proxy. You can run the alembic migrations.
First, you need to change your `.env` file

```
DB_NAME=glitchads
DB_PORT=5433
DATABASE_URL=postgresql+psycopg://postgres:password@localhost:${DB_PORT}/${DB_NAME}
```

Then you can run
```
source .venv/bin/activate
alembic upgrade head

```

The following is done in the google cloud web console.
* Log onto google cloud web console
* Choose glitchv2 project
* Go to cloud run service
* Choose `glitchads-staging`
* Click `EDIT AND DEPLOY NEW REVISION`
* Click `Select` for the `Container image URL`
* Expand `europe-west4-docker.pkg.dev/gltichv2/glitch`
* Expand `glitchads-staging`
* Select the latest image, this should be the one you just uploaded.
* Click deploy on the bottom left

### Production


The following is done in the google cloud web console.
* Log onto google cloud web console
* Choose glitchv2 project
* Go to cloud run service
* Choose `glitchads-prod`
* Click `EDIT AND DEPLOY NEW REVISION`
* Click `Select` for the `Container image URL`
* Expand `europe-west4-docker.pkg.dev/gltichv2/glitch`
* Expand `glitchads-prod`
* Select the latest image, this should be the one you just uploaded.
* Click deploy on the bottom left
