# Glitch Ads

Refer to README.md files in the frontend and backend folder.
